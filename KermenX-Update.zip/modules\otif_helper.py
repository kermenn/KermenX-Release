"""
Module: otif_helper.py
Tools: KERMEN TOOLS - OTIF TOOLS
Deskripsi:
Pengolahan data Work Order & Part On-Time In-Full (OTIF) SAP secara otomatis:
1. Ekstraksi Manufacture part (CAT vs NON CAT) dari Material Description.
2. Klasifikasi Work Order (Order): CAT ONLY, MIX PART, NON CAT ONLY.
3. Fokus & Pembagi Persentase: Khusus Work Order CAT ONLY dengan Purchasing Group 3VH.
   (MIX PART dan NON CAT tidak ditampilkan performancenya).
4. Evaluasi OTIF Status (100% SAP Benchmark):
   - Not Complete: Jika Initial Otif Date kosong.
   - Complete OTIF: Jika Actual Released == Initial Otif OR Initial Otif <= Planned Start Date.
   - Complete Not OTIF: Lainnya.
5. Simulasi Fleksibel OTIF (Simulasi H-1 hari):
   - Complete OTIF: Jika Actual Released == Initial Otif OR (Initial Otif - delta_days) <= Planned Start Date.
6. Menghasilkan Workbook Excel komprehensif:
   - Sheet 'Summary': 4 KPI Cards, Tabel Benchmark 100% SAP vs Simulasi H-1, & Matriks Perbandingan (CAT ONLY 3VH).
   - Sheet 'WO Analysis': 1.300 Work Order CAT ONLY (3VH) dengan detail status dan efek perbaikan (Improved to OTIF).
   - Sheet 'RAW': Seluruh 8.445 data transaksi lengkap dengan kolom Manuf, WO Parts Status, & Status OTIF.
"""
import os
import re
import time
import datetime
import config
import pandas as pd

import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
from python_calamine import CalamineWorkbook


MONTH_NAMES_MAP = [
    (1, "Januari", "Jan"),
    (2, "Februari", "Feb"),
    (3, "Maret", "Mar"),
    (4, "April", "Apr"),
    (5, "Mei", "Mei"),
    (6, "Juni", "Jun"),
    (7, "Juli", "Jul"),
    (8, "Agustus", "Ags"),
    (9, "September", "Sep"),
    (10, "Oktober", "Okt"),
    (11, "November", "Nov"),
    (12, "Desember", "Des")
]
MONTH_NAME_DICT = {num: (name_id, name_en) for num, name_id, name_en in MONTH_NAMES_MAP}


def to_excel_date(val):
    """
    Mengonversi berbagai format tanggal (string, timestamp, date) menjadi objek datetime.date
    agar ditulis sebagai True Excel Date dengan format DD/MM/YYYY.
    """
    if val is None or pd.isna(val) or str(val).strip() in ("", "nan", "None", "NaT"):
        return None
    if isinstance(val, datetime.date) and not isinstance(val, datetime.datetime):
        return val
    if isinstance(val, (datetime.datetime, pd.Timestamp)):
        return val.date()
    try:
        dt = pd.to_datetime(val, errors='coerce', dayfirst=True)
        if pd.notna(dt):
            return dt.date()
    except Exception:
        pass
    return None


def load_mb51_issued_pivot(mb51_file_path, log=print):
    """
    Membaca sheet MB51 dari file RAW DATA (.xlsb / .xlsx) secara cepat menggunakan Calamine.
    Memfilter Movement type 261, mengelompokkan berdasarkan Order + Material,
    dan menjumlahkan kolom 'Qty in unit of entry' (nilai absolut).
    Mengembalikan dict: {(order_key, mat_key): issued_qty} dan flag sukses bool.
    """
    if not mb51_file_path or not os.path.exists(mb51_file_path):
        return {}, False

    try:
        log(f"Membaca data MB51 dari: {os.path.basename(mb51_file_path)}...")
        wb = CalamineWorkbook.from_path(mb51_file_path)
        sheet_target = None
        for s in wb.sheet_names:
            if s.upper() == 'MB51':
                sheet_target = s
                break
        if not sheet_target:
            log(f"Peringatan: Sheet 'MB51' tidak ditemukan di {os.path.basename(mb51_file_path)}.")
            return {}, False

        rows = wb.get_sheet_by_name(sheet_target).to_python()
        if not rows or len(rows) < 2:
            return {}, False

        headers = [str(h).strip() for h in rows[0]]
        col_mvt = next((i for i, h in enumerate(headers) if 'MOVEMENT' in h.upper() and 'TYPE' in h.upper() and 'TEXT' not in h.upper()), None)
        col_order = next((i for i, h in enumerate(headers) if h.upper() == 'ORDER'), None)
        col_mat = next((i for i, h in enumerate(headers) if h.upper() == 'MATERIAL'), None)
        col_qty = next((i for i, h in enumerate(headers) if 'QTY' in h.upper() and 'ENTRY' in h.upper()), None)
        if col_qty is None:
            col_qty = next((i for i, h in enumerate(headers) if 'QTY' in h.upper() or 'QUANTITY' in h.upper()), None)

        if col_mvt is None or col_order is None or col_mat is None or col_qty is None:
            log(f"Peringatan: Kolom wajib di sheet MB51 tidak lengkap.")
            return {}, False

        pivot = {}
        row_count = 0
        for r in rows[1:]:
            if len(r) <= max(col_mvt, col_order, col_mat, col_qty):
                continue
            mvt_raw = str(r[col_mvt]).split('.')[0].strip()
            if mvt_raw != '261':
                continue

            order_raw = str(r[col_order]).split('.')[0].strip().lstrip('0')
            mat_raw = str(r[col_mat]).strip().lstrip('0')
            if not order_raw or not mat_raw or order_raw in ('nan', 'None') or mat_raw in ('nan', 'None'):
                continue

            try:
                qty_raw = abs(float(r[col_qty]))
            except (ValueError, TypeError):
                qty_raw = 0.0

            key = (order_raw, mat_raw)
            pivot[key] = pivot.get(key, 0.0) + qty_raw
            row_count += 1

        log(f"MB51: Sukses mengakumulasi {len(pivot):,} part unik dari {row_count:,} baris Movement 261.")
        return pivot, True
    except Exception as e:
        log(f"Peringatan: Gagal membaca sheet MB51 ({str(e)}). Melanjutkan tanpa data issued.")
        return {}, False


def parse_date_filter_param(val):
    """
    Mengonversi input string tanggal menjadi pd.Timestamp (normalized).
    Mendukung format: YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, YYYY/MM/DD, dsb.
    """
    if val is None or (isinstance(val, str) and not val.strip()):
        return None
    if isinstance(val, (pd.Timestamp, pd.DatetimeIndex)):
        return val.normalize()
    if isinstance(val, (datetime.date, datetime.datetime)):
        return pd.Timestamp(val).normalize()

    val_str = str(val).strip()
    formats = [
        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y",
        "%Y/%m/%d", "%d.%m.%Y", "%m/%d/%Y"
    ]
    for fmt in formats:
        try:
            return pd.to_datetime(datetime.datetime.strptime(val_str, fmt)).normalize()
        except Exception:
            pass
    try:
        return pd.to_datetime(val_str, dayfirst=True).normalize()
    except Exception:
        raise ValueError(f"Format tanggal tidak dikenali: '{val_str}'. Gunakan format YYYY-MM-DD atau DD/MM/YYYY.")


def detect_otif_dates_summary(input_file_path):
    """
    Mendeteksi rentang tanggal Planned Start Date dari file Excel secara cepat (menggunakan engine calamine jika tersedia).
    Mengembalikan dict berisi min_date, max_date, default_year, default_month, available_months.
    """
    if not input_file_path or not os.path.exists(input_file_path):
        return None
    try:
        file_ext = os.path.splitext(input_file_path)[1].lower()
        if file_ext == '.xlsb':
            df_dt = pd.read_excel(input_file_path, engine='calamine', usecols=['Planned Start Date'])
        else:
            try:
                df_dt = pd.read_excel(input_file_path, engine='calamine', usecols=['Planned Start Date'])
            except Exception:
                df_dt = pd.read_excel(input_file_path, usecols=['Planned Start Date'])

        dt = pd.to_datetime(df_dt['Planned Start Date'], errors='coerce').dropna()
        if dt.empty:
            return None

        min_dt = dt.min()
        max_dt = dt.max()
        mode_month = int(dt.dt.month.mode()[0]) if not dt.dt.month.mode().empty else min_dt.month
        mode_year = int(dt.dt.year.mode()[0]) if not dt.dt.year.mode().empty else min_dt.year

        unique_periods = dt.dt.to_period('M').unique()
        available_months = sorted([f"{p.year}-{p.month:02d}" for p in unique_periods])

        return {
            'min_date': min_dt.strftime('%Y-%m-%d'),
            'max_date': max_dt.strftime('%Y-%m-%d'),
            'default_month': mode_month,
            'default_year': mode_year,
            'available_months': available_months
        }
    except Exception:
        return None


def find_matching_otif_file(reference_dir=None):
    """
    Mencari file raw data OTIF secara otomatis di direktori Desktop, Downloads, atau folder terkait.
    Memprioritaskan file dengan kata kunci 'Raw data OTIF' atau 'Simulasi OTIF' yang paling baru.
    Mengabaikan file hasil proses sebelumnya (*PROCESSED* / *SUMMARY*).
    """
    search_dirs = []
    if reference_dir and os.path.exists(reference_dir):
        search_dirs.append(reference_dir)

    desktop_paths = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        r"C:\Users\yusril.i.wafir\Desktop"
    ]
    download_paths = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"C:\Users\yusril.i.wafir\Downloads"
    ]

    for p in desktop_paths + download_paths:
        if os.path.exists(p) and p not in search_dirs:
            search_dirs.append(p)

    candidates = []
    for d in search_dirs:
        try:
            for fname in os.listdir(d):
                if fname.startswith("~$") or "processed" in fname.lower() or "summary" in fname.lower() or "report monthly" in fname.lower() or "report" in fname.lower():
                    continue
                lower = fname.lower()
                if lower.endswith((".xlsx", ".xlsb", ".xls")):
                    score = 0
                    if "raw data otif" in lower:
                        score = 40
                    elif "simulasi otif" in lower:
                        score = 30
                    elif "master otif" in lower:
                        score = 20
                    elif "otif" in lower:
                        score = 10

                    if score > 0:
                        fpath = os.path.join(d, fname)
                        try:
                            mtime = os.path.getmtime(fpath)
                            candidates.append((score, mtime, fpath))
                        except Exception:
                            pass
        except Exception:
            continue

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return candidates[0][2]


def extract_part_manuf(desc):
    """
    Ekstraksi Manuf (CAT vs NON CAT) dari Material Description.
    Format Material Description umumnya: 'ITEM;PART_NO;BRAND'
    Jika bagian akhir mengandung 'CAT' atau 'CATERPILLAR', maka 'CAT', selain itu 'NON CAT'.
    """
    raw = str(desc).strip()
    if not raw or raw.lower() == 'nan':
        return 'NON CAT'
    parts = [p.strip() for p in raw.split(';') if p.strip()]
    if len(parts) >= 2:
        last = parts[-1].upper()
        if 'CAT' in last or 'CATERPILLAR' in last:
            return 'CAT'
    return 'NON CAT'


def classify_work_orders(df):
    """
    Mengelompokkan tipe suku cadang per Work Order:
    - CAT ONLY: Jika WO hanya memiliki komponen CAT
    - NON CAT ONLY: Jika WO hanya memiliki komponen NON CAT
    - MIX PART: Jika WO memiliki komponen CAT dan NON CAT
    """
    grouped = df.groupby(['Order', 'Manuf']).size().unstack(fill_value=0)

    def _classify(row):
        cat_cnt = row.get('CAT', 0)
        non_cat_cnt = row.get('NON CAT', 0)
        if cat_cnt > 0 and non_cat_cnt > 0:
            return 'MIX PART'
        elif cat_cnt > 0:
            return 'CAT ONLY'
        elif non_cat_cnt > 0:
            return 'NON CAT ONLY'
        return 'NON CAT ONLY'

    return grouped.apply(_classify, axis=1).to_dict()


def process_otif_excel(
    input_file_path,
    output_file_path=None,
    mb51_file_path=None,
    purchasing_group="3VH",
    wo_parts_status_filter="CAT ONLY",
    delta_days=1,
    date_filter_mode="all",
    filter_month=None,
    filter_year=None,
    filter_start_date=None,
    filter_end_date=None,
    status_callback=None
):
    """
    Memproses file Excel raw data OTIF SAP:
    1. Membaca data dengan Calamine / Pandas.
    2. Menentukan Manuf (CAT vs NON CAT).
    3. Mengklasifikasikan WO Parts Status (CAT ONLY, MIX PART, NON CAT ONLY).
    4. Menghitung OTIF Status 100% SAP dan Simulasi H-delta_days.
    5. Menghubungkan sheet MB51 (Movement 261) untuk kalkulasi Absorption Rate (Fully Issued, Partial, Unissued).
    6. Opsi Filter Planned Start Date: Semua Tanggal, Per Bulan (Bulan & Tahun), atau Rentang Tanggal.
    7. Fokus dan Pembagi Persentase: Strictly CAT ONLY dengan Purchasing Group 3VH.
    8. Membuat ringkasan Summary eksekutif (Simulasi H-1 & Absorption), tabel WO Analysis, dan Sheet RAW lengkap.
    """
    t_start = time.time()

    def log(msg):
        print(msg)
        if status_callback:
            status_callback(msg)

    if not os.path.exists(input_file_path):
        raise FileNotFoundError(f"File tidak ditemukan: {input_file_path}")

    # Auto-detect file RAW DATA (Sheet MB51) jika tidak diberikan secara manual
    has_mb51 = False
    mb51_dict = {}
    if not mb51_file_path:
        try:
            wb_chk = CalamineWorkbook.from_path(input_file_path)
            if any('MB51' in s.upper() for s in wb_chk.sheet_names):
                mb51_file_path = input_file_path
        except Exception:
            pass

    if not mb51_file_path:
        from modules.sap_helper import find_matching_raw_data_file
        mb51_file_path = find_matching_raw_data_file(os.path.dirname(input_file_path))
        if mb51_file_path:
            log(f"Auto-detect file RAW DATA (MB51): {os.path.basename(mb51_file_path)}")

    if mb51_file_path and os.path.exists(mb51_file_path):
        mb51_dict, has_mb51 = load_mb51_issued_pivot(mb51_file_path, log=log)
    else:
        log("Perhatian: File RAW DATA (MB51) tidak ditemukan. Kolom issued diisi 0.")

    # Validasi & Penyiapan Parameter Filter Tanggal
    date_mode = str(date_filter_mode).strip().lower() if date_filter_mode else "all"
    date_filter_label = "Semua Tanggal"
    file_tag = ""

    parsed_month = None
    parsed_year = None
    parsed_start_dt = None
    parsed_end_dt = None

    if date_mode == "month":
        if filter_month is not None:
            if isinstance(filter_month, int):
                parsed_month = filter_month
            else:
                m_str = str(filter_month).strip().lower()
                digits = re.findall(r'^\d+', m_str)
                if digits:
                    parsed_month = int(digits[0])
                else:
                    for num, name_id, name_en in MONTH_NAMES_MAP:
                        if name_id.lower() in m_str or name_en.lower() in m_str:
                            parsed_month = num
                            break
        if parsed_month is None or not (1 <= parsed_month <= 12):
            raise ValueError(f"Nilai bulan tidak valid: {filter_month}. Pilih bulan antara 1 s/d 12.")

        if filter_year is not None and str(filter_year).strip():
            try:
                parsed_year = int(str(filter_year).strip())
            except Exception:
                raise ValueError(f"Nilai tahun tidak valid: {filter_year}. Harap masukkan 4 digit angka.")
        else:
            parsed_year = time.localtime().tm_year

        month_id, month_en = MONTH_NAME_DICT.get(parsed_month, (f"Bulan {parsed_month}", f"Month {parsed_month}"))
        date_filter_label = f"{month_id} {parsed_year}"
        file_tag = f"{month_en} {parsed_year}"

    elif date_mode == "range":
        parsed_start_dt = parse_date_filter_param(filter_start_date)
        parsed_end_dt = parse_date_filter_param(filter_end_date)

        if parsed_start_dt is None and parsed_end_dt is None:
            raise ValueError("Rentang tanggal tidak boleh kosong. Harap isi Tanggal Mulai atau Tanggal Akhir.")

        if parsed_start_dt is not None and parsed_end_dt is not None:
            if parsed_start_dt > parsed_end_dt:
                raise ValueError("Tanggal Mulai tidak boleh lebih besar dari Tanggal Akhir!")
            date_filter_label = f"{parsed_start_dt.strftime('%d/%m/%Y')} s/d {parsed_end_dt.strftime('%d/%m/%Y')}"
            file_tag = f"{parsed_start_dt.strftime('%Y-%m-%d')} sd {parsed_end_dt.strftime('%Y-%m-%d')}"
        elif parsed_start_dt is not None:
            date_filter_label = f"Mulai {parsed_start_dt.strftime('%d/%m/%Y')}"
            file_tag = f"Sejak {parsed_start_dt.strftime('%Y-%m-%d')}"
        else:
            date_filter_label = f"Hingga {parsed_end_dt.strftime('%d/%m/%Y')}"
            file_tag = f"Hingga {parsed_end_dt.strftime('%Y-%m-%d')}"
    else:
        date_mode = "all"
        date_filter_label = "Semua Tanggal"
        file_tag = ""

    # Tentukan nama file output jika tidak disediakan
    if output_file_path is None:
        out_dir = config.get_output_dir("otif")
        base_name = os.path.splitext(os.path.basename(input_file_path))[0]
        base_name = re.sub(r' - REPORT MONTHLY.*', '', base_name, flags=re.IGNORECASE)
        if file_tag:
            output_file_path = os.path.join(out_dir, f"{base_name} - REPORT MONTHLY ({file_tag}).xlsx")
        else:
            output_file_path = os.path.join(out_dir, f"{base_name} - REPORT MONTHLY.xlsx")


    # Handle jika file target sedang terbuka di aplikasi Excel
    if os.path.exists(output_file_path):
        try:
            with open(output_file_path, "a"):
                pass
        except PermissionError:
            dir_name = os.path.dirname(output_file_path)
            base_name, ext = os.path.splitext(os.path.basename(output_file_path))
            output_file_path = os.path.join(dir_name, f"{base_name} ({time.strftime('%H%M%S')}){ext}")
            log(f"Perhatian: File target sedang terbuka. Menyimpan ke nama baru: {os.path.basename(output_file_path)}")

    log(f"Membaca file data: {os.path.basename(input_file_path)}...")

    file_ext = os.path.splitext(input_file_path)[1].lower()
    if file_ext == '.xlsb':
        df = pd.read_excel(input_file_path, engine='calamine')
    else:
        try:
            df = pd.read_excel(input_file_path, engine='calamine')
        except Exception:
            df = pd.read_excel(input_file_path)

    total_raw_rows = len(df)
    log(f"Data terbaca: {total_raw_rows:,} baris.")

    # Standardisasi nama kolom
    df.columns = [str(c).strip() for c in df.columns]

    # Validasi kolom-kolom kunci
    required_cols = ['Order', 'Material Description', 'Actual Released Date', 'Planned Start Date', 'Initial Otif Date']
    missing_cols = [c for c in required_cols if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Kolom wajib tidak ditemukan di file: {', '.join(missing_cols)}")

    # 1. Ekstraksi Manuf (CAT vs NON CAT)
    log("Langkah 1/5: Mengekstrak Manuf suku cadang (CAT vs NON CAT)...")
    df['Manuf'] = df['Material Description'].apply(extract_part_manuf)

    # 2. Klasifikasi Status Part per Work Order
    log("Langkah 2/5: Mengklasifikasikan Work Order (CAT ONLY, MIX PART, NON CAT)...")
    wo_status_map = classify_work_orders(df)
    df['WO Parts Status'] = df['Order'].map(wo_status_map)

    # 3. Hitung Tanggal & OTIF Status
    log("Langkah 3/5: Mengkalkulasi formula OTIF 100% SAP & Simulasi...")
    dt_released = pd.to_datetime(df['Actual Released Date'], errors='coerce')
    dt_planned = pd.to_datetime(df['Planned Start Date'], errors='coerce')
    dt_initial = pd.to_datetime(df['Initial Otif Date'], errors='coerce')

    # Status OTIF 100% SAP
    cond_not_complete = dt_initial.isna()
    cond_otif_100 = (dt_released == dt_initial) | (dt_initial <= dt_planned)
    df['OTIF Status (100% SAP)'] = np.where(
        cond_not_complete, 'Not Complete',
        np.where(cond_otif_100, 'Complete OTIF', 'Complete Not OTIF')
    )

    # Status Simulasi OTIF (Initial OTIF - delta_days)
    sim_col_name = f"OTIF Status (Initial OTIF-{delta_days})" if delta_days > 0 else "OTIF Status (Initial OTIF)"
    cond_otif_sim = (dt_released == dt_initial) | ((dt_initial - pd.Timedelta(days=delta_days)) <= dt_planned)
    df[sim_col_name] = np.where(
        cond_not_complete, 'Not Complete',
        np.where(cond_otif_sim, 'Complete OTIF', 'Complete Not OTIF')
    )

    # Format semua kolom tanggal menjadi objek datetime.date untuk Excel
    date_cols_candidates = [
        'Actual Released Date', 'Planned Start Date', 'Initial Otif Date',
        'Created On', 'TECO Date', 'Req. Date (MB25)', 'Req. Date (ZCKASSET57)',
        'WO Otif Date', 'Deletion Date'
    ]
    for dc in date_cols_candidates:
        if dc in df.columns:
            df[dc] = df[dc].apply(to_excel_date)

    # Filter Planned Start Date (Plan) jika aktif
    if date_mode == "month":
        cond_date = (dt_planned.dt.year == parsed_year) & (dt_planned.dt.month == parsed_month)
    elif date_mode == "range":
        dt_norm = dt_planned.dt.normalize()
        cond_date = pd.Series(True, index=df.index)
        if parsed_start_dt is not None:
            cond_date &= (dt_norm >= parsed_start_dt)
        if parsed_end_dt is not None:
            cond_date &= (dt_norm <= parsed_end_dt)
    else:
        cond_date = pd.Series(True, index=df.index)

    if date_mode != "all":
        matched_cnt = cond_date.sum()
        if matched_cnt == 0:
            valid_dt = dt_planned.dropna()
            r_str = f"{valid_dt.min().strftime('%d/%m/%Y')} s/d {valid_dt.max().strftime('%d/%m/%Y')}" if not valid_dt.empty else "tidak ada"
            raise ValueError(
                f"Tidak ditemukan data dengan Planned Start Date pada periode [{date_filter_label}]!\n"
                f"Rentang tanggal yang ada di file: {r_str}."
            )
        log(f"Filter Planned Start Date [{date_filter_label}]: {matched_cnt:,} dari {len(df):,} baris terpilih.")
        df_proc = df[cond_date].copy()
    else:
        df_proc = df.copy()

    # 4. Filter Khusus: CAT ONLY dengan Purchasing Group 3VH & Hitung Absorption
    pg_target = str(purchasing_group).strip().upper() if purchasing_group else "3VH"
    wo_target = str(wo_parts_status_filter).strip().upper() if wo_parts_status_filter else "CAT ONLY"
    log(f"Langkah 4/5: Menyortir {wo_target} (Purchasing Group {pg_target}) & Mencocokkan MB51...")

    # Hitung Qty Issued & Status Absorption per baris part
    clean_orders = df_proc['Order'].astype(str).str.replace(r'\.0$', '', regex=True).str.strip().str.lstrip('0')
    clean_mats = df_proc['Material'].astype(str).str.strip().str.lstrip('0') if 'Material' in df_proc.columns else pd.Series('', index=df_proc.index)

    df_proc['Qty Issued (MB51)'] = [mb51_dict.get((o, m), 0.0) for o, m in zip(clean_orders, clean_mats)]

    if 'Requirement Quantity' in df_proc.columns:
        req_vals = pd.to_numeric(df_proc['Requirement Quantity'], errors='coerce').fillna(0.0)
    else:
        req_vals = pd.Series(0.0, index=df_proc.index)

    df_proc['Outstanding Qty'] = np.maximum(0.0, req_vals - df_proc['Qty Issued (MB51)'])

    cond_fully = ((df_proc['Qty Issued (MB51)'] >= req_vals) & (req_vals > 0)) | ((req_vals == 0) & (df_proc['Qty Issued (MB51)'] > 0))
    cond_partial = (df_proc['Qty Issued (MB51)'] > 0) & (df_proc['Qty Issued (MB51)'] < req_vals)

    df_proc['Part Issue Status'] = np.where(
        cond_fully, 'Fully Issued',
        np.where(cond_partial, 'Partial', 'Unissued')
    )

    # Evaluasi filter pada basis baris (persis seperti Pivot Table Excel)
    cond_pg = pd.Series(True, index=df_proc.index)
    if pg_target != "ALL" and 'Purchasing Group' in df_proc.columns:
        cond_pg = df_proc['Purchasing Group'].astype(str).str.upper() == pg_target

    cond_wo = pd.Series(True, index=df_proc.index)
    if wo_target != "ALL":
        cond_wo = df_proc['WO Parts Status'].astype(str).str.upper() == wo_target

    filtered_raw = df_proc[cond_pg & cond_wo].copy()

    # Total Pembagi Persentase = Distinct Count of Order untuk CAT ONLY 3VH
    total_target_orders = filtered_raw['Order'].nunique()

    # Hitung angka metrik 100% SAP (Distinct Count of Order)
    otif_100_vc = filtered_raw.groupby('OTIF Status (100% SAP)')['Order'].nunique()
    c_otif_100 = int(otif_100_vc.get('Complete OTIF', 0))
    c_not_otif_100 = int(otif_100_vc.get('Complete Not OTIF', 0))
    c_not_comp_100 = int(otif_100_vc.get('Not Complete', 0))
    pct_otif_100 = (c_otif_100 / total_target_orders * 100) if total_target_orders > 0 else 0.0

    # Hitung angka metrik Simulasi (Distinct Count of Order)
    otif_sim_vc = filtered_raw.groupby(sim_col_name)['Order'].nunique()
    c_otif_sim = int(otif_sim_vc.get('Complete OTIF', 0))
    c_not_otif_sim = int(otif_sim_vc.get('Complete Not OTIF', 0))
    c_not_comp_sim = int(otif_sim_vc.get('Not Complete', 0))
    pct_otif_sim = (c_otif_sim / total_target_orders * 100) if total_target_orders > 0 else 0.0

    delta_otif_orders = c_otif_sim - c_otif_100
    delta_otif_pct = pct_otif_sim - pct_otif_100

    # Agregasi tabel WO Analysis: HANYA WORK ORDER CAT ONLY (3VH)
    target_orders_set = set(filtered_raw['Order'].unique())
    df_cat_only_raw = df_proc[df_proc['Order'].isin(target_orders_set)].copy()

    wo_analysis_df = df_cat_only_raw.groupby('Order').agg(
        Total_Parts=('Material', 'count') if 'Material' in df_cat_only_raw.columns else ('Order', 'count'),
        CAT_Parts=('Manuf', lambda x: (x == 'CAT').sum()),
        Plant=('Plant', 'first') if 'Plant' in df_proc.columns else ('Order', lambda x: ''),
        Order_Type=('Order Type', 'first') if 'Order Type' in df_proc.columns else ('Order', lambda x: ''),
        Purchasing_Group=('Purchasing Group', lambda x: ', '.join(sorted(x.dropna().astype(str).unique()))) if 'Purchasing Group' in df_proc.columns else ('Order', lambda x: ''),
        Parts_Fully_Issued=('Part Issue Status', lambda x: (x == 'Fully Issued').sum()),
        Parts_Partial=('Part Issue Status', lambda x: (x == 'Partial').sum()),
        Parts_Unissued=('Part Issue Status', lambda x: (x == 'Unissued').sum()),
        Total_Req_Qty=('Requirement Quantity', lambda x: pd.to_numeric(x, errors='coerce').fillna(0).sum()) if 'Requirement Quantity' in df_cat_only_raw.columns else ('Order', lambda x: 0),
        Total_Issued_Qty=('Qty Issued (MB51)', lambda x: pd.to_numeric(x, errors='coerce').fillna(0).sum()),
        Actual_Released_Date=('Actual Released Date', 'first'),
        Planned_Start_Date=('Planned Start Date', 'first'),
        Initial_Otif_Date=('Initial Otif Date', 'first'),
        WO_Parts_Status=('WO Parts Status', 'first'),
        OTIF_Sim=(sim_col_name, 'first'),
        OTIF_100=('OTIF Status (100% SAP)', 'first')
    ).reset_index()

    wo_analysis_df['Absorption_Rate'] = np.where(
        wo_analysis_df['Total_Parts'] > 0,
        (wo_analysis_df['Parts_Fully_Issued'] / wo_analysis_df['Total_Parts'] * 100).round(2),
        0.0
    )

    def _wo_absorb_status(row):
        if row['OTIF_Sim'] == 'Not Complete':
            return 'Not Complete'
        tot = row['Total_Parts']
        f_iss = row['Parts_Fully_Issued']
        p_iss = row['Parts_Partial']
        if tot > 0 and f_iss == tot:
            return 'Fully Absorbed'
        elif f_iss == 0 and p_iss == 0:
            return 'Unabsorbed'
        else:
            return 'Partially Absorbed'

    wo_analysis_df['WO_Absorption_Status'] = wo_analysis_df.apply(_wo_absorb_status, axis=1)
    wo_analysis_df.loc[wo_analysis_df['OTIF_Sim'] == 'Not Complete', 'Absorption_Rate'] = None

    def _status_shift(row):
        s100 = row['OTIF_100']
        ssim = row['OTIF_Sim']
        if s100 == 'Complete Not OTIF' and ssim == 'Complete OTIF':
            return '⭐ Improved to OTIF'
        elif s100 == ssim:
            return 'No Change'
        else:
            return f"{s100} -> {ssim}"

    wo_analysis_df['Simulation Effect'] = wo_analysis_df.apply(_status_shift, axis=1)

    # Metrik Ringkasan Absorption: KHUSUS COMPLETE WORK ORDERS (Complete OTIF & Complete Not OTIF)
    complete_target_orders = c_otif_sim + c_not_otif_sim
    complete_orders_set = set(filtered_raw[filtered_raw[sim_col_name].isin(['Complete OTIF', 'Complete Not OTIF'])]['Order'].unique())

    # Suku cadang khusus dari Complete Work Orders
    df_complete_parts = df_cat_only_raw[df_cat_only_raw['Order'].isin(complete_orders_set)].copy()
    tot_complete_parts = len(df_complete_parts)
    p_fully = int((df_complete_parts['Part Issue Status'] == 'Fully Issued').sum())
    p_partial = int((df_complete_parts['Part Issue Status'] == 'Partial').sum())
    p_unissued = int((df_complete_parts['Part Issue Status'] == 'Unissued').sum())
    pct_parts_iss = (p_fully / tot_complete_parts * 100) if tot_complete_parts > 0 else 0.0

    # Agregasi status WO Absorption khusus Complete Work Orders
    wo_complete_df = wo_analysis_df[wo_analysis_df['Order'].isin(complete_orders_set)].copy()
    wo_fully = int((wo_complete_df['WO_Absorption_Status'] == 'Fully Absorbed').sum())
    wo_partial = int((wo_complete_df['WO_Absorption_Status'] == 'Partially Absorbed').sum())
    wo_unabs = int((wo_complete_df['WO_Absorption_Status'] == 'Unabsorbed').sum())
    pct_wo_abs = (wo_fully / complete_target_orders * 100) if complete_target_orders > 0 else 0.0

    df_wo_fa = wo_complete_df[wo_complete_df['WO_Absorption_Status'] == 'Fully Absorbed']
    df_wo_pa = wo_complete_df[wo_complete_df['WO_Absorption_Status'] == 'Partially Absorbed']
    df_wo_ua = wo_complete_df[wo_complete_df['WO_Absorption_Status'] == 'Unabsorbed']

    # 5. Format & Simpan Excel dengan OpenPyXL
    log("Langkah 5/5: Mendesain Workbook Excel (Summary, WO Analysis, RAW)...")
    _write_excel_workbook(
        output_file_path=output_file_path,
        df_raw=df_proc,
        wo_analysis_df=wo_analysis_df,
        pg_target=pg_target,
        wo_target=wo_target,
        delta_days=delta_days,
        sim_col_name=sim_col_name,
        metrics={
            'total_orders': total_target_orders,
            'complete_orders': complete_target_orders,
            'c_otif_100': c_otif_100,
            'c_not_otif_100': c_not_otif_100,
            'c_not_comp_100': c_not_comp_100,
            'pct_otif_100': pct_otif_100,
            'c_otif_sim': c_otif_sim,
            'c_not_otif_sim': c_not_otif_sim,
            'c_not_comp_sim': c_not_comp_sim,
            'pct_otif_sim': pct_otif_sim,
            'delta_otif_orders': delta_otif_orders,
            'delta_otif_pct': delta_otif_pct,
            'total_target_parts': tot_complete_parts,
            'parts_fully_issued': p_fully,
            'parts_partial': p_partial,
            'parts_unissued': p_unissued,
            'pct_parts_issued': pct_parts_iss,
            'wo_fully_absorbed': wo_fully,
            'wo_partial_absorbed': wo_partial,
            'wo_unabsorbed': wo_unabs,
            'pct_wo_absorbed': pct_wo_abs,
            'overall_absorption_pct': pct_wo_abs,
            'wo_fully_parts': int(df_wo_fa['Total_Parts'].sum()),
            'wo_fully_req_qty': float(df_wo_fa['Total_Req_Qty'].sum()),
            'wo_fully_issued_qty': float(df_wo_fa['Total_Issued_Qty'].sum()),
            'wo_partial_parts': int(df_wo_pa['Total_Parts'].sum()),
            'wo_partial_req_qty': float(df_wo_pa['Total_Req_Qty'].sum()),
            'wo_partial_issued_qty': float(df_wo_pa['Total_Issued_Qty'].sum()),
            'wo_unabsorbed_parts': int(df_wo_ua['Total_Parts'].sum()),
            'wo_unabsorbed_req_qty': float(df_wo_ua['Total_Req_Qty'].sum()),
            'wo_unabsorbed_issued_qty': float(df_wo_ua['Total_Issued_Qty'].sum()),
            'tot_req_qty': float(wo_complete_df['Total_Req_Qty'].sum()),
            'tot_issued_qty': float(wo_complete_df['Total_Issued_Qty'].sum()),
        },
        date_filter_label=date_filter_label
    )

    elapsed = time.time() - t_start
    log(f"Proses selesai dalam {elapsed:.2f} detik! File tersimpan di: {os.path.basename(output_file_path)}")

    return {
        'total_raw_rows': total_raw_rows,
        'filtered_raw_rows': len(df_proc),
        'total_unique_orders': df['Order'].nunique(),
        'filtered_orders': total_target_orders,
        'total_orders': total_target_orders,
        'complete_orders': complete_target_orders,
        'purchasing_group': pg_target,
        'wo_parts_status': wo_target,
        'delta_days': delta_days,
        'date_filter_mode': date_mode,
        'date_filter_label': date_filter_label,
        'filter_month': parsed_month,
        'filter_year': parsed_year,
        'filter_start_date': parsed_start_dt.strftime('%d/%m/%Y') if parsed_start_dt is not None else None,
        'filter_end_date': parsed_end_dt.strftime('%d/%m/%Y') if parsed_end_dt is not None else None,
        'c_otif_100': c_otif_100,
        'c_not_otif_100': c_not_otif_100,
        'c_not_comp_100': c_not_comp_100,
        'pct_otif_100': pct_otif_100,
        'c_otif_sim': c_otif_sim,
        'c_not_otif_sim': c_not_otif_sim,
        'c_not_comp_sim': c_not_comp_sim,
        'pct_otif_sim': pct_otif_sim,
        'delta_otif_orders': delta_otif_orders,
        'delta_otif_pct': delta_otif_pct,
        'total_target_parts': tot_complete_parts,
        'parts_fully_issued': p_fully,
        'parts_partial': p_partial,
        'parts_unissued': p_unissued,
        'pct_parts_issued': pct_parts_iss,
        'wo_fully_absorbed': wo_fully,
        'wo_partial_absorbed': wo_partial,
        'wo_unabsorbed': wo_unabs,
        'pct_wo_absorbed': pct_wo_abs,
        'output_path': output_file_path,
        'elapsed_time': elapsed
    }


def _write_excel_workbook(
    output_file_path,
    df_raw,
    wo_analysis_df,
    pg_target,
    wo_target,
    delta_days,
    sim_col_name,
    metrics,
    date_filter_label=None
):
    """
    Menyusun workbook Excel fokus khusus CAT ONLY (Purchasing Group 3VH):
    - Sheet 1: Summary (KPI Cards & Tabel Simulasi H-1 vs Status Absorption, tanpa MIX PART / NON CAT)
    - Sheet 2: WO Analysis (Work Order CAT ONLY 3VH dengan kolom Absorption & Tanggal True Date)
    - Sheet 3: RAW (Data transaksi lengkap dengan True Date & Kolom MB51 Issued)
    """
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    navy_dark = "1E3A8A"
    blue_header = "2563EB"
    border_gray = Side(style='thin', color='CBD5E1')
    thin_border = Border(left=border_gray, right=border_gray, top=border_gray, bottom=border_gray)

    # ----------------------------------------------------
    # SHEET 1: SUMMARY (KHUSUS CAT ONLY - PURCH 3VH)
    # ----------------------------------------------------
    ws_sum = wb.create_sheet(title="Summary")
    ws_sum.views.sheetView[0].showGridLines = True

    # Header Banner
    ws_sum.merge_cells("B2:H2")
    ws_sum["B2"] = "REPORT OTIF MONTHLY - CK BMB"
    ws_sum["B2"].font = Font(name="Segoe UI", size=13, bold=True, color="FFFFFF")
    ws_sum["B2"].fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    ws_sum["B2"].alignment = Alignment(horizontal="center", vertical="center")
    ws_sum.row_dimensions[2].height = 36

    # Subtitle Info
    ws_sum.merge_cells("B3:H3")
    if date_filter_label and date_filter_label != "Semua Tanggal":
        ws_sum["B3"] = f"Purchasing Group = [{pg_target}]  |  Kategori Part = [{wo_target}]  |  Periode Plan = [{date_filter_label}]  |  Pembagi Persentase: {metrics['total_orders']:,} Distinct WO"
    else:
        ws_sum["B3"] = f"Purchasing Group = [{pg_target}]  |  Kategori Part = [{wo_target}]  |  Pembagi Persentase: {metrics['total_orders']:,} Distinct WO"
    ws_sum["B3"].font = Font(name="Segoe UI", size=9, italic=True, color="1E293B")
    ws_sum["B3"].fill = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")
    ws_sum["B3"].alignment = Alignment(horizontal="center", vertical="center")
    ws_sum.row_dimensions[3].height = 20

    # 4 KPI CARDS (HANYA CAT ONLY 3VH)
    # Card 2 diganti menjadi SIMULASI H-1 OTIF, Card 3 diganti menjadi ABSORPTION RATE
    card1_note = f"Periode: {date_filter_label}" if (date_filter_label and date_filter_label != "Semua Tanggal") else "Basis Pembagi Persentase"
    cards = [
        ("TOTAL WO (CAT ONLY 3VH)", f"{metrics['total_orders']:,} WO", card1_note, "3B82F6", "B"),
        (f"SIMULASI H-{delta_days} OTIF", f"{metrics['pct_otif_sim']:.2f}%", f"{metrics['c_otif_sim']:,} WO OTIF", "0D9488", "D"),
        ("ABSORPTION RATE (WO)", f"{metrics['pct_wo_absorbed']:.2f}%", f"{metrics['wo_fully_absorbed']:,} / {metrics['complete_orders']:,} Complete WO", "2563EB", "F"),
        ("PART ABSORPTION", f"{metrics['pct_parts_issued']:.2f}%", f"{metrics['parts_fully_issued']:,} / {metrics['total_target_parts']:,} Parts", "7C3AED", "H")
    ]

    for title, val, note, color_hex, col_letter in cards:
        c_title = ws_sum[f"{col_letter}5"]
        c_title.value = title
        c_title.font = Font(name="Segoe UI", size=8, bold=True, color="64748B")
        c_title.alignment = Alignment(horizontal="center", vertical="center")

        c_val = ws_sum[f"{col_letter}6"]
        c_val.value = val
        c_val.font = Font(name="Segoe UI", size=16, bold=True, color=color_hex)
        c_val.alignment = Alignment(horizontal="center", vertical="center")

        c_note = ws_sum[f"{col_letter}7"]
        c_note.value = note
        c_note.font = Font(name="Segoe UI", size=8, italic=True, color="475569")
        c_note.alignment = Alignment(horizontal="center", vertical="center")

        fill_card = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
        for r in range(5, 8):
            cell = ws_sum[f"{col_letter}{r}"]
            cell.fill = fill_card
            cell.border = thin_border

    ws_sum.row_dimensions[5].height = 18
    ws_sum.row_dimensions[6].height = 28
    ws_sum.row_dimensions[7].height = 18

    # TABEL 1: SIMULASI OTIF H-delta_days (CAT ONLY 3VH) - Menggantikan 100% SAP
    ws_sum["B9"] = f"1. SIMULASI OTIF H-{delta_days} HARI ({wo_target} - {pg_target})"
    ws_sum["B9"].font = Font(name="Segoe UI", size=10, bold=True, color=navy_dark)

    headers_tbl = ["Status OTIF", "Distinct Count of Order", "% of Total"]
    for i, h in enumerate(headers_tbl):
        c = ws_sum.cell(row=10, column=2 + i, value=h)
        c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
        c.fill = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
        c.alignment = Alignment(horizontal="center" if i > 0 else "left", vertical="center")
        c.border = thin_border

    tot_denom = metrics['total_orders']
    t1_rows = [
        ("Complete OTIF", metrics['c_otif_sim'], metrics['c_otif_sim'] / tot_denom if tot_denom > 0 else 0),
        ("Complete Not OTIF", metrics['c_not_otif_sim'], metrics['c_not_otif_sim'] / tot_denom if tot_denom > 0 else 0),
        ("Not Complete", metrics['c_not_comp_sim'], metrics['c_not_comp_sim'] / tot_denom if tot_denom > 0 else 0),
        ("Grand Total", tot_denom, 1.0)
    ]

    for idx, (stat, cnt, pct) in enumerate(t1_rows, start=11):
        is_total = (idx == 14)
        c_stat = ws_sum.cell(row=idx, column=2, value=stat)
        c_cnt = ws_sum.cell(row=idx, column=3, value=cnt)
        c_pct = ws_sum.cell(row=idx, column=4, value=pct)

        for cell in [c_stat, c_cnt, c_pct]:
            cell.font = Font(name="Segoe UI", size=9, bold=is_total)
            cell.border = thin_border
            if is_total:
                cell.fill = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")

        c_cnt.number_format = '#,##0'
        c_pct.number_format = '0.00%'
        c_cnt.alignment = Alignment(horizontal="right")
        c_pct.alignment = Alignment(horizontal="right")

    # TABEL 2: STATUS ABSORPTION SUKU CADANG (CAT ONLY 3VH) - Menggantikan Simulasi H-1
    ws_sum["F9"] = f"2. STATUS ABSORPTION SUKU CADANG (COMPLETE WO: {metrics['complete_orders']:,} WO)"
    ws_sum["F9"].font = Font(name="Segoe UI", size=10, bold=True, color=navy_dark)

    headers_tbl2 = ["Status Part Issue", "Count of Parts", "% of Total"]
    for i, h in enumerate(headers_tbl2):
        c = ws_sum.cell(row=10, column=6 + i, value=h)
        c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
        c.fill = PatternFill(start_color="0D9488", end_color="0D9488", fill_type="solid")
        c.alignment = Alignment(horizontal="center" if i > 0 else "left", vertical="center")
        c.border = thin_border

    tot_parts = metrics['total_target_parts']
    t2_rows = [
        ("Fully Issued", metrics['parts_fully_issued'], metrics['parts_fully_issued'] / tot_parts if tot_parts > 0 else 0),
        ("Partial", metrics['parts_partial'], metrics['parts_partial'] / tot_parts if tot_parts > 0 else 0),
        ("Unissued", metrics['parts_unissued'], metrics['parts_unissued'] / tot_parts if tot_parts > 0 else 0),
        ("Grand Total", tot_parts, 1.0)
    ]

    for idx, (stat, cnt, pct) in enumerate(t2_rows, start=11):
        is_total = (idx == 14)
        c_stat = ws_sum.cell(row=idx, column=6, value=stat)
        c_cnt = ws_sum.cell(row=idx, column=7, value=cnt)
        c_pct = ws_sum.cell(row=idx, column=8, value=pct)

        for cell in [c_stat, c_cnt, c_pct]:
            cell.font = Font(name="Segoe UI", size=9, bold=is_total)
            cell.border = thin_border
            if is_total:
                cell.fill = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")

        c_cnt.number_format = '#,##0'
        c_pct.number_format = '0.00%'
        c_cnt.alignment = Alignment(horizontal="right")
        c_pct.alignment = Alignment(horizontal="right")

    # TABEL 3: RINGKASAN STATUS ABSORPTION WORK ORDER (CAT ONLY 3VH)
    start_r3 = 17
    ws_sum.cell(row=start_r3, column=2, value=f"3. RINGKASAN STATUS ABSORPTION WORK ORDER (COMPLETE WO: {metrics['complete_orders']:,} WO)").font = Font(name="Segoe UI", size=10, bold=True, color=navy_dark)

    wo_absorb_headers = [
        "Kategori WO Absorption", "Distinct Count of Order", "% of Total WO",
        "Total Parts", "Total Qty Req", "Total Qty Issued", "% Qty Issued"
    ]
    for i, h in enumerate(wo_absorb_headers):
        c = ws_sum.cell(row=start_r3 + 1, column=2 + i, value=h)
        c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
        c.fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
        c.alignment = Alignment(horizontal="center" if i > 0 else "left", vertical="center")
        c.border = thin_border

    comp_denom = metrics['complete_orders']
    t3_data = [
        (
            "Fully Absorbed (100% Parts)",
            metrics['wo_fully_absorbed'],
            metrics['wo_fully_absorbed'] / comp_denom if comp_denom > 0 else 0,
            metrics['wo_fully_parts'],
            metrics['wo_fully_req_qty'],
            metrics['wo_fully_issued_qty'],
            metrics['wo_fully_issued_qty'] / metrics['wo_fully_req_qty'] if metrics['wo_fully_req_qty'] > 0 else 0
        ),
        (
            "Partially Absorbed",
            metrics['wo_partial_absorbed'],
            metrics['wo_partial_absorbed'] / comp_denom if comp_denom > 0 else 0,
            metrics['wo_partial_parts'],
            metrics['wo_partial_req_qty'],
            metrics['wo_partial_issued_qty'],
            metrics['wo_partial_issued_qty'] / metrics['wo_partial_req_qty'] if metrics['wo_partial_req_qty'] > 0 else 0
        ),
        (
            "Unabsorbed (0% Parts)",
            metrics['wo_unabsorbed'],
            metrics['wo_unabsorbed'] / comp_denom if comp_denom > 0 else 0,
            metrics['wo_unabsorbed_parts'],
            metrics['wo_unabsorbed_req_qty'],
            metrics['wo_unabsorbed_issued_qty'],
            0.0
        ),
        (
            "Grand Total (Complete WO)",
            comp_denom,
            1.0,
            tot_parts,
            metrics['tot_req_qty'],
            metrics['tot_issued_qty'],
            metrics['tot_issued_qty'] / metrics['tot_req_qty'] if metrics['tot_req_qty'] > 0 else 0
        )
    ]

    r_curr = start_r3 + 2
    for item in t3_data:
        cat_name, wo_cnt, wo_pct, p_cnt, req_q, iss_q, iss_pct = item
        is_tot = ("Grand Total" in cat_name)

        cells = [
            ws_sum.cell(row=r_curr, column=2, value=cat_name),
            ws_sum.cell(row=r_curr, column=3, value=wo_cnt),
            ws_sum.cell(row=r_curr, column=4, value=wo_pct),
            ws_sum.cell(row=r_curr, column=5, value=p_cnt),
            ws_sum.cell(row=r_curr, column=6, value=req_q),
            ws_sum.cell(row=r_curr, column=7, value=iss_q),
            ws_sum.cell(row=r_curr, column=8, value=iss_pct)
        ]

        for col_idx, cell in enumerate(cells):
            cell.font = Font(name="Segoe UI", size=9, bold=is_tot)
            cell.border = thin_border
            if is_tot:
                cell.fill = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")

        cells[1].number_format = '#,##0'
        cells[2].number_format = '0.00%'
        cells[3].number_format = '#,##0'
        cells[4].number_format = '#,##0.00'
        cells[5].number_format = '#,##0.00'
        cells[6].number_format = '0.00%'

        cells[1].alignment = Alignment(horizontal="right")
        cells[2].alignment = Alignment(horizontal="right")
        cells[3].alignment = Alignment(horizontal="right")
        cells[4].alignment = Alignment(horizontal="right")
        cells[5].alignment = Alignment(horizontal="right")
        cells[6].alignment = Alignment(horizontal="right")

        if cat_name == "Fully Absorbed (100% Parts)":
            cells[0].font = Font(name="Segoe UI", size=9, bold=True, color="166534")
            cells[1].font = Font(name="Segoe UI", size=9, bold=True, color="166534")
        elif cat_name == "Partially Absorbed":
            cells[0].font = Font(name="Segoe UI", size=9, bold=True, color="92400E")
            cells[1].font = Font(name="Segoe UI", size=9, bold=True, color="92400E")
        elif cat_name == "Unabsorbed (0% Parts)":
            cells[0].font = Font(name="Segoe UI", size=9, bold=True, color="991B1B")
            cells[1].font = Font(name="Segoe UI", size=9, bold=True, color="991B1B")

        r_curr += 1

    # Catatan kaki penjelasan pembagi Complete WO
    c_note_t3 = ws_sum.cell(
        row=r_curr + 1,
        column=2,
        value=f"*Catatan: Evaluasi Absorption Rate khusus Work Order status Complete ({metrics['complete_orders']:,} WO). Sebanyak {metrics['c_not_comp_sim']:,} WO Not Complete (Pending) tidak dihitung dalam absorption."
    )
    c_note_t3.font = Font(name="Segoe UI", size=8, italic=True, color="64748B")

    # Lebar kolom Summary
    ws_sum.column_dimensions['A'].width = 3
    ws_sum.column_dimensions['B'].width = 28
    ws_sum.column_dimensions['C'].width = 22
    ws_sum.column_dimensions['D'].width = 16
    ws_sum.column_dimensions['E'].width = 14
    ws_sum.column_dimensions['F'].width = 20
    ws_sum.column_dimensions['G'].width = 20
    ws_sum.column_dimensions['H'].width = 16

    # ----------------------------------------------------
    # SHEET 2: WO ANALYSIS (WORK ORDER CAT ONLY 3VH)
    # ----------------------------------------------------
    ws_wo = wb.create_sheet(title="WO Analysis")
    ws_wo.views.sheetView[0].showGridLines = True

    wo_cols = [
        ("Order", "Order"),
        ("Plant", "Plant"),
        ("Order Type", "Order_Type"),
        ("Purchasing Group", "Purchasing_Group"),
        ("WO Parts Status", "WO_Parts_Status"),
        ("Total Parts", "Total_Parts"),
        ("Parts Fully Issued", "Parts_Fully_Issued"),
        ("Parts Partial", "Parts_Partial"),
        ("Parts Unissued", "Parts_Unissued"),
        ("Absorption Rate", "Absorption_Rate"),
        ("Actual Released Date", "Actual_Released_Date"),
        ("Planned Start Date", "Planned_Start_Date"),
        ("Initial Otif Date", "Initial_Otif_Date"),
        (f"OTIF Status (Initial OTIF-{delta_days})", "OTIF_Sim"),
        ("Simulation Effect", "Simulation Effect"),
        ("WO Absorption Status", "WO_Absorption_Status")
    ]

    for col_idx, (col_name, _) in enumerate(wo_cols, start=1):
        c = ws_wo.cell(row=1, column=col_idx, value=col_name)
        c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
        c.fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = thin_border
    ws_wo.row_dimensions[1].height = 24

    for row_idx, r_data in enumerate(wo_analysis_df.to_dict('records'), start=2):
        for col_idx, (_, field) in enumerate(wo_cols, start=1):
            val = r_data.get(field, "")
            c = ws_wo.cell(row=row_idx, column=col_idx, value=val)
            c.font = Font(name="Segoe UI", size=9)
            c.border = thin_border

            if field in ["Total_Parts", "Parts_Fully_Issued", "Parts_Partial", "Parts_Unissued"]:
                c.alignment = Alignment(horizontal="right")
                c.number_format = '#,##0'
            elif field == "Absorption_Rate":
                if val is None or val == "" or str(val) == "nan" or str(val) == "-":
                    c.value = "-"
                    c.alignment = Alignment(horizontal="center")
                    c.font = Font(name="Segoe UI", size=9, color="94A3B8")
                else:
                    c.alignment = Alignment(horizontal="right")
                    try:
                        c.value = float(val) / 100.0 if float(val) > 1.0 else float(val)
                        c.number_format = '0.00%'
                    except Exception:
                        c.value = val
            elif "Date" in field and val:
                c.alignment = Alignment(horizontal="center")
                d_val = to_excel_date(val)
                if d_val:
                    c.value = d_val
                    c.number_format = 'DD/MM/YYYY'
            elif field == "OTIF_Sim":
                c.alignment = Alignment(horizontal="center")
                if val == 'Complete OTIF':
                    c.fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="166534", bold=True)
                elif val == 'Complete Not OTIF':
                    c.fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="991B1B")
                elif val == 'Not Complete':
                    c.fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="92400E")
            elif field == "WO_Absorption_Status":
                c.alignment = Alignment(horizontal="center")
                if val == 'Fully Absorbed':
                    c.fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="166534", bold=True)
                elif val == 'Partially Absorbed':
                    c.fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="92400E", bold=True)
                elif val == 'Unabsorbed':
                    c.fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="991B1B")
                elif val == 'Not Complete':
                    c.fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="64748B", italic=True)
            elif field == "Simulation Effect":
                c.alignment = Alignment(horizontal="center")
                if "Improved" in str(val):
                    c.fill = PatternFill(start_color="EFF6FF", end_color="EFF6FF", fill_type="solid")
                    c.font = Font(name="Segoe UI", size=9, color="1D4ED8", bold=True)

    for c_idx in range(1, len(wo_cols) + 1):
        col_letter = get_column_letter(c_idx)
        ws_wo.column_dimensions[col_letter].width = 18

    # ----------------------------------------------------
    # SHEET 3: RAW PROCESSED (Data Lengkap dengan MB51 & True Date)
    # ----------------------------------------------------
    ws_raw = wb.create_sheet(title="RAW")
    ws_raw.views.sheetView[0].showGridLines = True

    df_raw_export = df_raw.copy()
    raw_headers = list(df_raw_export.columns)

    # Identifikasi indeks kolom tanggal, numerik issued, dan status
    date_col_indices = [
        idx for idx, col in enumerate(raw_headers, start=1)
        if 'DATE' in col.upper() or col in [
            'Actual Released Date', 'Planned Start Date', 'Initial Otif Date',
            'Created On', 'TECO Date', 'Req. Date (MB25)', 'Req. Date (ZCKASSET57)', 'WO Otif Date'
        ]
    ]
    qty_issued_col_idx = raw_headers.index('Qty Issued (MB51)') + 1 if 'Qty Issued (MB51)' in raw_headers else None
    outstanding_col_idx = raw_headers.index('Outstanding Qty') + 1 if 'Outstanding Qty' in raw_headers else None
    status_col_idx = raw_headers.index('Part Issue Status') + 1 if 'Part Issue Status' in raw_headers else None

    # Tulis seluruh baris
    for r_idx, row in enumerate(dataframe_to_rows(df_raw_export, index=False, header=True), start=1):
        ws_raw.append(row)
        if r_idx == 1:
            ws_raw.row_dimensions[1].height = 22
            for col_idx in range(1, len(row) + 1):
                c = ws_raw.cell(row=1, column=col_idx)
                c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
                c.fill = PatternFill(start_color="334155", end_color="334155", fill_type="solid")
                c.alignment = Alignment(horizontal="center", vertical="center")
        else:
            for c_idx in date_col_indices:
                cell = ws_raw.cell(row=r_idx, column=c_idx)
                if cell.value:
                    d_val = to_excel_date(cell.value)
                    if d_val:
                        cell.value = d_val
                        cell.number_format = 'DD/MM/YYYY'
                        cell.alignment = Alignment(horizontal="center")
            if qty_issued_col_idx:
                c_q = ws_raw.cell(row=r_idx, column=qty_issued_col_idx)
                c_q.number_format = '#,##0.00'
                c_q.alignment = Alignment(horizontal="right")
            if outstanding_col_idx:
                c_o = ws_raw.cell(row=r_idx, column=outstanding_col_idx)
                c_o.number_format = '#,##0.00'
                c_o.alignment = Alignment(horizontal="right")
            if status_col_idx:
                c_s = ws_raw.cell(row=r_idx, column=status_col_idx)
                c_s.alignment = Alignment(horizontal="center")
                s_val = str(c_s.value)
                if s_val == 'Fully Issued':
                    c_s.fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
                    c_s.font = Font(name="Segoe UI", size=9, color="166534", bold=True)
                elif s_val == 'Partial':
                    c_s.fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
                    c_s.font = Font(name="Segoe UI", size=9, color="92400E", bold=True)
                elif s_val == 'Unissued':
                    c_s.fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
                    c_s.font = Font(name="Segoe UI", size=9, color="991B1B")

    for c_idx in range(1, min(len(raw_headers) + 1, 60)):
        col_letter = get_column_letter(c_idx)
        ws_raw.column_dimensions[col_letter].width = 16

    # Simpan File
    wb.save(output_file_path)
