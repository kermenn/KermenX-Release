# -*- coding: utf-8 -*-
"""
CV Builder ATS Helper Module for KermenX Enterprise Desktop Suite.
Generates 100% pixel-perfect, ATS-compliant Curriculum Vitae PDFs locally and offline.
Zero external cloud or network requests.
"""

import os
import sys
import json
import tempfile
import subprocess
import shutil

# Default reference data extracted directly from Yusril Irgi Wafir-resume (3).pdf
DEFAULT_CV_DATA = {
    "profile": {
        "name": "YUSRIL IRGI WAFIR",
        "email": "yusrilirgi@gmail.com",
        "linkedin": "https://www.linkedin.com/in/irgiwafir/",
        "location": "South Kalimantan, Indonesia",
        "summary": "Industrial Engineering graduate and Parts & Operations Specialist with 3.5+ years of experience within the Caterpillar dealer network (PT Trakindo Utama). Proven track record in counter parts sales, customer service, demand forecasting, and inventory optimization using CAT webSIS 2.0 and SAP/DBS systems. Adept at managing backorders, resolving parts inquiries, and maintaining backlogs below 10%. Seeking to leverage Caterpillar product knowledge and operational expertise."
    },
    "workExperiences": [
        {
            "company": "PT Trakindo Utama",
            "location": "South Kalimantan, Indonesia",
            "title": "Parts Analyst",
            "period": "Jan 2026 - Present",
            "bullets": [
                "**Operations & Inventory Analysis:** Analyzed performance metrics across Counter, Inventory, and Warehouse operations (e.g., OTIF, inventory turnover, forecast accuracy, GIT, and RMA acceptance) to drive continuous process improvement.",
                "**Process Improvement & Action Plan:** Identified operational bottlenecks and developed strategic action plans across departments to ensure key performance indicator (KPI) targets were met.",
                "**Cross-Functional Execution:** Monitored RMA, administered ASR, and collaborated with cross-functional teams to ensure timely resolution of operational discrepancies."
            ]
        },
        {
            "company": "PT Trakindo Utama",
            "location": "South Kalimantan, Indonesia",
            "title": "Counter Parts",
            "period": "Aug 2022 - Dec 2025",
            "bullets": [
                "**Backlog & Issue Resolution:** Maintained part order backlog below 10% and consistently resolved outstanding GINI cases within a 7-day target.",
                "**Demand Forecasting:** Improved parts forecast accuracy to >60% using SAP and Excel to analyze demand trends and simulate order scenarios.",
                "**Parts Sourcing & Order Execution:** Processed and expedited emergency/global backorders across Caterpillar and Trakindo branches, leveraging webSIS 2.0 and SAP for alternative parts identification.",
                "**Reporting & Customer Support:** Issued daily order status and ETA reports to ensure clear communication and timeline transparency for customers."
            ]
        },
        {
            "company": "PT Indonesia Asahan Aluminium (INALUM)",
            "location": "Kuala Tanjung, Indonesia",
            "title": "Procurement Service Intern",
            "period": "Mar 2021 - Jun 2021",
            "bullets": [
                "**End-to-End Procurement Support:** Managed PR processing and RFx follow-ups for mechanical, electrical, construction, and general services procurement.",
                "**Tender & Commercial Evaluation:** Participated in aanwijzing, technical/business evaluations, and commercial negotiations, assessing vendor BoQs to establish accurate Owner's Estimates (HPS).",
                "**Process Optimization & Innovation:** Developed a KBLI database website to streamline vendor capability assessments and accelerate partner evaluation for the procurement team."
            ]
        },
        {
            "company": "PT Indosat Ooredoo Hutchison",
            "location": "Maros, Sulawesi Selatan, Indonesia",
            "title": "Distribution and Marketing Intern",
            "period": "Aug 2020 - Feb 2021",
            "bullets": [
                "Provided education related to AVA (Availability, Visibility, Advocacy) to 346 partner outlets.",
                "Mapped 100 potential partner outlets using Google My Maps.",
                "Conducted audits of fraudulent outlets at MC Maros.",
                "Found and educated potential partner outlets as many as 35 outlets.",
                "Installed branding as many as 200 location points in the Maros Micro Cluster covering Maros, Pangkep and Barru districts.",
                "Created and launched a local marketing campaign targeting 100+ daily users."
            ]
        }
    ],
    "educations": [
        {
            "institution": "University of Hasanuddin",
            "location": "Gowa, South Sulawesi, Indonesia",
            "degree": "Bachelor of Industrial Engineering, 3.49/4.00",
            "period": "Aug 2017 - Dec 2021",
            "bullets": [
                "2021- Final project of thesis \"Perencanaan perawatan mesin dengan metode reliability engineering dan maintenance value stream mapping (mvsm)\" supervised by Dr.Eng.Farid Mardin,MT.,M.Sc. and Nurfaidah Tahir,ST.,MT.",
                "2021 - Research at PT Harapan Jaya Multi Bisnis",
                "2021 - Joined the ASIIN international accreditation team in Mechatronics and PPIC 2 courses"
            ]
        }
    ],
    "organisations": [
        {
            "organisation": "Himpunan Mahasiswa Teknik Industri (HMTI FT-UH) - Faculty of Engineering at Hasanuddin University",
            "role": "Member",
            "period": "Dec 2017 - May 2021",
            "bullets": [
                "Chairman of the committee in MIHRAB activities",
                "Chairman of the steering committee in ISRA activities",
                "Security Coordinator at MHMTI IV"
            ]
        },
        {
            "organisation": "Industrial Systems Engineering and Optimization Laboratory - Industrial Engineering Department",
            "role": "Assistant Coordinator",
            "period": "Mar 2020 - May 2021",
            "bullets": [
                "Assisted lecturers with research projects",
                "Designed and implemented project logistics simulations (Beer Game).",
                "Delivered training on industrial simulation tools, including Arena Simulation."
            ]
        },
        {
            "organisation": "Ikatan Pemuda Pelajar Mahasiswa Pangkep Unversitas Hasanuddin (IPPMP-UH)",
            "role": "Presidium of Congress XI",
            "period": "Jan 2019 - Apr 2019",
            "bullets": [
                "Lead the deliberation process starting from the end of the term of office of the chairman of the executive board and deliberation council until the election of a new chairman of the executive board and a new chairman of the deliberative council"
            ]
        }
    ],
    "skillsAndOthers": [
        {
            "category": "Projects (2026)",
            "text": "Developed AndroHeld, Mobile Android app integrated with OCR scanner and offline caching to optimize inventory tracking, quality control, and stock audit workflows."
        },
        {
            "category": "Development Program (2025)",
            "text": "Parts Analyst Development Program Batch 9"
        },
        {
            "category": "Training Attended (2023)",
            "text": "Product Knowledge - Parts Induction 1 ; SAP Counter - Monitor & Solving Outstanding Report ; Using Parts Literatur"
        },
        {
            "category": "Training Attended (2024)",
            "text": "Customer Experience ; Basic SHE ; House Keeping - 5S ; Product Knowledge - Parts Induction 2"
        },
        {
            "category": "Achievements (2019)",
            "text": "Awardee Van Deventeer Maas Indonesia Scholarship"
        },
        {
            "category": "Driver’s License",
            "text": "SIM A (for minibus/car driver license) & SIM C (for motorcycle driver license)"
        },
        {
            "category": "Technical Skills",
            "text": "Python (beginner) \u2022 Microsoft Excel (Advanced) \u2022 SAP ECC \u2022 webSIS 2.0 \u2022 Data Reporting & Visualization \u2022 Forecasting & Inventory Planning \u2022 Reliability Analyst"
        },
        {
            "category": "Achievements (2018)",
            "text": "Awardee Rumah Kepemimpinan Scholarship Regional Makassar"
        }
    ]
}


def find_headless_browser():
    """Locate local Chromium / Chrome / Edge executable for offline PDF rendering."""
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    ]
    
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    if local_app_data:
        candidates.append(os.path.join(local_app_data, r"Google\Chrome\Application\chrome.exe"))
        candidates.append(os.path.join(local_app_data, r"Microsoft\Edge\Application\msedge.exe"))

    program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    edge_core_base = os.path.join(program_files_x86, r"Microsoft\EdgeCore")
    if os.path.exists(edge_core_base):
        for root, dirs, files in os.walk(edge_core_base):
            if "msedge.exe" in files:
                candidates.insert(0, os.path.join(root, "msedge.exe"))
                break

    for path in candidates:
        if os.path.isfile(path):
            return path

    which_chrome = shutil.which("chrome")
    if which_chrome and os.path.isfile(which_chrome):
        return which_chrome
    
    which_edge = shutil.which("msedge")
    if which_edge and os.path.isfile(which_edge):
        return which_edge

    return None


def format_bullet_text(text):
    """
    Format bullet markdown bold syntax like '**Topic:** Description'
    into clean HTML '<b>Topic:</b> Description'.
    """
    if not text:
        return ""
    text = str(text).strip()
    if text.startswith("**") and ":**" in text:
        parts = text.split(":**", 1)
        topic = parts[0].replace("**", "").strip()
        rest = parts[1].strip()
        return f"<b>{topic}:</b> {rest}"
    elif "**" in text:
        parts = text.split("**")
        result = []
        is_bold = False
        for part in parts:
            if is_bold:
                result.append(f"<b>{part}</b>")
            else:
                result.append(part)
            is_bold = not is_bold
        return "".join(result)
    return text


def build_resume_html(data):
    """
    Constructs 100% pixel-perfect HTML that matches the exact layout,
    margins (20pt), fonts (Arial 18pt/12pt/9pt), and rule lines of
    the reference ATS resume.
    """
    profile = data.get("profile", {})
    work_exps = data.get("workExperiences", [])
    educations = data.get("educations", [])
    organisations = data.get("organisations", [])
    skills = data.get("skillsAndOthers", [])

    name = profile.get("name", "YUSRIL IRGI WAFIR").upper()
    email = profile.get("email", "")
    linkedin = profile.get("linkedin", "")
    location = profile.get("location", "")
    summary = profile.get("summary", "")

    # Work Experiences HTML (Auto-grouping consecutive roles under same company - Option 1)
    grouped_exps = []
    for exp in work_exps:
        comp = (exp.get("company") or "").strip()
        loc = (exp.get("location") or "").strip()
        title = (exp.get("title") or "").strip()
        period = (exp.get("period") or "").strip()
        bullets = exp.get("bullets", [])

        if grouped_exps and (not comp or comp.lower() == grouped_exps[-1]["company"].lower()):
            if not loc:
                loc = grouped_exps[-1]["location"]
            grouped_exps[-1]["roles"].append({
                "title": title,
                "period": period,
                "bullets": bullets
            })
        else:
            grouped_exps.append({
                "company": comp,
                "location": loc,
                "roles": [{
                    "title": title,
                    "period": period,
                    "bullets": bullets
                }]
            })

    work_html = []
    for grp in grouped_exps:
        comp = grp.get("company", "")
        loc = grp.get("location", "")
        roles = grp.get("roles", [])
        if loc:
            comp_header_html = f"<b>{comp}</b><span class=\"entry-loc-muted\"> - {loc}</span>"
        else:
            comp_header_html = f"<b>{comp}</b>"

        if len(roles) == 1:
            # Single role at company: standard single-role format
            r = roles[0]
            b_items = "".join([f"<li>{format_bullet_text(b)}</li>" for b in r.get("bullets", []) if str(b).strip()])
            work_html.append(f"""
        <div class="entry">
            <div class="entry-header">
                <div class="entry-title-left">{comp_header_html}</div>
                <div class="entry-date-right">{r.get('period', '')}</div>
            </div>
            <div class="entry-sub"><i>{r.get('title', '')}</i></div>
            <ul class="bullet-list">
                {b_items}
            </ul>
        </div>
        """)
        else:
            # Multi-role at company (Option 1): company name displayed once, role title + period on each role
            roles_html = []
            for idx, r in enumerate(roles):
                b_items = "".join([f"<li>{format_bullet_text(b)}</li>" for b in r.get("bullets", []) if str(b).strip()])
                spacing_style = "margin-top: 2pt;" if idx == 0 else "margin-top: 5pt;"
                roles_html.append(f"""
            <div class="role-entry" style="{spacing_style}">
                <div class="entry-header">
                    <div class="entry-sub" style="margin: 0;"><i>{r.get('title', '')}</i></div>
                    <div class="entry-date-right">{r.get('period', '')}</div>
                </div>
                <ul class="bullet-list">
                    {b_items}
                </ul>
            </div>
            """)

            inner_roles = "".join(roles_html)
            work_html.append(f"""
        <div class="entry company-group">
            <div class="entry-header">
                <div class="entry-title-left">{comp_header_html}</div>
            </div>
            {inner_roles}
        </div>
        """)

    # Educations HTML
    edu_html = []
    for edu in educations:
        inst = edu.get("institution", "")
        loc = edu.get("location", "")
        deg = edu.get("degree", "")
        period = edu.get("period", "")
        bullets = edu.get("bullets", [])

        if loc:
            edu_header_html = f"<b>{inst}</b><span class=\"entry-loc-muted\"> - {loc}</span>"
        else:
            edu_header_html = f"<b>{inst}</b>"
        b_items = "".join([f"<li>{format_bullet_text(b)}</li>" for b in bullets if str(b).strip()])

        edu_html.append(f"""
        <div class="entry">
            <div class="entry-header">
                <div class="entry-title-left">{edu_header_html}</div>
                <div class="entry-date-right">{period}</div>
            </div>
            <div class="entry-sub"><i>{deg}</i></div>
            <ul class="bullet-list">
                {b_items}
            </ul>
        </div>
        """)

    # Organisations HTML
    org_html = []
    for org in organisations:
        org_name = org.get("organisation", "")
        role = org.get("role", "")
        period = org.get("period", "")
        bullets = org.get("bullets", [])

        if " - " in org_name:
            p = org_name.split(" - ", 1)
            org_header_html = f"<b>{p[0]}</b><span class=\"entry-loc-muted\"> - {p[1]}</span>"
        else:
            org_header_html = f"<b>{org_name}</b>"

        b_items = "".join([f"<li>{format_bullet_text(b)}</li>" for b in bullets if str(b).strip()])

        org_html.append(f"""
        <div class="entry">
            <div class="entry-header">
                <div class="entry-title-left">{org_header_html}</div>
                <div class="entry-date-right">{period}</div>
            </div>
            <div class="entry-sub"><i>{role}</i></div>
            <ul class="bullet-list">
                {b_items}
            </ul>
        </div>
        """)

    # Skills, Achievements & Other Experience HTML
    skill_html = []
    for sk in skills:
        cat = sk.get("category", "").strip()
        txt = sk.get("text", "").strip()
        if not cat and not txt:
            continue
        if cat:
            item_content = f"<b>{cat}:</b> {txt}" if txt else f"<b>{cat}</b>"
        else:
            item_content = txt
        skill_html.append(f"<li>{item_content}</li>")

    contact_parts = []
    if email:
        contact_parts.append(f'<a href="mailto:{email}">{email}</a>')
    if linkedin:
        contact_parts.append(f'<a href="{linkedin}">{linkedin}</a>')
    contact_line = " | ".join(contact_parts)
    if contact_line:
        contact_line = f"| {contact_line}"

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{name} - Resume</title>
<style>
    @page {{
        size: A4;
        margin: 30pt 36pt 30pt 36pt;
    }}
    * {{
        box-sizing: border-box;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }}
    body {{
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
        font-size: 9.5pt;
        color: #000000;
        line-height: 1.32;
        margin: 0;
        padding: 0;
        background-color: #FFFFFF;
    }}
    a {{
        color: #757575;
        text-decoration: none;
    }}
    .header {{
        margin-bottom: 8pt;
    }}
    .name {{
        font-size: 19pt;
        font-weight: bold;
        line-height: 1.1;
        margin: 0 0 3pt 0;
        color: #000000;
    }}
    .contacts {{
        font-size: 9pt;
        line-height: 1.25;
        margin-bottom: 2pt;
        color: #757575;
    }}
    .contacts a {{
        color: #757575;
        text-decoration: none;
    }}
    .location {{
        font-size: 9pt;
        line-height: 1.25;
        margin-bottom: 5pt;
        color: #757575;
    }}
    .entry-loc-muted {{
        color: #757575;
        font-weight: bold;
    }}
    .summary {{
        font-size: 9.5pt;
        line-height: 1.34;
        text-align: left;
        margin: 0 0 10pt 0;
    }}
    .section-title {{
        font-size: 11pt;
        font-weight: bold;
        margin-top: 9pt;
        margin-bottom: 2pt;
        color: #000000;
        page-break-after: avoid;
        break-after: avoid;
    }}
    .section-divider {{
        border-bottom: 1px solid #000000;
        width: 100%;
        margin-bottom: 5pt;
        page-break-after: avoid;
        break-after: avoid;
    }}
    .entry {{
        margin-bottom: 7pt;
        page-break-inside: avoid;
        break-inside: avoid;
    }}
    .entry-header {{
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        width: 100%;
    }}
    .entry-title-left {{
        font-size: 9.5pt;
        font-weight: bold;
        text-align: left;
        flex: 1;
        padding-right: 10pt;
    }}
    .entry-date-right {{
        font-size: 9.5pt;
        font-weight: normal;
        text-align: right;
        white-space: nowrap;
    }}
    .entry-sub {{
        font-size: 9.5pt;
        font-style: italic;
        margin-top: 1pt;
        margin-bottom: 2pt;
    }}
    .bullet-list {{
        margin: 0;
        padding-left: 14pt;
        list-style-type: disc;
    }}
    .bullet-list li {{
        font-size: 9.5pt;
        line-height: 1.32;
        margin-bottom: 2pt;
        text-align: left;
    }}
    .skills-list {{
        margin: 0;
        padding-left: 14pt;
        list-style-type: disc;
    }}
    .skills-list li {{
        font-size: 9.5pt;
        line-height: 1.32;
        margin-bottom: 2pt;
        text-align: left;
    }}
</style>
</head>
<body>

    <!-- Header & Summary -->
    <div class="header">
        <div class="name">{name}</div>
        <div class="contacts">{contact_line}</div>
        <div class="location">{location}</div>
        <div class="summary">{summary}</div>
    </div>

    <!-- Work Experiences -->
    <div class="section-title">Work Experiences</div>
    <div class="section-divider"></div>
    {"".join(work_html)}

    <!-- Education Level -->
    <div class="section-title">Education Level</div>
    <div class="section-divider"></div>
    {"".join(edu_html)}

    <!-- Organisational Experience -->
    <div class="section-title">Organisational Experience</div>
    <div class="section-divider"></div>
    {"".join(org_html)}

    <!-- Skills, Achievements & Other Experience -->
    <div class="section-title">Skills, Achievements &amp; Other Experience</div>
    <div class="section-divider"></div>
    <ul class="skills-list">
        {"".join(skill_html)}
    </ul>

</body>
</html>
"""
    return html_content


def generate_cv_pdf(data=None, output_path=None, preview=False):
    """
    Generates ATS PDF resume from provided CV data dictionary.
    Runs 100% locally and offline via headless Chromium.
    """
    if data is None:
        data = DEFAULT_CV_DATA

    # Resolve output path
    if not output_path:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        out_dir = os.path.join(base_dir, "output", "09_CV_ATS")
        os.makedirs(out_dir, exist_ok=True)
        name_sanitized = data.get("profile", {}).get("name", "Resume").replace(" ", "_")
        output_path = os.path.join(out_dir, f"{name_sanitized}_ATS.pdf")
    else:
        out_dir = os.path.dirname(output_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

    browser = find_headless_browser()
    if not browser:
        return {
            "success": False,
            "error": "Tidak ditemukan browser Chromium/Chrome/Edge lokal untuk kompilasi PDF."
        }

    # Generate HTML content
    html_code = build_resume_html(data)

    temp_html = os.path.join(tempfile.gettempdir(), f"kermenx_cv_{os.getpid()}.html")
    try:
        with open(temp_html, "w", encoding="utf-8") as f:
            f.write(html_code)

        # Chrome/Edge headless flags for exact print-to-pdf
        cmd = [
            browser,
            "--headless=new",
            "--disable-gpu",
            "--no-pdf-header-footer",
            "--run-all-compositor-stages-before-draw",
            f"--print-to-pdf={output_path}",
            temp_html
        ]

        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        
        if not os.path.isfile(output_path) or os.path.getsize(output_path) == 0:
            return {
                "success": False,
                "error": f"Gagal menghasilkan PDF. Return code: {result.returncode}, Stderr: {result.stderr.decode('utf-8', errors='ignore')}"
            }

        if preview and os.path.exists(output_path):
            try:
                os.startfile(output_path)
            except Exception:
                pass

        return {
            "success": True,
            "pdf_path": output_path,
            "file_size": os.path.getsize(output_path),
            "message": f"CV ATS berhasil dicetak ke: {output_path}"
        }

    finally:
        if os.path.exists(temp_html):
            try:
                os.remove(temp_html)
            except Exception:
                pass


def get_default_data():
    """Return default reference data."""
    return DEFAULT_CV_DATA
