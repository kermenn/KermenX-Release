@echo off
cd /d "%~dp0app"
title KermenX
start "" "%~dp0app\KermenX.exe"
exit
