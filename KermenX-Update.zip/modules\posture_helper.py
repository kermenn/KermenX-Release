"""
Module: posture_helper.py
Khusus pengolahan data Inventory Parts Posture berskala besar (FTP / Regional).
Membaca file raksasa (ratusan MB) menggunakan engine calamine super cepat,
memfilter berdasarkan Plant (bisa All Plant atau spesifik kode plant),
membersihkan format teks .000,
dan menyusun Dashboard Executive Posture (Health, Excess, Deadstock, Obsolete).
"""
import os
import time
import pandas as pd
import numpy as np
from python_calamine import CalamineWorkbook
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

def process_posture_excel(input_file_path, target_plant="1346", output_file_path=None, status_callback=None, progress_callback=None):
    """
    Mengekstrak dan mengolah file Inventory Posture Regional:
    - Input: File Posture raksasa (~440 MB, 600k baris, 176 kolom).
    - Filter: 
        * Jika target_plant = 'ALL' / 'ALL PLANT' / None / '': Mengekstrak seluruh data plant (All Plant).
        * Jika target_plant diisi kode tertentu (e.g. '1346'): Memfilter baris untuk plant tersebut.
    - Kolom: Kolom esensial (Identitas, Stok, dan Kategori Posture).
    - Pembersihan: Konversi format teks .000 menjadi angka float murni.
    - Output: File Excel dengan Sheet 'Summary Posture' dan 'Data Posture'.
    """
    def log(msg):
        print(msg)
        if status_callback:
            status_callback(msg)

    def set_progress(pct, msg):
        log(msg)
        if progress_callback:
            try:
                progress_callback(pct, msg)
            except Exception:
                pass

    if not os.path.exists(input_file_path):
        raise FileNotFoundError(f"File tidak ditemukan: {input_file_path}")

    target_str = str(target_plant).strip() if target_plant is not None else ""
    is_all_plant = (
        not target_str or
        target_str.upper() in ["ALL", "ALL PLANT", "ALL PLANTS", "SEMUA", "*"]
    )
    plant_display = "ALL PLANTS" if is_all_plant else target_str

    if output_file_path is None:
        dir_name = os.path.dirname(input_file_path)
        base_name = os.path.splitext(os.path.basename(input_file_path))[0]
        if is_all_plant:
            output_file_path = os.path.join(dir_name, f"{base_name} - ALL PLANT CLEAN.xlsx")
        else:
            output_file_path = os.path.join(dir_name, f"{base_name} - PLANT {target_str} CLEAN.xlsx")

    # Handle jika file target sedang dibuka di aplikasi Excel
    if os.path.exists(output_file_path):
        try:
            with open(output_file_path, "a"):
                pass
        except PermissionError:
            dir_name = os.path.dirname(output_file_path)
            base_name, ext = os.path.splitext(os.path.basename(output_file_path))
            output_file_path = os.path.join(dir_name, f"{base_name} ({time.strftime('%H%M%S')}){ext}")
            log(f"Perhatian: File target sedang dibuka di Excel. Menyimpan ke: {os.path.basename(output_file_path)}")

    set_progress(5, f"[1/6] Membuka file Posture raksasa (~445 MB): {os.path.basename(input_file_path)}...")
    set_progress(8, "  -> Membaca struktur file dengan engine Calamine (tahap dekompresi XML, mohon tunggu beberapa saat)...")
    t0 = time.time()
    wb_calamine = CalamineWorkbook.from_path(input_file_path)
    sheet_name = wb_calamine.sheet_names[0]
    sheet_data = wb_calamine.get_sheet_by_name(sheet_name)
    
    total_file_rows = getattr(sheet_data, 'height', 0)
    total_file_cols = getattr(sheet_data, 'width', 0)
    set_progress(15, f"[2/6] Struktur file terdeteksi: {total_file_rows:,} baris x {total_file_cols} kolom. Mengurai data...")

    data_iter = sheet_data.to_python()
    headers = [str(h).strip() for h in data_iter[0]]
    set_progress(25, f"[2/6] Header terbaca ({len(headers)} kolom). Menyiapkan pemetaan {len(headers)} kolom...")

    # Kolom penting yang akan diekstrak
    selected_columns = [
        'snapshot_date',
        'PANO', 'DESCRIPTION', 'PLANT', 'SLOC', 'VAL_TYPE', 'UOM',
        'ATP', 'OO', 'TOTAL', 'MIN', 'MAX', 'RSV', 'LC',
        'GR_DATE', 'SNSKI', 'DMD12',
        'excess_treshold_plant', 'max_excess_treshold_plant',
        'Stock_Status',
        'health_qty_plant', 'health_value_plant',
        'excess_qty_plant', 'excess_value_plant',
        'deadstock_qty_plant', 'deadstock_value_plant',
        'obsolete_qty_plant', 'obsolete_value_plant'
    ]

    col_aliases = {
        'excess_treshold_plant': ['excess_treshold_plant', 'excess_threshold_plant'],
        'max_excess_treshold_plant': ['max_excess_treshold_plant', 'max_excess_threshold_plant']
    }

    col_indices = {}
    for col in selected_columns:
        if col in headers:
            col_indices[col] = headers.index(col)
        elif col in col_aliases:
            found = False
            for alias in col_aliases[col]:
                if alias in headers:
                    col_indices[col] = headers.index(alias)
                    found = True
                    break
            if not found:
                log(f"Perhatian: Kolom '{col}' tidak ditemukan di file!")
        else:
            log(f"Perhatian: Kolom '{col}' tidak ditemukan di file!")

    if 'PLANT' not in col_indices:
        raise ValueError("Kolom 'PLANT' tidak ditemukan di dalam file!")

    plant_idx = col_indices['PLANT']
    actual_columns = [col for col in selected_columns if col in col_indices]
    filtered_rows = []

    def clean_cell_plant(v):
        if v is None:
            return ""
        s = str(v).strip()
        if s.endswith(".0"):
            s = s[:-2]
        return s

    set_progress(30, f"[3/6] Memulai filtering data untuk cakupan: {plant_display}...")
    total_to_scan = len(data_iter) - 1
    log_interval = max(50000, total_to_scan // 10) if total_to_scan > 0 else 50000

    if is_all_plant:
        for idx, row in enumerate(data_iter[1:], start=1):
            if idx % log_interval == 0 or idx == total_to_scan:
                scan_pct = int(30 + (idx / total_to_scan) * 25)
                set_progress(scan_pct, f"  -> [3/6] Ekstraksi All Plant: {idx:,} / {total_to_scan:,} baris ({idx*100//total_to_scan}%)... ({len(filtered_rows):,} baris valid)")
            p_val = clean_cell_plant(row[plant_idx])
            if p_val and p_val.lower() not in ["none", "nan", "null"]:
                filtered_row = [row[col_indices[col]] for col in actual_columns]
                filtered_rows.append(filtered_row)
    else:
        # Mendukung single plant (e.g. "1346") maupun comma-separated ("1346, 1347")
        targets = {p.strip().upper() for p in target_str.split(",") if p.strip()}
        for idx, row in enumerate(data_iter[1:], start=1):
            if idx % log_interval == 0 or idx == total_to_scan:
                scan_pct = int(30 + (idx / total_to_scan) * 25)
                set_progress(scan_pct, f"  -> [3/6] Scanning Plant {target_str}: {idx:,} / {total_to_scan:,} baris ({idx*100//total_to_scan}%)... Ditemukan: {len(filtered_rows):,} baris")
            p_val = clean_cell_plant(row[plant_idx]).upper()
            if p_val in targets:
                filtered_row = [row[col_indices[col]] for col in actual_columns]
                filtered_rows.append(filtered_row)

    total_extracted = len(filtered_rows)
    set_progress(58, f"[3/6] Ekstraksi selesai! Berhasil mengumpulkan {total_extracted:,} baris cocok ({time.time()-t0:.1f}s).")

    if total_extracted == 0:
        if is_all_plant:
            raise ValueError("Tidak ada data yang ditemukan di dalam file Posture!")
        else:
            raise ValueError(f"Tidak ada data yang ditemukan untuk Plant '{target_str}'. Periksa kembali kode plant!")

    # Buat DataFrame
    set_progress(60, f"[4/6] Menyusun tabel & mengonversi format teks .000 menjadi numerik murni...")
    df = pd.DataFrame(filtered_rows, columns=actual_columns)
    if 'PLANT' in df.columns:
        df['PLANT'] = df['PLANT'].astype(str).str.strip().str.replace(r'\.0$', '', regex=True)

    numeric_cols = [
        'ATP', 'OO', 'TOTAL', 'MIN', 'MAX', 'RSV', 'LC',
        'DMD12', 'excess_treshold_plant', 'max_excess_treshold_plant',
        'health_qty_plant', 'health_value_plant',
        'excess_qty_plant', 'excess_value_plant',
        'deadstock_qty_plant', 'deadstock_value_plant',
        'obsolete_qty_plant', 'obsolete_value_plant'
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0)
    set_progress(65, "  -> Pembersihan format numerik selesai.")

    set_progress(68, "[5/6] Mengkalkulasi Pivot Posture (Health, Excess, Deadstock, Obsolete)...")
    health_qty = df['health_qty_plant'].sum()
    health_val = df['health_value_plant'].sum()
    excess_qty = df['excess_qty_plant'].sum()
    excess_val = df['excess_value_plant'].sum()
    deadstock_qty = df['deadstock_qty_plant'].sum()
    deadstock_val = df['deadstock_value_plant'].sum()
    obsolete_qty = df['obsolete_qty_plant'].sum()
    obsolete_val = df['obsolete_value_plant'].sum()

    total_posture_val = health_val + excess_val + deadstock_val + obsolete_val
    total_posture_qty = health_qty + excess_qty + deadstock_qty + obsolete_qty

    # Agregasi Pivot per Plant (khusus All Plant)
    pivot_plant_df = pd.DataFrame()
    if is_all_plant and 'PLANT' in df.columns:
        log("  -> Menyusun ringkasan Pivot Posture per Plant...")
        pivot_plant_df = df.groupby('PLANT').agg(
            Total_Items=('PANO', 'count'),
            Total_ATP=('ATP', 'sum'),
            Health_Val=('health_value_plant', 'sum'),
            Excess_Val=('excess_value_plant', 'sum'),
            Deadstock_Val=('deadstock_value_plant', 'sum'),
            Obsolete_Val=('obsolete_value_plant', 'sum')
        ).reset_index()
        pivot_plant_df['Total_Value'] = (
            pivot_plant_df['Health_Val'] +
            pivot_plant_df['Excess_Val'] +
            pivot_plant_df['Deadstock_Val'] +
            pivot_plant_df['Obsolete_Val']
        )
        pivot_plant_df = pivot_plant_df.sort_values(by='Total_Value', ascending=False).reset_index(drop=True)
        pivot_plant_df.rename(columns={'PLANT': 'Plant'}, inplace=True)

    # Agregasi Pivot per Val. Type
    pivot_vt_df = pd.DataFrame()
    if 'VAL_TYPE' in df.columns:
        log("  -> Menyusun ringkasan Pivot Posture per Val. Type...")
        df['VAL_TYPE'] = df['VAL_TYPE'].astype(str).str.strip()
        pivot_vt_df = df.groupby('VAL_TYPE').agg(
            Total_Items=('PANO', 'count'),
            Total_ATP=('ATP', 'sum'),
            Health_Val=('health_value_plant', 'sum'),
            Excess_Val=('excess_value_plant', 'sum'),
            Deadstock_Val=('deadstock_value_plant', 'sum'),
            Obsolete_Val=('obsolete_value_plant', 'sum')
        ).reset_index()
        pivot_vt_df['Total_Value'] = (
            pivot_vt_df['Health_Val'] +
            pivot_vt_df['Excess_Val'] +
            pivot_vt_df['Deadstock_Val'] +
            pivot_vt_df['Obsolete_Val']
        )
        pivot_vt_df = pivot_vt_df.sort_values(by='Total_Value', ascending=False).reset_index(drop=True)
        pivot_vt_df.rename(columns={'VAL_TYPE': 'Val. Type'}, inplace=True)

    sheet_data_name = "Data Posture ALL" if is_all_plant else f"Data Posture {target_str}"[:31]
    set_progress(75, f"[6/6] Menyiapkan penulisan file Excel ke: {os.path.basename(output_file_path)}...")
    if total_extracted > 50000:
        set_progress(78, f"  -> Perhatian: Data berukuran besar ({total_extracted:,} baris). Penulisan Excel sedang berlangsung di memori, mohon ditunggu...")

    with pd.ExcelWriter(output_file_path, engine='openpyxl') as writer:
        set_progress(82, f"  -> [6/6] Menulis sheet data '{sheet_data_name}' ({total_extracted:,} baris x {len(actual_columns)} kolom)...")
        df.to_excel(writer, sheet_name=sheet_data_name, index=False)
        wb = writer.book

        set_progress(90, "  -> [6/6] Sheet data selesai ditulis. Menyusun Dashboard 'Summary Posture' & KPI Cards...")
        ws_summary = wb.create_sheet(title='Summary Posture', index=0)
        ws_summary.views.sheetView[0].showGridLines = True
        wb.active = ws_summary

        # Styling Palette
        navy_dark = "1E3A8A"
        blue_header = "2563EB"
        green_card = "059669"
        green_light = "ECFDF5"
        yellow_card = "D97706"
        yellow_light = "FFFBEB"
        red_card = "DC2626"
        red_light = "FEF2F2"
        gray_card = "4B5563"
        gray_light = "F3F4F6"
        gray_border = "D1D5DB"
        gray_total = "E2E8F0"

        font_title = Font(name="Segoe UI", size=16, bold=True, color="FFFFFF")
        font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
        font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
        font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
        font_kpi_val = Font(name="Segoe UI", size=13, bold=True, color="1F2937")
        font_tbl_hdr = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
        font_tbl_body = Font(name="Segoe UI", size=9)
        font_tbl_total = Font(name="Segoe UI", size=9, bold=True, color="1F2937")

        fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
        fill_tbl_hdr = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
        fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")

        thin_border = Border(
            left=Side(style='thin', color=gray_border),
            right=Side(style='thin', color=gray_border),
            top=Side(style='thin', color=gray_border),
            bottom=Side(style='thin', color=gray_border)
        )
        total_border = Border(
            top=Side(style='thin', color="4B5563"),
            bottom=Side(style='double', color="4B5563"),
            left=Side(style='thin', color=gray_border),
            right=Side(style='thin', color=gray_border)
        )

        # 1. HEADER BANNER (Baris 2-3)
        ws_summary.merge_cells("B2:J2")
        title_banner = f"INVENTORY POSTURE DASHBOARD — {'ALL PLANTS' if is_all_plant else f'PLANT {plant_display}'}"
        ws_summary["B2"] = title_banner
        ws_summary["B2"].font = font_title
        ws_summary["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

        ws_summary.merge_cells("B3:J3")
        ws_summary["B3"] = f"Generated Date: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  Source: {os.path.basename(input_file_path)}  |  Total Data: {total_extracted:,} items"
        ws_summary["B3"].font = font_sub
        ws_summary["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

        for r in range(2, 4):
            for c in range(2, 11):
                ws_summary.cell(row=r, column=c).fill = fill_banner

        # 2. KPI CARDS (Baris 5-7): 4 Kategori Posture
        kpi_defs = [
            ("🟢 HEALTH STOCK", green_card, PatternFill(start_color=green_light, end_color=green_light, fill_type="solid"),
             health_val, health_qty, (health_val/total_posture_val if total_posture_val>0 else 0), 2),
            ("🟡 EXCESS STOCK", yellow_card, PatternFill(start_color=yellow_light, end_color=yellow_light, fill_type="solid"),
             excess_val, excess_qty, (excess_val/total_posture_val if total_posture_val>0 else 0), 4),
            ("🔴 DEADSTOCK", red_card, PatternFill(start_color=red_light, end_color=red_light, fill_type="solid"),
             deadstock_val, deadstock_qty, (deadstock_val/total_posture_val if total_posture_val>0 else 0), 6),
            ("⚫ OBSOLETE", gray_card, PatternFill(start_color=gray_light, end_color=gray_light, fill_type="solid"),
             obsolete_val, obsolete_qty, (obsolete_val/total_posture_val if total_posture_val>0 else 0), 8)
        ]

        for title, col_text, fill_c, val, qty, pct, c_start in kpi_defs:
            c_end = c_start + 1
            ws_summary.merge_cells(start_row=5, start_column=c_start, end_row=5, end_column=c_end)
            cell_hdr = ws_summary.cell(row=5, column=c_start, value=title)
            cell_hdr.font = Font(name="Segoe UI", size=9, bold=True, color=col_text)
            cell_hdr.fill = fill_c

            ws_summary.cell(row=6, column=c_start, value="Value:").font = font_kpi_label
            ws_summary.cell(row=6, column=c_start).fill = fill_c
            cell_v = ws_summary.cell(row=6, column=c_end, value=val)
            cell_v.font = font_kpi_val
            cell_v.number_format = "#,##0.00"
            cell_v.fill = fill_c

            ws_summary.cell(row=7, column=c_start, value="Qty / Share:").font = font_kpi_label
            ws_summary.cell(row=7, column=c_start).fill = fill_c
            cell_q = ws_summary.cell(row=7, column=c_end, value=f"{qty:,.0f} qty ({pct:.1%})")
            cell_q.font = Font(name="Segoe UI", size=9, bold=True, color="374151")
            cell_q.fill = fill_c

            for r in range(5, 8):
                for c in range(c_start, c_end + 1):
                    ws_summary.cell(row=r, column=c).border = thin_border

        # Card 5: TOTAL POSTURE OVERVIEW (Kolom J baris 5-7)
        ws_summary.cell(row=5, column=10, value="📊 TOTAL POSTURE").font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
        ws_summary.cell(row=5, column=10).fill = fill_banner
        ws_summary.cell(row=5, column=10).font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
        ws_summary.cell(row=6, column=10, value=total_posture_val).font = font_kpi_val
        ws_summary.cell(row=6, column=10).number_format = "#,##0.00"
        ws_summary.cell(row=7, column=10, value=f"{total_extracted:,} items | {total_posture_qty:,.0f} qty").font = Font(name="Segoe UI", size=8, bold=True, color="4B5563")

        for r in range(5, 8):
            ws_summary.cell(row=r, column=10).border = thin_border

        # Helper untuk merender tabel breakdown pivot
        def render_breakdown_table(ws, title_text, start_row, df_pivot, first_col_label):
            ws.cell(row=start_row, column=2, value=title_text).font = font_section

            h_row = start_row + 2
            tbl_headers = [
                first_col_label, "Total Items", "Total ATP Qty",
                "Health Value", "Excess Value", "Deadstock Value", "Obsolete Value",
                "Total Posture Value", "% Share"
            ]
            for i, h in enumerate(tbl_headers, start=2):
                c = ws.cell(row=h_row, column=i, value=h)
                c.font = font_tbl_hdr
                c.fill = fill_tbl_hdr
                c.alignment = Alignment(horizontal="center" if i != 2 else "left", vertical="center", wrap_text=True)
                c.border = thin_border

            curr_r = h_row + 1
            if not df_pivot.empty:
                for idx, r in df_pivot.iterrows():
                    vt = r[first_col_label]
                    items = r['Total_Items']
                    atp = r['Total_ATP']
                    h_v = r['Health_Val']
                    e_v = r['Excess_Val']
                    d_v = r['Deadstock_Val']
                    o_v = r['Obsolete_Val']
                    tot_v = r['Total_Value']
                    pct_s = tot_v / total_posture_val if total_posture_val > 0 else 0

                    row_vals = [
                        (vt, "@", "left"),
                        (items, "#,##0", "right"),
                        (atp, "#,##0.00", "right"),
                        (h_v, "#,##0.00", "right"),
                        (e_v, "#,##0.00", "right"),
                        (d_v, "#,##0.00", "right"),
                        (o_v, "#,##0.00", "right"),
                        (tot_v, "#,##0.00", "right"),
                        (pct_s, "0.0%", "right")
                    ]
                    fill_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid") if (idx % 2 == 1) else None

                    for col_i, (v, fmt, align) in enumerate(row_vals, start=2):
                        cell = ws.cell(row=curr_r, column=col_i, value=v)
                        cell.font = font_tbl_body
                        cell.number_format = fmt
                        cell.alignment = Alignment(horizontal=align, vertical="center")
                        cell.border = thin_border
                        if fill_alt:
                            cell.fill = fill_alt

                    curr_r += 1

                # GRAND TOTAL ROW
                data_start = h_row + 1
                data_end = curr_r - 1
                total_row_defs = [
                    ("GRAND TOTAL", "@", "left"),
                    (f"=SUM(C{data_start}:C{data_end})", "#,##0", "right"),
                    (f"=SUM(D{data_start}:D{data_end})", "#,##0.00", "right"),
                    (f"=SUM(E{data_start}:E{data_end})", "#,##0.00", "right"),
                    (f"=SUM(F{data_start}:F{data_end})", "#,##0.00", "right"),
                    (f"=SUM(G{data_start}:G{data_end})", "#,##0.00", "right"),
                    (f"=SUM(H{data_start}:H{data_end})", "#,##0.00", "right"),
                    (f"=SUM(I{data_start}:I{data_end})", "#,##0.00", "right"),
                    (1.0, "0.0%", "right")
                ]
                for col_i, (v, fmt, align) in enumerate(total_row_defs, start=2):
                    cell = ws.cell(row=curr_r, column=col_i, value=v)
                    cell.font = font_tbl_total
                    cell.number_format = fmt
                    cell.alignment = Alignment(horizontal=align, vertical="center")
                    cell.border = total_border
                    cell.fill = fill_total

                curr_r += 1

            return curr_r

        # 3. PIVOT BREAKDOWN
        next_r = 9
        if is_all_plant and not pivot_plant_df.empty:
            next_r = render_breakdown_table(
                ws_summary,
                "🏢 Breakdown Posture Value Berdasarkan Plant",
                start_row=next_r,
                df_pivot=pivot_plant_df,
                first_col_label="Plant"
            )
            next_r += 1  # Baris spasi antar tabel

        if not pivot_vt_df.empty:
            render_breakdown_table(
                ws_summary,
                "📊 Breakdown Posture Value Berdasarkan Valuation Type (Val. Type)",
                start_row=next_r,
                df_pivot=pivot_vt_df,
                first_col_label="Val. Type"
            )

        # Column widths
        col_w = {
            'A': 3, 'B': 16, 'C': 13, 'D': 15,
            'E': 18, 'F': 18, 'G': 18, 'H': 18,
            'I': 22, 'J': 14
        }
        for c_l, w in col_w.items():
            ws_summary.column_dimensions[c_l].width = w

        # Sheet Data Styling
        set_progress(95, "  -> [6/6] Mengaplikasikan styling visual (Palette Navy, Auto-filter, & Freeze Panes)...")
        ws_data = writer.sheets[sheet_data_name]
        ws_data.views.sheetView[0].showGridLines = True
        ws_data.freeze_panes = "A2"
        ws_data.auto_filter.ref = ws_data.dimensions

        for col in range(1, len(actual_columns) + 1):
            c = ws_data.cell(row=1, column=col)
            c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
            c.fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
            c.alignment = Alignment(horizontal="center", vertical="center")

        set_progress(98, "  -> [6/6] Melakukan kompresi & finalisasi penyimpanan file Excel...")

    elapsed_total = time.time() - t0
    set_progress(100, f"[SELESAI] Ekstraksi Posture sukses dalam {elapsed_total:.1f} detik ({elapsed_total/60:.1f} menit)!")
    log(f"  -> Total Data: {total_extracted:,} item part")
    log(f"  -> File Tersimpan: {output_file_path}")

    return {
        "output_path": output_file_path,
        "target_plant": "ALL" if is_all_plant else target_str,
        "plant": "ALL PLANTS" if is_all_plant else target_str,
        "total_items": total_extracted,
        "extracted_rows": total_extracted,
        "is_all_plant": is_all_plant,
        "health_val": health_val,
        "excess_val": excess_val,
        "deadstock_val": deadstock_val,
        "obsolete_val": obsolete_val,
        "total_posture_val": total_posture_val,
        "elapsed_time": time.time() - t0
    }


if __name__ == "__main__":
    test_f = r"D:\Users\yusril.i.wafir\Desktop\inventory_parts_posture_Southern Kalimantan_2026-09-28.xlsx"
    if os.path.exists(test_f):
        r = process_posture_excel(test_f, target_plant="ALL")
        print("Success:", r)
