"""
Module: settings_helper.py
Mengelola penyimpanan dan pemulihan status / input form terakhir aplikasi Kermen Tools
ke file kermen_settings.json, sehingga pengguna tidak perlu mengisi ulang form saat membuka kembali aplikasi.
"""
import os
import json
import base64
import config

SETTINGS_FILENAME = "kermen_settings.json"


def get_settings_file_path():
    """
    Mengembalikan path file settings JSON.
    Memprioritaskan folder dasar aplikasi (BASE_DIR).
    Fallback ke folder user (~/.kermen_tools) jika folder aplikasi read-only.
    """
    primary_path = os.path.join(config.BASE_DIR, SETTINGS_FILENAME)
    if os.path.exists(primary_path):
        return primary_path

    try:
        test_file = os.path.join(config.BASE_DIR, ".write_test")
        with open(test_file, "w", encoding="utf-8") as f:
            f.write("ok")
        os.remove(test_file)
        return primary_path
    except Exception:
        home_dir = os.path.join(os.path.expanduser("~"), ".kermen_tools")
        os.makedirs(home_dir, exist_ok=True)
        return os.path.join(home_dir, SETTINGS_FILENAME)


def _encode_secret(val):
    """Mengaburkan string rahasia (seperti password) dengan base64"""
    if not val:
        return ""
    try:
        encoded = base64.b64encode(str(val).encode("utf-8")).decode("utf-8")
        return f"b64:{encoded}"
    except Exception:
        return ""


def _decode_secret(val):
    """Mendekode string rahasia base64"""
    if not val or not isinstance(val, str):
        return ""
    if val.startswith("b64:"):
        try:
            return base64.b64decode(val[4:].encode("utf-8")).decode("utf-8")
        except Exception:
            return ""
    return val


def load_settings():
    """
    Membaca dan mengembalikan dictionary konfigurasi terakhir dari file JSON.
    Jika file belum ada atau kosong, mengembalikan dict kosong {}.
    """
    path = get_settings_file_path()
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)


        if not isinstance(data, dict):
            return {}

        # Dekode password jika ada
        if "sap" in data and isinstance(data["sap"], dict):
            sap_data = data["sap"]
            if "pass" in sap_data:
                sap_data["pass"] = _decode_secret(sap_data["pass"])
            if "saved_accounts" in sap_data and isinstance(sap_data["saved_accounts"], dict):
                decoded_accs = {}
                for u, p in sap_data["saved_accounts"].items():
                    decoded_accs[u] = _decode_secret(p)
                sap_data["saved_accounts"] = decoded_accs
            else:
                sap_data["saved_accounts"] = {}

            # Inisialisasi recent_users jika belum ada
            if "recent_users" not in sap_data or not isinstance(sap_data["recent_users"], list):
                init_users = []
                if sap_data.get("user"):
                    init_users.append(sap_data["user"])
                sap_data["recent_users"] = init_users

            # Pastikan user saat ini tersimpan di saved_accounts jika passwordnya ada
            cur_user = sap_data.get("user")
            cur_pass = sap_data.get("pass")
            if cur_user and cur_pass and cur_user not in sap_data["saved_accounts"]:
                sap_data["saved_accounts"][cur_user] = cur_pass

        return data
    except Exception as e:
        print(f"[Warning] Gagal membaca settings dari {path}: {e}")
        return {}


def save_settings(data):
    """
    Menyimpan dictionary state / konfigurasi ke file JSON.
    """
    if not isinstance(data, dict):
        return False
    path = get_settings_file_path()
    try:
        # Salin data agar tidak memodifikasi objek asli di memori
        save_data = json.loads(json.dumps(data))

        # Enkripsi password sebelum disimpan ke disk
        if "sap" in save_data and isinstance(save_data["sap"], dict):
            sap_data = save_data["sap"]
            if "pass" in sap_data:
                sap_data["pass"] = _encode_secret(sap_data["pass"])
            if "saved_accounts" in sap_data and isinstance(sap_data["saved_accounts"], dict):
                enc_accs = {}
                for u, p in sap_data["saved_accounts"].items():
                    enc_accs[u] = _encode_secret(p)
                sap_data["saved_accounts"] = enc_accs

        with open(path, "w", encoding="utf-8") as f:
            json.dump(save_data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"[Warning] Gagal menyimpan settings ke {path}: {e}")
        return False


def get_sap_user_history():
    """Mengembalikan list User ID SAP yang pernah digunakan sebelumnya"""
    settings = load_settings() or {}
    sap_data = settings.get("sap", {})
    return sap_data.get("recent_users", [])


def get_saved_sap_password(username):
    """Mengembalikan password yang tersimpan untuk User ID SAP tertentu"""
    if not username:
        return ""
    settings = load_settings() or {}
    sap_data = settings.get("sap", {})
    saved_accs = sap_data.get("saved_accounts", {})
    return saved_accs.get(str(username).strip(), "")


def remember_sap_account(username, password=""):
    """
    Menambahkan username ke daftar recent_users dan menyimpan passwordnya jika ada.
    Maksimal menyimpan 10 akun terakhir.
    """
    if not username:
        return
    username = str(username).strip()
    settings = load_settings() or {}
    if "sap" not in settings:
        settings["sap"] = {}

    sap_data = settings["sap"]
    recent = sap_data.get("recent_users", [])
    if username in recent:
        recent.remove(username)
    recent.insert(0, username)
    sap_data["recent_users"] = recent[:10]  # Maksimal 10 akun

    if "saved_accounts" not in sap_data:
        sap_data["saved_accounts"] = {}

    if password:
        sap_data["saved_accounts"][username] = str(password).strip()

    sap_data["user"] = username
    if password:
        sap_data["pass"] = str(password).strip()

    save_settings(settings)


def get_master_pin_hash():
    """Mengembalikan hash Master PIN yang aktif (dari kermen_settings.json atau default)"""
    settings = load_settings() or {}
    return settings.get("master_pin_hash") or getattr(config, 'DEFAULT_MASTER_PIN_HASH', '')


def verify_master_pin(entered_pin):
    """
    Memverifikasi apakah PIN 4-digit yang dimasukkan sesuai dengan Master PIN aktif.
    Mengembalikan True jika cocok, False jika salah.
    """
    if not entered_pin:
        return False
    pin_str = str(entered_pin).strip()
    entered_hash = config.hash_pin(pin_str)
    expected_hash = get_master_pin_hash()
    return entered_hash.lower() == expected_hash.lower()


def update_master_pin(new_pin):
    """
    Menyimpan Master PIN 4-digit baru ke kermen_settings.json dalam bentuk hash.
    """
    if not new_pin:
        return False
    pin_str = str(new_pin).strip()
    if len(pin_str) != 4 or not pin_str.isdigit():
        return False
    settings = load_settings() or {}
    settings["master_pin_hash"] = config.hash_pin(pin_str)
    return save_settings(settings)


def get_custom_output_dir():
    """Mengembalikan custom output directory dari kermen_settings.json jika diatur, atau string kosong"""
    settings = load_settings() or {}
    val = settings.get("output_dir", "")
    return str(val).strip() if val else ""


def set_custom_output_dir(new_dir):
    """
    Menyimpan atau mereset custom output directory ke kermen_settings.json.
    Jika new_dir kosong atau None, setting dihapus (revert ke default).
    """
    settings = load_settings() or {}
    if not new_dir or not str(new_dir).strip():
        if "output_dir" in settings:
            del settings["output_dir"]
    else:
        clean_path = os.path.abspath(str(new_dir).strip())
        settings["output_dir"] = clean_path
    return save_settings(settings)



