"""
Module: sap_helper.py
Khusus mengelola interaksi dengan SAP GUI Scripting.
"""
import win32com.client
import pythoncom
import subprocess
import time
import os
import config

def get_sap_gui(auto_start=True):
    """
    Menghubungkan ke SAP GUI Scripting Engine melalui Running Object Table (ROT).
    Mendukung koneksi via SapROTWr.SapROTWrapper (rekomendasi SAP)
    dan fallback ke GetObject('SAPGUI').
    Jika SAP Logon belum berjalan dan auto_start=True, akan mencoba membukanya.
    """
    pythoncom.CoInitialize()

    sap_gui = None

    # Cara 1: Menggunakan SapROTWr.SapROTWrapper (metode standar resmi SAP GUI)
    try:
        sap_rot = win32com.client.Dispatch("SapROTWr.SapROTWrapper")
        sap_gui = sap_rot.GetROTEntry("SAPGUI")
    except Exception:
        pass

    # Cara 2: Fallback menggunakan win32com GetObject
    if sap_gui is None:
        try:
            sap_gui = win32com.client.GetObject("SAPGUI")
        except Exception:
            pass

    # Jika belum ditemukan dan auto_start diaktifkan, coba buka saplogon.exe
    if sap_gui is None and auto_start:
        possible_saplogon_paths = [
            r"C:\Program Files\SAP\FrontEnd\SAPGUI\saplogon.exe",
            r"C:\Program Files (x86)\SAP\FrontEnd\SAPGUI\saplogon.exe",
        ]
        saplogon_exe = None
        for p in possible_saplogon_paths:
            if os.path.exists(p):
                saplogon_exe = p
                break

        if saplogon_exe:
            try:
                subprocess.Popen([saplogon_exe])
                # Tunggu SAP GUI terbuka dan mendaftar ke ROT (maksimal 8 detik)
                for _ in range(8):
                    time.sleep(1)
                    try:
                        sap_rot = win32com.client.Dispatch("SapROTWr.SapROTWrapper")
                        sap_gui = sap_rot.GetROTEntry("SAPGUI")
                        if sap_gui is not None:
                            break
                    except Exception:
                        pass
                    try:
                        sap_gui = win32com.client.GetObject("SAPGUI")
                        if sap_gui is not None:
                            break
                    except Exception:
                        pass
            except Exception:
                pass

    if sap_gui is None:
        raise RuntimeError(
            "Tidak dapat terhubung ke SAP GUI (Objek 'SAPGUI' tidak ditemukan di Running Object Table).\n\n"
            "Kemungkinan penyebab:\n"
            "1. Aplikasi SAP Logon belum dibuka / belum aktif di komputer Anda.\n"
            "2. Fitur 'SAP GUI Scripting' belum diaktifkan pada SAP GUI.\n\n"
            "Solusi:\n"
            "1. Buka aplikasi SAP Logon terlebih dahulu.\n"
            "2. Pastikan SAP GUI Scripting aktif di SAP GUI:\n"
            "   - Di SAP Logon, buka menu Options (ikon monitor pojok kiri atas -> Options, atau tekan Alt+F12 -> Options)\n"
            "   - Buka menu: Accessibility & Scripting -> Scripting\n"
            "   - Beri centang pada 'Enable scripting'\n"
            "   - Hapus centang pada: 'Notify when a script attaches to SAP GUI'\n"
            "   - Hapus centang pada: 'Notify when a script opens a connection'\n"
            "   - Klik OK / Apply, lalu tutup dan buka kembali SAP Logon."
        )

    return sap_gui


def dismiss_all_popups(session):
    """
    Menutup jendela modal / pop-up (wnd[1], wnd[2], dll.) yang muncul setelah login
    seperti System Messages, Pengumuman, Multi-Logon, atau dialog info lainnya.
    """
    try:
        for _ in range(5):
            if session.Children.Count > 1:
                top_wnd = session.Children(session.Children.Count - 1)
                # Multi-logon option 1 jika ada
                try:
                    top_wnd.findById("usr/radMULTI_LOGON_OPT1").select()
                except Exception:
                    pass

                # Coba tekan tombol Confirm/OK (btn[0] atau Enter)
                pressed = False
                for btn_id in ("tbar[0]/btn[0]", "btn[0]"):
                    try:
                        top_wnd.findById(btn_id).press()
                        pressed = True
                        time.sleep(0.5)
                        break
                    except Exception:
                        pass

                if not pressed:
                    try:
                        top_wnd.sendVKey(0)
                        time.sleep(0.5)
                    except Exception:
                        break
            else:
                break
    except Exception:
        pass


def is_session_logged_in(session):
    """
    Memeriksa apakah sesi SAP sudah benar-benar login atau masih di layar login.
    """
    try:
        # 1. Cek info session
        info = getattr(session, "Info", None)
        if info:
            u = str(getattr(info, "User", "") or "").strip()
            if u:
                return True

        # 2. Cek apakah ada field BNAME (hanya ada di layar login)
        try:
            bname = session.findById("wnd[0]/usr/txtRSYST-BNAME")
            if bname is not None:
                return False  # Masih berada di layar login!
        except Exception:
            pass

        # 3. Cek apakah ada command field okcd (muncul setelah berhasil login)
        try:
            okcd = session.findById("wnd[0]/tbar[0]/okcd")
            if okcd is not None:
                return True
        except Exception:
            pass
    except Exception:
        pass
    return False


def perform_login_on_session(session, username, password, client=None):
    """
    Melakukan proses input kredensial dan submit login pada jendela session SAP.
    """
    if client is None:
        client = config.SAP_CLIENT

    if not username or not str(username).strip():
        raise RuntimeError("SAP ID / Username belum diisi! Harap masukkan Username di panel Kredensial SAP.")
    if not password or not str(password).strip():
        raise RuntimeError("Password SAP belum diisi! Harap masukkan Password di panel Kredensial SAP.")

    # Tunggu dan pastikan field login siap (hingga 5 detik)
    for _ in range(5):
        try:
            if session.findById("wnd[0]/usr/txtRSYST-BNAME") is not None:
                break
        except Exception:
            time.sleep(0.5)

    try:
        try:
            session.findById("wnd[0]/usr/txtRSYST-MANDT").text = str(client)
        except Exception:
            pass

        session.findById("wnd[0]/usr/txtRSYST-BNAME").text = str(username)
        session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = str(password)

        try:
            session.findById("wnd[0]/usr/txtRSYST-LANGU").text = getattr(config, "SAP_LANGUAGE", "EN")
        except Exception:
            pass

        session.findById("wnd[0]").sendVKey(0)
        time.sleep(2)
    except Exception as e:
        raise RuntimeError(f"Gagal menginput kredensial login SAP: {str(e)}")

    # Handle dialog multi-logon jika ada
    try:
        if session.Children.Count > 1:
            session.findById("wnd[1]/usr/radMULTI_LOGON_OPT1").select()
            session.findById("wnd[1]").sendVKey(0)
            time.sleep(1)
    except Exception:
        pass

    # Cek pesan error di statusbar jika login gagal
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and getattr(sbar, "messageType", None) in ("E", "A"):
            raise RuntimeError(f"Gagal login ke SAP: {sbar.text}")
    except RuntimeError:
        raise
    except Exception:
        pass

    return session


def get_sap_session(username, password, connection_name=None, client=None):
    """
    Membuka koneksi SAP GUI dan melakukan login.
    Mengembalikan object session SAP yang siap digunakan.
    """
    if connection_name is None:
        connection_name = config.SAP_CONNECTION
    if client is None:
        client = config.SAP_CLIENT

    sap_gui = get_sap_gui(auto_start=True)

    try:
        application = sap_gui.GetScriptingEngine
    except Exception as e:
        raise RuntimeError(
            f"Gagal mengakses Scripting Engine dari SAP GUI: {str(e)}\n\n"
            "Pastikan opsi 'Enable scripting' sudah dicentang pada SAP GUI Options."
        )

    # 1. Buka koneksi ke SAP
    try:
        connection = application.OpenConnection(connection_name, True)
    except Exception as e:
        raise RuntimeError(
            f"Gagal membuka koneksi SAP '{connection_name}': {str(e)}\n\n"
            f"Pastikan nama koneksi '{connection_name}' terdaftar dan sama persis dengan yang ada di SAP Logon Anda."
        )

    time.sleep(2)
    if not connection.Children or connection.Children.Count == 0:
        raise RuntimeError("Koneksi SAP berhasil dibuka, namun tidak ada session aktif yang ditemukan.")

    session = connection.Children(0)

    # 2. Lakukan login
    return perform_login_on_session(session, username, password, client)


def download_stock_info(session, plant=None, sloc=None, variant=None, filename=None):
    """
    Menjalankan transaksi /NZMMM_STOCK_INFO, memfilter variant,
    dan mengekspor hasil ALV Grid ke file Excel (.XLSX).
    """
    if plant is None:
        plant = config.DEFAULT_PLANT
    if sloc is None:
        sloc = config.DEFAULT_SLOC
    if variant is None:
        variant = config.DEFAULT_VARIANT
    if filename is None:
        filename = f"INVENTORY {time.strftime('%d%m%Y')}.XLSX"

    time.sleep(1)

    # 1. Buka transaksi
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NZMMM_STOCK_INFO"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1)

    # 2. Isi parameter filter
    session.findById("wnd[0]/usr/ctxtS_WERKS-LOW").text = plant
    session.findById("wnd[0]/usr/ctxtS_LGORT-LOW").text = sloc
    session.findById("wnd[0]/usr/chkCB_RZS").selected = False
    session.findById("wnd[0]/usr/radRB_CUR").setFocus()
    session.findById("wnd[0]/usr/radRB_CUR").select()

    # 3. Eksekusi (F8)
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    time.sleep(2)

    # 4. Pilih Variant ALV (&MB_VARIANT -> &LOAD)
    session.findById("wnd[0]/usr/cntlCC_ALV/shellcont/shell").pressToolbarContextButton("&MB_VARIANT")
    session.findById("wnd[0]/usr/cntlCC_ALV/shellcont/shell").selectContextMenuItem("&LOAD")
    time.sleep(1)

    # 5. Cari variant dengan filter
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").currentCellRow = -1
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").firstVisibleRow = 635
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectColumn("VARIANT")
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").pressColumnHeader("VARIANT")
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").currentCellRow = -1
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectColumn("VARIANT")
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").contextMenu()
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectContextMenuItem("&FILTER")

    # Masukkan nama variant
    session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = variant
    session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-HIGH").setFocus()
    session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-HIGH").caretPosition = 0
    session.findById("wnd[2]/tbar[0]/btn[0]").press()
    time.sleep(1)

    # Klik baris variant pertama
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectedRows = "0"
    session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").clickCurrentCell()
    time.sleep(1)

    # 6. Export ke Spreadsheet (&XXL)
    session.findById("wnd[0]/usr/cntlCC_ALV/shellcont/shell").currentCellColumn = "SLOC"
    session.findById("wnd[0]/usr/cntlCC_ALV/shellcont/shell").selectedRows = "0"
    session.findById("wnd[0]/usr/cntlCC_ALV/shellcont/shell").contextMenu()
    session.findById("wnd[0]/usr/cntlCC_ALV/shellcont/shell").selectContextMenuItem("&XXL")
    time.sleep(1)

    # Konfirmasi format dialog
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    time.sleep(1)

    # 7. Simpan file Excel
    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = config.get_output_dir("sap")
    except Exception:
        pass
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = len(filename)
    session.findById("wnd[1]").sendVKey(0)

    return filename



# =========================================================================
# OTIF /NZCKWOPART AUTOMATION & ORDER EXTRACTION
# =========================================================================

def copy_orders_to_clipboard(orders_list):
    """
    Menyalin daftar nomor Work Order ke Windows Clipboard dengan pemisah baris (CRLF),
    siap untuk di-paste langsung ke Multiple Selection dialog di SAP GUI.
    """
    import win32clipboard
    import win32con

    cleaned_orders = [str(o).strip() for o in orders_list if str(o).strip() and str(o).strip() not in ('0', 'nan', 'None')]
    text_data = "\r\n".join(cleaned_orders)

    for _ in range(5):
        try:
            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardText(text_data, win32con.CF_UNICODETEXT)
            win32clipboard.CloseClipboard()
            return len(cleaned_orders)
        except Exception:
            time.sleep(0.1)
    return len(cleaned_orders)


def find_matching_raw_data_file(reference_dir=None):
    """
    Mencari file RAW DATA (berisi sheet MB51 & AS57D) di Downloads, Desktop, atau folder referensi.
    Memprioritaskan file dengan pola 'RAW DATA*.xlsb' atau 'RAW DATA*.xlsx' yang paling baru.
    Memastikan file memiliki sheet MB51 dan AS57D.
    """
    import glob
    import pandas as pd
    search_dirs = []
    if reference_dir and os.path.exists(reference_dir):
        search_dirs.append(reference_dir)

    desktop_paths = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        r"C:\Users\yusril.i.wafir\Desktop"
    ]
    download_paths = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"C:\Users\yusril.i.wafir\Downloads"
    ]

    for p in desktop_paths + download_paths:
        if os.path.exists(p) and p not in search_dirs:
            search_dirs.append(p)

    patterns = [
        "RAW DATA*.xlsb", "RAW DATA*.xlsx",
        "RAW_DATA*.xlsb", "RAW_DATA*.xlsx"
    ]

    all_candidates = []
    for d in search_dirs:
        for pat in patterns:
            found = glob.glob(os.path.join(d, pat))
            for f in found:
                base = os.path.basename(f)
                if not base.startswith("~$") and os.path.exists(f):
                    if not any(x in base.upper() for x in ['REPORT', 'PROCESSED', 'SUMMARY', 'MONTHLY', 'SIMULASI', 'READINESS', 'REVIEWED']):
                        all_candidates.append(f)

    if not all_candidates:
        return None

    # Urutkan berdasarkan waktu modifikasi terbaru
    all_candidates.sort(key=lambda x: os.path.getmtime(x), reverse=True)

    # Verifikasi keberadaan sheet MB51 dan AS57D
    for f in all_candidates:
        try:
            eng = 'calamine' if f.lower().endswith('.xlsb') else None
            ef = pd.ExcelFile(f, engine=eng)
            sheets_upper = [s.upper() for s in ef.sheet_names]
            if 'MB51' in sheets_upper and 'AS57D' in sheets_upper:
                return f
        except Exception:
            continue

    return all_candidates[0] if all_candidates else None


def detect_raw_dates_summary(input_file_path):
    """
    Mendeteksi rentang tanggal dari file Raw Data (mengambil dari sheet AS57D atau MB51).
    Mengembalikan dict berisi min_date, max_date, default_year, default_month, available_months.
    """
    if not input_file_path or not os.path.exists(input_file_path):
        return None
    try:
        import pandas as pd
        engine = 'calamine' if input_file_path.lower().endswith('.xlsb') else None
        # Coba dari AS57D Planned Start Date terlebih dahulu
        col_date = None
        df = None
        try:
            df = pd.read_excel(input_file_path, sheet_name='AS57D', engine=engine, usecols=['Planned Start Date'])
            col_date = 'Planned Start Date'
        except Exception:
            try:
                df = pd.read_excel(input_file_path, sheet_name='MB51', engine=engine, usecols=['Posting Date'])
                col_date = 'Posting Date'
            except Exception:
                return None

        dt = pd.to_datetime(df[col_date], errors='coerce', dayfirst=True).dropna()
        # Filter tanggal yang wajar (hindari noise tanggal 1970 atau masa depan jauh)
        dt = dt[(dt.dt.year >= 2024) & (dt.dt.year <= 2030)]
        if dt.empty:
            return None

        min_dt = dt.min()
        max_dt = dt.max()
        mode_month = int(dt.dt.month.mode()[0]) if not dt.dt.month.mode().empty else min_dt.month
        mode_year = int(dt.dt.year.mode()[0]) if not dt.dt.year.mode().empty else min_dt.year

        unique_periods = dt.dt.to_period('M').unique()
        available_months = sorted([f"{p.year}-{p.month:02d}" for p in unique_periods])

        return {
            'min_date': min_dt.strftime('%Y-%m-%d'),
            'max_date': max_dt.strftime('%Y-%m-%d'),
            'default_month': mode_month,
            'default_year': mode_year,
            'available_months': available_months
        }
    except Exception:
        return None



def extract_unique_orders_from_raw(
    raw_file_path,
    date_filter_mode="all",
    filter_month=None,
    filter_year=None,
    filter_start_date=None,
    filter_end_date=None
):
    """
    Mengekstrak daftar unik Work Order dari Raw Data:
    1. Sheet 'MB51':
       - Filter Movement type == 261
       - Filter Posting Date sesuai tanggal yang dipilih
       - Ambil kolom 'Order'
    2. Sheet 'AS57D':
       - Filter Planned Start Date sesuai tanggal yang dipilih
       - Ambil kolom 'Order Number'
    3. Gabungkan dan deduplikasi (unique) sehingga data ringan saat di-copy ke SAP.

    Mengembalikan:
        (unique_orders_list, stats_dict)
    """
    import pandas as pd
    from modules.otif_helper import parse_date_filter_param

    if not os.path.exists(raw_file_path):
        raise FileNotFoundError(f"File Raw Data tidak ditemukan: {raw_file_path}")

    engine = 'calamine' if raw_file_path.lower().endswith('.xlsb') else None

    # Parse filter date params jika mode range
    start_dt = None
    end_dt = None
    if date_filter_mode == "range":
        start_dt = parse_date_filter_param(filter_start_date)
        end_dt = parse_date_filter_param(filter_end_date)
        if start_dt is None or end_dt is None:
            raise ValueError("Tanggal awal dan tanggal akhir harus diisi untuk rentang tanggal!")
        if start_dt > end_dt:
            raise ValueError("Tanggal awal tidak boleh lebih besar dari tanggal akhir!")

    orders_mb51 = []
    orders_as57d = []

    # 1. Ekstraksi dari MB51
    try:
        df_mb = pd.read_excel(
            raw_file_path,
            sheet_name='MB51',
            engine=engine,
            usecols=['Posting Date', 'Movement type', 'Order']
        )

        # Filter Movement type == 261
        mvt_str = df_mb['Movement type'].astype(str).str.replace(r'\.0$', '', regex=True).str.strip()
        df_mb_filtered = df_mb[mvt_str == '261'].copy()

        # Filter Posting Date
        if date_filter_mode == 'month' and filter_month and filter_year:
            dt_s = pd.to_datetime(df_mb_filtered['Posting Date'], errors='coerce', dayfirst=True)
            df_mb_filtered = df_mb_filtered[(dt_s.dt.month == int(filter_month)) & (dt_s.dt.year == int(filter_year))]
        elif date_filter_mode == 'range' and start_dt and end_dt:
            dt_s = pd.to_datetime(df_mb_filtered['Posting Date'], errors='coerce', dayfirst=True)
            df_mb_filtered = df_mb_filtered[(dt_s >= start_dt) & (dt_s <= end_dt + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1))]

        # Ambil Order
        for val in df_mb_filtered['Order'].dropna():
            s = str(val).split('.')[0].strip()
            if s and s not in ('0', 'nan', 'None'):
                orders_mb51.append(s)
    except Exception as e:
        print(f"[Warning] Gagal membaca sheet MB51: {e}")

    # 2. Ekstraksi dari AS57D
    try:
        df_as = pd.read_excel(
            raw_file_path,
            sheet_name='AS57D',
            engine=engine,
            usecols=['Planned Start Date', 'Order Number']
        )

        df_as_filtered = df_as.copy()
        if date_filter_mode == 'month' and filter_month and filter_year:
            dt_s = pd.to_datetime(df_as_filtered['Planned Start Date'], errors='coerce', dayfirst=True)
            df_as_filtered = df_as_filtered[(dt_s.dt.month == int(filter_month)) & (dt_s.dt.year == int(filter_year))]
        elif date_filter_mode == 'range' and start_dt and end_dt:
            dt_s = pd.to_datetime(df_as_filtered['Planned Start Date'], errors='coerce', dayfirst=True)
            df_as_filtered = df_as_filtered[(dt_s >= start_dt) & (dt_s <= end_dt + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1))]

        # Ambil Order Number
        for val in df_as_filtered['Order Number'].dropna():
            s = str(val).split('.')[0].strip()
            if s and s not in ('0', 'nan', 'None'):
                orders_as57d.append(s)
    except Exception as e:
        print(f"[Warning] Gagal membaca sheet AS57D: {e}")

    # 3. Gabungkan dan deduplikasi (pertahankan urutan kemunculan unik)
    unique_orders = list(dict.fromkeys(orders_mb51 + orders_as57d))

    stats = {
        'mb51_unique': len(set(orders_mb51)),
        'as57d_unique': len(set(orders_as57d)),
        'total_unique': len(unique_orders)
    }

    return unique_orders, stats


def download_zckwopart_otif(
    session,
    orders_list,
    plant=None,
    erdat=None,
    save_dir=None,
    filename=None,
    log_callback=None
):
    """
    Menjalankan transaksi /NZCKWOPART pada SAP GUI secara andal & adaptif.
    """
    def _log(m):
        if log_callback:
            log_callback(m)
        else:
            print(m)

    if plant is None:
        plant = getattr(config, 'DEFAULT_OTIF_SAP_PLANT', "3069")
    if save_dir is None:
        save_dir = config.get_output_dir("sap")

    if filename is None:
        filename = f"Report_OTIF_CKBMB_{time.strftime('%d%m%Y')}.XLSX"

    os.makedirs(save_dir, exist_ok=True)
    full_save_path = os.path.join(save_dir, filename)

    # 0. Bersihkan pop-up modal awal jika ada
    dismiss_all_popups(session)

    # 1. Buka transaksi /NZCKWOPART
    _log("[STEP 1/7] Membuka transaksi /NZCKWOPART di SAP...")
    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/NZCKWOPART"
        session.findById("wnd[0]").sendVKey(0)
    except Exception:
        dismiss_all_popups(session)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/NZCKWOPART"
        session.findById("wnd[0]").sendVKey(0)

    time.sleep(2)
    dismiss_all_popups(session)

    # Cek pesan error statusbar jika transaksi tidak ditemukan
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and getattr(sbar, "messageType", None) in ("E", "A"):
            raise RuntimeError(f"SAP Error saat membuka /NZCKWOPART: {sbar.text}")
    except RuntimeError:
        raise
    except Exception:
        pass

    # 2. Copy WO ke clipboard Windows
    if orders_list:
        _log(f"[STEP 2/7] Menyalin {len(orders_list)} Work Order ke clipboard...")
        copy_orders_to_clipboard(orders_list)

    # 3. Input Plant
    _log(f"[STEP 3/7] Mengisi Plant: {plant}...")
    try:
        session.findById("wnd[0]/usr/ctxtS_WERKS-LOW").text = str(plant)
    except Exception:
        try:
            session.findById("wnd[0]/usr/ctxtP_WERKS").text = str(plant)
        except Exception:
            raise RuntimeError(f"Gagal mengisi Plant '{plant}' di /NZCKWOPART: Elemen input Plant tidak ditemukan. Pastikan transaksi /NZCKWOPART berhasil terbuka.")

    # 4. Created On Date jika ada
    if erdat:
        _log(f"[STEP 4/7] Mengisi Created On (>= {erdat})...")
        try:
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").text = str(erdat)
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").setFocus()
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").caretPosition = 1
            session.findById("wnd[0]").sendVKey(2)
            time.sleep(0.5)

            try:
                opt_shell = session.findById("wnd[1]/usr/cntlOPTION_CONTAINER/shellcont/shell")
                opt_shell.setCurrentCell(1, "TEXT")
                opt_shell.selectedRows = "1"
                opt_shell.doubleClickCurrentCell()
            except Exception:
                try:
                    session.findById("wnd[1]/tbar[0]/btn[0]").press()
                except Exception:
                    pass
            time.sleep(0.5)
        except Exception as ex:
            _log(f"  [Catatan] Pengaturan tanggal dilewati: {ex}")

    # 5. Multiple Selection untuk S_AUFNR (Work Orders)
    if orders_list:
        _log(f"[STEP 5/7] Mengunggah {len(orders_list)} WO via Multiple Selection...")
        btn_aufnr = None
        for b_name in ("btn%_S_AUFNR_%_APP_%-VALU_PUSH", "btn%_S_AUFNR_%_APP_%-VALU_PUSH"):
            try:
                btn_aufnr = session.findById(f"wnd[0]/usr/{b_name}")
                if btn_aufnr: break
            except Exception:
                pass

        if btn_aufnr:
            btn_aufnr.press()
        else:
            session.findById("wnd[0]/usr/btn%_S_AUFNR_%_APP_%-VALU_PUSH").press()

        time.sleep(1)
        # btn[24]: Upload from Clipboard
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
        time.sleep(1)
        # btn[8]: Copy / Confirm (F8)
        session.findById("wnd[1]/tbar[0]/btn[8]").press()
        time.sleep(1)

    # 6. Eksekusi transaksi (F8)
    _log("[STEP 6/7] Menjalankan query SAP (F8)... Menunggu pemrosesan data...")
    session.findById("wnd[0]/tbar[1]/btn[8]").press()

    # Tunggu pemrosesan query SAP & kemunculan ALV Grid (hingga 60 detik)
    grid = None
    for attempt in range(30):
        time.sleep(2)
        try:
            sbar = session.findById("wnd[0]/sbar")
            if sbar:
                msg_type = str(getattr(sbar, "messageType", "") or "")
                msg_txt = str(getattr(sbar, "text", "") or "")
                if msg_type in ("E", "A"):
                    raise RuntimeError(f"SAP Error saat eksekusi: {msg_txt}")
                if "no data" in msg_txt.lower() or "tidak ada data" in msg_txt.lower() or "keine daten" in msg_txt.lower():
                    raise RuntimeError(f"Tidak ada data ditemukan di SAP untuk kriteria WO / Plant ini: {msg_txt}")
        except RuntimeError:
            raise
        except Exception:
            pass

        # Cari ALV Grid di layar
        for grid_path in (
            "wnd[0]/usr/cntlGRID1/shellcont/shell/shellcont[1]/shell",
            "wnd[0]/usr/cntlGRID1/shellcont/shell",
            "wnd[0]/usr/cntlGRID/shellcont/shell",
            "wnd[0]/usr/shell/shellcont[1]/shell",
            "wnd[0]/usr/cntlCONTAINER/shellcont/shell"
        ):
            try:
                g = session.findById(grid_path)
                if g:
                    grid = g
                    break
            except Exception:
                pass

        if grid is not None:
            break

    if grid is None:
        try:
            if session.findById("wnd[0]/usr/ctxtS_WERKS-LOW"):
                raise RuntimeError("Laporan SAP tidak menghasilkan tabel data. Kemungkinan tidak ada transaksi WO yang cocok pada kriteria tersebut.")
        except RuntimeError:
            raise
        except Exception:
            pass
        raise RuntimeError("Tabel laporan ALV Grid tidak ditemukan di SAP setelah 60 detik.")

    _log("[STEP 7/7] Mengekspor hasil laporan ke Excel Spreadsheet...")
    # 7. Pilih Layout jika ada
    try:
        session.findById("wnd[0]/tbar[1]/btn[33]").press()
        time.sleep(1)
        layout_shell = session.findById("wnd[1]/usr/subSUB_CONFIGURATION:SAPLSALV_CUL_LAYOUT_CHOOSE:0500/cntlD500_CONTAINER/shellcont/shell")
        layout_shell.setCurrentCell(1, "TEXT")
        layout_shell.selectedRows = "1"
        layout_shell.clickCurrentCell()
        time.sleep(1)
    except Exception:
        pass

    # 8. Export ALV Grid ke Spreadsheet (&XXL)
    try:
        row_cnt = getattr(grid, "RowCount", 0)
        target_row = 4 if row_cnt > 4 else (0 if row_cnt > 0 else 0)
        grid.setCurrentCell(target_row, "UDATE")
        grid.selectedRows = str(target_row)
    except Exception:
        pass

    exported = False
    try:
        grid.contextMenu()
        time.sleep(0.5)
        grid.selectContextMenuItem("&XXL")
        exported = True
        time.sleep(1.5)
    except Exception:
        for b_exp in ("btn[43]", "btn[45]", "btn[32]"):
            try:
                session.findById(f"wnd[0]/tbar[1]/{b_exp}").press()
                exported = True
                time.sleep(1.5)
                break
            except Exception:
                pass

    if not exported:
        try:
            session.findById("wnd[0]/mbar/menu[0]/menu[3]/menu[1]").select()
            time.sleep(1.5)
        except Exception:
            pass

    # 9. Konfirmasi format dialog
    try:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(1)
    except Exception:
        pass

    # 10. Isi Path dan Filename
    for _ in range(5):
        try:
            if session.findById("wnd[1]/usr/ctxtDY_PATH"):
                break
        except Exception:
            time.sleep(0.5)

    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = save_dir
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
        time.sleep(0.5)
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(2)
    except Exception as ex:
        raise RuntimeError(f"Gagal mengisi lokasi simpan file Excel ({save_dir}\\{filename}): {ex}")

    # Handle dialog konfirmasi replace jika file sudah ada sebelumnya
    try:
        if session.Children.Count > 1:
            top_wnd = session.Children(session.Children.Count - 1)
            try:
                top_wnd.findById("tbar[0]/btn[11]").press()
            except Exception:
                try:
                    top_wnd.findById("tbar[0]/btn[0]").press()
                except Exception:
                    pass
    except Exception:
        pass

    # Tunggu beberapa detik hingga file selesai ditulis ke disk
    for _ in range(20):
        if os.path.exists(full_save_path) and os.path.getsize(full_save_path) > 0:
            break
        time.sleep(1)

    _log(f"Laporan ZCKWOPART berhasil disimpan: {full_save_path}")
    return full_save_path


# =========================================================================
# STOCK HUB (MB52) AUTOMATION
# =========================================================================

def download_stock_hub(
    session,
    variant=None,
    save_dir=None,
    filename=None
):
    """
    Menjalankan transaksi MB52 pada SAP GUI untuk menarik data Stock HUB:
    1. Buka transaksi /NMB52
    2. Tekan tombol Get Variant (btn[17])
    3. Input Variant (default '/YUSRIL'), kosongkan created by (ENAME-LOW), lalu eksekusi (btn[8])
    4. Eksekusi laporan MB52 (F8 / sendVKey 8)
    5. Tekan tombol Export / Spreadsheet (btn[43])
    6. Konfirmasi format dialog (btn[0])
    7. Masukkan direktori (Desktop) dan nama file Excel
    8. Konfirmasi simpan (btn[0]) dan tangani popup overwrite jika ada
    """
    if variant is None:
        variant = getattr(config, 'DEFAULT_MB52_VARIANT', "/YUSRIL")
    if save_dir is None:
        save_dir = config.get_output_dir("sap")

    if filename is None:
        filename = f"Stock HUB {time.strftime('%d%m%Y')}.XLSX"

    os.makedirs(save_dir, exist_ok=True)
    full_save_path = os.path.join(save_dir, filename)

    # 1. Buka transaksi MB52
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NMB52"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)

    # 2. Get Variant (btn[17])
    session.findById("wnd[0]/tbar[1]/btn[17]").press()
    time.sleep(1)

    # 3. Input Variant /YUSRIL & kosongkan ENAME-LOW
    session.findById("wnd[1]/usr/txtV-LOW").text = str(variant).strip()
    session.findById("wnd[1]/usr/txtENAME-LOW").text = ""
    session.findById("wnd[1]/usr/txtENAME-LOW").setFocus()
    session.findById("wnd[1]/usr/txtENAME-LOW").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    time.sleep(1.5)

    # 4. Eksekusi report (F8)
    session.findById("wnd[0]").sendVKey(8)
    time.sleep(3)

    # Cek pesan error statusbar jika ada
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and getattr(sbar, "messageType", None) in ("E", "A"):
            raise RuntimeError(f"SAP Error saat eksekusi MB52: {sbar.text}")
    except RuntimeError:
        raise
    except Exception:
        pass

    # 5. Export / Spreadsheet (btn[43])
    session.findById("wnd[0]/tbar[1]/btn[43]").press()
    time.sleep(1.5)

    # 6. Konfirmasi format dialog (btn[0])
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    time.sleep(1.5)

    # 7. Isi Path dan Filename
    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = save_dir
    except Exception:
        pass
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = len(filename)
    time.sleep(0.5)
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    time.sleep(2)

    # 8. Tangani dialog konfirmasi replace jika file sudah ada
    try:
        if session.Children.Count > 1:
            top_wnd = session.Children(session.Children.Count - 1)
            try:
                top_wnd.findById("tbar[0]/btn[11]").press()
            except Exception:
                try:
                    top_wnd.findById("tbar[0]/btn[0]").press()
                except Exception:
                    pass
    except Exception:
        pass

    # 9. Tunggu file selesai ditulis ke disk
    for _ in range(15):
        if os.path.exists(full_save_path) and os.path.getsize(full_save_path) > 0:
            break
        alt_path = os.path.join(save_dir, filename.replace('.XLSX', '').replace('.xlsx', ''))
        if os.path.exists(alt_path) and os.path.getsize(alt_path) > 0:
            try:
                if not os.path.exists(full_save_path):
                    os.rename(alt_path, full_save_path)
            except Exception:
                pass
            break
        time.sleep(1)

    return full_save_path


def get_active_or_new_sap_session(username=None, password=None, connection_name=None, client=None):
    """
    Mencoba terhubung ke sesi SAP GUI yang sudah aktif terbuka di layar terlebih dahulu.
    Mencari koneksi yang cocok dengan connection_name dan client yang diminta (misal: 'SAP CK' atau 'SAP ECC').
    Jika ada sesi aktif yang SUDAH login, langsung gunakan.
    Jika ada sesi yang masih di layar login, lakukan login otomatis.
    Jika tidak ada sesi terbuka yang cocok, buat koneksi baru dan lakukan login.
    """
    pythoncom.CoInitialize()
    target_conn = str(connection_name or "").strip().lower()
    target_client = str(client or "").strip()

    try:
        sap_gui = get_sap_gui(auto_start=False)
        if sap_gui:
            app = sap_gui.GetScriptingEngine
            matching_conn = None

            if app.Children.Count > 0:
                # 1. Cari koneksi yang deskripsinya cocok dengan target_conn
                for i in range(app.Children.Count):
                    c = app.Children(i)
                    desc = str(getattr(c, "Description", "") or "").strip().lower()
                    if target_conn and (target_conn in desc or desc in target_conn):
                        matching_conn = c
                        break

                # 2. Jika tidak ada yang cocok tapi target_conn kosong, ambil koneksi pertama
                if not matching_conn and not target_conn and app.Children.Count > 0:
                    matching_conn = app.Children(0)

            if matching_conn and matching_conn.Children.Count > 0:
                for j in range(matching_conn.Children.Count):
                    sess = matching_conn.Children(j)
                    sess_info = getattr(sess, "Info", None)
                    sess_client = str(getattr(sess_info, "Client", "") or "").strip()
                    if target_client and sess_client and sess_client != target_client:
                        continue

                    if is_session_logged_in(sess):
                        dismiss_all_popups(sess)
                        return sess
                    else:
                        # Sesi terbuka tapi masih di layar login! Lakukan login pada sesi ini
                        if username and password:
                            s = perform_login_on_session(sess, username, password, client)
                            dismiss_all_popups(s)
                            return s
                        else:
                            raise RuntimeError(
                                f"Jendela '{getattr(matching_conn, 'Description', 'SAP')}' berada di layar login, namun SAP ID / Username atau Password belum diisi di aplikasi KermenX.\n"
                                "Silakan isi Username dan Password terlebih dahulu pada panel Kredensial SAP."
                            )
    except RuntimeError:
        raise
    except Exception:
        pass

    s = get_sap_session(username, password, connection_name, client)
    dismiss_all_popups(s)
    return s


def _set_migo_action(session, action_key):
    """Mengatur Action ComboBox pada transaksi MIGO (A08 = Transfer Posting, A03 = Cancellation)"""
    carriers = ["0003", "0007", "0001", "0005"]
    for c in carriers:
        try:
            elem = session.findById(f"wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:{c}/subSUB_FIRSTLINE:SAPLMIGO:0011/cmbGODYNPRO-ACTION")
            if elem:
                elem.key = action_key
                return True
        except Exception:
            pass
    return False


def _set_migo_mat_doc(session, mat_doc):
    """Mengisi field Nomor Material Document pada mode Cancellation"""
    carriers = ["0003", "0007", "0001", "0005"]
    for c in carriers:
        try:
            txt_doc = session.findById(f"wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:{c}/subSUB_FIRSTLINE:SAPLMIGO:0011/subSUB_FIRSTLINE_REFDOC:SAPLMIGO:2010/txtGODYNPRO-MAT_DOC")
            if txt_doc:
                txt_doc.text = mat_doc
                try:
                    txt_doc.caretPosition = len(mat_doc)
                except Exception:
                    pass
                return True
        except Exception:
            pass
    return False


def _set_migo_item_ok(session, set_focus=False):
    """Centang checkbox Item OK (chkGODYNPRO-DETAIL_TAKE)"""
    carriers = ["0007", "0003", "0001", "0005"]
    for c in carriers:
        try:
            chk = session.findById(f"wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:{c}/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/subSUB_DETAIL_TAKE:SAPLMIGO:0304/chkGODYNPRO-DETAIL_TAKE")
            if chk:
                chk.selected = True
                if set_focus:
                    try:
                        chk.setFocus()
                    except Exception:
                        pass
                return True
        except Exception:
            pass
    return False


def execute_batch_migo(session, items_list, progress_callback=None, log_callback=None):
    """
    Menjalankan transaksi /NMIGO mode Transfer Posting (TP - 344) dan melakukan perulangan input batch item part.
    """
    def _log(m):
        if log_callback:
            log_callback(m)
        else:
            print(m)

    time.sleep(1)
    _log("Membuka transaksi SAP /NMIGO (Mode TP - 344)...")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NMIGO"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)

    # Set Action MIGO ke A08 (Transfer Posting)
    try:
        if _set_migo_action(session, "A08"):
            _log("Action MIGO diatur ke: A08 (Transfer Posting).")
    except Exception as ex:
        _log(f"Peringatan: Gagal set Action A08 ({ex}). Melanjutkan...")

    success_cnt = 0
    fail_cnt = 0
    results = []
    total = len(items_list)

    for idx, itm in enumerate(items_list):
        pn = str(itm.get("pn", "")).strip()
        qty = str(itm.get("qty", "1")).strip()
        plant = str(itm.get("plant", "1346")).strip()
        from_sloc = str(itm.get("from_sloc", "DMDV")).strip()
        to_sloc = str(itm.get("to_sloc", "DMDV")).strip()
        val_type = str(itm.get("val_type") or itm.get("valtype") or "RPRODUCT").strip()

        if not pn:
            continue

        pct = 40 + int(((idx + 1) / total) * 55)
        if progress_callback:
            progress_callback(pct, f"Memproses MIGO TP [{idx+1}/{total}]: {pn} ({qty} qty)...")

        _log(f"[{idx+1}/{total}] Input MIGO TP: PN={pn}, Plant={plant}, From={from_sloc}, To={to_sloc}, Qty={qty}, ValType={val_type}...")

        try:
            # 1. Input field item detail MIGO (PN, Plant, SLoc Asal, SLoc Tujuan, Qty)
            session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/ctxtGODYNPRO-MAKTX").text = pn
            session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/ctxtGODYNPRO-NAME1").text = plant
            session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/ctxtGODYNPRO-LGOBE").text = from_sloc
            session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/ctxtGOITEM-UMLGOBE").text = to_sloc
            session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/txtGODYNPRO-ERFMG").text = qty

            # 2. Enter
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            # 3. Centang Item OK (chkGODYNPRO-DETAIL_TAKE)
            _set_migo_item_ok(session, set_focus=False)
            time.sleep(0.3)

            # 4. Enter & Isi Valuasi / Batch (BWTAR=ValType, UMBAR=PXPRODUCT)
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            try:
                session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/ctxtGODYNPRO-BWTAR").text = val_type
            except Exception:
                pass

            try:
                session.findById("wnd[0]/usr/ssubSUB_MAIN_CARRIER:SAPLMIGO:0007/subSUB_ITEMDETAIL:SAPLMIGO:0303/subSUB_DETAIL:SAPLMIGO:0305/tabsTS_GOITEM/tabpOK_GOITEM_TRANS/ssubSUB_TS_GOITEM_TRANS:SAPLMIGO:0390/ctxtGODYNPRO-UMBAR").text = "PXPRODUCT"
            except Exception:
                pass

            time.sleep(0.3)

            # 5. Press btn[7] (Check)
            session.findById("wnd[0]/tbar[1]/btn[7]").press()
            time.sleep(0.5)

            # Jika muncul window notifikasi / popup (wnd[1]), tekan konfirmasi btn[0]
            try:
                for _ in range(3):
                    btn_ok = session.findById("wnd[1]/tbar[0]/btn[0]")
                    if btn_ok is not None:
                        btn_ok.press()
                        time.sleep(0.5)
                    else:
                        break
            except Exception:
                pass

            # 6. Press btn[23] (Post / Line Confirm)
            session.findById("wnd[0]/tbar[1]/btn[23]").press()
            time.sleep(1.0)

            # Cek jika ada popup konfirmasi setelah posting di wnd[1]
            try:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
                time.sleep(0.5)
            except Exception:
                pass

            # Cek status bar
            msg_text = ""
            msg_type = ""
            try:
                sbar = session.findById("wnd[0]/sbar")
                if sbar:
                    msg_text = str(getattr(sbar, "text", "") or "")
                    msg_type = str(getattr(sbar, "messageType", "") or "")
            except Exception:
                pass

            if msg_type in ("E", "A"):
                _log(f"  ❌ Error MIGO TP ({pn}): {msg_text}")
                fail_cnt += 1
                results.append({"pn": pn, "status": "Error", "message": msg_text})
            else:
                _log(f"  ✅ Sukses MIGO TP ({pn}): {msg_text or 'Berhasil diposting'}")
                success_cnt += 1
                results.append({"pn": pn, "status": "Success", "message": msg_text or "Posted"})

        except Exception as ex:
            _log(f"  ❌ Gagal memproses item {pn}: {str(ex)}")
            fail_cnt += 1
            results.append({"pn": pn, "status": "Error", "message": str(ex)})

    _log(f"Selesai! {success_cnt} item sukses, {fail_cnt} item gagal.")
    return {
        "status": "success",
        "migo_mode": "tp_344",
        "total_items": total,
        "success_count": success_cnt,
        "fail_count": fail_cnt,
        "details": results
    }


def execute_batch_migo_cancellation(session, items_list, progress_callback=None, log_callback=None):
    """
    Menjalankan transaksi /NMIGO mode Cancellation (A03) untuk membatalkan daftar Nomor Dokumen Material.
    """
    def _log(m):
        if log_callback:
            log_callback(m)
        else:
            print(m)

    time.sleep(1)
    _log("Membuka transaksi SAP /NMIGO (Mode Cancellation - A03)...")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NMIGO"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)

    # Set Action MIGO ke A03 (Cancellation)
    try:
        if _set_migo_action(session, "A03"):
            _log("Action MIGO diatur ke: A03 (Cancellation).")
    except Exception as ex:
        _log(f"Peringatan: Gagal set Action A03 ({ex}). Melanjutkan...")

    success_cnt = 0
    fail_cnt = 0
    results = []
    total = len(items_list)

    for idx, itm in enumerate(items_list):
        # Ambil nomor Mat Doc baik dari key 'pn' maupun 'mat_doc'
        mat_doc = str(itm.get("pn", "") or itm.get("mat_doc", "")).strip()

        if not mat_doc:
            continue

        pct = 40 + int(((idx + 1) / total) * 55)
        if progress_callback:
            progress_callback(pct, f"Membatalkan Mat Doc [{idx+1}/{total}]: {mat_doc}...")

        _log(f"[{idx+1}/{total}] Memproses Cancellation Dokumen: {mat_doc}...")

        try:
            # 1. Input Nomor Material Document
            if not _set_migo_mat_doc(session, mat_doc):
                raise RuntimeError(f"Field Mat Doc (txtGODYNPRO-MAT_DOC) tidak ditemukan di SAP!")

            # 2. Enter
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.8)

            # 3. Centang Item OK & Set Focus
            _set_migo_item_ok(session, set_focus=True)
            time.sleep(0.3)

            # 4. Press btn[7] (Check)
            session.findById("wnd[0]/tbar[1]/btn[7]").press()
            time.sleep(0.5)

            # Jika muncul window notifikasi / popup (wnd[1]), tekan konfirmasi btn[0]
            try:
                for _ in range(3):
                    btn_ok = session.findById("wnd[1]/tbar[0]/btn[0]")
                    if btn_ok is not None:
                        btn_ok.press()
                        time.sleep(0.5)
                    else:
                        break
            except Exception:
                pass

            # 5. Press btn[23] (Post / Cancel Confirm)
            session.findById("wnd[0]/tbar[1]/btn[23]").press()
            time.sleep(1.0)

            # Cek jika ada popup konfirmasi setelah posting di wnd[1]
            try:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
                time.sleep(0.5)
            except Exception:
                pass

            # Cek status bar
            msg_text = ""
            msg_type = ""
            try:
                sbar = session.findById("wnd[0]/sbar")
                if sbar:
                    msg_text = str(getattr(sbar, "text", "") or "")
                    msg_type = str(getattr(sbar, "messageType", "") or "")
            except Exception:
                pass

            if msg_type in ("E", "A"):
                _log(f"  ❌ Error Cancel ({mat_doc}): {msg_text}")
                fail_cnt += 1
                results.append({"pn": mat_doc, "status": "Error", "message": msg_text})
            else:
                _log(f"  ✅ Sukses Cancel ({mat_doc}): {msg_text or 'Dokumen berhasil dibatalkan'}")
                success_cnt += 1
                results.append({"pn": mat_doc, "status": "Success", "message": msg_text or "Cancelled"})

        except Exception as ex:
            _log(f"  ❌ Gagal membatalkan dokumen {mat_doc}: {str(ex)}")
            fail_cnt += 1
            results.append({"pn": mat_doc, "status": "Error", "message": str(ex)})

    _log(f"Selesai! {success_cnt} dokumen berhasil dibatalkan, {fail_cnt} dokumen gagal.")
    return {
        "status": "success",
        "migo_mode": "cancellation",
        "total_items": total,
        "success_count": success_cnt,
        "fail_count": fail_cnt,
        "details": results
    }

