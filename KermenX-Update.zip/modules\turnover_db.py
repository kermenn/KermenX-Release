"""
Module: turnover_db.py
Database lokal internal untuk menyimpan data historis COGS, Inventory Parts, dan Target Budget TO.
Mendukung:
- Penyimpanan persisten (JSON) di folder 'data/turnover_database.json'
- Rekonstruksi data historis 2025 (back-simulated 4 bulan: Sep-Des 2025 @ USD 2,054,027/bulan)
- Fitur Edit, Tambah (Add), Hapus (Delete), dan Sinkronisasi data COGS & Inventory
- Penyediaan DataFrame Inventory & Series COGS rolling 12 bulan penuh kapan pun dibutuhkan
Semua nominal dalam mata uang USD ($).
"""
import os
import json
import pandas as pd
from datetime import datetime


def get_db_path():
    """Mencari path absolut ke turnover_database.json"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    target = os.path.join(base_dir, "data", "turnover_database.json")
    if not os.path.exists(target):
        # Coba cek di folder aplikasi portable atau current working directory
        alt = os.path.join(os.getcwd(), "data", "turnover_database.json")
        if os.path.exists(alt):
            return alt
    return target


def normalize_date_str(val):
    """Mengonversi berbagai format input tanggal menjadi string ISO 'YYYY-MM-01'."""
    if not val or pd.isna(val):
        return None
    if isinstance(val, (datetime, pd.Timestamp)):
        return val.strftime("%Y-%m-01")
    val_str = str(val).strip()
    formats = [
        "%b %Y", "%B %Y", "%b-%y", "%b-%Y", "%B-%Y",
        "%Y-%m-%d", "%Y-%m", "%d/%m/%Y", "%m/%d/%Y", "%Y%m", "%m-%Y"
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(val_str, fmt)
            return dt.strftime("%Y-%m-01")
        except Exception:
            pass
    try:
        dt = pd.to_datetime(val_str, errors='coerce')
        if pd.notna(dt):
            return dt.strftime("%Y-%m-01")
    except Exception:
        pass
    return None


def format_month_display(date_str):
    """Mengubah 'YYYY-MM-01' menjadi format 'Mon YYYY' (misal: 'Sep 2026')."""
    try:
        dt = pd.to_datetime(date_str)
        return dt.strftime("%b %Y")
    except Exception:
        return str(date_str)


def load_turnover_db():
    """Membaca isi database turnover JSON. Mengembalikan struktur default jika file belum ada."""
    p = get_db_path()
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    # Default baseline jika file belum terbentuk
    return {
        "metadata": {
            "currency": "USD",
            "description": "Database Internal Turn Over Parts (COGS & Inventory History)",
            "back_simulated_months": ["2025-09-01", "2025-10-01", "2025-11-01", "2025-12-01"]
        },
        "cogs_monthly": {
            "2025-09-01": 2054027.00,
            "2025-10-01": 2054027.00,
            "2025-11-01": 2054027.00,
            "2025-12-01": 2054027.00,
            "2026-01-01": 1501274.65,
            "2026-02-01": 1315896.88,
            "2026-03-01": 1344379.47,
            "2026-04-01": 1701344.92,
            "2026-05-01": 1612931.94,
            "2026-06-01": 1788061.46,
            "2026-07-01": 975572.70,
            "2026-08-01": 1550707.20,
            "2026-09-01": 1477610.61
        },
        "inventory_monthly": {},
        "budget_to": {
            "2025-11-01": 3.06,
            "2025-12-01": 3.10,
            "2026-01-01": 3.7741,
            "2026-02-01": 3.6706,
            "2026-03-01": 3.4771,
            "2026-04-01": 3.2712,
            "2026-05-01": 3.1259,
            "2026-06-01": 3.0386,
            "2026-07-01": 2.9746,
            "2026-08-01": 2.9767,
            "2026-09-01": 2.8832,
            "2026-10-01": 2.9710
        }
    }


def save_turnover_db(db):
    """Menyimpan database turnover ke file JSON."""
    p = get_db_path()
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2)
    except Exception as e:
        print(f"Warning: Gagal menyimpan database turnover: {e}")


def get_all_month_records():
    """
    Mengambil seluruh daftar data bulanan yang ada di database.
    Mengembalikan list of dict terurut tanggal (kronologis):
    [
        {
            "date_str": "2026-09-01",
            "month_display": "Sep 2026",
            "cogs": 1477610.61,
            "parts_soh": 5057037.50,
            "parts_git": 218552.02,
            "parts_gini": 24208.76,
            "core_px": 530.82,
            "total_inv": 5300329.10,
            "budget_to": 2.8832,
            "is_back_sim": False
        }, ...
    ]
    """
    db = load_turnover_db()
    cogs_map = db.get("cogs_monthly", {})
    inv_map = db.get("inventory_monthly", {})
    bud_map = db.get("budget_to", {})
    back_sim = set(db.get("metadata", {}).get("back_simulated_months", []))

    all_dates = set(cogs_map.keys()) | set(inv_map.keys()) | set(bud_map.keys())
    sorted_dates = sorted(all_dates)

    records = []
    for d in sorted_dates:
        cogs_val = cogs_map.get(d, 0.0)
        inv_item = inv_map.get(d, {})
        cats = inv_item.get("categories", {}) if isinstance(inv_item, dict) else {}
        total_inv = inv_item.get("total", 0.0) if isinstance(inv_item, dict) else 0.0
        bud_val = bud_map.get(d, 3.0)

        soh = cats.get("Parts SOH", 0.0)
        git = cats.get("Parts GIT", 0.0)
        gini = cats.get("Parts GINI", 0.0)
        core_px = cats.get("Core PX", 0.0)

        if total_inv <= 0 and (soh > 0 or git > 0 or gini > 0 or core_px > 0):
            total_inv = round(soh + git + gini + core_px, 2)

        records.append({
            "date_str": d,
            "month_display": format_month_display(d),
            "cogs": float(cogs_val) if cogs_val is not None else 0.0,
            "parts_soh": float(soh),
            "parts_git": float(git),
            "parts_gini": float(gini),
            "core_px": float(core_px),
            "total_inv": float(total_inv),
            "budget_to": float(bud_val) if bud_val is not None else 3.0,
            "is_back_sim": (d in back_sim)
        })
    return records


def get_month_record(month_input):
    """Mengambil satu baris data bulanan berdasarkan string tanggal atau nama bulan (misal: 'Sep 2026')."""
    d_norm = normalize_date_str(month_input)
    if not d_norm:
        return None
    for r in get_all_month_records():
        if r["date_str"] == d_norm:
            return r
    return None


def save_month_record(month_input, cogs=None, parts_soh=0.0, parts_git=0.0, parts_gini=0.0, core_px=0.0, total_inv=None, budget_to=None):
    """
    Menyimpan atau memperbarui data satu bulan ke database.
    Jika total_inv None, dihitung otomatis dari penjumlahan: parts_soh + parts_git + parts_gini + core_px.
    """
    d_norm = normalize_date_str(month_input)
    if not d_norm:
        raise ValueError(f"Format bulan tidak valid: {month_input}")

    db = load_turnover_db()
    cogs_map = db.setdefault("cogs_monthly", {})
    inv_map = db.setdefault("inventory_monthly", {})
    bud_map = db.setdefault("budget_to", {})

    # 1. Update COGS
    if cogs is not None:
        cogs_map[d_norm] = round(float(cogs), 2)

    # 2. Update Inventory
    soh_f = round(float(parts_soh or 0), 2)
    git_f = round(float(parts_git or 0), 2)
    gini_f = round(float(parts_gini or 0), 2)
    core_f = round(float(core_px or 0), 2)

    if total_inv is not None and float(total_inv) > 0:
        tot_f = round(float(total_inv), 2)
    else:
        tot_f = round(soh_f + git_f + gini_f + core_f, 2)

    inv_map[d_norm] = {
        "total": tot_f,
        "categories": {
            "Parts SOH": soh_f,
            "Parts GIT": git_f,
            "Parts GINI": gini_f,
            "Core PX": core_f
        }
    }

    # 3. Update Budget TO
    if budget_to is not None:
        bud_map[d_norm] = round(float(budget_to), 4)

    save_turnover_db(db)
    return d_norm


def delete_month_record(month_input):
    """Menghapus data suatu bulan dari database."""
    d_norm = normalize_date_str(month_input)
    if not d_norm:
        return False

    db = load_turnover_db()
    changed = False

    if d_norm in db.get("cogs_monthly", {}):
        del db["cogs_monthly"][d_norm]
        changed = True

    if d_norm in db.get("inventory_monthly", {}):
        del db["inventory_monthly"][d_norm]
        changed = True

    if d_norm in db.get("budget_to", {}):
        del db["budget_to"][d_norm]
        changed = True

    if changed:
        save_turnover_db(db)
    return changed


def get_available_months():
    """
    Mengambil daftar nama bulan unik (misal: 'Sep 2026', 'Aug 2026', dst.)
    diurutkan dari yang TERBARU (descending). Cocok untuk dropdown pilihan bulan.
    """
    recs = get_all_month_records()
    if not recs:
        return ["Bulan Terakhir (Auto)"]

    # Filter yang memiliki data inventory atau COGS
    valid = [r for r in recs if (r["total_inv"] > 0 or r["cogs"] > 0)]
    valid.sort(key=lambda x: x["date_str"], reverse=True)

    months = [r["month_display"] for r in valid]
    # Unique preserve order
    seen = set()
    res = []
    for m in months:
        if m not in seen:
            seen.add(m)
            res.append(m)
    return res


def get_inventory_dataframe():
    """
    Membangun DataFrame histori Inventory bulanan langsung dari database internal.
    Kolom: ['Parsed_Date', 'Month_Display', 'Total_Inventory', 'Parts SOH', 'Parts GIT', 'Parts GINI', 'Core PX']
    """
    recs = get_all_month_records()
    # Hanya ambil bulan yang memiliki nilai inventory
    inv_recs = [r for r in recs if r["total_inv"] > 0]
    if not inv_recs:
        return pd.DataFrame()

    data = []
    for r in inv_recs:
        dt = pd.to_datetime(r["date_str"])
        data.append({
            "Parsed_Date": dt,
            "Month_Display": r["month_display"],
            "Total_Inventory": r["total_inv"],
            "Parts SOH": r["parts_soh"],
            "Parts GIT": r["parts_git"],
            "Parts GINI": r["parts_gini"],
            "Core PX": r["core_px"]
        })

    df = pd.DataFrame(data)
    df.sort_values("Parsed_Date", inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df


def upsert_cogs_dataframe(df_cogs, date_col="Date", val_col="COGS"):
    """
    Menggabungkan data COGS baru dari DataFrame ke dalam database internal.
    """
    db = load_turnover_db()
    cogs_map = db.setdefault("cogs_monthly", {})

    updated = False
    for _, r in df_cogs.iterrows():
        dt = r.get(date_col)
        val = r.get(val_col)
        if pd.notna(dt) and pd.notna(val):
            d_norm = normalize_date_str(dt)
            if d_norm:
                cogs_map[d_norm] = round(float(val), 2)
                updated = True

    if updated:
        save_turnover_db(db)


def upsert_inventory_dataframe(df_inv, date_col="Date", cat_col="Category", val_col="Inventory"):
    """
    Menggabungkan data Inventory baru ke dalam database internal.
    """
    db = load_turnover_db()
    inv_map = db.setdefault("inventory_monthly", {})

    updated = False
    for _, r in df_inv.iterrows():
        dt = r.get(date_col)
        cat = str(r.get(cat_col, "Total"))
        val = r.get(val_col)
        if pd.notna(dt) and pd.notna(val):
            d_norm = normalize_date_str(dt)
            if not d_norm:
                continue

            month_entry = inv_map.setdefault(d_norm, {"total": 0.0, "categories": {}})
            cats = month_entry.setdefault("categories", {})
            cats[cat] = round(float(val), 2)
            month_entry["total"] = round(sum(cats.values()), 2)
            updated = True

    if updated:
        save_turnover_db(db)


def get_cogs_series():
    """
    Mengambil seluruh histori COGS bulanan dalam format pandas Series
    yang terurut berdasarkan tanggal (Timestamp), lengkap dengan data 2025 back-simulated.
    """
    db = load_turnover_db()
    cogs_map = db.get("cogs_monthly", {})
    if not cogs_map:
        return pd.Series(dtype=float)

    data = []
    for d_str, val in cogs_map.items():
        try:
            dt = pd.to_datetime(d_str)
            data.append((dt, float(val)))
        except Exception:
            pass

    data.sort(key=lambda x: x[0])
    idx = [x[0] for x in data]
    vals = [x[1] for x in data]
    return pd.Series(vals, index=idx, name="COGS_Monthly")


def get_budget_map():
    """
    Mengambil mapping Budget TO {Month_Display (misal: 'Sep 2026'): budget_val}
    """
    db = load_turnover_db()
    bud_raw = db.get("budget_to", {})
    res = {}
    for d_str, val in bud_raw.items():
        try:
            m_disp = format_month_display(d_str)
            res[m_disp] = float(val)
        except Exception:
            pass
    return res
