"""
GIT Monitoring Helper (Goods In Transit)
Menggabungkan ekstraksi SAP (/NZMPU_PO_MONI) dan automated tracking CKB Logistics.

Aturan Kategori Rekomendasi Tindakan:
1. MERAH (Urgent): "Need GR segera"
   -> Jika status CKB adalah "Delivered" atau "Hand over Rantau" (Barang fisik sudah tiba di site/gudang).
2. KUNING: "Need follow up to sending branch for create shipment"
   -> Jika kolom Shipment Number kosong / belum ada resi dari cabang pengirim.
3. BIRU: "Need follow up shipment to ckb"
   -> Jika nomor resi ada dan status masih berjalan di CKB.
"""

import os
import sys
import time
import re
from typing import Dict, List, Optional, Callable
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from modules import ckb_tracking_helper as ckb
import config


def download_sap_git_export(
    session,
    plant: str = "1346",
    selpa: str = "WE101",
    variant: str = "/yusril",
    save_dir: Optional[str] = None,
    filename: Optional[str] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None
) -> str:
    """
    Menjalankan otomasi transaksi SAP /NZMPU_PO_MONI dan mengekspor spreadsheet ALV.
    """
    def _log(msg):
        if log_callback:
            log_callback(msg)

    def _prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    if not save_dir:
        save_dir = config.get_output_dir("sap")
    os.makedirs(save_dir, exist_ok=True)

    if not filename:
        filename = f"SAP_GIT_EXPORT_{plant}_{time.strftime('%Y%m%d_%H%M%S')}.XLSX"
    if not filename.upper().endswith(".XLSX"):
        filename += ".XLSX"

    target_file = os.path.abspath(os.path.join(save_dir, filename))
    if os.path.exists(target_file):
        try:
            os.remove(target_file)
        except Exception:
            pass

    _log(f"[SAP GIT] Membuka transaksi /NZMPU_PO_MONI (Plant: {plant}, Scope: {selpa})...")
    _prog(10, "Mengakses transaksi /NZMPU_PO_MONI...")

    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nzmpu_po_moni"
        session.findById("wnd[0]").sendVKey(0)
    except Exception:
        session.findById("wnd[0]/tbar[0]/okcd").text = "zmpu_po_moni"
        session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.0)

    # 1. Isi parameter form
    _log("[SAP GIT] Mengisi kriteria pencarian...")
    try:
        session.findById("wnd[0]/usr/ctxtSELPA-LOW").text = selpa
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_WERKS-LOW").text = plant
    except Exception:
        pass

    _prog(25, "Menjalankan query di SAP (F8)...")
    _log("[SAP GIT] Menjalankan query (F8)...")
    session.findById("wnd[0]").sendVKey(8)
    time.sleep(2.5)

    # Cek pesan error di Status Bar jika data kosong
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and sbar.messageType in ("E", "A"):
            raise RuntimeError(f"SAP Error: {sbar.text}")
    except Exception as ex:
        if "SAP Error:" in str(ex):
            raise

    # 2. Pemilihan Layout ALV
    _prog(40, f"Memilih layout ALV Variant {variant}...")
    _log(f"[SAP GIT] Menerapkan layout variant: {variant}")
    try:
        session.findById("wnd[0]/tbar[1]/btn[33]").press()
        time.sleep(1.2)

        # Dialog Select Layout
        layout_shell = session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell")
        layout_shell.currentCellRow = -1
        layout_shell.selectColumn("VARIANT")
        layout_shell.contextMenu()
        layout_shell.selectContextMenuItem("&FILTER")
        time.sleep(0.8)

        # Input filter variant
        session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = variant
        session.findById("wnd[2]").sendVKey(0)
        time.sleep(0.8)

        # Klik baris 0
        layout_shell.currentCellColumn = "TEXT"
        layout_shell.selectedRows = "0"
        layout_shell.clickCurrentCell()
        time.sleep(1.5)
    except Exception as ex:
        _log(f"[SAP GIT] Info pemilihan layout variant: {ex} (Melanjutkan dengan layout saat ini)")

    # 3. Export Spreadsheet &XXL
    _prog(55, "Mengekspor spreadsheet Excel dari SAP (&XXL)...")
    _log("[SAP GIT] Mengekspor grid ALV ke Excel...")
    try:
        grid = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
        grid.setCurrentCell(0, "EBELN")
        grid.selectedRows = "0"
        grid.contextMenu()
        grid.selectContextMenuItem("&XXL")
    except Exception:
        # Fallback tombol toolbar export jika context menu berbeda
        session.findById("wnd[0]/mbar/mprg/memu[1]/subm[0]").select()

    time.sleep(1.5)

    # Konfirmasi format dialog 1 (Excel Spreadsheet)
    try:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(1.2)
    except Exception:
        pass

    # Dialog simpan file
    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = save_dir
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception as ex:
        _log(f"[SAP GIT] Dialog simpan file: {ex}")

    _prog(65, "Menunggu file ekspor tersimpan di disk...")
    # Tunggu file selesai ditulis hingga 15 detik
    for _ in range(30):
        if os.path.exists(target_file) and os.path.getsize(target_file) > 1000:
            break
        time.sleep(0.5)

    if not os.path.exists(target_file):
        # Coba cek apakah tersimpan di C:\TEMP\EXPORT.XLSX
        temp_export = r"C:\TEMP\EXPORT.XLSX"
        if os.path.exists(temp_export):
            import shutil
            shutil.copy2(temp_export, target_file)
            _log(f"[SAP GIT] Mengambil hasil dari fallback C:\\TEMP\\EXPORT.XLSX ke {target_file}")
        else:
            raise FileNotFoundError(f"File ekspor SAP tidak ditemukan di {target_file}!")

    _log(f"[SAP GIT] Berkas ekspor SAP berhasil diunduh: {target_file} ({os.path.getsize(target_file):,} bytes)")
    return target_file


def process_git_monitoring(
    excel_path: str,
    output_dir: Optional[str] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> dict:
    """
    Membaca data ekspor SAP, melakukan tracking otomatis ke web CKB,
    mengklasifikasikan rekomendasi tindakan, dan menyusun laporan Excel resmi.
    """
    def _log(msg):
        if log_callback:
            log_callback(msg)

    def _prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"Berkas Excel tidak ditemukan: {excel_path}")

    _log(f"[GIT MONITORING] Membaca berkas data: {excel_path}")
    _prog(15, "Membaca berkas data PO/STO...")

    df = pd.read_excel(excel_path)
    total_rows = len(df)
    _log(f"[GIT MONITORING] Berhasil membaca {total_rows} baris data.")

    # Deteksi kolom penting
    col_shipment = None
    col_po = None
    col_mat = None
    col_desc = None
    col_qty = None

    for c in df.columns:
        c_low = str(c).lower()
        if "shipment" in c_low and "number" in c_low:
            col_shipment = c
        elif not col_shipment and "shipment" in c_low:
            col_shipment = c
        elif "purchasing" in c_low and "document" in c_low and "type" not in c_low:
            col_po = c
        elif not col_po and "ebeln" in c_low:
            col_po = c
        elif "material" in c_low and not col_mat:
            col_mat = c
        elif "short" in c_low and "text" in c_low and not col_desc:
            col_desc = c
        elif ("order" in c_low and "quantity" in c_low) or c_low == "menge":
            col_qty = c

    if not col_shipment:
        # Fallback cari kolom yang mengandung kata resi/ship
        for c in df.columns:
            if "ship" in str(c).lower() or "br" in str(c).lower():
                col_shipment = c
                break

    if not col_shipment:
        raise ValueError("Kolom 'Shipment Number' tidak ditemukan di berkas Excel SAP!")

    _log(f"[GIT MONITORING] Kolom terpetakan -> PO: {col_po}, Part: {col_mat}, Shipment: {col_shipment}")

    # 1. Ekstrak daftar BR unik (ambil bagian sebelum tanda '-')
    unique_br_map = {}  # clean_br -> list of indices
    row_br_cleaned = []

    for idx, raw_val in enumerate(df[col_shipment]):
        s_val = str(raw_val).strip()
        if not s_val or s_val.lower() in ("nan", "none", "-", ""):
            row_br_cleaned.append("")
        else:
            # Ambil bagian sebelum '-'
            br_clean = s_val.split("-")[0].strip()
            row_br_cleaned.append(br_clean)
            if br_clean not in unique_br_map:
                unique_br_map[br_clean] = []
            unique_br_map[br_clean].append(idx)

    total_br_unique = len(unique_br_map)
    count_without_shipment = sum(1 for b in row_br_cleaned if not b)
    _log(f"[GIT MONITORING] Terdeteksi {total_br_unique} nomor unik BR CKB. {count_without_shipment} baris belum memiliki resi.")

    # 2. Jalankan Scraping CKB
    ckb_results = {}
    if total_br_unique > 0:
        _prog(25, f"Melacak {total_br_unique} nomor resi unik di web CKB...")
        ckb_results = ckb.track_multiple_brs(
            br_list=list(unique_br_map.keys()),
            progress_callback=lambda p, m: _prog(25 + int(0.55 * p), m),
            log_callback=lambda m: _log(m)
        )

    # 3. Klasifikasi Kategori Rekomendasi Tindakan
    _prog(80, "Mengklasifikasikan status tindakan (Merah/Kuning/Biru)...")
    _log("[GIT MONITORING] Menyusun status rekomendasi tindakan...")

    actions = []
    priorities = []
    cn_numbers = []
    ship_dates = []
    ship_froms = []
    ship_tos = []
    ckb_statuses = []

    count_need_gr = 0
    count_need_branch = 0
    count_need_ckb = 0

    items_preview = []

    for idx in range(total_rows):
        br = row_br_cleaned[idx]
        po_val = str(df[col_po].iloc[idx]) if col_po else ""
        mat_val = str(df[col_mat].iloc[idx]) if col_mat else ""
        desc_val = str(df[col_desc].iloc[idx]) if col_desc else ""
        qty_val = str(df[col_qty].iloc[idx]) if col_qty else ""
        raw_ship_val = str(df[col_shipment].iloc[idx]) if pd.notna(df[col_shipment].iloc[idx]) else ""

        if not br:
            # KUNING: Tidak ada nomor resi
            act = "Need follow up to sending branch for create shipment"
            prio = "YELLOW"
            cn = "-"
            s_date = "-"
            s_from = "-"
            s_to = "-"
            st_ckb = "Belum Ada Resi"
            count_need_branch += 1
        else:
            info = ckb_results.get(br, {})
            cn = info.get("cn_number", "-")
            s_date = info.get("ship_date", "-")
            s_from = info.get("ship_from", "-")
            s_to = info.get("ship_to", "-")
            st_ckb = info.get("ckb_status", "Belum Terlacak")
            has_handover = info.get("has_handover_rantau", False)

            # Cek apakah Delivered atau Hand over Rantau
            is_delivered = "delivered" in st_ckb.lower() or "hand over" in st_ckb.lower() or has_handover or "handover" in st_ckb.lower()

            if is_delivered:
                # MERAH (Paling Urgent): Barang sudah sampai di site!
                act = "Need GR segera"
                prio = "RED"
                count_need_gr += 1
            else:
                # BIRU: Barang masih berjalan di CKB
                act = "Need follow up shipment to ckb"
                prio = "BLUE"
                count_need_ckb += 1

        actions.append(act)
        priorities.append(prio)
        cn_numbers.append(cn)
        ship_dates.append(s_date)
        ship_froms.append(s_from)
        ship_tos.append(s_to)
        ckb_statuses.append(st_ckb)

        # Simpan ke item preview (untuk UI tabel KermenX)
        if idx < 300:
            items_preview.append({
                "no": idx + 1,
                "po": po_val,
                "material": mat_val,
                "description": desc_val,
                "qty": qty_val,
                "raw_shipment": raw_ship_val,
                "br_number": br or "-",
                "cn_number": cn,
                "ship_date": s_date,
                "ship_from": s_from,
                "ship_to": s_to,
                "ckb_status": st_ckb,
                "action": act,
                "priority": prio
            })

    # Tambahkan kolom-kolom baru ke DataFrame
    df["BR Number (CKB)"] = [b or "-" for b in row_br_cleaned]
    df["CN Number (CKB)"] = cn_numbers
    df["Tanggal Kirim (CKB)"] = ship_dates
    df["Ship From (CKB)"] = ship_froms
    df["Ship To (CKB)"] = ship_tos
    df["Status CKB Terkini"] = ckb_statuses
    df["Rekomendasi Tindakan"] = actions
    df["Prioritas"] = priorities

    # 4. Buat File Excel Laporan Resmi Berwarna
    _prog(90, "Menyusun berkas laporan Excel GIT berformat eksekutif...")
    if not output_dir:
        output_dir = config.get_output_dir("sap")
    os.makedirs(output_dir, exist_ok=True)

    timestamp_str = time.strftime("%Y%m%d_%H%M%S")
    out_filename = f"LAPORAN_GIT_MONITORING_{timestamp_str}.XLSX"
    out_filepath = os.path.abspath(os.path.join(output_dir, out_filename))

    _save_styled_excel(df, out_filepath, count_need_gr, count_need_branch, count_need_ckb)
    _log(f"[GIT MONITORING] Laporan selesai disimpan di: {out_filepath}")
    _prog(100, "Pemantauan GIT Selesai!")

    return {
        "status": "success",
        "output_path": out_filepath,
        "total_rows": total_rows,
        "total_br_unique": total_br_unique,
        "count_need_gr": count_need_gr,
        "count_need_branch": count_need_branch,
        "count_need_ckb": count_need_ckb,
        "items": items_preview
    }


def _save_styled_excel(df: pd.DataFrame, file_path: str, cnt_gr: int, cnt_br: int, cnt_ckb: int):
    """
    Menyimpan DataFrame ke berkas Excel dengan styling warna rapi menggunakan openpyxl.
    """
    wb = openpyxl.Workbook()
    # Sheet 1: Detail GIT
    ws = wb.active
    ws.title = "GIT Monitoring Details"

    # Styling Palettes
    header_font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")  # Dark Slate

    thin_border = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1")
    )

    # Action Status Fills & Fonts
    # RED: Need GR segera (Urgent)
    red_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    red_font = Font(name="Segoe UI", size=9.5, bold=True, color="991B1B")

    # YELLOW: Need follow up to sending branch
    yellow_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    yellow_font = Font(name="Segoe UI", size=9.5, bold=True, color="92400E")

    # BLUE: Need follow up shipment to ckb
    blue_fill = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")
    blue_font = Font(name="Segoe UI", size=9.5, bold=True, color="1E40AF")

    data_font = Font(name="Segoe UI", size=9.5)
    data_align = Alignment(vertical="center")

    # Tulis Header Ringkasan KPI di Baris 1-3
    ws.merge_cells("A1:G1")
    ws["A1"] = "RINGKASAN STATUS MONITORING GOODS IN TRANSIT (GIT & CKB TRACKING)"
    ws["A1"].font = Font(name="Segoe UI", size=12, bold=True, color="1E293B")

    ws["A2"] = "🔴 NEED GR SEGERA (Barang Tiba di Site)"
    ws["B2"] = cnt_gr
    ws["A2"].font = Font(name="Segoe UI", size=10, bold=True, color="DC2626")
    ws["B2"].font = Font(name="Segoe UI", size=10, bold=True, color="DC2626")

    ws["C2"] = "🟡 NEED FOLLOW UP CABANG PENGIRIM (Belum Ada Resi)"
    ws["D2"] = cnt_br
    ws["C2"].font = Font(name="Segoe UI", size=10, bold=True, color="D97706")
    ws["D2"].font = Font(name="Segoe UI", size=10, bold=True, color="D97706")

    ws["E2"] = "🔵 NEED FOLLOW UP EKSPEDISI CKB (In Transit)"
    ws["F2"] = cnt_ckb
    ws["E2"].font = Font(name="Segoe UI", size=10, bold=True, color="2563EB")
    ws["F2"].font = Font(name="Segoe UI", size=10, bold=True, color="2563EB")

    # Baris 5: Table Headers
    start_row = 5
    cols = list(df.columns)
    # Hapus kolom Prioritas dari tampilan jika hanya untuk styling
    if "Prioritas" in cols:
        cols.remove("Prioritas")

    for col_idx, col_name in enumerate(cols, start=1):
        cell = ws.cell(row=start_row, column=col_idx, value=str(col_name))
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border

    ws.row_dimensions[start_row].height = 28

    # Tulis Data Rows
    act_col_idx = cols.index("Rekomendasi Tindakan") + 1 if "Rekomendasi Tindakan" in cols else None

    for r_idx, (_, row) in enumerate(df.iterrows(), start=start_row + 1):
        ws.row_dimensions[r_idx].height = 20
        act_val = str(row.get("Rekomendasi Tindakan", ""))
        prio_val = str(row.get("Prioritas", ""))

        for c_idx, col_name in enumerate(cols, start=1):
            val = row[col_name]
            cell = ws.cell(row=r_idx, column=c_idx, value=val if pd.notna(val) else "-")
            cell.font = data_font
            cell.alignment = data_align
            cell.border = thin_border

            # Highlight khusus pada kolom Rekomendasi Tindakan
            if c_idx == act_col_idx:
                if prio_val == "RED":
                    cell.fill = red_fill
                    cell.font = red_font
                elif prio_val == "YELLOW":
                    cell.fill = yellow_fill
                    cell.font = yellow_font
                elif prio_val == "BLUE":
                    cell.fill = blue_fill
                    cell.font = blue_font

    # Auto-fit lebar kolom
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            # Skip baris KPI merge A1
            if cell.row in (1, 2, 3):
                continue
            v_str = str(cell.value or "")
            if len(v_str) > max_len:
                max_len = len(v_str)
        ws.column_dimensions[col_letter].width = min(max(max_len + 3, 11), 45)

    ws.freeze_panes = f"A{start_row + 1}"

    wb.save(file_path)

