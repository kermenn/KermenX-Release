Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = scriptDir & "\app"
WshShell.Run Chr(34) & scriptDir & "\app\KermenX.exe" & Chr(34), 1, False
