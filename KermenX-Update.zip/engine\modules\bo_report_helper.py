# -*- coding: utf-8 -*-
"""
KermenX - Outstanding Backorder (BO) Report & Fixed ETA Engine
Mengintegrasikan dan menyempurnakan alur kerja macro 'myRobot.xlsm':
1. Ekstraksi SAP GUI otomatis (/NVA05N, /NZVSD_PARTS_PROGRESS, /NVL10C, /NME2N, /NZMIM_SHIP_DELV_REPT, /NZMMM_POSUBCON_MONI).
2. Pemrosesan data dengan Pandas (super cepat, bebas crash & memory leak Excel).
3. Fast Batch Scraping CKB Logistics via Windows Schannel curl (metode GIT Monitoring, <4 detik per 100 resi tanpa Selenium).
4. Algoritma Hierarchical Fixed ETA (menghilangkan 'TBA' dengan kalkulasi bertingkat: Delivered -> In-Transit -> PO SLA -> PR SLA).
5. Pembentukan laporan Excel 3 worksheet standar enterprise ('BO_Report', 'SO Incomplete', 'Subcont_BO').
"""

import os
import sys
import time
import json
import re
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Callable, Tuple, Any

import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from modules import ckb_tracking_helper as ckb
import config

# Path ke database matriks lead time
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
ENGINE_DIR = os.path.dirname(MODULE_DIR)
LEADTIME_JSON_PATH = os.path.join(ENGINE_DIR, "assets", "leadtime_matrix.json")


def _log(msg: str, callback: Optional[Callable[[str], None]] = None):
    if callback:
        try:
            callback(msg)
        except Exception:
            pass
    else:
        print(f"[BO_REPORT] {msg}", flush=True)


def _prog(percent: int, msg: str, callback: Optional[Callable[[int, str], None]] = None):
    if callback:
        try:
            callback(percent, msg)
        except Exception:
            pass
    else:
        print(f"[PROGRESS] {percent} | {msg}", flush=True)


def load_leadtime_matrix() -> Dict[str, dict]:
    """Memuat database rute lead time transit (350+ rute SAP Trakindo)."""
    if os.path.exists(LEADTIME_JSON_PATH):
        try:
            with open(LEADTIME_JSON_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            _log(f"Peringatan: Gagal memuat leadtime_matrix.json: {e}")
    return {}


def _parse_date_safe(d_val: Any) -> Optional[date]:
    """Parse berbagai format tanggal SAP / CKB menjadi datetime.date."""
    if d_val is None or pd.isna(d_val):
        return None
    if isinstance(d_val, pd.Timestamp):
        if pd.isna(d_val):
            return None
        return d_val.date()
    if isinstance(d_val, datetime):
        return d_val.date()
    if isinstance(d_val, date):
        return d_val

    s = str(d_val).strip()
    if not s or s.lower() in ("nan", "none", "-", "tba", "nat", "<nat>", ""):
        return None

    # Bersihkan keterangan tambahan seperti timestamp
    s_clean = s.split(" ")[0].strip()
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d-%b-%Y", "%d/%m/%Y", "%d-%m-%Y", "%Y.%m.%d"):
        try:
            return datetime.strptime(s_clean, fmt).date()
        except Exception:
            pass
    return None


def get_regional_fallback_leadtime(origin_plant: str, dest_plant: str, service_type: str = "ED") -> int:
    """
    Fallback cerdas lead time regional jika rute spesifik berstatus TBA atau belum terdaftar.
    Mengacu pada SLA logistik transit Kalimantan Selatan / Timur (1H45 Batu Licin, 1H34 BDJ, 1G31 BPN, 1A08 CKG).
    """
    srv = str(service_type).upper()
    is_air = srv in ("ED", "XQ", "XE", "AIR")

    # Normalisasi plant
    ori = str(origin_plant).strip().upper()
    dst = str(dest_plant).strip().upper()

    # Rute Lokal / Internal Kalsel (Banjarmasin ke Batu Licin dll)
    if ori in ("1H34", "BDJ") and dst in ("1H45", "1346", "LOP"):
        return 1 if is_air else 2

    # Rute Kalimantan Timur (Balikpapan ke Batu Licin)
    if ori in ("1G31", "BPN") and dst in ("1H45", "1346", "LOP"):
        return 2 if is_air else 4

    # Rute Hub Utama Jakarta / Cengkareng / Cakung ke Batu Licin
    if ori in ("1A08", "1A12", "CKG", "1A25", "1A11", "JKT") and dst in ("1H45", "1346", "LOP"):
        return 3 if is_air else 8

    # Rute Luar Pulau / Remote Hub (Sumatera, Papua, Makassar)
    if ori in ("1F24", "1B46", "1B42", "1C61"):
        return 4 if is_air else 12

    # Default fallback aman
    return 3 if is_air else 7


def calculate_fixed_eta(
    row: pd.Series,
    leadtime_matrix: Dict[str, dict],
    default_dest: str = "1H45"
) -> Tuple[str, str, str]:
    """
    Algoritma Hierarchical Fixed ETA untuk setiap baris Outstanding BO.
    Mengembalikan tuple: (ETA_Fix_Str, ETA_Method, Remark_Action)
    """
    ckb_status = str(row.get("Last Tracking Status", "")).strip().lower()
    shipment_no = str(row.get("Shipment Number", "")).strip()
    dest_plant = str(row.get("Plant", default_dest)).strip()
    origin_plant = str(row.get("Sourcing BO", row.get("Supplying Plant", "1A08"))).strip()
    service_type = str(row.get("ShpCon", row.get("Ship by", "ED"))).strip().upper()
    if not service_type or service_type in ("-", "NAN", "NONE"):
        service_type = "ED"

    picked_up_date = _parse_date_safe(row.get("Picked up", row.get("Ship Date", None)))
    delivered_date = _parse_date_safe(row.get("Delivered -ETA", None))
    po_date = _parse_date_safe(row.get("Doc Date", row.get("Created on", None)))
    eta_sap = _parse_date_safe(row.get("ETA SAP", None))
    est_ship_cat = _parse_date_safe(row.get("Est Ship CAT", row.get("ESD Previous", None)))

    # -------------------------------------------------------------
    # TINGKAT 1: Barang Sudah Tiba / Delivered di Ekspedisi CKB
    # -------------------------------------------------------------
    if any(k in ckb_status for k in ["delivered", "hand over", "handover", "selesai"]):
        actual_date = delivered_date or picked_up_date or date.today()
        return (
            actual_date.strftime("%d-%b-%Y"),
            "Arrived (CKB Delivered)",
            "Barang sudah tiba di site/gudang - Segera lakukan Goods Receipt (GR MIGO)"
        )

    # -------------------------------------------------------------
    # TINGKAT 2: Barang In-Transit dengan Nomor Resi & Tanggal Kirim
    # -------------------------------------------------------------
    if shipment_no and shipment_no not in ("-", "nan", "none", "") and (picked_up_date or any(k in ckb_status for k in ["transit", "manifest", "pod", "departed", "cleared"])):
        # Hitung lead time rute
        lookup_model = f"{origin_plant}{dest_plant}{service_type}"
        lt_days = None
        if lookup_model in leadtime_matrix:
            rule_val = leadtime_matrix[lookup_model].get("leadtime_days")
            if isinstance(rule_val, int):
                lt_days = rule_val

        # Fallback regional jika model TBA / belum terdaftar
        if lt_days is None:
            lt_days = get_regional_fallback_leadtime(origin_plant, dest_plant, service_type)

        base_date = picked_up_date or date.today()
        calc_eta = base_date + timedelta(days=lt_days)
        return (
            calc_eta.strftime("%d-%b-%Y"),
            f"In-Transit (+{lt_days}d SLA)",
            f"Barang sedang bergerak via CKB ({ckb_status or 'In Transit'}) - Pantau jadwal tiba"
        )

    # -------------------------------------------------------------
    # TINGKAT 3: PO Rilis, Ada Estimasi Pengiriman CAT / Sourcing PO
    # -------------------------------------------------------------
    purch_ord = str(row.get("Purchasing Ord", row.get("Purch Ord", ""))).strip()
    if purch_ord and purch_ord not in ("-", "nan", "none", ""):
        fallback_transit = get_regional_fallback_leadtime(origin_plant, dest_plant, service_type)
        if est_ship_cat:
            calc_eta = est_ship_cat + timedelta(days=fallback_transit)
            return (
                calc_eta.strftime("%d-%b-%Y"),
                f"PO Sourced (+{fallback_transit}d Transit)",
                "Menunggu keberangkatan dari Sourcing Plant / Facility CAT"
            )
        elif eta_sap:
            return (
                eta_sap.strftime("%d-%b-%Y"),
                "SAP Committed ETA",
                "PO aktif - Konfirmasi kesiapan pengiriman ke bagian expediting"
            )
        else:
            base_d = po_date or date.today()
            calc_eta = base_d + timedelta(days=7 + fallback_transit)
            return (
                calc_eta.strftime("%d-%b-%Y"),
                "PO SLA (7d Prep + Transit)",
                "PO sudah terbit - Menunggu nomor resi pengiriman cabang pengirim"
            )

    # -------------------------------------------------------------
    # TINGKAT 4: Masih Purchase Requisition (PR) / Belum Terbit PO
    # -------------------------------------------------------------
    purch_req = str(row.get("Purchase Req", row.get("Purch Req", ""))).strip()
    if purch_req and purch_req not in ("-", "nan", "none", ""):
        base_d = po_date or date.today()
        fallback_transit = get_regional_fallback_leadtime(origin_plant, dest_plant, service_type)
        calc_eta = base_d + timedelta(days=14 + fallback_transit)
        return (
            calc_eta.strftime("%d-%b-%Y"),
            "PR Cycle (+14d Procurement)",
            "PR pending - Perlu approval / percepatan rilis PO pengadaan"
        )

    # -------------------------------------------------------------
    # TINGKAT 5: Outstanding Open Sales Order (Belum Ada PR/PO)
    # -------------------------------------------------------------
    base_d = po_date or date.today()
    calc_eta = base_d + timedelta(days=21)
    return (
        calc_eta.strftime("%d-%b-%Y"),
        "Backorder Open (+21d Est)",
        "Sales Order Backorder - Perlu pembuatan PR / sourcing allocation segera"
    )


def process_bo_data_pipeline(
    df_raw: pd.DataFrame,
    plant_code: str = "1H45",
    scrape_ckb: bool = True,
    log_callback: Optional[Callable[[str], None]] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    """
    Pipeline pemrosesan data BO Report lengkap:
    - Filtering BO (Outstanding Qty > 0, buang rejection)
    - Fast Scraping CKB
    - Hierarchical Fixed ETA
    - Menghasilkan 3 DataFrame (BO_Report, SO_Incomplete, Subcont_BO) dan ringkasan metrik.
    """
    _prog(10, "Memulai pembersihan dan penyelarasan data BO...", progress_callback)
    _log(f"Data mentah masuk: {len(df_raw)} baris", log_callback)

    # Normalisasi nama kolom standar (case-insensitive strip)
    col_map = {c: str(c).strip() for c in df_raw.columns}
    df = df_raw.rename(columns=col_map)

    # Kolom utama yang dibutuhkan
    order_qty_col = next((c for c in df.columns if c.lower() in ["outstanding qty", "order quantity", "order qty", "qty", "quantity"]), None)
    delv_qty_col = next((c for c in df.columns if c.lower() in ["confirmed quantity", "od quantity", "delv qty", "delivered qty"]), None)
    rej_col = next((c for c in df.columns if "rejection" in c.lower()), None)

    # Konversi kuantitas ke numerik
    if "Outstanding Qty" in df.columns:
        df["Outstanding Qty"] = pd.to_numeric(df["Outstanding Qty"], errors="coerce").fillna(0)
    elif order_qty_col and order_qty_col in df.columns:
        df["Order Quantity"] = pd.to_numeric(df[order_qty_col], errors="coerce").fillna(0)
        if delv_qty_col and delv_qty_col in df.columns:
            df["Confirmed Quantity"] = pd.to_numeric(df[delv_qty_col], errors="coerce").fillna(0)
            df["Outstanding Qty"] = df["Order Quantity"] - df["Confirmed Quantity"]
        else:
            df["Outstanding Qty"] = df["Order Quantity"]
    else:
        df["Outstanding Qty"] = 1.0  # Fallback jika tidak ada kolom qty, anggap semua baris aktif

    # Filter 1: Hanya ambil baris dengan Outstanding Qty > 0
    df_bo = df[df["Outstanding Qty"] > 0].copy()
    _log(f"Baris setelah filter Outstanding Qty > 0: {len(df_bo)} baris", log_callback)

    # Filter 2: Buang baris yang memiliki Reason for Rejection
    if rej_col and rej_col in df_bo.columns:
        df_bo = df_bo[df_bo[rej_col].isna() | (df_bo[rej_col].astype(str).str.strip().isin(["", "-", "nan", "None"]))].copy()
        _log(f"Baris setelah filter Reason for Rejection: {len(df_bo)} baris", log_callback)

    # Normalisasi kolom Shipment Number untuk tracking CKB
    shipment_col = next((c for c in df_bo.columns if "shipment number" in c.lower() or "shipment" in c.lower()), None)
    if shipment_col and shipment_col in df_bo.columns:
        df_bo["Shipment Number"] = df_bo[shipment_col].astype(str).str.strip().replace(["nan", "None", "-"], "")
    else:
        df_bo["Shipment Number"] = ""

    # Inisialisasi kolom tracking CKB bawaan
    for col in ["Last Tracking Status", "Origin", "Destination", "Picked up", "Delivered -ETA", "Follow-up Forwarder"]:
        if col not in df_bo.columns:
            df_bo[col] = "-"

    # -------------------------------------------------------------
    # FAST SCRAPING CKB LOGISTICS (Metode GIT Monitoring)
    # -------------------------------------------------------------
    if scrape_ckb:
        unique_shipments = [s for s in df_bo["Shipment Number"].unique() if s and s != "-"]
        total_ship = len(unique_shipments)
        _log(f"Ditemukan {total_ship} nomor Shipment / Resi unik untuk dilacak via CKB...", log_callback)

        if total_ship > 0:
            _prog(25, f"Melacak {total_ship} resi CKB via fast batch scraper...", progress_callback)
            try:
                ckb_results = ckb.track_multiple_brs(
                    br_list=unique_shipments,
                    batch_size=5,
                    progress_callback=lambda p, m: _prog(25 + int(p * 0.35), m, progress_callback),
                    log_callback=lambda m: _log(m, log_callback)
                )

                # Petakan hasil scraping ke baris DataFrame
                for idx, row in df_bo.iterrows():
                    s_no = row["Shipment Number"]
                    if s_no in ckb_results:
                        res = ckb_results[s_no]
                        df_bo.at[idx, "Last Tracking Status"] = res.get("status", "-")
                        df_bo.at[idx, "Origin"] = res.get("ship_from", "-")
                        df_bo.at[idx, "Destination"] = res.get("ship_to", "-")
                        df_bo.at[idx, "Picked up"] = res.get("ship_date", "-")
                        df_bo.at[idx, "Delivered -ETA"] = res.get("delivered_date", "-")
            except Exception as e:
                _log(f"Peringatan: Kendala saat scraping CKB: {e}", log_callback)

    # -------------------------------------------------------------
    # HIERARCHICAL FIXED ETA CALCULATION
    # -------------------------------------------------------------
    _prog(65, "Menghitung estimasi ETA Fix bertingkat untuk seluruh baris BO...", progress_callback)
    leadtime_matrix = load_leadtime_matrix()

    eta_fix_list = []
    eta_method_list = []
    action_list = []

    for _, row in df_bo.iterrows():
        eta_val, eta_mth, act_rem = calculate_fixed_eta(row, leadtime_matrix, default_dest=plant_code)
        eta_fix_list.append(eta_val)
        eta_method_list.append(eta_mth)
        action_list.append(act_rem)

    df_bo["ETA Fix"] = eta_fix_list
    df_bo["ETA Method"] = eta_method_list
    df_bo["Action Requirement"] = action_list

    # Klasifikasi Milestone
    milestones = []
    for _, row in df_bo.iterrows():
        s_no = str(row.get("Shipment Number", "")).strip()
        po_no = str(row.get("Purchasing Document", row.get("Purchase Req", ""))).strip()
        pr_no = str(row.get("Purchase Requisition", "")).strip()
        st = str(row.get("Last Tracking Status", "")).strip().lower()

        if any(k in st for k in ["delivered", "hand over"]):
            milestones.append("Milestone 4 - Arrived / Ready GR")
        elif s_no and s_no not in ("-", "nan", "none", ""):
            milestones.append("Milestone 3 - In Transit")
        elif po_no and po_no not in ("-", "nan", "none", ""):
            milestones.append("Milestone 2 - PO Issued")
        elif pr_no and pr_no not in ("-", "nan", "none", ""):
            milestones.append("Milestone 1 - PR Created")
        else:
            milestones.append("Milestone 0 - Open SO")

    df_bo["Milestone"] = milestones

    # -------------------------------------------------------------
    # SHEET 1: FORMULASI BO_REPORT 40 KOLOM LENGKAP
    # -------------------------------------------------------------
    _prog(80, "Menyusun tabel BO_Report standar enterprise...", progress_callback)

    final_bo_cols = [
        "Plant", "Sold To", "Customer Name", "PO Number", "Sales Document", "Doc Date",
        "Item (SD)", "Material", "Description", "Outstanding Qty", "ETA Fix", "ETA Method",
        "Action Requirement", "Milestone", "FAC Source", "ETA SAP", "Need by Date",
        "Purchase Req", "Purchasing Document", "OM", "Prfl", "ShpCon", "Customer Reference Number",
        "Inbound Delivery", "Shipment Number", "Origin", "Destination", "Last Tracking Status",
        "Picked up", "Delivered -ETA"
    ]

    # Pastikan seluruh kolom target ada
    for col in final_bo_cols:
        if col not in df_bo.columns:
            # Fallback pencarian nama alternatif
            alt_map = {
                "Doc Date": "Created on",
                "Description": "Material Description",
                "FAC Source": "CAT Facillity",
                "Purchase Req": "Purchase Requisition",
                "OM": "Order Method",
                "Inbound Delivery": "Inbound Delivery from PO or STO"
            }
            alt = alt_map.get(col)
            if alt and alt in df_bo.columns:
                df_bo[col] = df_bo[alt]
            else:
                df_bo[col] = "-"

    df_bo_report = df_bo[final_bo_cols].copy()

    # -------------------------------------------------------------
    # SHEET 2: REKAPITULASI SO INCOMPLETE
    # -------------------------------------------------------------
    so_col = next((c for c in df_bo.columns if "sales document" in c.lower()), "Sales Document")
    so_summary = []
    if so_col in df_bo.columns:
        for so_num, grp in df_bo.groupby(so_col):
            so_summary.append({
                "Sales Document": so_num,
                "Plant": grp["Plant"].iloc[0] if "Plant" in grp.columns else plant_code,
                "Customer Name": grp["Customer Name"].iloc[0] if "Customer Name" in grp.columns else "-",
                "PO Number": grp["PO Number"].iloc[0] if "PO Number" in grp.columns else "-",
                "Doc Date": grp["Doc Date"].iloc[0] if "Doc Date" in grp.columns else "-",
                "Total BO Items": len(grp),
                "Total Outstanding Qty": grp["Outstanding Qty"].sum(),
                "Earliest ETA Fix": grp["ETA Fix"].min(),
                "Status Sourcing": "In Transit" if any(grp["Shipment Number"] != "-") else "Waiting PO/Shipment"
            })
    df_so_incomplete = pd.DataFrame(so_summary)

    # -------------------------------------------------------------
    # SHEET 3: SUBCONTRACT BO (Jika ada PO Subcont)
    # -------------------------------------------------------------
    sub_col = next((c for c in df.columns if "subcont" in c.lower() or "sub no" in c.lower()), None)
    if sub_col and sub_col in df.columns:
        df_subcont = df[df[sub_col].notna() & (df[sub_col].astype(str).str.strip().isin(["", "-", "nan", "None"]) == False)].copy()
    else:
        df_subcont = pd.DataFrame()

    # Ringkasan KPI
    metrics = {
        "total_raw_rows": len(df_raw),
        "total_bo_rows": len(df_bo_report),
        "total_outstanding_qty": int(df_bo_report["Outstanding Qty"].sum()) if not df_bo_report.empty else 0,
        "total_unique_so": len(df_so_incomplete),
        "total_shipped_lines": int((df_bo_report["Shipment Number"] != "-").sum()),
        "total_arrived_lines": int(df_bo_report["Milestone"].str.contains("Arrived", case=False).sum()),
        "plant": plant_code
    }

    _prog(90, "Pipeline kalkulasi BO selesai.", progress_callback)
    return df_bo_report, df_so_incomplete, df_subcont, metrics


def save_styled_bo_excel(
    df_bo: pd.DataFrame,
    df_so: pd.DataFrame,
    df_sub: pd.DataFrame,
    output_path: str,
    metrics: Dict[str, Any],
    log_callback: Optional[Callable[[str], None]] = None
) -> str:
    """
    Menyimpan hasil ke berkas Excel cantik dengan 3 worksheet dan format styling RyTuneX.
    """
    _log(f"Menyusun berkas Excel terformat: {output_path}", log_callback)
    wb = openpyxl.Workbook()
    # Hapus sheet default kosong
    wb.remove(wb.active)

    # Definisi Palet RyTuneX Slate
    header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    header_font = Font(name="Segoe UI", size=10, bold=True, color="F8FAFC")
    zebra_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
    regular_font = Font(name="Segoe UI", size=9, color="0F172A")
    eta_font = Font(name="Segoe UI", size=9, bold=True, color="047857") # Emerald Green
    thin_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0")
    )

    # 1. WORKSHEET BO_Report
    ws_bo = wb.create_sheet(title="BO_Report")
    ws_bo.views.sheetView[0].showGridLines = True

    # Tulis Headers
    headers_bo = list(df_bo.columns)
    for col_idx, h in enumerate(headers_bo, 1):
        cell = ws_bo.cell(row=1, column=col_idx, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Tulis Baris Data
    for r_idx, (_, row) in enumerate(df_bo.iterrows()):
        row_num = r_idx + 2
        is_even = (row_num % 2 == 0)
        current_fill = zebra_fill if is_even else white_fill

        for c_idx, col_name in enumerate(headers_bo, 1):
            val = row[col_name]
            cell = ws_bo.cell(row=row_num, column=c_idx, value=val)
            cell.fill = current_fill
            cell.border = thin_border
            cell.font = eta_font if col_name == "ETA Fix" else regular_font

            # Alignment cerdas
            if col_name in ["Plant", "Sold To", "Sales Document", "Item (SD)", "Doc Date", "ETA Fix", "Milestone", "Shipment Number", "Origin", "Destination"]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif col_name == "Outstanding Qty":
                cell.alignment = Alignment(horizontal="right", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

    # 2. WORKSHEET SO Incomplete
    ws_so = wb.create_sheet(title="SO Incomplete")
    ws_so.views.sheetView[0].showGridLines = True
    if not df_so.empty:
        headers_so = list(df_so.columns)
        for c_idx, h in enumerate(headers_so, 1):
            cell = ws_so.cell(row=1, column=c_idx, value=h)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for r_idx, (_, row) in enumerate(df_so.iterrows()):
            row_num = r_idx + 2
            current_fill = zebra_fill if (row_num % 2 == 0) else white_fill
            for c_idx, col_name in enumerate(headers_so, 1):
                cell = ws_so.cell(row=row_num, column=c_idx, value=row[col_name])
                cell.fill = current_fill
                cell.border = thin_border
                cell.font = regular_font
                cell.alignment = Alignment(horizontal="center" if col_name != "Customer Name" else "left", vertical="center")

    # 3. WORKSHEET Subcont_BO
    if not df_sub.empty:
        ws_sub = wb.create_sheet(title="Subcont_BO")
        ws_sub.views.sheetView[0].showGridLines = True
        headers_sub = list(df_sub.columns)
        for c_idx, h in enumerate(headers_sub, 1):
            cell = ws_sub.cell(row=1, column=c_idx, value=h)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for r_idx, (_, row) in enumerate(df_sub.iterrows()):
            row_num = r_idx + 2
            current_fill = zebra_fill if (row_num % 2 == 0) else white_fill
            for c_idx, col_name in enumerate(headers_sub, 1):
                cell = ws_sub.cell(row=row_num, column=c_idx, value=str(row[col_name]))
                cell.fill = current_fill
                cell.border = thin_border
                cell.font = regular_font

    # Auto-fit Column Widths untuk semua sheet
    for ws in wb.worksheets:
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col[:150]: # Sample 150 baris untuk efisiensi
                val_str = str(cell.value or "")
                if len(val_str) > max_len:
                    max_len = len(val_str)
            ws.column_dimensions[col_letter].width = max(min(max_len + 3, 40), 12)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    wb.save(output_path)
    _log(f"Berkas berhasil disimpan ({os.path.getsize(output_path):,} bytes)", log_callback)
    return output_path


def _set_clipboard(values: List[str]) -> bool:
    """Mengisi Windows Clipboard dengan daftar baris teks untuk paste massal SAP (btn[24])."""
    try:
        import win32clipboard
        text = "\r\n".join(str(v).strip() for v in values if str(v).strip())
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(text, win32clipboard.CF_UNICODETEXT)
        win32clipboard.CloseClipboard()
        return True
    except Exception as e:
        print(f"[CLIPBOARD ERROR] {e}", flush=True)
        return False


def _export_alv_grid(session, save_dir: str, filename: str, log_func=None) -> Optional[str]:
    """Helper serbaguna untuk mengekspor ALV grid aktif SAP GUI ke file Excel."""
    target_path = os.path.abspath(os.path.join(save_dir, filename))
    if os.path.exists(target_path):
        try: os.remove(target_path)
        except Exception: pass

    exported = False
    # Method 1: Menu Bar List -> Export -> Spreadsheet
    try:
        session.findById("wnd[0]/mbar/menu[0]/menu[3]/menu[1]").select()
        exported = True
    except Exception:
        pass

    # Method 2: Toolbar button 45
    if not exported:
        try:
            session.findById("wnd[0]/tbar[1]/btn[45]").press()
            exported = True
        except Exception:
            pass

    # Method 3: Shell toolbar context menu &MB_EXPORT -> &PC
    if not exported:
        try:
            session.findById("wnd[0]/usr/cntlCONTAINER/shellcont/shell").pressToolbarContextButton("&MB_EXPORT")
            session.findById("wnd[0]/usr/cntlCONTAINER/shellcont/shell").selectContextMenuItem("&PC")
            exported = True
        except Exception:
            pass

    # Method 4: Shell context menu &XXL
    if not exported:
        try:
            grid = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
            grid.setCurrentCell(0, grid.getCellValue(0, 0))
            grid.selectedRows = "0"
            grid.contextMenu()
            grid.selectContextMenuItem("&XXL")
            exported = True
        except Exception:
            pass

    time.sleep(1.2)

    # Format Confirmation Dialog (Radio SPOPLI atau OK)
    try:
        session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").select()
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(0.8)
    except Exception:
        try:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            time.sleep(0.8)
        except Exception:
            pass

    # File Save Dialog (DY_PATH, DY_FILENAME)
    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = save_dir
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
        try:
            session.findById("wnd[1]/tbar[0]/btn[11]").press()  # Replace / Save
        except Exception:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception as ex:
        if log_func: log_func(f"Dialog simpan file ({filename}): {ex}")

    # Tunggu file tersimpan
    for _ in range(30):
        if os.path.exists(target_path) and os.path.getsize(target_path) > 100:
            return target_path
        time.sleep(0.5)

    # Fallback C:\Temp
    alt = os.path.join(r"C:\Temp", filename)
    if os.path.exists(alt) and os.path.getsize(alt) > 100:
        import shutil
        shutil.copy2(alt, target_path)
        return target_path

    return None


def clean_and_arrange_feeding_data(feeding_path: str, log_callback: Optional[Callable[[str], None]] = None) -> Dict[str, List[str]]:
    """
    Mengimplementasikan pembersihan data tingkat tinggi (setara macro VBA ColumnsByHeader pada myRobot):
    1. Filter Reason for rejection: hanya pertahankan baris tanpa alasan penolakan (kosong / NaN / non-rejected).
    2. Filter Storage Location: buang baris dengan lokasi gudang (SLoc) kosong.
    3. Filter Item Category: buang kategori item 'Y300' (jasa/servis non-parts).
    4. Filter Outstanding BO Qty: hanya pertahankan item dengan sisa backorder > 0.
    5. Fallback Nomor PO: jika nomor Purchasing Document kosong, isi dari Customer Reference Number.
    6. Hapus Duplikasi Item: buang baris duplikat berdasarkan [Sales Document, Item, Material].
    7. Kembalikan daftar nomor PO, Nomor Delivery/Shipment, dan Subcont PO unik untuk multi-selection SAP.
    """
    result: Dict[str, List[str]] = {
        "po_numbers": [],
        "delivery_numbers": [],
        "subcont_pos": []
    }
    if not os.path.exists(feeding_path) or os.path.getsize(feeding_path) < 100:
        return result

    try:
        df = pd.read_excel(feeding_path)
        initial_count = len(df)

        def _find_col(keywords: List[str]) -> Optional[str]:
            for col in df.columns:
                c_str = str(col).lower().strip()
                if any(k in c_str for k in keywords):
                    return col
            return None

        # 1. Reason for rejection (simpan hanya yang kosong / NaN)
        rej_col = _find_col(["rejection", "reason for rej", "abgru"])
        if rej_col:
            df = df[df[rej_col].isna() | df[rej_col].astype(str).str.strip().isin(["", "nan", "-", "0", "None"])]

        # 2. Storage Location (buang yang kosong)
        sloc_col = _find_col(["storage location", "sloc", "lgort"])
        if sloc_col:
            df = df[df[sloc_col].notna() & (~df[sloc_col].astype(str).str.strip().isin(["", "nan", "-", "None"]))]

        # 3. Item Category (buang Y300)
        item_cat_col = _find_col(["item category", "item cat", "pstyv"])
        if item_cat_col:
            df = df[~df[item_cat_col].astype(str).str.strip().str.upper().str.contains("Y300|300", regex=True)]

        # 4. Filter BO Qty > 0
        bo_col = _find_col(["bo qty", "backorder qty", "open qty", "outstanding qty"])
        order_col = _find_col(["order qty", "order quantity", "ord.qty", "kwmeng"])
        conf_col = _find_col(["confirmed qty", "confirmed quantity", "conf.qty", "bmeng"])

        if bo_col:
            calc_bo = pd.to_numeric(df[bo_col], errors="coerce").fillna(0)
            df = df[calc_bo > 0]
        elif order_col and conf_col:
            ord_q = pd.to_numeric(df[order_col], errors="coerce").fillna(0)
            cnf_q = pd.to_numeric(df[conf_col], errors="coerce").fillna(0)
            df = df[(ord_q - cnf_q) > 0]

        # 5. Fallback Nomor PO dari Customer Reference Number
        po_col = _find_col(["purchasing document", "purchasing doc", "purch.doc", "ebeln", "po number"])
        cust_ref_col = _find_col(["customer reference", "cust ref", "cust.ref", "bstkd"])
        if po_col and cust_ref_col:
            mask_empty_po = df[po_col].isna() | df[po_col].astype(str).str.strip().isin(["", "nan", "-", "0", "None"])
            df.loc[mask_empty_po, po_col] = df.loc[mask_empty_po, cust_ref_col]

        # 6. Hapus Duplikasi Item
        sd_col = _find_col(["sales document", "sales doc", "vbeln"])
        item_col = _find_col(["item (sd)", "item sd", "posnr"])
        mat_col = _find_col(["material", "part number", "matnr"])
        subset = [c for c in [sd_col, item_col, mat_col] if c]
        if subset:
            df.drop_duplicates(subset=subset, inplace=True)

        # 7. Ekstraksi nomor-nomor dokumen unik
        if po_col:
            raw_pos = df[po_col].dropna().astype(str).str.split('.').str[0].str.strip()
            result["po_numbers"] = [x for x in raw_pos.unique() if x and x not in ("nan", "-", "0", "None")]

        ship_col = _find_col(["shipment number", "shipment", "inbound delivery", "delivery", "vbeln_vl", "bolnr"])
        if ship_col:
            raw_sn = df[ship_col].dropna().astype(str).str.split('.').str[0].str.strip()
            result["delivery_numbers"] = [x for x in raw_sn.unique() if x and x not in ("nan", "-", "0", "None")]

        sub_col = _find_col(["po subcont", "subcont no", "subcont", "subcon"])
        if sub_col:
            raw_sub = df[sub_col].dropna().astype(str).str.split('.').str[0].str.strip()
            result["subcont_pos"] = [x for x in raw_sub.unique() if x and x not in ("nan", "-", "0", "None")]

        # Tulis kembali feeding_data.xlsx terfilter rapi
        df.to_excel(feeding_path, index=False)
        if log_callback:
            log_callback(f"Pembersihan ColumnsByHeader: {initial_count} baris mentah -> {len(df)} baris valid. "
                         f"Ditemukan {len(result['po_numbers'])} PO, {len(result['delivery_numbers'])} Delivery/Shipment, "
                         f"{len(result['subcont_pos'])} Subcont.")
    except Exception as ex:
        if log_callback:
            log_callback(f"Peringatan pembersihan feeding data: {ex}")

    return result


def download_sap_bo_data(
    session,
    plant: str = "1H45",
    sales_office: str = "0H45",
    sales_org: str = "0Z02",
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    save_dir: Optional[str] = None,
    filename: Optional[str] = None,
    variant: Optional[str] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None
) -> str:
    """
    Menjalankan otomasi rantai 6 transaksi SAP bertingkat sesuai macro 'myRobot.xlsm':
    1. /NVA05N: Mengambil daftar Sales Order open (10 tipe doc: YEPS, YIPS, YO01, YSUP, dll) -> rob_so.xls
    2. /NZVSD_PARTS_PROGRESS: Mengambil data progress backorder parts -> feeding_data.xlsx & rob_summary.xls
    3. /NVL10C: Mengambil data delivery creation / OTIL -> rob_otil.xls
    4. /NME2N: Mengambil data Purchase Order supplier & vendor -> rob_po.xls
    5. /NZMIM_SHIP_DELV_REPT: Mengambil nomor pengiriman & shipment tracking resi -> rob_sn.xls
    6. /NZMMM_POSUBCON_MONI: Mengambil data PO subkontraktor -> rob_sub.xls
    7. Konsolidasi Data (Pandas Merge): Menggabungkan data dari seluruh berkas SAP ke feeding_data.xlsx.
    """
    def _local_log(msg):
        if log_callback:
            log_callback(msg)
        else:
            print(f"[SAP BO] {msg}", flush=True)

    def _local_prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)
        else:
            print(f"[PROGRESS] {pct} | {msg}", flush=True)

    if not session:
        raise ValueError("Sesi SAP GUI tidak tersedia! Pastikan SAP Logon sudah terbuka dan login ke sistem ECC (Client 300).")

    if not save_dir:
        save_dir = r"C:\Temp"
    os.makedirs(save_dir, exist_ok=True)

    if not filename:
        filename = "feeding_data.xlsx"
    if not filename.lower().endswith(".xlsx") and not filename.lower().endswith(".xls"):
        filename += ".xlsx"

    target_feeding_path = os.path.abspath(os.path.join(save_dir, filename))
    if os.path.exists(target_feeding_path):
        try: os.remove(target_feeding_path)
        except Exception: pass

    # =========================================================================
    # TAHAP 1: TRANSAKSI /NVA05N (Daftar Sales Orders Open)
    # =========================================================================
    _local_prog(5, "[1/6] Mengakses transaksi /NVA05N untuk menarik daftar Open Sales Order...")
    _local_log(f"Membuka transaksi /NVA05N (Sales Org: {sales_org}, Office: {sales_office})...")

    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA05N"
        session.findById("wnd[0]").sendVKey(0)
    except Exception:
        session.findById("wnd[0]/tbar[0]/okcd").text = "nva05n"
        session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.0)

    # Isi 10 tipe dokumen SO (AddTypeDoc)
    so_doc_types = ["YEPS", "YIPS", "YIDP", "YO02", "YO01", "YPOS", "YO03", "YPIP", "YPEX", "YSUP"]
    _set_clipboard(so_doc_types)
    try:
        session.findById("wnd[0]/usr/btn%_SAUART_%_APP_%-VALU_PUSH").press()
        time.sleep(0.6)
        session.findById("wnd[1]/tbar[0]/btn[24]").press() # Paste dari clipboard
        time.sleep(0.6)
        session.findById("wnd[1]/tbar[0]/btn[8]").press()  # Execute / Check
        time.sleep(0.6)
    except Exception as ex:
        _local_log(f"Info input tipe dokumen SO: {ex}")

    # Radio Open Sales Orders (PVBOFF)
    try: session.findById("wnd[0]/usr/radPVBOFF").select()
    except Exception: pass

    if date_from:
        try: session.findById("wnd[0]/usr/ctxtSAUDAT-LOW").text = date_from
        except Exception: pass
    if date_to:
        try: session.findById("wnd[0]/usr/ctxtSAUDAT-HIGH").text = date_to
        except Exception: pass

    try: session.findById("wnd[0]/usr/ctxtSVKORG-LOW").text = sales_org
    except Exception: pass
    try: session.findById("wnd[0]/usr/ctxtSVKBUR-LOW").text = sales_office
    except Exception: pass

    # Execute F8
    session.findById("wnd[0]").sendVKey(8)
    time.sleep(2.5)

    # Layout variant /BO_SO jika tersedia
    try:
        session.findById("wnd[0]/tbar[1]/btn[33]").press()
        time.sleep(0.8)
        layout_shell = session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell")
        layout_shell.currentCellRow = -1
        layout_shell.selectColumn("VARIANT")
        layout_shell.contextMenu()
        layout_shell.selectContextMenuItem("&FILTER")
        time.sleep(0.5)
        session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/BO_SO"
        session.findById("wnd[2]").sendVKey(0)
        time.sleep(0.5)
        layout_shell.selectedRows = "0"
        layout_shell.clickCurrentCell()
        time.sleep(1.0)
    except Exception:
        pass

    # Ekspor rob_so.xls
    rob_so_path = _export_alv_grid(session, save_dir, "rob_so.xls", _local_log)

    so_numbers = []
    if rob_so_path and os.path.exists(rob_so_path) and os.path.getsize(rob_so_path) > 100:
        try:
            df_so_raw = pd.read_excel(rob_so_path)
            so_col = None
            for col in df_so_raw.columns:
                c_str = str(col).lower()
                if any(k in c_str for k in ["sales doc", "sales order", "vbeln", "document"]):
                    so_col = col
                    break
            if so_col is None and len(df_so_raw.columns) > 0:
                so_col = df_so_raw.columns[0]
            if so_col:
                so_numbers = [str(x).split(".")[0].strip() for x in df_so_raw[so_col].dropna().unique() if str(x).strip() and str(x).strip() not in ("nan", "-")]
                _local_log(f"Berhasil menarik {len(so_numbers)} nomor Sales Order aktif dari /NVA05N.")
        except Exception as ex:
            _local_log(f"Peringatan membaca rob_so.xls: {ex}")

    # =========================================================================
    # TAHAP 2: TRANSAKSI /NZVSD_PARTS_PROGRESS (Parts Progress Backorder)
    # =========================================================================
    _local_prog(25, "[2/6] Mengakses transaksi /nzvsd_parts_progress untuk menarik data backorder parts...")
    _local_log("Membuka transaksi /nzvsd_parts_progress...")

    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nzvsd_parts_progress"
        session.findById("wnd[0]").sendVKey(0)
    except Exception:
        session.findById("wnd[0]/tbar[0]/okcd").text = "nzvsd_parts_progress"
        session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.0)

    try: session.findById("wnd[0]/usr/ctxtS_VKORG-LOW").text = sales_org
    except Exception: pass
    try: session.findById("wnd[0]/usr/ctxtS_VKBUR-LOW").text = sales_office
    except Exception: pass
    try: session.findById("wnd[0]/usr/ctxtS_WERKS-LOW").text = plant
    except Exception: pass

    if date_to:
        try: session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").text = date_to
        except Exception: pass

    try: session.findById("wnd[0]/usr/chkP_BOPART").selected = False
    except Exception: pass
    try: session.findById("wnd[0]/usr/chkP_SUBCON").selected = False
    except Exception: pass
    try: session.findById("wnd[0]/usr/cmbP_DELST").key = "Not Completed"
    except Exception: pass

    # Paste nomor SO hasil Tahap 1 jika ada
    if so_numbers:
        _set_clipboard(so_numbers)
        try:
            session.findById("wnd[0]/usr/btn%_S_VBELN_%_APP_%-VALU_PUSH").press()
            time.sleep(0.6)
            session.findById("wnd[1]/tbar[0]/btn[24]").press()
            time.sleep(0.6)
            session.findById("wnd[1]/tbar[0]/btn[8]").press()
            time.sleep(0.6)
        except Exception as ex:
            _local_log(f"Info input multi-SO ke /NZVSD: {ex}")

    # Execute F8
    session.findById("wnd[0]").sendVKey(8)
    time.sleep(3.0)

    # Terapkan varian /MYROBOT jika tersedia
    try:
        session.findById("wnd[0]/tbar[1]/btn[33]").press()
        time.sleep(1.0)
        layout_shell = session.findById("wnd[1]/usr/cntlGRID/shellcont/shell")
        layout_shell.currentCellRow = -1
        layout_shell.selectColumn("VARIANT")
        layout_shell.selectedRows = ""
        session.findById("wnd[1]/tbar[0]/btn[38]").press()
        time.sleep(0.5)
        session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/MYROBOT"
        session.findById("wnd[2]").sendVKey(0)
        time.sleep(0.5)
        layout_shell.selectedRows = "0"
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(1.2)
    except Exception:
        pass

    # Ekspor feeding_data.xlsx
    feeding_exported = _export_alv_grid(session, save_dir, filename, _local_log)
    if not feeding_exported or not os.path.exists(feeding_exported):
        feeding_exported = os.path.join(save_dir, filename)

    # =========================================================================
    # TAHAP 3: TRANSAKSI /NVL10C (Delivery Creation / OTIL)
    # =========================================================================
    _local_prog(40, "[3/6] Mengakses transaksi /NVL10c untuk menarik data Delivery Order (OTIL)...")
    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/NVL10c"
        session.findById("wnd[0]").sendVKey(0)
        time.sleep(1.0)

        try: session.findById("wnd[0]/usr/ctxtST_LEDAT-LOW").text = ""
        except Exception: pass
        try: session.findById("wnd[0]/usr/ctxtST_LEDAT-HIGH").text = ""
        except Exception: pass

        try:
            session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB2").select()
        except Exception:
            pass

        if so_numbers:
            _set_clipboard(so_numbers)
            try:
                session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB2/ssub%_SUBSCREEN_ORDER_CRITERIA:RVV50R10C:1020/btn%_ST_VBELN_%_APP_%-VALU_PUSH").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[24]").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[8]").press()
                time.sleep(0.5)
            except Exception:
                pass

        session.findById("wnd[0]").sendVKey(8)
        time.sleep(2.5)

        # Layout variant /SUB
        try:
            session.findById("wnd[0]/tbar[1]/btn[46]").press()
            time.sleep(0.5)
            session.findById("wnd[0]/tbar[1]/btn[33]").press()
            time.sleep(0.5)
            session.findById("wnd[1]/tbar[0]/btn[29]").press()
            time.sleep(0.5)
            session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/SUB"
            session.findById("wnd[2]").sendVKey(0)
            time.sleep(0.5)
            session.findById("wnd[1]/usr/lbl[1,3]").setFocus()
            session.findById("wnd[1]").sendVKey(2)
            time.sleep(0.5)
        except Exception:
            pass

        _export_alv_grid(session, save_dir, "rob_otil.xls", _local_log)
    except Exception as ex:
        _local_log(f"Info transaksi /NVL10c: {ex} (Melanjutkan tahap berikutnya)")

    # =========================================================================
    # TAHAP 3.5: PEMBERSIHAN & PENYELARASAN DATA FEEDING (ColumnsByHeader)
    # =========================================================================
    _local_prog(50, "Menjalankan pembersihan dan arrangement data feeding (ColumnsByHeader)...")
    cleaned_feed = clean_and_arrange_feeding_data(feeding_exported, _local_log)
    po_numbers = cleaned_feed["po_numbers"]
    delivery_numbers = cleaned_feed["delivery_numbers"]
    subcont_pos = cleaned_feed["subcont_pos"]

    # =========================================================================
    # TAHAP 4: TRANSAKSI /NME2N (Purchase Orders Supplier & Vendor)
    # =========================================================================
    _local_prog(60, "[4/6] Mengakses transaksi /NME2N untuk menarik data Purchase Order supplier...")
    if not po_numbers:
        _local_log("Zero-row guard: Tidak ada nomor PO aktif dari feeding data. Tahap /NME2N dilewati.")
    else:
        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = "/NME2N"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(1.0)

            try: session.findById("wnd[0]/usr/ctxtLISTU").text = "ALV"
            except Exception: pass

            _set_clipboard(po_numbers)
            try:
                session.findById("wnd[0]/usr/btn%_EN_EBELN_%_APP_%-VALU_PUSH").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[24]").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[8]").press()
                time.sleep(0.5)
            except Exception:
                pass

            session.findById("wnd[0]").sendVKey(8)
            time.sleep(2.5)

            # Layout variant /BO_REPORT
            try:
                session.findById("wnd[0]/tbar[1]/btn[33]").press()
                time.sleep(0.8)
                layout_shell = session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell")
                layout_shell.currentCellRow = -1
                layout_shell.selectColumn("VARIANT")
                layout_shell.contextMenu()
                layout_shell.selectContextMenuItem("&FILTER")
                time.sleep(0.5)
                session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/BO_REPORT"
                session.findById("wnd[2]").sendVKey(0)
                time.sleep(0.5)
                layout_shell.selectedRows = "0"
                layout_shell.clickCurrentCell()
                time.sleep(1.0)
            except Exception:
                pass

            _export_alv_grid(session, save_dir, "rob_po.xls", _local_log)
        except Exception as ex:
            _local_log(f"Info transaksi /NME2N: {ex} (Melanjutkan tahap berikutnya)")

    # =========================================================================
    # TAHAP 5: TRANSAKSI /NZMIM_SHIP_DELV_REPT (Shipment Delivery & Resi)
    # =========================================================================
    _local_prog(75, "[5/6] Mengakses transaksi /NZMIM_SHIP_DELV_REPT untuk menarik nomor shipment & DA...")
    if not delivery_numbers:
        _local_log("Zero-row guard: Tidak ada nomor delivery/shipment dari feeding data. Tahap /NZMIM dilewati.")
    else:
        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = "/NZMIM_SHIP_DELV_REPT"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(1.0)

            try: session.findById("wnd[0]/usr/radRB_RPT").select()
            except Exception: pass

            session.findById("wnd[0]").sendVKey(8) # F8
            time.sleep(1.0)

            _set_clipboard(delivery_numbers)
            try:
                session.findById("wnd[0]/usr/btn%_SP$00006_%_APP_%-VALU_PUSH").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[24]").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[8]").press()
                time.sleep(0.5)
            except Exception:
                pass

            session.findById("wnd[0]").sendVKey(8) # Execute
            time.sleep(2.5)

            # Layout variant /ROB
            try:
                grid_shell = session.findById("wnd[0]/usr/cntlCONTAINER/shellcont/shell")
                grid_shell.pressToolbarContextButton("&MB_VARIANT")
                grid_shell.selectContextMenuItem("&LOAD")
                time.sleep(0.8)
                layout_shell = session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell")
                layout_shell.currentCellRow = -1
                layout_shell.selectColumn("VARIANT")
                layout_shell.contextMenu()
                layout_shell.selectContextMenuItem("&FILTER")
                time.sleep(0.5)
                session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/ROB"
                session.findById("wnd[2]").sendVKey(0)
                time.sleep(0.5)
                layout_shell.selectedRows = "0"
                layout_shell.clickCurrentCell()
                time.sleep(1.0)
            except Exception:
                pass

            _export_alv_grid(session, save_dir, "rob_sn.xls", _local_log)
        except Exception as ex:
            _local_log(f"Info transaksi /NZMIM_SHIP_DELV_REPT: {ex} (Melanjutkan tahap berikutnya)")

    # =========================================================================
    # TAHAP 6: TRANSAKSI /NZMMM_POSUBCON_MONI (PO Subcontracting Monitoring)
    # =========================================================================
    _local_prog(85, "[6/6] Mengakses transaksi /nzmmm_posubcon_moni untuk memantau PO subkontraktor...")
    sub_targets = subcont_pos if subcont_pos else po_numbers
    if not sub_targets:
        _local_log("Zero-row guard: Tidak ada PO subkontraktor/target. Tahap subcon dilewati.")
    else:
        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = "/nzmmm_posubcon_moni"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(1.0)

            _set_clipboard(sub_targets)
            try:
                session.findById("wnd[0]/usr/btn%_S_EBELN_%_APP_%-VALU_PUSH").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[24]").press()
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[8]").press()
                time.sleep(0.5)
            except Exception:
                pass

            try: session.findById("wnd[0]/usr/txtS_WERKS-LOW").text = "1*"
            except Exception: pass
            try: session.findById("wnd[0]/usr/radRB_ICOMP").select()
            except Exception: pass

            # Select layout /MNL
            try:
                session.findById("wnd[0]/usr/ctxtP_LAYOUT").setFocus()
                session.findById("wnd[0]").sendVKey(4) # F4
                time.sleep(0.5)
                session.findById("wnd[1]/tbar[0]/btn[29]").press()
                time.sleep(0.5)
                session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/MNL"
                session.findById("wnd[2]").sendVKey(0)
                time.sleep(0.5)
                session.findById("wnd[1]/usr/lbl[1,3]").setFocus()
                session.findById("wnd[1]").sendVKey(2)
                time.sleep(0.5)
            except Exception:
                pass

            session.findById("wnd[0]").sendVKey(8)
            time.sleep(2.5)

            _export_alv_grid(session, save_dir, "rob_sub.xls", _local_log)
        except Exception as ex:
            _local_log(f"Info transaksi /nzmmm_posubcon_moni: {ex} (Melanjutkan konsolidasi)")

    # Keluar ke menu awal
    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/N"
        session.findById("wnd[0]").sendVKey(0)
    except Exception:
        pass

    # =========================================================================
    # TAHAP 7: KONSOLIDASI DATA DENGAN PANDAS (Data Merging)
    # =========================================================================
    _local_prog(92, "Mengonsolidasikan dan menggabungkan data (Data Merging) dari seluruh berkas SAP...")
    try:
        if os.path.exists(feeding_exported) and os.path.getsize(feeding_exported) > 100:
            df_main = pd.read_excel(feeding_exported)

            # 1. Merge OTIL Date dari rob_otil.xls
            rob_otil_file = os.path.join(save_dir, "rob_otil.xls")
            if os.path.exists(rob_otil_file) and os.path.getsize(rob_otil_file) > 100:
                try:
                    df_otil = pd.read_excel(rob_otil_file)
                    so_otil_col = next((c for c in df_otil.columns if any(k in str(c).lower() for k in ["sales doc", "sales document", "vbeln", "order"])), None)
                    date_otil_col = next((c for c in df_otil.columns if any(k in str(c).lower() for k in ["gi date", "planned gi", "delivery date", "creation date", "wadat"])), None)
                    if so_otil_col and date_otil_col:
                        df_otil_clean = df_otil[[so_otil_col, date_otil_col]].drop_duplicates(subset=[so_otil_col])
                        main_so_col = next((c for c in df_main.columns if any(k in str(c).lower() for k in ["sales document", "sales doc", "vbeln"])), None)
                        if main_so_col:
                            df_main[main_so_col] = df_main[main_so_col].astype(str).str.split('.').str[0].str.strip()
                            df_otil_clean[so_otil_col] = df_otil_clean[so_otil_col].astype(str).str.split('.').str[0].str.strip()
                            df_main = df_main.merge(df_otil_clean.rename(columns={date_otil_col: "OTIL Date"}), left_on=main_so_col, right_on=so_otil_col, how="left")
                            if so_otil_col in df_main.columns and so_otil_col != main_so_col:
                                df_main.drop(columns=[so_otil_col], inplace=True)
                            _local_log("Data OTIL Date berhasil digabungkan.")
                except Exception as ex_otil:
                    _local_log(f"Info merge rob_otil.xls: {ex_otil}")

            # 2. Merge PO Delivery Date dan Vendor dari rob_po.xls
            rob_po_file = os.path.join(save_dir, "rob_po.xls")
            if os.path.exists(rob_po_file) and os.path.getsize(rob_po_file) > 100:
                try:
                    df_po = pd.read_excel(rob_po_file)
                    po_col = next((c for c in df_po.columns if any(k in str(c).lower() for k in ["purchasing doc", "purch.doc", "ebeln"])), None)
                    po_deliv_col = next((c for c in df_po.columns if any(k in str(c).lower() for k in ["delivery date", "deliv.date", "eindt"])), None)
                    vendor_col = next((c for c in df_po.columns if any(k in str(c).lower() for k in ["vendor", "name", "lifnr"])), None)

                    if po_col and (po_deliv_col or vendor_col):
                        keep_cols = [c for c in [po_col, po_deliv_col, vendor_col] if c]
                        df_po_clean = df_po[keep_cols].drop_duplicates(subset=[po_col])
                        main_po_col = next((c for c in df_main.columns if any(k in str(c).lower() for k in ["purchasing doc", "purchasing document", "po number"])), None)
                        if main_po_col:
                            df_main[main_po_col] = df_main[main_po_col].astype(str).str.split('.').str[0].str.strip()
                            df_po_clean[po_col] = df_po_clean[po_col].astype(str).str.split('.').str[0].str.strip()
                            rename_map = {}
                            if po_deliv_col: rename_map[po_deliv_col] = "PO Delivery Date"
                            if vendor_col: rename_map[vendor_col] = "Vendor Name"
                            df_main = df_main.merge(df_po_clean.rename(columns=rename_map), left_on=main_po_col, right_on=po_col, how="left")
                            if po_col in df_main.columns and po_col != main_po_col:
                                df_main.drop(columns=[po_col], inplace=True)
                            _local_log("Data tanggal delivery PO dan vendor berhasil digabungkan.")
                except Exception as ex_po:
                    _local_log(f"Info merge rob_po.xls: {ex_po}")

            # 3. Merge Shipment / DA Number dari rob_sn.xls
            rob_sn_file = os.path.join(save_dir, "rob_sn.xls")
            if os.path.exists(rob_sn_file) and os.path.getsize(rob_sn_file) > 100:
                try:
                    df_sn = pd.read_excel(rob_sn_file)
                    sn_col = next((c for c in df_sn.columns if any(k in str(c).lower() for k in ["shipment", "delivery", "vbeln"])), None)
                    da_col = next((c for c in df_sn.columns if any(k in str(c).lower() for k in ["da no", "da number", "bolnr"])), None)
                    if sn_col and da_col:
                        df_sn_clean = df_sn[[sn_col, da_col]].drop_duplicates(subset=[sn_col])
                        main_sn_col = next((c for c in df_main.columns if any(k in str(c).lower() for k in ["shipment number", "shipment"])), None)
                        if main_sn_col:
                            df_main[main_sn_col] = df_main[main_sn_col].astype(str).str.split('.').str[0].str.strip()
                            df_sn_clean[sn_col] = df_sn_clean[sn_col].astype(str).str.split('.').str[0].str.strip()
                            df_main = df_main.merge(df_sn_clean.rename(columns={da_col: "DA Number"}), left_on=main_sn_col, right_on=sn_col, how="left")
                            if sn_col in df_main.columns and sn_col != main_sn_col:
                                df_main.drop(columns=[sn_col], inplace=True)
                            _local_log("Data Shipment Number & DA Number berhasil digabungkan.")
                except Exception as ex_sn:
                    _local_log(f"Info merge rob_sn.xls: {ex_sn}")

            # 4. Merge Subcon Info dari rob_sub.xls
            rob_sub_file = os.path.join(save_dir, "rob_sub.xls")
            if os.path.exists(rob_sub_file) and os.path.getsize(rob_sub_file) > 100:
                try:
                    df_sub = pd.read_excel(rob_sub_file)
                    sub_ebeln_col = next((c for c in df_sub.columns if any(k in str(c).lower() for k in ["purchasing doc", "purch.doc", "ebeln"])), None)
                    sub_deliv_col = next((c for c in df_sub.columns if any(k in str(c).lower() for k in ["delivery date", "deliv.date", "eindt"])), None)
                    if sub_ebeln_col and sub_deliv_col:
                        df_sub_clean = df_sub[[sub_ebeln_col, sub_deliv_col]].drop_duplicates(subset=[sub_ebeln_col])
                        main_po_col = next((c for c in df_main.columns if any(k in str(c).lower() for k in ["purchasing doc", "purchasing document", "po number"])), None)
                        if main_po_col:
                            df_sub_clean[sub_ebeln_col] = df_sub_clean[sub_ebeln_col].astype(str).str.split('.').str[0].str.strip()
                            df_main = df_main.merge(df_sub_clean.rename(columns={sub_deliv_col: "Subcon Delivery Date"}), left_on=main_po_col, right_on=sub_ebeln_col, how="left")
                            if sub_ebeln_col in df_main.columns and sub_ebeln_col != main_po_col:
                                df_main.drop(columns=[sub_ebeln_col], inplace=True)
                            _local_log("Data Subcontracting berhasil digabungkan.")
                except Exception as ex_sub:
                    _local_log(f"Info merge rob_sub.xls: {ex_sub}")

            # Simpan dataframe yang telah dikonsolidasikan kembali ke feeding_data.xlsx
            df_main.to_excel(feeding_exported, index=False)
            _local_log(f"Konsolidasi selesai: {len(df_main)} baris data backorder tersimpan di {feeding_exported}")
    except Exception as ex_merge:
        _local_log(f"Peringatan konsolidasi data: {ex_merge}")

    _local_prog(100, f"Selesai! Berkas feeding data siap diproses di Tahap 2.")
    _local_log(f"=== Selesai: Berkas feeding data terkonsolidasi tersimpan di {feeding_exported} ===")
    return feeding_exported


def run_full_bo_report(
    session=None,
    feeding_file: Optional[str] = None,
    plant: str = "1H45",
    sales_office: str = "0H45",
    sales_org: str = "0Z02",
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    scrape_ckb: bool = True,
    auto_download_sap: bool = False,
    output_dir: Optional[str] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None
) -> Dict[str, Any]:
    """
    Fungsi eksekusi utama yang dipanggil dari PythonBridge IPC KermenX.
    Mendukung mode offline (via feeding_file) maupun otomatisasi online SAP GUI.
    """
    _prog(5, "Menginisialisasi modul BO Report & Fixed ETA...", progress_callback)
    _log("=== KermenX BO Report & Fixed ETA Engine ===", log_callback)

    if not output_dir:
        output_dir = os.path.join(ENGINE_DIR, "output", "bo_report")
    os.makedirs(output_dir, exist_ok=True)

    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"BO_REPORT_{plant}_{timestamp_str}.xlsx"
    output_path = os.path.join(output_dir, output_filename)

    df_raw = None

    # MODE 1: Otomatisasi SAP GUI Scripting
    if auto_download_sap and session:
        _prog(10, "Menghubungi SAP GUI untuk mengunduh transaksi backorder...", progress_callback)
        downloaded = download_sap_bo_data(
            session=session,
            plant=plant,
            sales_office=sales_office,
            sales_org=sales_org,
            date_from=date_from,
            date_to=date_to,
            save_dir=r"C:\Temp",
            filename="feeding_data.xlsx",
            log_callback=log_callback,
            progress_callback=progress_callback
        )
        if downloaded and os.path.exists(downloaded):
            feeding_file = downloaded

    # MODE 2: Impor dari Berkas Excel Feeding Data
    if feeding_file and os.path.exists(feeding_file):
        _prog(15, f"Membaca berkas input: {os.path.basename(feeding_file)}...", progress_callback)
        _log(f"Membuka berkas: {feeding_file}", log_callback)
        try:
            xl = pd.ExcelFile(feeding_file)
            target_sheet = 0
            for s in xl.sheet_names:
                if s.lower() in ["bo_report", "feeding_data", "data", "sheet1", "gendata"]:
                    target_sheet = s
                    break
            df_raw = pd.read_excel(feeding_file, sheet_name=target_sheet)
        except Exception as e:
            _log(f"Gagal membaca via ExcelFile, mencoba fallback: {e}", log_callback)
            try:
                df_raw = pd.read_excel(feeding_file, sheet_name=0)
            except Exception as e2:
                raise ValueError(f"Gagal membaca berkas Excel input: {e2}")
    else:
        # Periksa apakah ada template cadangan di MACRO PROJECT / Desktop
        sample_candidates = [
            r"C:\Temp\feeding_data.xlsx",
            r"C:\Users\Yusril Irgi\Downloads\MACRO PROJECT\temp\2025\October\BO REPORT CSML PTCK SITE BMB 13Oct2025.xlsx"
        ]
        for c in sample_candidates:
            if os.path.exists(c):
                _log(f"Menggunakan berkas cadangan yang tersedia: {c}", log_callback)
                df_raw = pd.read_excel(c, sheet_name="BO_Report" if "BO REPORT" in c else 0)
                break

    if df_raw is None or df_raw.empty:
        raise ValueError("Data masukan kosong! Harap sediakan berkas 'feeding_data.xlsx' atau aktifkan otomatisasi SAP.")

    # Jalankan pipeline kalkulasi
    df_bo, df_so, df_sub, metrics = process_bo_data_pipeline(
        df_raw=df_raw,
        plant_code=plant,
        scrape_ckb=scrape_ckb,
        log_callback=log_callback,
        progress_callback=progress_callback
    )

    # Simpan hasil ke Excel
    _prog(95, "Menyimpan berkas Excel terformat...", progress_callback)
    final_file = save_styled_bo_excel(
        df_bo=df_bo,
        df_so=df_so,
        df_sub=df_sub,
        output_path=output_path,
        metrics=metrics,
        log_callback=log_callback
    )

    metrics["output_file"] = final_file
    metrics["output_filename"] = output_filename
    _prog(100, f"Selesai! Laporan tersimpan di {output_filename}", progress_callback)
    _log(f"=== Selesai: {metrics['total_bo_rows']} baris BO berhasil diproses dengan Fixed ETA ===", log_callback)

    return metrics
