"""
his_cat_helper.py
Modul mesin pencarian spesifikasi Hose Assembly HIS 2.0 Caterpillar (HIS CAT) untuk KermenX Suite.
Membaca tabel hose_consist dan cat_couplings pada cat_couplings.db.
Menyediakan Cut Length (No-Skive & Reusable), Bulk Hose, Fitting End 1 & End 2, Sleeve Armor Guard, dan Working Pressure.
"""
import os
import sys
import re
import sqlite3

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(CURRENT_DIR)
ROOT_DIR = os.path.dirname(PARENT_DIR)


def find_db_path() -> str:
    """Mencari lokasi cat_couplings.db dari beberapa kemungkinan direktori"""
    candidates = [
        os.path.join(PARENT_DIR, "assets", "couplings", "cat_couplings.db"),
        os.path.join(CURRENT_DIR, "assets", "couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "KermenX", "engine", "assets", "couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "KermenX_Csharp", "Assets", "Couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "AndroHeld_Google", "app", "src", "main", "assets", "cat_couplings.db"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return os.path.abspath(p)
    return ""


def clean_pn(raw: str) -> str:
    """Membersihkan string part number: buang suffix batch SAP, strip, spasi, uppercase"""
    if not raw:
        return ""
    val = str(raw).strip()
    if ":" in val:
        val = val.split(":")[0].strip()
    if "/" in val and not re.match(r"^[0-9]+/[0-9]+", val):
        val = val.split("/")[0].strip()
    return val.replace("-", "").replace(" ", "").replace(".", "").upper()


def get_stats() -> dict:
    """Mengambil jumlah total records hose_consist di cat_couplings.db"""
    db_path = find_db_path()
    if not db_path:
        return {"error": "Database cat_couplings.db tidak ditemukan", "total": 0}

    try:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        count = c.execute("SELECT COUNT(*) FROM hose_consist").fetchone()[0]
        conn.close()
        return {"status": "success", "total": count}
    except Exception as e:
        return {"error": str(e), "total": 0}


def search_hose_consist(query: str, limit: int = 50) -> dict:
    """
    Pencarian Hose Consist berdasarkan nomor part assembly atau kriteria lainnya.
    """
    db_path = find_db_path()
    if not db_path:
        return {"status": "error", "message": "Database cat_couplings.db tidak ditemukan", "results": []}

    q = query.strip()
    q_clean = clean_pn(q)
    if not q:
        return {"status": "success", "query": "", "total": 0, "results": []}

    results = []

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        sql = """
            SELECT id, part_number, part_number_raw, part_number_clean, status,
                   primary_hose_type, overall_length_mm, max_work_pressure_psi,
                   cut_length_no_skive_mm, cut_length_reusable_mm,
                   coupling1_permanent_pn, coupling1_permanent_smartcode,
                   coupling2_permanent_pn, coupling2_permanent_smartcode,
                   coupling1_reusable_pn, coupling2_reusable_pn
            FROM hose_consist
            WHERE part_number LIKE ?
               OR part_number_clean LIKE ?
               OR part_number_raw LIKE ?
               OR primary_hose_type LIKE ?
               OR coupling1_permanent_pn LIKE ?
               OR coupling2_permanent_pn LIKE ?
            ORDER BY 
                CASE 
                    WHEN part_number_clean = ? THEN 1
                    WHEN part_number_clean LIKE ? THEN 2
                    ELSE 3
                END,
                part_number ASC
            LIMIT ?
        """
        rows = c.execute(sql, (
            f"%{q}%", f"%{q_clean}%", f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%",
            q_clean, f"{q_clean}%", limit
        )).fetchall()

        for r in rows:
            item = dict(r)
            c1 = item.get("coupling1_permanent_pn") or item.get("coupling1_reusable_pn") or "-"
            c2 = item.get("coupling2_permanent_pn") or item.get("coupling2_reusable_pn") or "-"
            cut_len = item.get("cut_length_no_skive_mm") or item.get("cut_length_reusable_mm")
            cut_str = f"{cut_len}mm" if cut_len else "-"

            results.append({
                "id": item["id"],
                "part_number": item["part_number"],
                "part_number_raw": item.get("part_number_raw") or item["part_number"],
                "part_number_clean": item.get("part_number_clean", ""),
                "status": item.get("status") or "ACTIVE",
                "hose_type": item.get("primary_hose_type") or "HOSE",
                "oal_mm": item.get("overall_length_mm"),
                "cut_length_mm": cut_len,
                "cut_length_str": cut_str,
                "pressure_psi": item.get("max_work_pressure_psi") or "-",
                "coupling1": c1,
                "coupling2": c2,
                "subtitle": f"OAL: {item.get('overall_length_mm') or '-'}mm | Cut: {cut_str} | Ends: {c1} & {c2}"
            })

        conn.close()
        return {"status": "success", "query": q, "total": len(results), "results": results}
    except Exception as e:
        return {"status": "error", "message": str(e), "results": []}


def get_consist_detail(part_number: str) -> dict:
    """
    Mengambil spesifikasi lengkap satu Hose Assembly HIS CAT,
    termasuk rincian fitting coupling 1 & coupling 2 dari katalog coupling.
    """
    db_path = find_db_path()
    if not db_path:
        return {"found": False, "message": "Database cat_couplings.db tidak ditemukan."}

    pn = part_number.strip()
    pn_clean = clean_pn(pn)

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        sql = """
            SELECT * FROM hose_consist
            WHERE part_number = ? OR part_number_clean = ? OR part_number_raw = ?
            LIMIT 1
        """
        row = c.execute(sql, (pn, pn_clean, pn)).fetchone()
        if not row:
            conn.close()
            return {"found": False, "message": f"Hose Consist '{pn}' tidak ditemukan."}

        consist = dict(row)

        # Lookup detail fitting coupling 1
        c1_pn = consist.get("coupling1_permanent_pn") or consist.get("coupling1_reusable_pn")
        coupling1_detail = None
        if c1_pn:
            c1_clean = clean_pn(c1_pn)
            c1_row = c.execute(
                "SELECT * FROM cat_couplings WHERE part_number = ? OR REPLACE(part_number, '-', '') = ? OR smart_code = ? LIMIT 1",
                (c1_pn, c1_clean, c1_pn)
            ).fetchone()
            if c1_row:
                coupling1_detail = dict(c1_row)

        # Lookup detail fitting coupling 2
        c2_pn = consist.get("coupling2_permanent_pn") or consist.get("coupling2_reusable_pn")
        coupling2_detail = None
        if c2_pn:
            c2_clean = clean_pn(c2_pn)
            c2_row = c.execute(
                "SELECT * FROM cat_couplings WHERE part_number = ? OR REPLACE(part_number, '-', '') = ? OR smart_code = ? LIMIT 1",
                (c2_pn, c2_clean, c2_pn)
            ).fetchone()
            if c2_row:
                coupling2_detail = dict(c2_row)

        conn.close()
        return {
            "found": True,
            "consist": consist,
            "coupling1_detail": coupling1_detail,
            "coupling2_detail": coupling2_detail
        }
    except Exception as e:
        return {"found": False, "message": str(e)}
