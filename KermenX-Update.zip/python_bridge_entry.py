"""
python_bridge_entry.py
Entry point jembatan IPC lengkap yang dipanggil oleh aplikasi C# Frontend (KermenTools).
Menghubungkan seluruh fungsi backend di folder 'Kermen tools/modules'.
"""
import sys
import os
import json
import base64
import argparse
import time
import glob

# Pastikan encoding stdout & stderr UTF-8 dengan error replacement agar emoji tidak pernah crash di Windows
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Daftarkan folder saat ini, 'modules', dan 'Kermen tools' ke sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(CURRENT_DIR)
KERMEN_TOOLS_DIR = os.path.join(PARENT_DIR, "Kermen tools")
MODULES_DIR = os.path.join(CURRENT_DIR, "modules")
if not os.path.exists(MODULES_DIR):
    MODULES_DIR = os.path.join(KERMEN_TOOLS_DIR, "modules")

candidate_paths = [
    CURRENT_DIR,
    MODULES_DIR,
    KERMEN_TOOLS_DIR,
    os.path.join(KERMEN_TOOLS_DIR, "modules"),
]

for p in candidate_paths:
    if os.path.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

import config


def log_progress(percent: int, message: str):
    try:
        print(f"[PROGRESS] {percent} | {message}", flush=True)
    except Exception:
        safe_msg = str(message).encode("ascii", "replace").decode("ascii")
        print(f"[PROGRESS] {percent} | {safe_msg}", flush=True)


def log_info(message: str):
    try:
        print(f"[INFO] {message}", flush=True)
    except Exception:
        safe_msg = str(message).encode("ascii", "replace").decode("ascii")
        print(f"[INFO] {safe_msg}", flush=True)


def log_error(message: str):
    try:
        print(f"[ERROR] {message}", flush=True)
    except Exception:
        safe_msg = str(message).encode("ascii", "replace").decode("ascii")
        print(f"[ERROR] {safe_msg}", flush=True)


def log_result(data: dict):
    print(f"[RESULT] {json.dumps(data, default=str)}", flush=True)


def handle_ping():
    log_progress(50, "Memeriksa runtime Python...")
    time.sleep(0.1)
    log_progress(100, "Python Engine Siap")
    log_info(f"Python Runtime: {sys.version.split()[0]} ({sys.executable})")
    log_info(f"Target Backend: {KERMEN_TOOLS_DIR}")
    return 0


def handle_bridge():
    log_progress(30, "Memeriksa modul Kermen Tools...")
    log_info(f"Direktori Kermen Tools: {KERMEN_TOOLS_DIR}")
    modules_found = []
    if os.path.exists(MODULES_DIR):
        for f in os.listdir(MODULES_DIR):
            if f.endswith(".py") and not f.startswith("__"):
                modules_found.append(f)
    log_info(f"Modul terdeteksi ({len(modules_found)} berkas): {', '.join(modules_found)}")
    log_progress(100, "Jembatan IPC Terhubung Sempurna")
    return 0


# =========================================================================
# 1. WORK ORDER READINESS
# =========================================================================
def handle_readiness(payload: dict):
    raw_path = payload.get("as57d", "").strip()
    if not raw_path or not os.path.exists(raw_path):
        log_error("Berkas RAW DATA (AS57D & MB52) belum dipilih atau tidak ditemukan!")
        return 1

    import modules.wo_readiness_helper as wrh

    stock_path = payload.get("stock_info", "").strip() or None
    if not stock_path:
        stock_path = wrh.find_matching_stock_info(raw_path)
        if stock_path:
            log_info(f"Auto-detect Stock Info cocok: {os.path.basename(stock_path)}")

    kuota_path = payload.get("kuota_path", "").strip() or None
    if not kuota_path:
        kuota_path = wrh.find_matching_kuota_file(raw_path)

    mp_path = payload.get("mp_path", "").strip() or None
    consist_path = payload.get("consist_path", "").strip() or None
    output_mode = payload.get("output_mode", "both")

    log_progress(20, "Memulai pengolahan Part Readiness...")

    def _cb(msg):
        log_info(msg)
        if "Membaca" in msg: log_progress(35, msg)
        elif "Pencocokan" in msg: log_progress(60, msg)
        elif "Menyusun" in msg: log_progress(80, msg)

    res = wrh.process_wo_readiness(
        raw_path,
        stock_info_path=stock_path,
        kuota_file_path=kuota_path or "",
        mp_file_path=mp_path,
        consist_file_path=consist_path,
        output_mode=output_mode,
        status_callback=_cb
    )

    log_progress(100, "Analisis Part Readiness Selesai!")
    log_info(f"Laporan tersimpan di: {res.get('output_path')}")
    if res.get('release_total_evaluated', 0) > 0:
        log_info(f"Evaluasi Rilis Part Antar-Cabang: {res.get('release_total_evaluated', 0):,} part fisik dievaluasi ({res.get('release_safe_items', 0):,} Aman Rilis, {res.get('release_deadstock_items', 0):,} Deadstock Bebas Dilepas).")
    log_result(res)
    return 0


# =========================================================================
# 2. OTIF TOOLS
# =========================================================================
def handle_otif(payload: dict):
    raw_path = payload.get("otif_file", "").strip()
    if not raw_path or not os.path.exists(raw_path):
        log_error("Berkas RAW DATA OTIF belum dipilih atau tidak ditemukan!")
        return 1

    import modules.otif_helper as oth

    mb51_path = payload.get("mb51_path", "").strip() or None
    pg = payload.get("purchasing_group", "3VH")
    wo_status = payload.get("wo_parts_status", "CAT ONLY")
    delta_days = int(payload.get("delta_days", 1))
    date_mode = payload.get("date_mode", "all")
    f_month = payload.get("filter_month")
    f_year = payload.get("filter_year")
    f_start = payload.get("filter_start_date")
    f_end = payload.get("filter_end_date")

    if f_month: f_month = int(f_month)
    if f_year: f_year = int(f_year)

    log_progress(20, "Memulai analisis & simulasi OTIF...")

    def _cb(msg):
        log_info(msg)
        if "Membaca" in msg: log_progress(35, msg)
        elif "Menghitung" in msg: log_progress(65, msg)
        elif "Menyusun" in msg: log_progress(85, msg)

    res = oth.process_otif_excel(
        input_file_path=raw_path,
        mb51_file_path=mb51_path,
        purchasing_group=pg,
        wo_parts_status_filter=wo_status,
        delta_days=delta_days,
        date_filter_mode=date_mode,
        filter_month=f_month,
        filter_year=f_year,
        filter_start_date=f_start,
        filter_end_date=f_end,
        status_callback=_cb
    )

    log_progress(100, "Analisis & Simulasi OTIF Selesai!")
    log_info(f"Laporan tersimpan di: {res.get('output_path')}")
    log_result(res)
    return 0


# =========================================================================
# 3. STOCK INFO & POSTURE
# =========================================================================
def handle_stock(payload: dict):
    sub_action = payload.get("sub_action", "stock_info")

    if sub_action == "posture":
        posture_path = payload.get("posture_file", "").strip() or payload.get("master_stock", "").strip()
        if not posture_path or not os.path.exists(posture_path):
            log_error("Berkas data Posture Regional (~400MB) belum dipilih atau tidak ditemukan!")
            return 1

        import modules.posture_helper as ph
        target_plant = payload.get("target_plant", "all")
        plant_arg = None if target_plant == "all" else target_plant

        log_progress(5, f"Memulai ekstraksi data Posture Regional (Cakupan: {target_plant})...")
        res = ph.process_posture_excel(
            posture_path,
            target_plant=plant_arg,
            status_callback=lambda m: log_info(m),
            progress_callback=lambda p, m: log_progress(p, m)
        )
        log_progress(100, "Ekstraksi Posture Regional Selesai!")
        log_info(f"Laporan tersimpan di: {res.get('output_path')}")
        log_result(res)
        return 0
    else:
        stock_path = payload.get("master_stock", "").strip() or payload.get("stock_info", "").strip()
        if not stock_path or not os.path.exists(stock_path):
            log_error("Berkas Stock_Info belum dipilih atau tidak ditemukan!")
            return 1

        import modules.excel_helper as eh
        from modules.wo_readiness_helper import find_matching_kuota_file

        kuota_path = payload.get("kuota_path", "").strip() or None
        if not kuota_path:
            kuota_path = find_matching_kuota_file(stock_path)

        log_progress(20, "Mengolah data Stock_Info & menyusun Dashboard...")
        res = eh.process_inventory_excel(
            stock_path,
            kuota_file_path=kuota_path,
            status_callback=lambda m: log_info(m)
        )
        log_progress(100, "Pengolahan Data Stock_Info Selesai!")
        log_info(f"Laporan tersimpan di: {res.get('output_path')}")
        log_result(res)
        return 0


# =========================================================================
# 4. MACRO SAP TOOLS
# =========================================================================
def handle_sap(payload: dict):
    import pythoncom
    pythoncom.CoInitialize()
    try:
        try:
            import modules.sap_helper as sh
        except ImportError:
            import sap_helper as sh

        try:
            import config
        except ImportError:
            import modules.config as config

        conn_name = payload.get("sap_conn", "SAP ECC").strip()
        client = payload.get("sap_client", "300").strip()
        user = payload.get("sap_user", "").strip()
        pwd = payload.get("sap_pwd", "").strip()
        action = payload.get("sap_action", "stock_info").strip()

        log_info(f"Koneksi SAP: {conn_name} | Client: {client} | SAP ID: {user or '(kosong)'}")
        log_progress(15, f"Menghubungkan ke SAP GUI ({conn_name} - Client {client})...")

        # 1. Buka koneksi dan sesi SAP (attach ke sesi aktif jika sudah login, atau login baru)
        session = sh.get_active_or_new_sap_session(username=user, password=pwd, connection_name=conn_name, client=client)
        log_progress(30, "Koneksi & Sesi SAP GUI aktif.")

        if action == "stock_info":
            plant = payload.get("sap_plant", "1346").strip()
            sloc = payload.get("sap_sloc", "1000").strip()
            variant = payload.get("sap_variant", "/YUSRIL").strip()
            nama_file_stock = f"INVENTORY {time.strftime('%d%m%Y')}.XLSX"

            log_progress(45, "Menjalankan transaksi /NZMMM_STOCK_INFO...")
            sh.download_stock_info(session, plant=plant, sloc=sloc, variant=variant, filename=nama_file_stock)

            log_progress(80, "Memeriksa berkas hasil download Stock Info...")
            possible_paths = [
                nama_file_stock,
                os.path.join(config.get_output_dir("sap"), nama_file_stock),
                os.path.join(config.get_base_output_dir(), nama_file_stock),
                os.path.join(r"C:\temp", nama_file_stock),
                os.path.join(os.path.expanduser("~"), "Downloads", nama_file_stock),
                os.path.join(r"D:\Users\yusril.i.wafir\Downloads", nama_file_stock),
                os.path.join(config.OUTPUT_DIR, nama_file_stock)
            ]

            found_path = None
            for p in possible_paths:
                if os.path.exists(p):
                    found_path = p
                    break

            if not found_path:
                found_path = os.path.join(config.get_output_dir("sap"), nama_file_stock)

            # Jika ada kuota file, lakukan pemrosesan tambahan
            kuota_path = payload.get("kuota_path", "").strip() or None
            try:
                import modules.excel_helper as eh
                if kuota_path and os.path.exists(kuota_path) and os.path.exists(found_path):
                    eh.process_inventory_excel(found_path, kuota_file_path=kuota_path)
            except Exception as ex:
                log_info(f"Catatan olah kuota: {ex}")

            log_progress(100, "Download Stock Info SAP Selesai!")
            log_result({"status": "success", "output_path": os.path.abspath(found_path), "filename": nama_file_stock})
            return 0

        elif action == "otif" or action == "zckwopart":
            raw_path = payload.get("raw_data_path", "").strip()
            if not raw_path or not os.path.exists(raw_path):
                log_error("Berkas RAW DATA (MB51 & AS57D) tidak ditemukan!")
                return 1

            target_plant = payload.get("sap_plant", "3069").strip()
            date_mode = payload.get("date_mode", "month")
            f_month = payload.get("filter_month")
            f_year = payload.get("filter_year")
            f_start = payload.get("filter_start_date")
            f_end = payload.get("filter_end_date")
            out_dir = payload.get("save_dir", "").strip() or config.get_output_dir("sap")
            fname = payload.get("filename", "").strip() or f"Report_OTIF_CKBMB_{time.strftime('%d%m%Y')}.XLSX"

            if f_month: f_month = int(f_month)
            if f_year: f_year = int(f_year)

            log_progress(40, "Mengekstrak daftar unik Work Order dari RAW DATA...")
            orders_list, otif_stats = sh.extract_unique_orders_from_raw(
                raw_file_path=raw_path,
                date_filter_mode=date_mode,
                filter_month=f_month,
                filter_year=f_year,
                filter_start_date=f_start,
                filter_end_date=f_end
            )

            if not orders_list:
                log_error("Tidak ada nomor Work Order yang ditemukan dari kriteria tanggal tersebut!")
                return 1

            log_info(f"Ditemukan {len(orders_list)} Work Order unik untuk diproses.")
            log_progress(60, f"Menjalankan /NZCKWOPART di SAP ({len(orders_list)} WO)...")

            saved_otif_path = sh.download_zckwopart_otif(
                session=session,
                orders_list=orders_list,
                plant=target_plant,
                erdat=payload.get("sap_erdat", None),
                save_dir=out_dir,
                filename=fname,
                log_callback=lambda m: log_info(m)
            )

            log_progress(100, "Download ZCKWOPART SAP Selesai!")
            log_result({
                "status": "success",
                "output_path": os.path.abspath(saved_otif_path),
                "total_wo": len(orders_list),
                "mb51_unique": otif_stats.get("mb51_unique", 0),
                "as57d_unique": otif_stats.get("as57d_unique", 0)
            })
            return 0

        elif action == "hub" or action == "stock_hub":
            variant = payload.get("sap_variant", "/YUSRIL").strip()
            out_dir = payload.get("save_dir", "").strip() or config.get_output_dir("sap")
            fname = payload.get("filename", "").strip() or f"Stock HUB {time.strftime('%d%m%Y')}.XLSX"
            if not fname.upper().endswith(".XLSX"):
                fname += ".XLSX"

            log_progress(50, "Menjalankan transaksi MB52 di SAP...")
            saved_hub_path = sh.download_stock_hub(
                session=session,
                variant=variant,
                save_dir=out_dir,
                filename=fname
            )

            log_progress(100, "Download Stock 4 HUB Selesai!")
            log_result({"status": "success", "output_path": os.path.abspath(saved_hub_path), "filename": fname})
            return 0

        elif action == "migo":
            items_json = payload.get("items_list", "[]")
            migo_mode = payload.get("migo_mode", "tp_344").strip().lower()
            import json
            try:
                items = json.loads(items_json)
            except Exception as e:
                log_error(f"Format data items JSON tidak valid: {e}")
                return 1

            if not items:
                log_error("Daftar item MIGO masih kosong!")
                return 1

            mode_label = "Cancellation (A03)" if migo_mode == "cancellation" else "TP - 344"
            log_progress(40, f"Membuka transaksi /NMIGO Mode {mode_label} ({len(items)} item)...")

            if migo_mode == "cancellation":
                res = sh.execute_batch_migo_cancellation(
                    session,
                    items,
                    progress_callback=lambda pct, msg: log_progress(pct, msg),
                    log_callback=lambda m: log_info(m)
                )
            else:
                res = sh.execute_batch_migo(
                    session,
                    items,
                    progress_callback=lambda pct, msg: log_progress(pct, msg),
                    log_callback=lambda m: log_info(m)
                )

            log_progress(100, f"Batch MIGO {mode_label} selesai! ({res.get('success_count', 0)} sukses, {res.get('fail_count', 0)} gagal)")
            log_result(res)
            return 0

        else:
            log_error(f"Aksi SAP '{action}' tidak dikenal.")
            return 1

    except Exception as e:
        log_error(f"Gagal eksekusi SAP Macro: {e}")
        return 1
    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


# =========================================================================
# 5. ANDROHELD DATA HUB
# =========================================================================
def handle_androheld(payload: dict):
    raw_path = payload.get("raw_data", "").strip()
    posture_path = payload.get("posture_file", "").strip()
    inventory_path = payload.get("inventory_file", "").strip()

    if not raw_path or not os.path.exists(raw_path):
        log_error("Berkas RAW DATA WO (Part Readiness) belum dipilih atau tidak ditemukan!")
        return 1

    if not posture_path or not os.path.exists(posture_path):
        log_error("Berkas Posture Clean Report belum dipilih atau tidak ditemukan!")
        return 1

    if not inventory_path or not os.path.exists(inventory_path):
        log_error("Berkas Master Inventory Processed belum dipilih atau tidak ditemukan!")
        return 1

    import modules.androheld_helper as ah

    log_progress(20, "Memulai pengolahan 3 file logistik SAP AndroHeld...")

    def _cb(m):
        log_info(m)
        if "[1/4]" in m: log_progress(30, m)
        elif "[2/4]" in m: log_progress(55, m)
        elif "[3/4]" in m: log_progress(75, m)
        elif "[4/4]" in m: log_progress(90, m)

    auto_upload_val = payload.get("auto_upload", "true")
    auto_upload = str(auto_upload_val).lower() in ("true", "1", "yes")
    supabase_config = None
    if auto_upload:
        url = payload.get("supabase_url", "").strip()
        key = payload.get("supabase_key", "").strip()
        table = payload.get("supabase_table", "androheld_items").strip()
        if url and key:
            supabase_config = {
                "supabase_url": url,
                "supabase_key": key,
                "supabase_table": table
            }

    res = ah.process_androheld_data(
        raw_data_path=raw_path,
        posture_path=posture_path,
        inventory_path=inventory_path,
        supabase_config=supabase_config,
        status_callback=_cb
    )

    out_dir = ""
    if res and isinstance(res, dict):
        json_p = res.get("json_path", "")
        if json_p:
            out_dir = os.path.dirname(json_p)

    log_progress(100, "Integrasi & Sync AndroHeld Selesai!")
    log_info("File JSON & Database SQLite berhasil diperbarui.")
    log_result({"success": True, "output_path": out_dir})
    return 0


# =========================================================================
# 6. SWIFT FLEET FORECASTING
# =========================================================================
def handle_swift(payload: dict):
    raw_path = payload.get("swift_file", "").strip()
    if not raw_path or not os.path.exists(raw_path):
        log_error("Berkas inspeksi keausan SWIFT belum dipilih atau tidak ditemukan!")
        return 1

    import modules.swift_helper as sh
    from config import get_output_dir

    mep_path = payload.get("mep_path", "").strip() or None
    sheet_name = payload.get("sheet_name", None)
    if sheet_name and "(Auto" in sheet_name:
        sheet_name = None

    only_latest = payload.get("only_latest", True)
    filter_mep = payload.get("filter_mep", True)
    comp_filter = payload.get("comp_filter", "UNDERCARRIAGE")
    daily_hrs = float(payload.get("daily_hours", 16.0))
    auto_upload = payload.get("auto_upload", False)

    log_progress(20, "Membaca file inspeksi keausan (Rust Calamine Engine)...")
    df_raw = sh.load_data_file(raw_path, sheet_name=sheet_name, callback=log_info)

    log_progress(50, "Menghitung Wear Rate & RUL Forecasting...")
    df_proc, summary = sh.calculate_swift_wear(
        df_raw,
        only_latest_inspection=only_latest,
        filter_mep=filter_mep,
        component_filter=comp_filter,
        daily_operating_hours=daily_hrs,
        mep_db_path=mep_path,
        callback=log_info
    )

    log_progress(80, "Mengekspor laporan Excel multi-sheet & JSON...")
    out_dir = get_output_dir("swift")
    excel_path = sh.export_swift_excel(df_proc, summary, out_dir, callback=log_info)
    json_path = sh.export_swift_json(df_proc, summary, out_dir, callback=log_info)

    if auto_upload:
        url = payload.get("supabase_url", "").strip()
        key = payload.get("supabase_key", "").strip()
        t_comp = payload.get("table_comp", "swift_components").strip()
        t_kpi = payload.get("table_kpi", "swift_kpi").strip()
        if url and key:
            log_progress(90, "Sinkronisasi ke Cloud Database Supabase...")
            sh.upload_swift_to_supabase(url, key, t_comp, t_kpi, df_proc, summary, callback=log_info)
        else:
            log_info("URL/Key Supabase kosong. Upload cloud dilewati.")

    log_progress(100, "Forecasting SWIFT Selesai!")
    log_info(f"Laporan tersimpan di: {excel_path}")
    log_result({
        "output_path": excel_path,
        "json_path": json_path,
        "summary": summary
    })
    return 0


# =========================================================================
# 7. STO GENERATOR
# =========================================================================
def handle_sto(payload: dict):
    mode = payload.get("mode", "readiness")
    import modules.sto_helper as sth

    if mode == "manual":
        items_list = payload.get("items_list", [])
        if not items_list:
            log_error("Daftar Part Number (PN) kosong! Harap tambahkan minimal 1 item.")
            return 1

        supplying_mode = payload.get("supplying_mode", "custom")
        custom_plant = payload.get("custom_plant", "1G31").strip()
        hub_path = payload.get("hub_file", "").strip() or None
        header_note = payload.get("header_note", "Replenish Stock for Reservasi CK").strip()
        rec_plant = payload.get("receiving_plant", "3069")
        rec_sloc = payload.get("receiving_sloc", "0001")

        log_progress(30, f"Membuat STO Manual ({len(items_list)} items, Mode: {supplying_mode})...")
        res = sth.generate_manual_sto_analysis(
            items_list=items_list,
            supplying_mode=supplying_mode,
            custom_plant=custom_plant,
            hub_file_path=hub_path,
            header_note=header_note,
            receiving_plant=rec_plant,
            receiving_sloc=rec_sloc,
            status_callback=lambda m: log_info(m)
        )
        log_progress(100, "Pembuatan Form STO Manual Selesai!")
        log_result(res)
        return 0

    else:
        report_path = payload.get("report_file", "").strip()
        hub_path = payload.get("hub_file", "").strip()

        if not report_path or not os.path.exists(report_path):
            log_error("Berkas Laporan Part Readiness belum dipilih atau tidak ditemukan!")
            return 1

        if not hub_path or not os.path.exists(hub_path):
            detected_hub = sth.find_matching_stock_hub(report_path)
            if detected_hub:
                hub_path = detected_hub
                log_info(f"Auto-detect Stock HUB cocok: {os.path.basename(hub_path)}")
            else:
                log_error("Berkas Stock HUB tidak ditemukan!")
                return 1

        scope = payload.get("scope", "mp")
        target_sheet = None
        if scope == "mp":
            target_sheet = "MONTHLY PLAN"
        elif scope == "all":
            target_sheet = "ALL STATUS"
        elif scope == "filtered":
            target_sheet = "FILTERED STATUS"

        rec_plant = payload.get("receiving_plant", "3069")
        rec_sloc = payload.get("receiving_sloc", "0001")
        include_consist = str(payload.get("include_hose_consist", "true")).lower() in ("true", "1", "yes")

        log_progress(30, f"Memulai analisis alokasi kaskade 4 HUB (Scope: {scope}, Consist: {include_consist})...")
        res = sth.process_sto_analysis(
            readiness_report_path=report_path,
            hub_file_path=hub_path,
            target_sheet=target_sheet,
            receiving_plant=rec_plant,
            receiving_sloc=rec_sloc,
            include_hose_consist=include_consist,
            status_callback=lambda m: log_info(m)
        )

        log_progress(100, "Analisis STO Selesai!")
        log_result(res)
        return 0


# =========================================================================
# 8. TURNOVER ANALYSIS
# =========================================================================
def handle_turnover(payload: dict):
    sub_action = payload.get("sub_action", "calculate").lower().strip()

    import modules.turnover_db as tdb

    if sub_action == "get_db":
        log_progress(50, "Membaca data historis Turnover dari database internal...")
        recs = tdb.get_all_month_records()
        avail_months = tdb.get_available_months()
        log_progress(100, "Database Turnover berhasil dimuat.")
        log_result({
            "status": "success",
            "records": recs,
            "available_months": avail_months
        })
        return 0

    elif sub_action == "save_record":
        month_in = payload.get("month", "").strip()
        cogs_v = float(payload.get("cogs", 0)) if payload.get("cogs") else None
        soh_v = float(payload.get("parts_soh", 0)) if payload.get("parts_soh") else 0.0
        git_v = float(payload.get("parts_git", 0)) if payload.get("parts_git") else 0.0
        gini_v = float(payload.get("parts_gini", 0)) if payload.get("parts_gini") else 0.0
        core_v = float(payload.get("core_px", 0)) if payload.get("core_px") else 0.0
        bud_v = float(payload.get("budget_to", 3.0)) if payload.get("budget_to") else 3.0

        log_progress(50, f"Menyimpan data periode {month_in} ke database...")
        d_saved = tdb.save_month_record(
            month_input=month_in,
            cogs=cogs_v,
            parts_soh=soh_v,
            parts_git=git_v,
            parts_gini=gini_v,
            core_px=core_v,
            budget_to=bud_v
        )
        log_progress(100, f"Data periode {month_in} tersimpan.")
        log_result({
            "status": "success",
            "saved_month": d_saved
        })
        return 0

    elif sub_action == "delete_record":
        month_in = payload.get("month", "").strip()
        log_progress(50, f"Menghapus data periode {month_in}...")
        del_ok = tdb.delete_month_record(month_in)
        log_progress(100, "Penghapusan selesai.")
        log_result({
            "status": "success",
            "deleted": del_ok,
            "month": month_in
        })
        return 0

    elif sub_action == "import_history":
        import pandas as pd
        excel_path = payload.get("file_path", "").strip()
        if not excel_path or not os.path.exists(excel_path):
            log_error(f"Berkas Excel import tidak ditemukan: {excel_path}")
            return 1

        log_progress(30, f"Membaca berkas Excel: {os.path.basename(excel_path)}...")
        df = pd.read_excel(excel_path)
        col_mth = None
        col_inv = None
        col_cat = None
        col_cogs = None

        for col in df.columns:
            c_low = str(col).lower()
            if any(k in c_low for k in ["month", "bulan", "date", "periode"]):
                col_mth = col
            elif any(k in c_low for k in ["cat", "tipe", "jenis", "group", "kategori"]):
                col_cat = col
            elif any(k in c_low for k in ["inv", "stock", "stok"]):
                col_inv = col
            elif any(k in c_low for k in ["cogs", "hpp", "cost"]):
                col_cogs = col

        imported_any = False
        if col_mth and col_inv:
            tdb.upsert_inventory_dataframe(
                df,
                date_col=col_mth,
                cat_col=col_cat if col_cat else "Category",
                val_col=col_inv
            )
            imported_any = True

        if col_mth and col_cogs:
            tdb.upsert_cogs_dataframe(
                df,
                date_col=col_mth,
                val_col=col_cogs
            )
            imported_any = True

        if not imported_any:
            log_error("Kolom bulan atau inventory/COGS tidak ditemukan di file tersebut.")
            return 1

        log_progress(100, "Import data Excel ke database internal berhasil!")
        log_result({
            "status": "success",
            "message": f"Data dari {os.path.basename(excel_path)} berhasil diimpor ke database."
        })
        return 0

    # Default: hitung turnover
    history_file = payload.get("history_file", "").strip() or None
    target_month = payload.get("target_month", "Bulan Terakhir (Auto)").strip()
    manual_budget = payload.get("manual_budget_to", "").strip() or None
    manual_cogs = payload.get("manual_cogs_12m", "").strip() or None

    if manual_budget:
        try: manual_budget = float(manual_budget)
        except ValueError: manual_budget = None

    if manual_cogs:
        try: manual_cogs = float(manual_cogs)
        except ValueError: manual_cogs = None

    import modules.turnover_helper as th

    log_progress(30, f"Menghitung Turn Over & Months of Supply (Target: {target_month})...")
    res = th.process_turnover_excel(
        inventory_file_path=history_file,
        manual_budget_to=manual_budget,
        manual_cogs_12m=manual_cogs,
        target_month=target_month,
        status_callback=lambda m: log_info(m)
    )

    out_file = res.get("output_file") or res.get("output_path")
    res_dict = {
        "output_path": out_file,
        "output_file": out_file,
        "summary": res.get("summary"),
        "available_months": res.get("available_months", [])
    }

    log_progress(100, "Analisis Turnover Selesai!")
    log_info(f"Laporan tersimpan di: {out_file}")
    log_result(res_dict)
    return 0



# =========================================================================
# EMAIL OUTLOOK AUTOMATION
# =========================================================================
def handle_email(payload: dict):
    action = payload.get("action", "readiness").lower().strip()
    report_type = payload.get("report_type", "report").lower().strip()
    to = payload.get("to", "").strip()
    cc = payload.get("cc", "").strip()
    subject = payload.get("subject", "").strip()
    notes = payload.get("notes", "").strip()
    attachment_path = payload.get("attachment_path", "").strip()
    send_mode = payload.get("send_mode", "display").lower().strip()
    is_send = (send_mode == "send")
    is_display = not is_send

    import modules.email_helper as eh

    log_progress(15, "Memeriksa ketersediaan Microsoft Outlook Desktop...")
    if not eh.is_outlook_available():
        raise RuntimeError(
            "Aplikasi Microsoft Outlook tidak terdeteksi atau belum dibuka di komputer Anda.\n"
            "Pastikan aplikasi Microsoft Outlook sudah terinstall dan telah login."
        )

    log_progress(35, f"Menyusun konten & layout email ({action.upper()})...")

    # Ambil daftar berkas lampiran
    attachments = []
    if attachment_path:
        for att in attachment_path.split(";"):
            clean_att = att.strip()
            if clean_att and os.path.exists(clean_att):
                attachments.append(clean_att)

    body_html = ""
    res = {}

    try:
        if action == "readiness":
            target_file = attachments[0] if attachments else None
            body_html = eh.generate_readiness_email_body(
                notes=notes,
                report_file_path=target_file,
                report_type=report_type
            )
            log_progress(70, "Membuka draft email di Outlook..." if is_display else "Mengirim email via Outlook...")
            res = eh.send_report_email_outlook(
                to=to, cc=cc, subject=subject, body_html=body_html,
                attachment_paths=attachments, display=is_display, send=is_send
            )

        elif action == "counter":
            target_file = attachments[0] if attachments else None
            body_html = eh.generate_counter_followup_email_body(
                notes=notes,
                report_file_path=target_file,
                source_type=report_type
            )
            log_progress(70, "Membuka draft email di Outlook..." if is_display else "Mengirim email via Outlook...")
            res = eh.send_report_email_outlook(
                to=to, cc=cc, subject=subject, body_html=body_html,
                attachment_paths=attachments, display=is_display, send=is_send
            )

        elif action == "otif":
            target_file = attachments[0] if attachments else None
            body_html = eh.generate_otif_daily_email_body(
                notes=notes,
                report_file_path=target_file
            )
            log_progress(70, "Membuka draft email di Outlook..." if is_display else "Mengirim email via Outlook...")
            res = eh.send_report_email_outlook(
                to=to, cc=cc, subject=subject, body_html=body_html,
                attachment_paths=attachments, display=is_display, send=is_send
            )

        elif action == "sto":
            body_html = eh.generate_sto_email_body(
                notes=notes,
                include_signature=True
            )
            log_progress(70, "Membuka draft email di Outlook..." if is_display else "Mengirim email via Outlook...")
            res = eh.send_sto_email_outlook(
                to=to, cc=cc, subject=subject, body_html=body_html,
                attachment_paths=attachments, display=is_display, send=is_send
            )

        elif action == "turnover":
            target_file = attachments[0] if attachments else None
            body_html = eh.generate_turnover_email_body(
                notes=notes,
                report_file_path=target_file
            )
            log_progress(70, "Membuka draft email di Outlook..." if is_display else "Mengirim email via Outlook...")
            res = eh.send_report_email_outlook(
                to=to, cc=cc, subject=subject, body_html=body_html,
                attachment_paths=attachments, display=is_display, send=is_send
            )

        else:
            raise ValueError(f"Action email '{action}' tidak dikenal.")

    except Exception as ex:
        err_msg = str(ex)
        if "-2147467260" in err_msg or "operation aborted" in err_msg.lower():
            raise RuntimeError(
                "Tidak dapat membuat item pesan di Microsoft Outlook (Operation Aborted).\n\n"
                "Kemungkinan penyebab:\n"
                "1. Aplikasi Microsoft Outlook belum dibuka di komputer Anda.\n"
                "2. Profil email Outlook belum login atau sedang ada dialog popup yang aktif.\n\n"
                "Solusi: Silakan buka aplikasi Microsoft Outlook terlebih dahulu di desktop Anda, lalu klik tombol email kembali."
            )
        raise

    log_progress(100, "Draft Outlook berhasil disiapkan!" if is_display else "Email berhasil dikirim via Outlook!")
    status_label = "Draft terbuka di Outlook" if is_display else "Terkirim langsung via Outlook"
    log_info(f"Proses email selesai ({status_label}): {res}")
    log_result({"status": "success", "action": action, "mode": send_mode, "details": res})
    return 0


# =========================================================================
# DISPATCHER
# =========================================================================
def main():
    parser = argparse.ArgumentParser(description="Kermen Tools Python Bridge Complete Entry Point")
    parser.add_argument("--task", default="ping", help="Nama task yang dieksekusi")
    parser.add_argument("--payload-file", default="", help="Path berkas JSON parameter payload")
    parser.add_argument("--payload-base64", default="", help="Parameter JSON dalam format Base64")
    parser.add_argument("--payload", default="{}", help="Parameter JSON langsung")

    args = parser.parse_args()

    payload = {}
    if args.payload_file and os.path.exists(args.payload_file):
        try:
            with open(args.payload_file, "r", encoding="utf-8-sig") as f:
                payload = json.load(f)
        except Exception as ex:
            log_error(f"Gagal membaca payload-file '{args.payload_file}': {ex}")
            payload = {}
    elif args.payload_base64:
        try:
            decoded = base64.b64decode(args.payload_base64).decode("utf-8")
            payload = json.loads(decoded)
        except Exception as ex:
            log_error(f"Gagal parse base64 payload: {ex}")
            payload = {}
    elif args.payload:
        try:
            payload = json.loads(args.payload)
        except Exception:
            payload = {}

    task = args.task.lower().strip()

    try:
        if task == "ping":
            sys.exit(handle_ping())
        elif task == "bridge":
            sys.exit(handle_bridge())
        elif task in ("readiness", "wo_readiness"):
            sys.exit(handle_readiness(payload))
        elif task == "otif":
            sys.exit(handle_otif(payload))
        elif task in ("stock", "posture", "stock_info"):
            sys.exit(handle_stock(payload))
        elif task == "sap":
            sys.exit(handle_sap(payload))
        elif task in ("androheld", "androheld_sync"):
            sys.exit(handle_androheld(payload))
        elif task == "swift":
            sys.exit(handle_swift(payload))
        elif task == "sto":
            sys.exit(handle_sto(payload))
        elif task == "turnover":
            sys.exit(handle_turnover(payload))
        elif task == "email":
            sys.exit(handle_email(payload))
        else:
            log_error(f"Task '{task}' tidak dikenal.")
            sys.exit(1)
    except Exception as ex:
        log_error(f"Terjadi kesalahan internal saat menjalankan '{task}': {str(ex)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
