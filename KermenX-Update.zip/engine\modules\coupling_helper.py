"""
coupling_helper.py
Modul mesin pencarian spesifikasi coupling Caterpillar (CAT) untuk KermenX Suite.
Mendukung Single Search (detail + diagram WebP) dan Multiple/Batch Search (input dinamis + ekspor Excel resmi).
"""
import os
import sys
import sqlite3
import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(CURRENT_DIR)
ROOT_DIR = os.path.dirname(PARENT_DIR)


def find_db_path() -> str:
    """Mencari lokasi cat_couplings.db dari beberapa kemungkinan direktori"""
    candidates = [
        os.path.join(PARENT_DIR, "assets", "couplings", "cat_couplings.db"),
        os.path.join(CURRENT_DIR, "assets", "couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "KermenX", "engine", "assets", "couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "KermenX_Csharp", "Assets", "Couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "AndroHeld_Google", "app", "src", "main", "assets", "cat_couplings.db"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return os.path.abspath(p)
    return ""


def find_images_dir() -> str:
    """Mencari lokasi folder coupling_images"""
    candidates = [
        os.path.join(PARENT_DIR, "assets", "couplings", "images"),
        os.path.join(CURRENT_DIR, "assets", "couplings", "images"),
        os.path.join(ROOT_DIR, "KermenX", "engine", "assets", "couplings", "images"),
        os.path.join(ROOT_DIR, "KermenX_Csharp", "Assets", "Couplings", "images"),
        os.path.join(ROOT_DIR, "AndroHeld_Google", "app", "src", "main", "assets", "coupling_images"),
    ]
    for p in candidates:
        if os.path.exists(p) and os.path.isdir(p):
            return os.path.abspath(p)
    return ""


def clean_pn(raw: str) -> str:
    """Membersihkan string part number: strip spasi, hapus tanda minus, uppercase"""
    if not raw:
        return ""
    return str(raw).strip().replace("-", "").replace(" ", "").upper()


def get_db_connection():
    db_path = find_db_path()
    if not db_path:
        raise FileNotFoundError("Berkas database 'cat_couplings.db' tidak ditemukan di direktori aset KermenX!")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def search_single_coupling(query: str) -> dict:
    """
    Pencarian single part number coupling.
    Mengembalikan data spesifikasi detail, gambar diagram, dan daftar equivalent parts.
    """
    raw_query = str(query or "").strip()
    if not raw_query:
        return {"found": False, "message": "Part Number pencarian tidak boleh kosong."}

    cln = clean_pn(raw_query)
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Coba exact match (dengan atau tanpa tanda minus)
    cursor.execute("""
        SELECT * FROM cat_couplings
        WHERE REPLACE(part_number, '-', '') = ? OR part_number = ?
        LIMIT 5
    """, (cln, raw_query))
    rows = cursor.fetchall()

    # 2. Jika tidak ada, coba LIKE prefix
    if not rows and len(cln) >= 4:
        cursor.execute("""
            SELECT * FROM cat_couplings
            WHERE REPLACE(part_number, '-', '') LIKE ? OR fitting_style LIKE ?
            LIMIT 5
        """, (f"{cln}%", f"%{raw_query}%"))
        rows = cursor.fetchall()

    if not rows:
        conn.close()
        return {
            "found": False,
            "query": raw_query,
            "message": f"Part Number '{raw_query}' tidak ditemukan di katalog coupling Caterpillar."
        }

    # Ambil baris pertama sebagai hasil utama
    r = rows[0]
    img_dir = find_images_dir()
    diagram_filename = r["diagram_image"] or ""
    diagram_full_path = ""
    if diagram_filename and img_dir:
        cand_img = os.path.join(img_dir, diagram_filename)
        if os.path.exists(cand_img):
            diagram_full_path = cand_img

    item = {
        "id": r["id"],
        "part_number": r["part_number"],
        "pdf_page": r["pdf_page"],
        "catalog_page": r["catalog_page"],
        "section_title": r["section_title"] or "-",
        "fitting_style": r["fitting_style"] or "-",
        "hose_id_mm": r["hose_id_mm"],
        "hose_id_inch": r["hose_id_inch"] or "-",
        "hose_dash": r["hose_dash"] or "-",
        "series": r["series"] or "-",
        "head_or_thread_size": r["head_or_thread_size"] or "-",
        "end_dash": r["end_dash"] or "-",
        "tube_od_mm": r["tube_od_mm"],
        "tube_od_inch": r["tube_od_inch"] or "-",
        "length_b_mm": r["length_b_mm"],
        "length_b_inch": r["length_b_inch"],
        "cutoff_c_mm": r["cutoff_c_mm"],
        "cutoff_c_inch": r["cutoff_c_inch"],
        "drop_d_mm": r["drop_d_mm"],
        "drop_d_inch": r["drop_d_inch"],
        "mating_seal_pn": r["mating_seal_pn"] or "-",
        "diagram_image": diagram_filename,
        "diagram_image_path": diagram_full_path
    }

    # Cari equivalent parts (Dash & Head Size sama, PN berbeda)
    alternatives = []
    dash = r["hose_dash"]
    head = r["head_or_thread_size"]
    pn = r["part_number"]
    if dash and head and head != "-":
        cursor.execute("""
            SELECT part_number, fitting_style, hose_dash, head_or_thread_size, cutoff_c_mm, drop_d_mm, mating_seal_pn
            FROM cat_couplings
            WHERE hose_dash = ? AND head_or_thread_size = ? AND part_number != ?
            GROUP BY part_number
            ORDER BY part_number ASC
            LIMIT 15
        """, (dash, head, pn))
        alt_rows = cursor.fetchall()
        for ar in alt_rows:
            alternatives.append({
                "part_number": ar["part_number"],
                "fitting_style": ar["fitting_style"] or "-",
                "hose_dash": ar["hose_dash"] or "-",
                "head_or_thread_size": ar["head_or_thread_size"] or "-",
                "cutoff_c_mm": ar["cutoff_c_mm"],
                "drop_d_mm": ar["drop_d_mm"],
                "mating_seal_pn": ar["mating_seal_pn"] or "-"
            })

    conn.close()

    return {
        "found": True,
        "query": raw_query,
        "item": item,
        "alternatives": alternatives,
        "total_matches": len(rows)
    }


def batch_search_couplings(pn_list: list) -> list:
    """
    Pencarian massal daftar part number.
    Mengembalikan list berisi spesifikasi lengkap atau status Tidak Ditemukan.
    """
    if not pn_list:
        return []

    conn = get_db_connection()
    cursor = conn.cursor()

    results = []
    for idx, raw_pn in enumerate(pn_list, start=1):
        clean = clean_pn(raw_pn)
        if not clean:
            continue

        cursor.execute("""
            SELECT part_number, section_title, fitting_style, hose_dash, hose_id_inch,
                   head_or_thread_size, cutoff_c_mm, cutoff_c_inch, drop_d_mm, drop_d_inch,
                   length_b_mm, mating_seal_pn
            FROM cat_couplings
            WHERE REPLACE(part_number, '-', '') = ? OR part_number = ?
            LIMIT 1
        """, (clean, raw_pn.strip()))
        row = cursor.fetchone()

        if row:
            results.append({
                "no": idx,
                "input_pn": raw_pn.strip(),
                "part_number": row["part_number"],
                "section_title": row["section_title"] or "-",
                "fitting_style": row["fitting_style"] or "-",
                "hose_dash": row["hose_dash"] or "-",
                "hose_id_inch": row["hose_id_inch"] or "-",
                "head_or_thread_size": row["head_or_thread_size"] or "-",
                "cutoff_c_mm": row["cutoff_c_mm"] if row["cutoff_c_mm"] is not None else "-",
                "cutoff_c_inch": row["cutoff_c_inch"] if row["cutoff_c_inch"] is not None else "-",
                "drop_d_mm": row["drop_d_mm"] if row["drop_d_mm"] is not None else "-",
                "drop_d_inch": row["drop_d_inch"] if row["drop_d_inch"] is not None else "-",
                "length_b_mm": row["length_b_mm"] if row["length_b_mm"] is not None else "-",
                "mating_seal_pn": row["mating_seal_pn"] or "-",
                "status": "Ditemukan",
                "is_found": True
            })
        else:
            results.append({
                "no": idx,
                "input_pn": raw_pn.strip(),
                "part_number": "-",
                "section_title": "-",
                "fitting_style": "-",
                "hose_dash": "-",
                "hose_id_inch": "-",
                "head_or_thread_size": "-",
                "cutoff_c_mm": "-",
                "cutoff_c_inch": "-",
                "drop_d_mm": "-",
                "drop_d_inch": "-",
                "length_b_mm": "-",
                "mating_seal_pn": "-",
                "status": "Tidak Ditemukan",
                "is_found": False
            })

    conn.close()
    return results


def export_coupling_excel(items: list, output_dir: str = "") -> str:
    """
    Ekspor hasil batch search ke format Excel (.xlsx) resmi KermenX.
    Header Dark Navy #1E3A8A, font Segoe UI, borders rapi, zebra striping, dan kolom auto-fit.
    """
    if not output_dir or not os.path.exists(output_dir):
        output_dir = os.path.join(ROOT_DIR, "Output")
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"Katalog_Coupling_Batch_{timestamp}.xlsx"
    file_path = os.path.join(output_dir, filename)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Katalog Coupling CAT"

    # Style Definitions
    navy_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    accent_fill = PatternFill(start_color="3B82F6", end_color="3B82F6", fill_type="solid")
    zebra_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")

    font_banner = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=10, italic=True, color="E2E8F0")
    font_header = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    font_data = Font(name="Segoe UI", size=9.5, color="0F172A")
    font_cutoff = Font(name="Segoe UI", size=10, bold=True, color="1E3A8A")
    font_found = Font(name="Segoe UI", size=9.5, bold=True, color="059669")
    font_not_found = Font(name="Segoe UI", size=9.5, bold=True, color="DC2626")

    align_center = Alignment(horizontal="center", vertical="center")
    align_left = Alignment(horizontal="left", vertical="center")
    align_right = Alignment(horizontal="right", vertical="center")

    thin_border_side = Side(border_style="thin", color="CBD5E1")
    thin_border = Border(left=thin_border_side, right=thin_border_side, top=thin_border_side, bottom=thin_border_side)

    # 1. Banner Header (Row 1-2)
    ws.merge_cells("A1:N1")
    banner_cell = ws["A1"]
    banner_cell.value = "KATALOG SPESIFIKASI COUPLING CATERPILLAR (CAT)"
    banner_cell.font = font_banner
    banner_cell.fill = navy_fill
    banner_cell.alignment = align_center
    ws.row_dimensions[1].height = 34

    ws.merge_cells("A2:N2")
    sub_cell = ws["A2"]
    now_str = datetime.datetime.now().strftime("%d %b %Y %H:%M WIB")
    found_count = sum(1 for it in items if it.get("is_found", False))
    sub_cell.value = f"Total Part Dievaluasi: {len(items)} Item | Ditemukan: {found_count} | Tidak Ditemukan: {len(items) - found_count} | Diekspor: {now_str}"
    sub_cell.font = font_sub
    sub_cell.fill = navy_fill
    sub_cell.alignment = align_center
    ws.row_dimensions[2].height = 22

    # Row 3 kosong pemisah
    ws.row_dimensions[3].height = 10

    # 2. Table Headers (Row 4)
    headers = [
        "No", "Part Number Input", "Part Number Resmi", "Fitting Style / Deskripsi",
        "Hose Dash", "Hose ID (Inch)", "Head / Thread Size",
        "Cutoff C (mm)", "Cutoff C (in)", "Drop D (mm)", "Drop D (in)",
        "Length B (mm)", "Mating Seal PN", "Status"
    ]
    ws.row_dimensions[4].height = 26

    for col_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=col_idx, value=h)
        cell.font = font_header
        cell.fill = accent_fill
        cell.alignment = align_center
        cell.border = thin_border

    # 3. Data Rows (Row 5+)
    for row_idx, itm in enumerate(items, start=5):
        ws.row_dimensions[row_idx].height = 20
        is_even = (row_idx % 2 == 0)
        curr_fill = zebra_fill if is_even else white_fill

        is_found = itm.get("is_found", False)
        status_text = "Ditemukan" if is_found else "Tidak Ditemukan"

        row_values = [
            itm.get("no", row_idx - 4),
            itm.get("input_pn", "-"),
            itm.get("part_number", "-"),
            itm.get("fitting_style", "-"),
            itm.get("hose_dash", "-"),
            itm.get("hose_id_inch", "-"),
            itm.get("head_or_thread_size", "-"),
            itm.get("cutoff_c_mm", "-"),
            itm.get("cutoff_c_inch", "-"),
            itm.get("drop_d_mm", "-"),
            itm.get("drop_d_inch", "-"),
            itm.get("length_b_mm", "-"),
            itm.get("mating_seal_pn", "-"),
            status_text
        ]

        for col_idx, val in enumerate(row_values, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.fill = curr_fill
            cell.border = thin_border

            # Alignment & Font Rules
            if col_idx in (1, 5, 6, 13, 14):
                cell.alignment = align_center
            elif col_idx in (8, 9, 10, 11, 12):
                cell.alignment = align_right
            else:
                cell.alignment = align_left

            if col_idx == 14:
                cell.font = font_found if is_found else font_not_found
            elif col_idx == 8: # Cutoff C
                cell.font = font_cutoff
            else:
                cell.font = font_data

    # 4. Auto-fit Column Width
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            # Lewati merge banner row 1 & 2
            if cell.row in (1, 2, 3):
                continue
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 11)

    # Khusus kolom deskripsi berikan ruang lebih
    ws.column_dimensions["D"].width = max(ws.column_dimensions["D"].width, 32)
    ws.column_dimensions["G"].width = max(ws.column_dimensions["G"].width, 24)

    wb.save(file_path)
    return os.path.abspath(file_path)
