"""
Module: sto_helper.py
Khusus pengolahan dan pencocokan kebutuhan Part Not Ready (WO Readiness)
terhadap Stok Aktual di 4 HUB:
1. 1S66 - Banjarmasin Hub (Prioritas 1)
2. 1S67 - Samarinda Hub   (Prioritas 2)
3. 1S81 - Surabaya Hub    (Prioritas 3)
4. 1S76 - Jakarta Mega Hub (Prioritas 4)

Output:
- Mengenerate file Excel Form STO per HUB (format upload otomatis SAP BAPI)
- Memberikan ringkasan alokasi per HUB & item yang belum terpenuhi (shortage)
"""
import os
import glob
import time
import re
from datetime import datetime
import openpyxl

import config
from modules.email_helper import extract_not_ready_details_from_excel


def find_matching_stock_hub(reference_path=None):
    """
    Mencari file data Stock HUB secara otomatis dari berbagai lokasi potensial:
    1. Folder file RAW DATA / Reference (jika ada)
    2. Folder Desktop pengguna
    3. Folder Downloads pengguna
    4. Direktori aplikasi Kermen Tools
    """
    search_dirs = []

    if reference_path and os.path.exists(reference_path):
        ref_dir = os.path.dirname(os.path.abspath(reference_path))
        if ref_dir not in search_dirs:
            search_dirs.append(ref_dir)

    # Tambahkan Desktop
    desktop_candidates = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop")
    ]
    for d in desktop_candidates:
        if os.path.exists(d) and d not in search_dirs:
            search_dirs.append(d)

    # Tambahkan Downloads
    downloads_candidates = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads")
    ]
    for d in downloads_candidates:
        if os.path.exists(d) and d not in search_dirs:
            search_dirs.append(d)

    # Folder Aplikasi & Output SAP
    for d in [config.get_output_dir("sap"), config.get_base_output_dir(), config.BASE_DIR]:
        if os.path.exists(d) and d not in search_dirs:
            search_dirs.append(d)


    patterns = [
        "*Stock*HUB*.xlsx",
        "*Stock*HUB*.xlsb",
        "*Stock*HUB*.xls",
        "*STOCK*HUB*.XLSX",
        "*STOCK*HUB*.XLSB",
        "*Stock HUB*.xlsx",
        "*Stock HUB*.XLSX"
    ]

    found_files = []
    for s_dir in search_dirs:
        for pat in patterns:
            try:
                matches = glob.glob(os.path.join(s_dir, pat))
                for m in matches:
                    if os.path.isfile(m) and not os.path.basename(m).startswith("~$"):
                        if m not in found_files:
                            found_files.append(m)
            except Exception:
                pass

    if not found_files:
        return None

    # Kembalikan file dengan waktu modifikasi terbaru
    return max(found_files, key=os.path.getmtime)


def normalize_mat_key(mat_str):
    """Menghilangkan karakter spasi dan simbol untuk perbandingan part number yang robust"""
    if not mat_str:
        return ""
    clean = re.sub(r'[^A-Za-z0-9]', '', str(mat_str)).upper()
    return clean


def parse_numeric(val):
    """Konversi nilai sel ke float secara aman"""
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    c = re.sub(r'[^\d.-]', '', str(val).replace(',', ''))
    try:
        return float(c) if c else 0.0
    except Exception:
        return 0.0


_VALTYPE_CATALOG = {}
_CATALOG_LOADED = False


def init_valtype_catalog(hub_path=None):
    """Memuat katalog valuation type dari Stock HUB secara cepat ke cache jika belum dimuat"""
    global _VALTYPE_CATALOG, _CATALOG_LOADED
    if _CATALOG_LOADED and _VALTYPE_CATALOG:
        return _VALTYPE_CATALOG

    if not hub_path or not os.path.exists(hub_path):
        hub_path = find_matching_stock_hub()

    if not hub_path or not os.path.exists(hub_path):
        return _VALTYPE_CATALOG

    try:
        wb = openpyxl.load_workbook(hub_path, read_only=True, data_only=True)
        ws = wb.active
        mat_col = 0
        batch_col = 4
        first_row = True
        for r in ws.iter_rows(values_only=True):
            if not r:
                continue
            if first_row:
                h_row = [str(c).strip().lower() if c is not None else "" for c in r]
                for idx, h in enumerate(h_row):
                    if 'material' in h or 'part' in h:
                        mat_col = idx
                    elif 'batch' in h or 'val' in h:
                        batch_col = idx
                first_row = False
                continue

            mat_raw = r[mat_col] if len(r) > mat_col else None
            batch_raw = r[batch_col] if len(r) > batch_col else None
            if mat_raw and batch_raw:
                mat_str = str(mat_raw).strip().upper()
                b_str = str(batch_raw).strip().upper()
                if b_str:
                    nk = normalize_mat_key(mat_str)
                    bk = normalize_mat_key(mat_str.split(':')[0])
                    if nk:
                        _VALTYPE_CATALOG[nk] = b_str
                    if bk:
                        _VALTYPE_CATALOG[bk] = b_str

        wb.close()
        _CATALOG_LOADED = True
    except Exception as e:
        print(f"[Warning] Gagal memuat valtype catalog dari Stock HUB: {e}")

    return _VALTYPE_CATALOG


def get_auto_valuation_type(pn, hub_path=None):
    """
    Menentukan Valuation Type otomatis (CATNEW, NCATNEW, RPRODUCT, PXPRODUCT, PEPRODUCT, KITNEW)
    berdasarkan:
    1. Pencarian di katalog Stock HUB (45,000+ material terdaftar)
    2. Aturan pola penomoran resmi Caterpillar & Trakindo:
       - Prefix 0R, 10R, 11R, 20R..50R (Reman Caterpillar) -> RPRODUCT
       - Prefix/Suffix PX -> PXPRODUCT
       - Prefix/Suffix PE -> PEPRODUCT
       - Mengandung kata/kode KIT -> KITNEW
       - Suffix :MT, :NM, :CG, :LS atau Allied vendor -> NCATNEW
       - Default Caterpillar -> CATNEW
    """
    if not pn:
        return "CATNEW"

    pn_str = str(pn).strip().upper()
    nk = normalize_mat_key(pn_str)
    bk = normalize_mat_key(pn_str.split(':')[0])

    # 1. Cek di cache catalog jika sudah ada
    if nk in _VALTYPE_CATALOG:
        return _VALTYPE_CATALOG[nk]
    if bk in _VALTYPE_CATALOG:
        return _VALTYPE_CATALOG[bk]

    # Coba muat catalog jika belum
    if not _CATALOG_LOADED:
        init_valtype_catalog(hub_path)
        if nk in _VALTYPE_CATALOG:
            return _VALTYPE_CATALOG[nk]
        if bk in _VALTYPE_CATALOG:
            return _VALTYPE_CATALOG[bk]

    # 2. Aturan Heuristik Standar Caterpillar & Trakindo
    clean_base = pn_str.split(':')[0].replace(' ', '').replace('-', '')
    # Reman Caterpillar: 0R atau 2-digit R (10R, 11R, 20R..50R)
    if re.match(r'^(?:0R|\d{2}R)[0-9A-Z]+', clean_base):
        return "RPRODUCT"

    # Parts Exchange
    if clean_base.startswith('PX') or clean_base.endswith('PX'):
        return "PXPRODUCT"

    # Periodic Exchange
    if clean_base.startswith('PE') or clean_base.endswith('PE'):
        return "PEPRODUCT"

    # Kit
    if 'KIT' in clean_base or 'KIT' in pn_str:
        return "KITNEW"

    # Non-CAT (Allied) dari suffix SAP
    if any(pn_str.endswith(sfx) for sfx in (':MT', ':NM', ':CG', ':LS', ':FL')):
        return "NCATNEW"

    # Default Caterpillar
    return "CATNEW"


def load_stock_hub_data(hub_path, status_callback=None):
    """
    Membaca data persediaan dari file Excel Stock HUB (misal Stock HUB.XLSX).
    Mengembalikan struktur data inventory:
    hub_inventory[normalized_key] = {
        'exact_mat': primary_material_code,
        'plants': {
            '1S66': [ {'batch': 'CATNEW', 'qty': 10.0, 'sloc': 'DMDV'}, ... ],
            '1S67': [ ... ], ...
        }
    }
    """
    if not hub_path or not os.path.exists(hub_path):
        raise FileNotFoundError(f"File Stock HUB tidak ditemukan: {hub_path}")

    if status_callback:
        status_callback(f"Membaca data Stock HUB ({os.path.basename(hub_path)})...")

    wb = openpyxl.load_workbook(hub_path, read_only=True, data_only=True)
    sheet_name = wb.sheetnames[0]
    ws = wb[sheet_name]

    headers = None
    mat_col = 0
    plant_col = 1
    sloc_col = 2
    batch_col = 4
    unrestricted_col = 6

    hub_inventory = {}
    row_count = 0

    for r in ws.iter_rows(values_only=True):
        if not r or all(c is None for c in r):
            continue

        if headers is None:
            # Cari baris header
            h_row = [str(c).strip().lower() if c is not None else "" for c in r]
            for idx, h in enumerate(h_row):
                if 'material' in h or 'part' in h:
                    mat_col = idx
                elif 'plant' in h:
                    plant_col = idx
                elif 'sloc' in h or 'storage' in h:
                    sloc_col = idx
                elif 'batch' in h:
                    batch_col = idx
                elif 'unrestricted' in h:
                    unrestricted_col = idx
            headers = h_row
            continue

        row_count += 1
        mat_raw = r[mat_col] if len(r) > mat_col else None
        plant_raw = r[plant_col] if len(r) > plant_col else None
        sloc_raw = r[sloc_col] if len(r) > sloc_col else "DMDV"
        batch_raw = r[batch_col] if len(r) > batch_col else "CATNEW"
        unrestricted_raw = r[unrestricted_col] if len(r) > unrestricted_col else 0

        if not mat_raw:
            continue

        mat_str = str(mat_raw).strip()
        batch_str = str(batch_raw).strip().upper() if batch_raw else "CATNEW"

        # Simpan ke katalog valuation type global (meskipun stok 0)
        norm_key = normalize_mat_key(mat_str)
        base_norm = normalize_mat_key(mat_str.split(':')[0])
        if norm_key:
            _VALTYPE_CATALOG[norm_key] = batch_str
        if base_norm:
            _VALTYPE_CATALOG[base_norm] = batch_str

        if not plant_raw:
            continue

        unrestricted_qty = parse_numeric(unrestricted_raw)
        if unrestricted_qty <= 0:
            continue

        plant_str = str(plant_raw).strip().upper()
        sloc_str = str(sloc_raw).strip().upper() if sloc_raw else "DMDV"

        keys_to_register = {norm_key, base_norm}

        for k in keys_to_register:
            if not k:
                continue
            if k not in hub_inventory:
                hub_inventory[k] = {
                    'primary_mat': mat_str,
                    'plants': {}
                }
            if plant_str not in hub_inventory[k]['plants']:
                hub_inventory[k]['plants'][plant_str] = []

            hub_inventory[k]['plants'][plant_str].append({
                'batch': batch_str,
                'qty': unrestricted_qty,
                'sloc': sloc_str,
                'mat_code': mat_str
            })

    wb.close()

    if status_callback:
        status_callback(f"Berhasil membaca {row_count:,} baris Stock HUB ({len(hub_inventory):,} part terdaftar).")

    return hub_inventory


def extract_hose_consist_deficits_from_excel(readiness_report_path):
    """
    Mengekstrak daftar komponen Hose (Coupling & Bulk Hose) yang berstatus DEFICIT
    dari sheet 'Hose Consist Analysis' pada file laporan Part Readiness.
    """
    if not readiness_report_path or not os.path.exists(readiness_report_path):
        return []

    deficit_items = []
    try:
        wb = openpyxl.load_workbook(readiness_report_path, read_only=True, data_only=True)
        sheet_target = None
        for sname in wb.sheetnames:
            if "hose consist" in sname.lower() or "consist analysis" in sname.lower():
                sheet_target = sname
                break

        if not sheet_target:
            wb.close()
            return []

        ws = wb[sheet_target]
        header_row_found = False
        col_map = {}

        for row_vals in ws.iter_rows(values_only=True):
            if not row_vals or all(c is None for c in row_vals):
                continue

            row_str = [str(c).strip().lower() if c is not None else "" for c in row_vals]
            if not header_row_found:
                if any("part number" in s or "tipe komponen" in s for s in row_str):
                    header_row_found = True
                    for idx, s in enumerate(row_str):
                        if "part number" in s or s == "pn":
                            col_map["pn"] = idx
                        elif "tipe komponen" in s or "tipe" in s:
                            col_map["type"] = idx
                        elif "deskripsi" in s:
                            col_map["desc"] = idx
                        elif "total akumulasi" in s or "kebutuhan" in s:
                            col_map["req_qty"] = idx
                        elif "stok atp" in s or "stok" in s:
                            if "req_qty" not in col_map or idx != col_map.get("req_qty"):
                                if "avail_stock" not in col_map:
                                    col_map["avail_stock"] = idx
                        elif "net balance" in s or "balance" in s:
                            col_map["balance"] = idx
                        elif "status" in s:
                            col_map["status"] = idx
                        elif "defisit" in s:
                            col_map["deficit"] = idx
                        elif "digunakan" in s or "hose assembly" in s:
                            col_map["used_in"] = idx
                    continue
                else:
                    continue

            pn_idx = col_map.get("pn")
            def_idx = col_map.get("deficit")
            stat_idx = col_map.get("status")

            if pn_idx is None or len(row_vals) <= pn_idx:
                continue

            pn_val = str(row_vals[pn_idx]).strip() if row_vals[pn_idx] is not None else ""
            if not pn_val or pn_val.lower().startswith("total") or pn_val.lower() == "none":
                continue

            deficit_val = 0.0
            if def_idx is not None and len(row_vals) > def_idx and row_vals[def_idx] is not None:
                deficit_val = parse_numeric(row_vals[def_idx])

            status_val = ""
            if stat_idx is not None and len(row_vals) > stat_idx and row_vals[stat_idx] is not None:
                status_val = str(row_vals[stat_idx]).strip()

            is_deficit = ("deficit" in status_val.lower()) or (deficit_val > 0)
            if not is_deficit:
                continue

            req_val = parse_numeric(row_vals[col_map["req_qty"]]) if "req_qty" in col_map and len(row_vals) > col_map["req_qty"] else deficit_val
            avail_val = parse_numeric(row_vals[col_map["avail_stock"]]) if "avail_stock" in col_map and len(row_vals) > col_map["avail_stock"] else 0.0
            bal_val = parse_numeric(row_vals[col_map["balance"]]) if "balance" in col_map and len(row_vals) > col_map["balance"] else -deficit_val
            desc_val = str(row_vals[col_map["desc"]]).strip() if "desc" in col_map and len(row_vals) > col_map["desc"] and row_vals[col_map["desc"]] is not None else ""
            type_val = str(row_vals[col_map["type"]]).strip() if "type" in col_map and len(row_vals) > col_map["type"] and row_vals[col_map["type"]] is not None else "COUPLING"
            type_upper = type_val.upper()

            # Filter ketat: Hanya masukkan tipe COUPLING, lewati BULK HOSE / Hose BK
            if "HOSE" in type_upper or "BULK" in type_upper or "BK" in type_upper:
                continue
            if type_upper and "COUPLING" not in type_upper:
                continue

            used_in_val = str(row_vals[col_map["used_in"]]).strip() if "used_in" in col_map and len(row_vals) > col_map["used_in"] and row_vals[col_map["used_in"]] is not None else ""

            if deficit_val <= 0 and req_val > avail_val:
                deficit_val = req_val - avail_val

            if deficit_val > 0:
                deficit_items.append({
                    "pn": pn_val,
                    "mat_no": pn_val,
                    "desc": desc_val or "Coupling Hose",
                    "req_qty": req_val,
                    "avail_stock": avail_val,
                    "balance": bal_val,
                    "deficit": deficit_val,
                    "remarks": "Defisit Coupling Consist",
                    "used_in": used_in_val
                })

        wb.close()
    except Exception as e:
        print(f"[Warning] Gagal mengekstrak defisit dari Hose Consist Analysis: {e}")

    return deficit_items


def process_sto_analysis(readiness_report_path, hub_file_path, output_dir=None, target_sheet=None, receiving_plant=None, receiving_sloc=None, include_hose_consist=True, status_callback=None, **kwargs):
    """
    Menjalankan alur lengkap analisa STO:
    1. Mengambil detail part Not Ready & Deficit dari file Laporan Part Readiness
    2. Menyertakan part defisit dari sheet 'Hose Consist Analysis' (jika opsi aktif)
    3. Membaca data Stock HUB
    4. Alokasi kaskade (1S66 -> 1S67 -> 1S81 -> 1S76)
    5. Mengenerate file Excel Form STO per HUB (format upload otomatis SAP)
    6. Mengembalikan laporan ringkasan alokasi
    """
    t0 = time.time()

    if not readiness_report_path or not os.path.exists(readiness_report_path):
        raise FileNotFoundError(f"File Laporan Part Readiness tidak ditemukan: {readiness_report_path}")

    if not hub_file_path or not os.path.exists(hub_file_path):
        raise FileNotFoundError(f"File Stock HUB tidak ditemukan: {hub_file_path}")

    if output_dir is None:
        output_dir = config.get_output_dir("sto")
    os.makedirs(output_dir, exist_ok=True)

    rec_plant = str(receiving_plant).strip() if receiving_plant else getattr(config, 'DEFAULT_STO_RECEIVING_PLANT', '1346')
    rec_sloc = str(receiving_sloc).strip() if receiving_sloc else getattr(config, 'DEFAULT_STO_RECEIVING_SLOC', 'DMDV')

    if status_callback:
        status_callback("Mengekstrak data part Not Ready dari laporan...")

    # Ekstrak part Not Ready
    extracted = extract_not_ready_details_from_excel(readiness_report_path, top_n=999999, target_sheet=target_sheet)
    not_ready_items = []
    if extracted:
        not_ready_items = extracted.get('all_items', []) or extracted.get('top_items', []) or extracted.get('not_ready_items', [])

    # Ekstrak part defisit dari sheet 'Hose Consist Analysis' jika ada dan opsi aktif
    if include_hose_consist:
        consist_deficits = extract_hose_consist_deficits_from_excel(readiness_report_path)
        if consist_deficits:
            if status_callback:
                status_callback(f"Menyertakan {len(consist_deficits)} part defisit Coupling dari sheet 'Hose Consist Analysis' (Hose BK diabaikan)...")
            existing_map = {}
            for it in not_ready_items:
                k = normalize_mat_key(it.get('pn', ''))
                if k:
                    existing_map[k] = it

            added_count = 0
            for c_it in consist_deficits:
                c_key = normalize_mat_key(c_it.get('pn', ''))
                if c_key and c_key in existing_map:
                    existing_map[c_key]['deficit'] = existing_map[c_key].get('deficit', 0.0) + c_it.get('deficit', 0.0)
                    existing_map[c_key]['req_qty'] = existing_map[c_key].get('req_qty', 0.0) + c_it.get('req_qty', 0.0)
                    existing_map[c_key]['remarks'] = (str(existing_map[c_key].get('remarks', '')) + f" + Coupling Deficit ({c_it.get('deficit', 0.0):g})").strip()
                else:
                    not_ready_items.append(c_it)
                    if c_key:
                        existing_map[c_key] = c_it
                    added_count += 1

    if not not_ready_items:
        return {
            "status": "empty",
            "message": "Tidak ada part Not Ready (Defisit) yang ditemukan pada laporan.",
            "total_not_ready": 0,
            "total_requested_deficit": 0.0,
            "total_allocated_qty": 0.0,
            "fulfillment_pct": 0.0,
            "generated_files": []
        }

    # Filter hanya part yang memang defisit > 0
    deficit_items = [it for it in not_ready_items if it.get('deficit', 0) > 0]
    if not deficit_items:
        return {
            "status": "empty",
            "message": "Seluruh part telah terpenuhi atau tidak ada defisit kebutuhan.",
            "total_not_ready": len(not_ready_items),
            "generated_files": []
        }

    # Baca Stock HUB
    hub_inventory = load_stock_hub_data(hub_file_path, status_callback=status_callback)

    if status_callback:
        status_callback("Memulai pencocokan alokasi kaskade ke 4 HUB...")

    # Struktur penampung alokasi per HUB
    allocations_by_hub = {hub["code"]: [] for hub in config.HUB_PRIORITY_ORDER}
    detailed_allocations = []
    unfulfilled_items = []

    total_allocated_qty = 0.0
    total_requested_deficit = 0.0

    custom_mapping = getattr(config, 'CUSTOM_PN_MAPPING', {})

    for item in deficit_items:
        mat_no = item.get('mat_no', '').strip()
        pn_val = item.get('pn', '').strip()
        desc_val = item.get('desc', '').strip()
        rem_val = item.get('remarks', '').strip()
        deficit_qty = float(item.get('deficit', 0.0))

        total_requested_deficit += deficit_qty
        remaining_deficit = deficit_qty

        # Siapkan kunci pencarian
        search_keys = []
        if pn_val:
            search_keys.append(normalize_mat_key(pn_val))
            search_keys.append(normalize_mat_key(pn_val.split(':')[0]))
            # Cek custom mapping
            if pn_val in custom_mapping:
                search_keys.append(normalize_mat_key(custom_mapping[pn_val]))
        if mat_no:
            search_keys.append(normalize_mat_key(mat_no))
            # Hapus leading zeroes SAP
            lstripped = mat_no.lstrip('0')
            if lstripped:
                search_keys.append(normalize_mat_key(lstripped))

        # Cari data stok di HUB
        matched_inv = None
        for k in search_keys:
            if k and k in hub_inventory:
                matched_inv = hub_inventory[k]
                break

        item_allocations = []

        if matched_inv and matched_inv.get('plants'):
            plant_records = matched_inv['plants']

            # Lakukan alokasi kaskade berdasarkan urutan prioritas HUB
            for hub_info in config.HUB_PRIORITY_ORDER:
                hub_code = hub_info["code"]
                hub_name = hub_info["name"]

                if hub_code not in plant_records:
                    continue

                hub_batches = plant_records[hub_code]
                # Urutkan batch: prioritaskan CATNEW, lalu NCATNEW, lalu Reman & PX, dsb
                def batch_sort_key(b):
                    b_name = str(b.get('batch', '')).strip().upper()
                    if b_name == 'CATNEW':
                        return 0
                    elif b_name == 'NCATNEW':
                        return 1
                    elif b_name in ('RPRODUCT', 'RFULL', 'RPARTIAL', 'RNOCORE'):
                        return 2
                    elif b_name in ('PXPRODUCT', 'PEPRODUCT', 'PXNOCORE', 'PXBER'):
                        return 3
                    elif 'NEW' in b_name:
                        return 4
                    elif 'USED' in b_name:
                        return 6
                    return 5

                hub_batches.sort(key=batch_sort_key)

                for b_entry in hub_batches:
                    avail_in_hub = b_entry.get('qty', 0.0)
                    if avail_in_hub <= 0:
                        continue

                    take_qty = min(remaining_deficit, avail_in_hub)
                    if take_qty <= 0:
                        continue

                    # Kurangi stok di memori
                    b_entry['qty'] -= take_qty
                    remaining_deficit -= take_qty
                    total_allocated_qty += take_qty

                    # Tentukan kode material untuk upload SAP
                    # Format yang tepat adalah material code yang sesuai SAP (PN:AA atau dari Stock HUB)
                    sap_mat_code = pn_val if (':' in pn_val) else (b_entry.get('mat_code') or f"{pn_val}:AA")

                    alloc_record = {
                        "supplying_plant": hub_code,
                        "supplying_hub_name": hub_name,
                        "material": sap_mat_code,
                        "pn": pn_val,
                        "description": desc_val,
                        "valuation_type": b_entry.get('batch', 'CATNEW'),
                        "qty": take_qty,
                        "sloc": b_entry.get('sloc', config.DEFAULT_STO_SUPPLYING_SLOC)
                    }

                    allocations_by_hub[hub_code].append(alloc_record)
                    item_allocations.append(alloc_record)

                    if remaining_deficit <= 0:
                        break

                if remaining_deficit <= 0:
                    break

        item_summary = {
            "pn": pn_val,
            "mat_no": mat_no,
            "description": desc_val,
            "req_qty": float(item.get('req_qty', 0.0)),
            "avail_stock": float(item.get('avail_stock', 0.0)),
            "balance": float(item.get('balance', -deficit_qty)),
            "deficit_qty": deficit_qty,
            "allocated_qty": deficit_qty - remaining_deficit,
            "remaining_deficit": remaining_deficit,
            "is_fully_fulfilled": (remaining_deficit <= 0),
            "allocations": item_allocations,
            "remarks": rem_val
        }
        detailed_allocations.append(item_summary)

        if remaining_deficit > 0:
            unfulfilled_items.append(item_summary)

    # Step 4: Generate File Excel Form STO per HUB
    if status_callback:
        status_callback("Mengenerate file Excel FORM STO per HUB...")

    # Cari template FORM STO
    template_paths = [
        os.path.join(config.BASE_DIR, "templates", "FORM_STO.xlsx"),
        r"D:\Users\yusril.i.wafir\Desktop\FORM STO.xlsx",
        os.path.join(os.path.expanduser("~"), "Desktop", "FORM STO.xlsx")
    ]
    template_file = None
    for tp in template_paths:
        if os.path.exists(tp):
            template_file = tp
            break

    if not template_file:
        raise FileNotFoundError("File master template 'FORM_STO.xlsx' tidak ditemukan di folder templates maupun Desktop.")

    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    date_display = datetime.now().strftime("%d-%b-%Y")

    generated_files = []

    for hub_info in config.HUB_PRIORITY_ORDER:
        hub_code = hub_info["code"]
        hub_name = hub_info["name"]
        hub_slug = hub_info["slug"]
        items_for_hub = allocations_by_hub.get(hub_code, [])

        if not items_for_hub:
            continue

        # Buka workbook template
        wb_sto = openpyxl.load_workbook(template_file)
        if 'Template FIle STO' in wb_sto.sheetnames:
            ws_sto = wb_sto['Template FIle STO']
        else:
            ws_sto = wb_sto.active

        # Hapus baris data lama (mulai baris 3 ke bawah)
        if ws_sto.max_row >= 3:
            ws_sto.delete_rows(3, ws_sto.max_row - 2)

        # Isi data item
        for idx, alloc in enumerate(items_for_hub, start=1):
            row_num = 2 + idx  # baris 3 adalah item 1

            # Format Qty (bilangan bulat jika bulat)
            q_val = alloc['qty']
            if q_val == int(q_val):
                q_val = int(q_val)

            ws_sto.cell(row=row_num, column=1, value=1)                                           # PO no
            ws_sto.cell(row=row_num, column=2, value=config.DEFAULT_STO_DOC_TYPE)                # Doc type: ZOTS
            ws_sto.cell(row=row_num, column=3, value=hub_code)                                   # Supplying Plant
            ws_sto.cell(row=row_num, column=4, value=config.DEFAULT_STO_SUPPLYING_SLOC)          # Supplying SLoc: DMDV
            ws_sto.cell(row=row_num, column=5, value=config.DEFAULT_STO_HEADER_NOTE)             # Header note
            ws_sto.cell(row=row_num, column=6, value=config.DEFAULT_STO_PURCH_ORG)               # Purch org: 1001
            ws_sto.cell(row=row_num, column=7, value=config.DEFAULT_STO_PURCH_GRP)               # Purch grp: H13
            ws_sto.cell(row=row_num, column=8, value=config.DEFAULT_STO_COMP_CODE)               # Comp code: 1000
            ws_sto.cell(row=row_num, column=14, value=config.DEFAULT_STO_SHIP_IN)                # Ship in: S
            ws_sto.cell(row=row_num, column=15, value=config.DEFAULT_STO_SHIPPING_COND)          # Shipping Cond: ED
            ws_sto.cell(row=row_num, column=18, value=idx)                                       # Item: 1, 2, ...
            ws_sto.cell(row=row_num, column=21, value=alloc['material'])                         # Material
            ws_sto.cell(row=row_num, column=23, value=alloc['valuation_type'])                   # Valuation type
            ws_sto.cell(row=row_num, column=24, value=q_val)                                     # Qty
            ws_sto.cell(row=row_num, column=26, value=rec_plant)                                 # Receiving Plant: dynamic / default
            ws_sto.cell(row=row_num, column=27, value=rec_sloc)                                  # Receiving SLoc: dynamic / default

        # Nama file output
        out_filename = f"FORM_STO_{hub_code}_{hub_slug}_{timestamp_str}.xlsx"
        out_filepath = os.path.join(output_dir, out_filename)
        wb_sto.save(out_filepath)
        wb_sto.close()

        total_hub_qty = sum(a['qty'] for a in items_for_hub)
        generated_files.append({
            "plant": hub_code,
            "name": hub_name,
            "slug": hub_slug,
            "filepath": out_filepath,
            "filename": out_filename,
            "item_count": len(items_for_hub),
            "total_qty": total_hub_qty
        })

    elapsed = time.time() - t0

    result = {
        "status": "success",
        "date_display": date_display,
        "timestamp": timestamp_str,
        "elapsed_time": elapsed,
        "output_dir": output_dir,
        "total_not_ready": len(deficit_items),
        "total_requested_deficit": total_requested_deficit,
        "total_allocated_qty": total_allocated_qty,
        "fulfillment_pct": round((total_allocated_qty / total_requested_deficit * 100), 1) if total_requested_deficit > 0 else 0.0,
        "generated_files": generated_files,
        "unfulfilled_items": unfulfilled_items,
        "unfulfilled_count": len(unfulfilled_items),
        "detailed_allocations": detailed_allocations,
        "allocations_by_hub": allocations_by_hub,
    }

    if status_callback:
        status_callback(f"Selesai! {len(generated_files)} file Form STO berhasil dibuat dalam {elapsed:.1f}s.")

    return result


def generate_manual_sto_analysis(
    manual_items=None,
    supplying_plant=None,
    use_hub_cascade=False,
    hub_file_path=None,
    header_note=None,
    output_dir=None,
    receiving_plant=None,
    receiving_sloc=None,
    status_callback=None,
    **kwargs
):
    """
    Mengenerate Form STO dari daftar input part manual (Ad-Hoc / Custom Plant / Customer Request):
    - manual_items: list of dict [{'pn': '1R0755', 'qty': 10.0, 'valtype': 'CATNEW'/'Auto'}]
    - supplying_plant: kode plant jika spesifik (misal '1G31', '1G38', '1H35')
    - use_hub_cascade: jika True, matching stok otomatis ke 4 HUB
    - header_note: catatan header / Customer Request (misal 'Customer Request PT Adaro Unit EX01')
    """
    t0 = time.time()

    if manual_items is None:
        manual_items = kwargs.get("items_list") or []

    supplying_mode = kwargs.get("supplying_mode")
    if supplying_mode:
        use_hub_cascade = (str(supplying_mode).strip().lower() == "hub")

    custom_plant = kwargs.get("custom_plant")
    if custom_plant and not supplying_plant:
        supplying_plant = custom_plant

    rec_plant = str(receiving_plant).strip() if receiving_plant else getattr(config, 'DEFAULT_STO_RECEIVING_PLANT', '1346')
    rec_sloc = str(receiving_sloc).strip() if receiving_sloc else getattr(config, 'DEFAULT_STO_RECEIVING_SLOC', 'DMDV')

    if not manual_items:
        return {
            "status": "empty",
            "message": "Daftar part manual kosong. Silakan tambahkan part terlebih dahulu.",
            "total_not_ready": 0,
            "generated_files": []
        }

    if output_dir is None:
        output_dir = config.get_output_dir("sto")
    os.makedirs(output_dir, exist_ok=True)


    template_paths = [
        os.path.join(config.BASE_DIR, "templates", "FORM_STO.xlsx"),
        r"D:\Users\yusril.i.wafir\Desktop\FORM STO.xlsx",
        os.path.join(os.path.expanduser("~"), "Desktop", "FORM STO.xlsx")
    ]
    template_file = None
    for tp in template_paths:
        if os.path.exists(tp):
            template_file = tp
            break

    if not template_file:
        raise FileNotFoundError("Master template 'FORM_STO.xlsx' tidak ditemukan di folder templates maupun Desktop.")

    note_to_use = header_note.strip() if (header_note and header_note.strip()) else config.DEFAULT_STO_HEADER_NOTE
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    date_display = datetime.now().strftime("%d-%b-%Y")

    # Skenario 1: Menggunakan Auto-Cascade ke 4 HUB
    if use_hub_cascade:
        if not hub_file_path or not os.path.exists(hub_file_path):
            raise FileNotFoundError(f"File Stock HUB tidak ditemukan untuk kaskade: {hub_file_path}")

        hub_inventory = load_stock_hub_data(hub_file_path, status_callback=status_callback)

        allocations_by_hub = {hub["code"]: [] for hub in config.HUB_PRIORITY_ORDER}
        detailed_allocations = []
        unfulfilled_items = []
        total_allocated_qty = 0.0
        total_requested = sum(parse_numeric(it.get('qty', 0)) for it in manual_items)

        for it in manual_items:
            pn_val = str(it.get('pn', '')).strip()
            qty_val = parse_numeric(it.get('qty', 0))
            manual_valtype = str(it.get('valtype', 'Auto')).strip()

            if not pn_val or qty_val <= 0:
                continue

            remaining_qty = qty_val
            norm_k = normalize_mat_key(pn_val)
            norm_base = normalize_mat_key(pn_val.split(':')[0])

            matched_inv = hub_inventory.get(norm_k) or hub_inventory.get(norm_base)
            item_allocs = []

            if matched_inv and matched_inv.get('plants'):
                plant_recs = matched_inv['plants']
                for hub_info in config.HUB_PRIORITY_ORDER:
                    h_code = hub_info["code"]
                    h_name = hub_info["name"]

                    if h_code not in plant_recs:
                        continue

                    h_batches = plant_recs[h_code]
                    def manual_batch_sort(b):
                        b_name = str(b.get('batch', '')).strip().upper()
                        req_vt = str(manual_valtype).strip().upper() if manual_valtype else ""
                        if req_vt and req_vt not in ('AUTO', 'NONE') and b_name == req_vt:
                            return -1  # Prioritaskan batch yang sama persis dengan yang diminta
                        if b_name == 'CATNEW':
                            return 0
                        elif b_name == 'NCATNEW':
                            return 1
                        elif b_name in ('RPRODUCT', 'RFULL', 'RPARTIAL', 'RNOCORE'):
                            return 2
                        elif b_name in ('PXPRODUCT', 'PEPRODUCT', 'PXNOCORE', 'PXBER'):
                            return 3
                        elif 'NEW' in b_name:
                            return 4
                        elif 'USED' in b_name:
                            return 6
                        return 5

                    h_batches.sort(key=manual_batch_sort)

                    for b_entry in h_batches:
                        avail = b_entry.get('qty', 0.0)
                        if avail <= 0:
                            continue

                        take = min(remaining_qty, avail)
                        if take <= 0:
                            continue

                        b_entry['qty'] -= take
                        remaining_qty -= take
                        total_allocated_qty += take

                        sap_mat = pn_val if (':' in pn_val) else (b_entry.get('mat_code') or f"{pn_val}:AA")
                        vt = (b_entry.get('batch') or it.get('resolved_vt') or get_auto_valuation_type(pn_val, hub_file_path)) if manual_valtype in ('Auto', '', None) else manual_valtype

                        rec = {
                            "supplying_plant": h_code,
                            "supplying_hub_name": h_name,
                            "material": sap_mat,
                            "pn": pn_val,
                            "description": "Manual Request",
                            "valuation_type": vt,
                            "qty": take,
                            "sloc": b_entry.get('sloc', config.DEFAULT_STO_SUPPLYING_SLOC)
                        }
                        allocations_by_hub[h_code].append(rec)
                        item_allocs.append(rec)

                        if remaining_qty <= 0:
                            break
                    if remaining_qty <= 0:
                        break

            item_summary = {
                "pn": pn_val,
                "mat_no": "",
                "description": "Manual Request",
                "deficit_qty": qty_val,
                "allocated_qty": qty_val - remaining_qty,
                "remaining_deficit": remaining_qty,
                "is_fully_fulfilled": (remaining_qty <= 0),
                "allocations": item_allocs,
                "remarks": "Manual Part Request"
            }
            detailed_allocations.append(item_summary)
            if remaining_qty > 0:
                unfulfilled_items.append(item_summary)

        # Generate file per HUB
        generated_files = []
        for hub_info in config.HUB_PRIORITY_ORDER:
            h_code = hub_info["code"]
            h_name = hub_info["name"]
            h_slug = hub_info["slug"]
            items_for_hub = allocations_by_hub.get(h_code, [])
            if not items_for_hub:
                continue

            wb_sto = openpyxl.load_workbook(template_file)
            ws_sto = wb_sto['Template FIle STO'] if 'Template FIle STO' in wb_sto.sheetnames else wb_sto.active
            if ws_sto.max_row >= 3:
                ws_sto.delete_rows(3, ws_sto.max_row - 2)

            for idx, alloc in enumerate(items_for_hub, start=1):
                r_num = 2 + idx
                q_v = int(alloc['qty']) if alloc['qty'] == int(alloc['qty']) else alloc['qty']

                ws_sto.cell(row=r_num, column=1, value=1)
                ws_sto.cell(row=r_num, column=2, value=config.DEFAULT_STO_DOC_TYPE)
                ws_sto.cell(row=r_num, column=3, value=h_code)
                ws_sto.cell(row=r_num, column=4, value=config.DEFAULT_STO_SUPPLYING_SLOC)
                ws_sto.cell(row=r_num, column=5, value=note_to_use)
                ws_sto.cell(row=r_num, column=6, value=config.DEFAULT_STO_PURCH_ORG)
                ws_sto.cell(row=r_num, column=7, value=config.DEFAULT_STO_PURCH_GRP)
                ws_sto.cell(row=r_num, column=8, value=config.DEFAULT_STO_COMP_CODE)
                ws_sto.cell(row=r_num, column=14, value=config.DEFAULT_STO_SHIP_IN)
                ws_sto.cell(row=r_num, column=15, value=config.DEFAULT_STO_SHIPPING_COND)
                ws_sto.cell(row=r_num, column=18, value=idx)
                ws_sto.cell(row=r_num, column=21, value=alloc['material'])
                ws_sto.cell(row=r_num, column=23, value=alloc['valuation_type'])
                ws_sto.cell(row=r_num, column=24, value=q_v)
                ws_sto.cell(row=r_num, column=26, value=rec_plant)
                ws_sto.cell(row=r_num, column=27, value=rec_sloc)

            out_fn = f"FORM_STO_{h_code}_{h_slug}_{timestamp_str}.xlsx"
            out_fp = os.path.join(output_dir, out_fn)
            wb_sto.save(out_fp)
            wb_sto.close()

            q_hub_tot = sum(a['qty'] for a in items_for_hub)
            generated_files.append({
                "plant": h_code,
                "name": h_name,
                "slug": h_slug,
                "filepath": out_fp,
                "filename": out_fn,
                "item_count": len(items_for_hub),
                "total_qty": q_hub_tot
            })

        elapsed = time.time() - t0
        return {
            "status": "success",
            "mode": "manual_hub",
            "date_display": date_display,
            "timestamp": timestamp_str,
            "elapsed_time": elapsed,
            "output_dir": output_dir,
            "total_not_ready": len(manual_items),
            "total_requested_deficit": total_requested,
            "total_allocated_qty": total_allocated_qty,
            "fulfillment_pct": round((total_allocated_qty / total_requested * 100), 1) if total_requested > 0 else 0.0,
            "generated_files": generated_files,
            "unfulfilled_items": unfulfilled_items,
            "unfulfilled_count": len(unfulfilled_items),
            "detailed_allocations": detailed_allocations,
            "allocations_by_hub": allocations_by_hub,
        }

    # Skenario 2: Menggunakan Specific Plant Tertentu (Luar HUB / Custom Customer Request)
    target_plant = str(supplying_plant).strip().upper() if supplying_plant else "1S66"
    wb_sto = openpyxl.load_workbook(template_file)
    ws_sto = wb_sto['Template FIle STO'] if 'Template FIle STO' in wb_sto.sheetnames else wb_sto.active
    if ws_sto.max_row >= 3:
        ws_sto.delete_rows(3, ws_sto.max_row - 2)

    detailed_allocs = []
    total_q = 0.0

    for idx, it in enumerate(manual_items, start=1):
        pn_raw = str(it.get('pn', '')).strip()
        q_raw = parse_numeric(it.get('qty', 0))
        vt_raw = str(it.get('valtype', 'Auto')).strip()

        if not pn_raw or q_raw <= 0:
            continue

        sap_mat = pn_raw if (':' in pn_raw) else f"{pn_raw}:AA"

        # Tentukan valuation type
        if vt_raw and vt_raw.upper() not in ('AUTO', '', 'NONE'):
            final_vt = vt_raw.upper()
        else:
            final_vt = it.get('resolved_vt') or get_auto_valuation_type(pn_raw, hub_file_path)

        r_num = 2 + idx
        q_v = int(q_raw) if q_raw == int(q_raw) else q_raw
        total_q += q_raw

        ws_sto.cell(row=r_num, column=1, value=1)
        ws_sto.cell(row=r_num, column=2, value=config.DEFAULT_STO_DOC_TYPE)
        ws_sto.cell(row=r_num, column=3, value=target_plant)
        ws_sto.cell(row=r_num, column=4, value=config.DEFAULT_STO_SUPPLYING_SLOC)
        ws_sto.cell(row=r_num, column=5, value=note_to_use)
        ws_sto.cell(row=r_num, column=6, value=config.DEFAULT_STO_PURCH_ORG)
        ws_sto.cell(row=r_num, column=7, value=config.DEFAULT_STO_PURCH_GRP)
        ws_sto.cell(row=r_num, column=8, value=config.DEFAULT_STO_COMP_CODE)
        ws_sto.cell(row=r_num, column=14, value=config.DEFAULT_STO_SHIP_IN)
        ws_sto.cell(row=r_num, column=15, value=config.DEFAULT_STO_SHIPPING_COND)
        ws_sto.cell(row=r_num, column=18, value=idx)
        ws_sto.cell(row=r_num, column=21, value=sap_mat)
        ws_sto.cell(row=r_num, column=23, value=final_vt)
        ws_sto.cell(row=r_num, column=24, value=q_v)
        ws_sto.cell(row=r_num, column=26, value=rec_plant)
        ws_sto.cell(row=r_num, column=27, value=rec_sloc)

        detailed_allocs.append({
            "pn": sap_mat,
            "description": "Custom Plant Request",
            "deficit_qty": q_raw,
            "allocated_qty": q_raw,
            "remaining_deficit": 0.0,
            "is_fully_fulfilled": True,
            "allocations": [{
                "supplying_plant": target_plant,
                "supplying_hub_name": f"Plant {target_plant}",
                "material": sap_mat,
                "qty": q_raw,
                "valuation_type": final_vt
            }],
            "remarks": f"Direct STO -> {target_plant}"
        })

    out_fn = f"FORM_STO_{target_plant}_CUSTOM_{timestamp_str}.xlsx"
    out_fp = os.path.join(output_dir, out_fn)
    wb_sto.save(out_fp)
    wb_sto.close()

    elapsed = time.time() - t0
    gen_file = {
        "plant": target_plant,
        "name": f"Plant {target_plant}",
        "slug": f"CUSTOM_{target_plant}",
        "filepath": out_fp,
        "filename": out_fn,
        "item_count": len(detailed_allocs),
        "total_qty": total_q
    }

    return {
        "status": "success",
        "mode": "manual_specific",
        "date_display": date_display,
        "timestamp": timestamp_str,
        "elapsed_time": elapsed,
        "output_dir": output_dir,
        "total_not_ready": len(detailed_allocs),
        "total_requested_deficit": total_q,
        "total_allocated_qty": total_q,
        "fulfillment_pct": 100.0,
        "generated_files": [gen_file],
        "unfulfilled_items": [],
        "unfulfilled_count": 0,
        "detailed_allocations": detailed_allocs,
        "allocations_by_hub": {target_plant: detailed_allocs},
    }

