"""
Module: counter_macro_helper.py
Khusus mengelola otomatisasi Macro Process Counter (YSUP / Sales Order):
1. Tarik Outstanding Counter (/NZVSD_PARTS_PROGRESS) -> Ekspor ke .XLSX via ALV Spreadsheet (&XXL)
2. Process SO (/NVA02) -> Update PO, Order Reason (ZIN), NBD, Status KSTC, Text Y002 (No. GI)
3. Create Delivery (/NVL10C) -> Eksekusi delivery background untuk SO range 2340000000-2349999999
4. Picking & Goods Issue (/NVL06O) -> Monitor delivery, Create Transfer Order (Picking), dan Post GI
5. Run All -> Menjalankan seluruh alur 1 s/d 4 secara end-to-end tanpa jeda manual
"""

import os
import time
import re
import pandas as pd
import openpyxl
import config
import modules.sap_helper as sh

def _safe_log(callback, msg):
    if callback:
        try:
            callback(msg)
        except Exception:
            pass
    else:
        print(msg)

def _safe_prog(callback, pct, msg):
    if callback:
        try:
            callback(pct, msg)
        except Exception:
            pass
    else:
        print(f"[{pct}%] {msg}")

def dismiss_popups(session, max_count=5):
    """Menutup modal popup tak terduga di SAP."""
    try:
        sh.dismiss_all_popups(session, max_attempts=max_count)
    except Exception:
        pass


def _export_alv_to_spreadsheet(session, save_dir, filename, log_callback=None):
    """
    Mengekspor ALV Grid ke file Excel (.XLSX) menggunakan metode modern &XXL.
    """
    os.makedirs(save_dir, exist_ok=True)
    full_save_path = os.path.join(save_dir, filename)

    exported = False
    # Coba via Grid Context Menu (&XXL)
    for grid_id in [
        "wnd[0]/usr/cntlGRID1/shellcont/shell/shellcont[1]/shell",
        "wnd[0]/usr/cntlGRID1/shellcont/shell",
        "wnd[0]/usr/cntlGRID/shellcont/shell"
    ]:
        try:
            g = session.findById(grid_id)
            if g:
                g.currentCellColumn = "VBELN" if "VBELN" in getattr(g, "ColumnOrder", []) else ""
                g.contextMenu()
                time.sleep(0.5)
                g.selectContextMenuItem("&XXL")
                exported = True
                time.sleep(1)
                break
        except Exception:
            pass

    # Fallback tombol Spreadsheet (btn[43] / btn[45] / Menubar)
    if not exported:
        for btn_code in ["btn[43]", "btn[45]", "btn[32]"]:
            try:
                session.findById(f"wnd[0]/tbar[1]/{btn_code}").press()
                exported = True
                time.sleep(1.5)
                break
            except Exception:
                pass

    if not exported:
        try:
            session.findById("wnd[0]/mbar/menu[0]/menu[3]/menu[1]").select()
            time.sleep(1.5)
            exported = True
        except Exception:
            pass

    # Konfirmasi format dialog Spreadsheet jika muncul
    try:
        if session.Children.Count > 1:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            time.sleep(1)
    except Exception:
        pass

    # Tunggu dialog simpan path & filename
    for _ in range(5):
        try:
            if session.findById("wnd[1]/usr/ctxtDY_PATH"):
                break
        except Exception:
            time.sleep(0.5)

    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = save_dir
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = len(filename)
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(2)
    except Exception:
        try:
            session.findById("wnd[1]").sendVKey(0)
        except Exception:
            pass

    # Tangani dialog replace jika file sudah ada
    try:
        if session.Children.Count > 1:
            top_wnd = session.Children(session.Children.Count - 1)
            try:
                top_wnd.findById("tbar[0]/btn[11]").press()
            except Exception:
                top_wnd.findById("tbar[0]/btn[0]").press()
    except Exception:
        pass

    # Tunggu file tersimpan di disk
    found_file = None
    for _ in range(15):
        if os.path.exists(full_save_path) and os.path.getsize(full_save_path) > 0:
            found_file = full_save_path
            break
        alt_path = os.path.join(save_dir, filename.replace('.XLSX', '.xlsx'))
        if os.path.exists(alt_path) and os.path.getsize(alt_path) > 0:
            found_file = alt_path
            break
        time.sleep(1)

    if not found_file:
        raise RuntimeError(f"File hasil ekspor tidak ditemukan di: {full_save_path}")

    return found_file


# =========================================================================
# 1. TARIK OUTSTANDING COUNTER (/NZVSD_PARTS_PROGRESS)
# =========================================================================

def download_outstanding_counter(
    session,
    sales_office="0H86",
    date_outstanding=None,
    variant="/////YUSRIL",
    save_dir=None,
    filename=None,
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan /NZVSD_PARTS_PROGRESS, memfilter Document Held,
    mengekspor ke .XLSX via ALV Spreadsheet (&XXL), dan mengekstrak daftar SO & GI.
    """
    _safe_prog(progress_callback, 10, "Membuka transaksi /NZVSD_PARTS_PROGRESS...")
    _safe_log(log_callback, "[COUNTER] Membuka transaksi /NZVSD_PARTS_PROGRESS di SAP...")

    dismiss_popups(session)

    if save_dir is None:
        save_dir = config.get_output_dir("sap")
    if filename is None:
        filename = f"OUTS_COUNTER_{time.strftime('%d%m%Y_%H%M%S')}.XLSX"

    os.makedirs(save_dir, exist_ok=True)
    full_save_path = os.path.join(save_dir, filename)

    # 1. Buka ZVSD_PARTS_PROGRESS
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NZVSD_PARTS_PROGRESS"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)
    dismiss_popups(session)

    # 2. Input Kriteria Seleksi
    _safe_prog(progress_callback, 25, f"Mengisi filter Sales Office {sales_office} & Order Type YSUP...")
    _safe_log(log_callback, f"[COUNTER] Filter: VKORG=0z02, VKBUR={sales_office}, AUART=YSUP, Date={date_outstanding or '-'}")

    try:
        session.findById("wnd[0]/usr/ctxtS_VKORG-LOW").text = "0z02"
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_VKBUR-LOW").text = str(sales_office).strip()
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_AUART-LOW").text = "YSUP"
    except Exception:
        pass

    if date_outstanding:
        try:
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").text = str(date_outstanding).strip()
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").setFocus()
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").caretPosition = len(str(date_outstanding))
        except Exception:
            pass

    # Tekan F2 / Double click opsi bila diperlukan
    try:
        session.findById("wnd[0]").sendVKey(2)
        time.sleep(0.5)
        if session.Children.Count > 1:
            try:
                session.findById("wnd[1]/usr/cntlOPTION_CONTAINER/shellcont/shell").setCurrentCell(1, "TEXT")
                session.findById("wnd[1]/usr/cntlOPTION_CONTAINER/shellcont/shell").selectedRows = "1"
                session.findById("wnd[1]/usr/cntlOPTION_CONTAINER/shellcont/shell").doubleClickCurrentCell()
            except Exception:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception:
        pass

    # 3. Eksekusi Report (F8)
    _safe_prog(progress_callback, 40, "Mengeksekusi report outstanding SAP...")
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    time.sleep(3)

    # Periksa error statusbar
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and getattr(sbar, "messageType", None) in ("E", "A"):
            raise RuntimeError(f"SAP Error: {sbar.text}")
    except RuntimeError:
        raise
    except Exception:
        pass

    # 4. Pilih Variant ALV jika diminta
    if variant:
        _safe_prog(progress_callback, 50, f"Menerapkan Layout ALV Variant: {variant}...")
        try:
            session.findById("wnd[0]/tbar[1]/btn[33]").press()
            time.sleep(1)
            # Filter variant
            session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").selectColumn("VARIANT")
            session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").contextMenu()
            session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").selectContextMenuItem("&FILTER")
            session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = variant
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
            time.sleep(0.5)
            session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").selectedRows = "0"
            session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").doubleClickCurrentCell()
            time.sleep(1)
        except Exception as vex:
            _safe_log(log_callback, f"[COUNTER] Info: Melewati pemilihan variant layout ({vex})")

    # 5. Filter Sales Order Status = 'Document Held'
    _safe_prog(progress_callback, 65, "Menerapkan filter Sales Order Status: Document Held...")
    try:
        session.findById("wnd[0]/tbar[1]/btn[29]").press()
        time.sleep(1)
        try:
            session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/cntlCONTAINER1_FILT/shellcont/shell").pressToolbarButton("&FIND")
            session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "Sales Order Status"
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
            session.findById("wnd[2]/tbar[0]/btn[12]").press()
            session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/btnAPP_WL_SING").press()
            session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/btn600_BUTTON").press()
            session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "Document Held"
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
        except Exception:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(1)
    except Exception as fex:
        _safe_log(log_callback, f"[COUNTER] Info: Melewati filter dialog Document Held ({fex})")

    # 6. EXPORT KE SPREADSHEET (.XLSX) VIA METODE MODERN &XXL
    _safe_prog(progress_callback, 75, "Mengekspor data ke format Excel .XLSX (&XXL)...")
    _safe_log(log_callback, "[COUNTER] Mengekspor data ALV Grid ke file Excel Spreadsheet...")

    found_file = _export_alv_to_spreadsheet(session, save_dir, filename, log_callback)

    # 7. PARSING FILE EXCEL (.XLSX) DI BACKGROUND TANPA BUKA EXCEL
    _safe_prog(progress_callback, 90, "Mengekstrak kolom Sales Order (SO) dan No. GI...")
    extracted_items = parse_counter_excel(found_file, log_callback)

    _safe_prog(progress_callback, 100, f"Tarik Outstanding berhasil! ({len(extracted_items)} SO ditemukan)")
    _safe_log(log_callback, f"[SUCCESS] Total {len(extracted_items)} Sales Order siap diproses.")

    return {
        "output_file": found_file,
        "total_items": len(extracted_items),
        "items": extracted_items
    }


def download_outstanding_cancellation(
    session,
    sales_office="0H86",
    date_outstanding=None,
    variant="/////YUSRIL",
    save_dir=None,
    filename=None,
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan /NZVSD_PARTS_PROGRESS khusus Cancellation:
    - VKORG: 0z02, VKBUR: sales_office, AUART: YSUP
    - Date Outstanding (>= date)
    - Delivery Status: 'Not Completed'
    - Filter ALV: sales order status, layout /YUSRIL, IREQ > 0
    - Ekspor ke .XLSX via ALV Spreadsheet (&XXL) dan ekstrak SO & GI.
    """
    _safe_prog(progress_callback, 10, "Membuka transaksi /NZVSD_PARTS_PROGRESS (Cancellation)...")
    _safe_log(log_callback, "[COUNTER-CANCEL] Membuka /NZVSD_PARTS_PROGRESS di SAP...")

    dismiss_popups(session)

    if save_dir is None:
        save_dir = config.get_output_dir("sap")
    if filename is None:
        filename = f"OUTS_CANCEL_{time.strftime('%d%m%Y_%H%M%S')}.XLSX"

    os.makedirs(save_dir, exist_ok=True)

    # 1. Buka ZVSD_PARTS_PROGRESS
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NZVSD_PARTS_PROGRESS"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)
    dismiss_popups(session)

    # 2. Input Kriteria Seleksi
    _safe_prog(progress_callback, 20, f"Mengisi kriteria: Office={sales_office}, Not Completed, Date>={date_outstanding or '-'}...")
    _safe_log(log_callback, f"[COUNTER-CANCEL] Filter: VKORG=0z02, VKBUR={sales_office}, AUART=YSUP, DELST=Not Completed")

    try:
        session.findById("wnd[0]/usr/ctxtS_VKORG-LOW").text = "0z02"
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_VKBUR-LOW").text = str(sales_office).strip()
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_AUART-LOW").text = "YSUP"
    except Exception:
        pass

    if date_outstanding:
        try:
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").text = str(date_outstanding).strip()
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").setFocus()
            session.findById("wnd[0]/usr/ctxtS_ERDAT-LOW").caretPosition = len(str(date_outstanding))
        except Exception:
            pass

    # Opsi tanggal >= (GE)
    try:
        session.findById("wnd[0]").sendVKey(2)
        time.sleep(0.5)
        if session.Children.Count > 1:
            try:
                session.findById("wnd[1]/usr/cntlOPTION_CONTAINER/shellcont/shell").setCurrentCell(2, "TEXT")
                session.findById("wnd[1]/usr/cntlOPTION_CONTAINER/shellcont/shell").selectedRows = "2"
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
            except Exception:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception:
        pass

    # Delivery status Not Completed
    try:
        session.findById("wnd[0]/usr/cmbP_DELST").Key = "Not Completed"
    except Exception:
        pass

    # 3. Eksekusi F8
    _safe_prog(progress_callback, 35, "Mengeksekusi report /NZVSD_PARTS_PROGRESS...")
    session.findById("wnd[0]").sendVKey(8)
    time.sleep(3)

    # Periksa error statusbar
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and getattr(sbar, "messageType", None) in ("E", "A"):
            raise RuntimeError(f"SAP Error: {sbar.text}")
    except RuntimeError:
        raise
    except Exception:
        pass

    # 4. Filter Sales Order Status
    _safe_prog(progress_callback, 45, "Menerapkan filter Sales Order Status...")
    try:
        session.findById("wnd[0]/tbar[1]/btn[29]").press()
        time.sleep(1)
        session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/cntlCONTAINER1_FILT/shellcont/shell").pressToolbarButton("&FIND")
        session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "sales order status"
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        session.findById("wnd[2]").Close()
        session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/btnAPP_WL_SING").press()
        session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/btn600_BUTTON").press()
        session.findById("wnd[2]").sendVKey(4)
        session.findById("wnd[3]/usr/lbl[1,4]").setFocus()
        session.findById("wnd[3]").sendVKey(2)
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        time.sleep(1)
    except Exception as fex1:
        _safe_log(log_callback, f"[COUNTER-CANCEL] Info filter status dilewati: {fex1}")
        try:
            if session.Children.Count > 1:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
        except Exception:
            pass

    # 5. Pilih Layout / Variant /YUSRIL
    _safe_prog(progress_callback, 55, "Menerapkan layout /YUSRIL...")
    try:
        session.findById("wnd[0]/tbar[1]/btn[33]").press()
        time.sleep(1)
        session.findById("wnd[1]/tbar[0]/btn[38]").press()
        session.findById("wnd[2]/usr/subSUB_DYN0500:SAPLSKBH:0600/cntlCONTAINER1_FILT/shellcont/shell").pressToolbarButton("&FIND")
        session.findById("wnd[3]/usr/txtGS_SEARCH-VALUE").text = "LAYOUT"
        session.findById("wnd[3]/tbar[0]/btn[0]").press()
        session.findById("wnd[3]").Close()
        session.findById("wnd[2]/usr/subSUB_DYN0500:SAPLSKBH:0600/btnAPP_WL_SING").press()
        session.findById("wnd[2]/usr/subSUB_DYN0500:SAPLSKBH:0600/btn600_BUTTON").press()
        session.findById("wnd[3]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "/YUSRIL"
        session.findById("wnd[3]/tbar[0]/btn[0]").press()
        session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").selectedRows = "0"
        session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").clickCurrentCell()
        time.sleep(1)
    except Exception as vex:
        _safe_log(log_callback, f"[COUNTER-CANCEL] Info layout dilewati: {vex}")
        try:
            while session.Children.Count > 1:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
        except Exception:
            pass

    # 6. Filter IREQ > 0
    _safe_prog(progress_callback, 65, "Menerapkan filter IREQ > 0...")
    try:
        session.findById("wnd[0]/tbar[1]/btn[29]").press()
        time.sleep(1)
        session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/cntlCONTAINER1_FILT/shellcont/shell").pressToolbarButton("&FIND")
        session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "IREQ"
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        session.findById("wnd[2]").Close()
        session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/btnAPP_WL_SING").press()
        session.findById("wnd[1]/usr/subSUB_DYN0500:SAPLSKBH:0600/btn600_BUTTON").press()
        session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = "0"
        session.findById("wnd[2]/tbar[0]/btn[2]").press()
        session.findById("wnd[3]/usr/cntlOPTION_CONTAINER/shellcont/shell").setCurrentCell(4, "TEXT")
        session.findById("wnd[3]/usr/cntlOPTION_CONTAINER/shellcont/shell").selectedRows = "4"
        session.findById("wnd[3]/usr/cntlOPTION_CONTAINER/shellcont/shell").doubleClickCurrentCell()
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        time.sleep(1)
    except Exception as iex:
        _safe_log(log_callback, f"[COUNTER-CANCEL] Info filter IREQ dilewati: {iex}")
        try:
            while session.Children.Count > 1:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
        except Exception:
            pass

    # 7. Ekspor Spreadsheet &XXL
    _safe_prog(progress_callback, 75, "Mengekspor data ke Excel .XLSX via ALV Spreadsheet (&XXL)...")
    _safe_log(log_callback, "[COUNTER-CANCEL] Ekspor ALV Grid ke file .XLSX...")

    found_file = _export_alv_to_spreadsheet(session, save_dir, filename, log_callback)

    # 8. Parsing File Excel
    _safe_prog(progress_callback, 90, "Mengekstrak kolom Sales Order (SO) dan No. GI...")
    extracted_items = parse_counter_excel(found_file, log_callback)

    _safe_prog(progress_callback, 100, f"Tarik Outstanding Cancel berhasil! ({len(extracted_items)} SO ditemukan)")
    _safe_log(log_callback, f"[SUCCESS] Total {len(extracted_items)} Sales Order siap dibatalkan.")

    return {
        "output_file": found_file,
        "total_items": len(extracted_items),
        "items": extracted_items
    }


def parse_counter_excel(file_path, log_callback=None):
    """
    Membaca berkas Excel hasil ekspor ZVSD_PARTS_PROGRESS,
    mendeteksi kolom SO dan GI secara cerdas, membuang duplikat, dan mengembalikan list item.
    """
    items = []
    if not os.path.exists(file_path):
        return items

    try:
        df = pd.read_excel(file_path, dtype=str)
    except Exception:
        try:
            df = pd.read_excel(file_path, engine='calamine', dtype=str)
        except Exception:
            df = pd.read_excel(file_path, engine='openpyxl', dtype=str)

    if df.empty:
        return items

    # Cari baris header jika baris 1-8 berisi teks kop laporan
    so_col_idx = None
    gi_col_idx = None

    # Cara A: Periksa nama kolom dataframe
    for i, col in enumerate(df.columns):
        col_str = str(col).strip().upper()
        if any(k in col_str for k in ["SALES DOC", "SALES DOCUMENT", "VBELN", "NO SO", "SO NUMBER", "ORDER"]):
            if so_col_idx is None:
                so_col_idx = i
        elif any(k in col_str for k in ["GOODS ISSUE", "GI NUMBER", "NO GI", "REF", "REFERENCE", "KETERANGAN"]):
            if gi_col_idx is None:
                gi_col_idx = i

    # Cara B: Jika header belum ketemu, scan 15 baris pertama untuk mencari baris header
    start_row = 0
    if so_col_idx is None:
        for r_idx in range(min(15, len(df))):
            row_vals = [str(x).strip().upper() for x in df.iloc[r_idx]]
            for c_idx, val in enumerate(row_vals):
                if any(k in val for k in ["SALES DOC", "SALES DOCUMENT", "VBELN", "NO SO", "ORDER"]):
                    so_col_idx = c_idx
                elif any(k in val for k in ["GOODS ISSUE", "GI NUMBER", "NO GI", "REF"]):
                    gi_col_idx = c_idx
            if so_col_idx is not None:
                start_row = r_idx + 1
                break

    # Cara C: Fallback posisi standar (seperti macro lama: kolom C dan D / index 2 dan 3)
    if so_col_idx is None:
        if df.shape[1] >= 4:
            so_col_idx = 2
            gi_col_idx = 3
        elif df.shape[1] >= 2:
            so_col_idx = 0
            gi_col_idx = 1
        else:
            so_col_idx = 0
            gi_col_idx = None

    # Ekstraksi dan pembersihan data
    seen_sos = set()
    for idx in range(start_row, len(df)):
        raw_so = str(df.iloc[idx, so_col_idx] if so_col_idx is not None else "").strip()
        # Bersihkan format float jika ada (misal '2340123456.0')
        if raw_so.endswith(".0"):
            raw_so = raw_so[:-2]

        # Validasi format SO (hanya angka / panjang minimal 5)
        clean_so = re.sub(r'[^0-9]', '', raw_so)
        if not clean_so or clean_so in seen_sos or clean_so in ('0', 'NAN', 'NONE'):
            continue

        raw_gi = ""
        if gi_col_idx is not None and gi_col_idx < df.shape[1]:
            raw_gi = str(df.iloc[idx, gi_col_idx]).strip()
            if raw_gi.endswith(".0"):
                raw_gi = raw_gi[:-2]
            if raw_gi.upper() in ('NAN', 'NONE'):
                raw_gi = ""

        seen_sos.add(clean_so)
        items.append({
            "so": clean_so,
            "gi": raw_gi,
            "status": "Siap",
            "message": "-"
        })

    return items


# =========================================================================
# 2. PROCESS SO (/NVA02)
# =========================================================================

def execute_process_counter_so(
    session,
    items,
    po_number,
    nbd_date,
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan /NVA02 untuk setiap Sales Order di dalam list items:
    - Isi PO Number (VBKD-BSTKD)
    - Isi Order Reason (VBAK-AUGRU) = 'ZIN'
    - Header Extra: ZZSERNRH = '-', ZZNBDT = nbd_date
    - Header Status: radio button active (radJ_STMAINT-ANWS[0,1])
    - Header Text Y002: 'No. GI ' + GI Number
    - Simpan SO (VKey 11)
    """
    if not items:
        raise ValueError("Daftar Sales Order (SO) kosong!")

    total = len(items)
    success_count = 0
    fail_count = 0

    _safe_log(log_callback, f"[COUNTER] Memulai pemrosesan {total} Sales Order via /NVA02...")
    _safe_prog(progress_callback, 5, f"Membuka transaksi /NVA02 ({total} item)...")

    # Pastikan di menu utama
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA02"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1)
    dismiss_popups(session)

    for i, itm in enumerate(items):
        so_num = str(itm.get("so", "")).strip()
        gi_num = str(itm.get("gi", "")).strip()
        pct = 5 + int(((i + 1) / total) * 85)

        _safe_prog(progress_callback, pct, f"[{i+1}/{total}] Memproses SO: {so_num}...")
        _safe_log(log_callback, f"[SO {i+1}/{total}] Memproses Sales Order: {so_num} (GI: {gi_num or '-'})")

        try:
            # 1. Buka SO
            session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA02"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            session.findById("wnd[0]/usr/ctxtVBAK-VBELN").text = so_num
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            # Cek modal error jika SO terkunci
            if session.Children.Count > 1:
                top_wnd = session.Children(session.Children.Count - 1)
                top_wnd.sendVKey(0)
                time.sleep(0.5)

            # 2. Isi PO Number
            if po_number:
                try:
                    session.findById("wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/txtVBKD-BSTKD").text = str(po_number).strip()
                    session.findById("wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/txtVBKD-BSTKD").setFocus()
                    session.findById("wnd[0]").sendVKey(0)
                    session.findById("wnd[0]").sendVKey(0)
                except Exception:
                    pass

            # 3. Isi Order Reason = ZIN
            try:
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/ssubHEADER_FRAME:SAPMV45A:4440/cmbVBAK-AUGRU").Key = "ZIN"
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/ssubHEADER_FRAME:SAPMV45A:4440/cmbVBAK-AUGRU").setFocus()
                session.findById("wnd[0]").sendVKey(0)
            except Exception:
                pass

            # 4. Header Extra (Header Details btn[26])
            try:
                session.findById("wnd[0]/tbar[1]/btn[26]").press()
                time.sleep(0.5)
                # Serial & NBD
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\12/ssubSUBSCREEN_BODY:SAPMV45A:4312/sub8309:SAPMV45A:8309/ctxtVBAK-ZZSERNRH").text = "-"
                if nbd_date:
                    session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\12/ssubSUBSCREEN_BODY:SAPMV45A:4312/sub8309:SAPMV45A:8309/ctxtVBAK-ZZNBDT").text = str(nbd_date).strip()
                session.findById("wnd[0]").sendVKey(0)
            except Exception:
                pass

            # 5. Header Status KSTC (tabpT\10)
            try:
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\10").select()
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\10/ssubSUBSCREEN_BODY:SAPMV45A:4305/btnBT_KSTC").press()
                time.sleep(0.5)
                session.findById("wnd[0]/usr/tabsTABSTRIP_0300/tabpANWS/ssubSUBSCREEN:SAPLBSVA:0302/tblSAPLBSVATC_E/radJ_STMAINT-ANWS[0,1]").selected = True
                session.findById("wnd[0]/tbar[0]/btn[3]").press()
            except Exception:
                pass

            # 6. Header Text Y002 (tabpT\08)
            try:
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\08").select()
                shell_text = session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\08/ssubSUBSCREEN_BODY:SAPMV45A:4152/subSUBSCREEN_TEXT:SAPLV70T:2100/cntlSPLITTER_CONTAINER/shellcont/shellcont/shell/shellcont[0]/shell")
                shell_text.selectItem("Y002", "Column1")
                shell_text.doubleClickItem("Y002", "Column1")
                time.sleep(0.5)
                text_editor = session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\08/ssubSUBSCREEN_BODY:SAPMV45A:4152/subSUBSCREEN_TEXT:SAPLV70T:2100/cntlSPLITTER_CONTAINER/shellcont/shellcont/shell/shellcont[1]/shell")
                text_editor.text = f"No. GI {gi_num}"
            except Exception:
                pass

            # 7. Simpan (Save F11 / btn[11])
            session.findById("wnd[0]").sendVKey(11)
            time.sleep(1)

            # Tunggu session busy
            while session.Busy:
                time.sleep(0.2)

            # Pop up konfirmasi save jika muncul
            if session.Children.Count > 1:
                try:
                    session.Children(session.Children.Count - 1).sendVKey(0)
                except Exception:
                    pass

            itm["status"] = "Sukses"
            itm["message"] = "Berhasil disimpan"
            success_count += 1
            _safe_log(log_callback, f"  [OK] SO {so_num} berhasil di-update & disimpan.")

        except Exception as so_err:
            fail_count += 1
            itm["status"] = "Gagal"
            itm["message"] = str(so_err)
            _safe_log(log_callback, f"  [ERROR] SO {so_num} gagal diproses: {so_err}")
            dismiss_popups(session)

    _safe_prog(progress_callback, 100, f"Process SO selesai ({success_count} sukses, {fail_count} gagal)")
    _safe_log(log_callback, f"[COUNTER] Selesai: {success_count} SO sukses, {fail_count} gagal.")

    return {
        "total": total,
        "success_count": success_count,
        "fail_count": fail_count,
        "items": items
    }


# =========================================================================
# 2B. PROCESS CANCELLATION SO (/NVA02 - REASON Y3)
# =========================================================================

def execute_process_cancellation_so(
    session,
    items,
    rejection_reason="Y3",
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan proses pembatalan Sales Order via /NVA02:
    - Masuk /NVA02
    - Isi nomor SO
    - Select All Items (btnBT_MKAL)
    - Menu Edit -> Fast change of... -> Reason for rejection
    - Set Reason = rejection_reason (default: 'Y3')
    - Simpan SO (Ctrl+S / VKey 11)
    - Update status baris tabel menjadi 'Cancelled (Y3)'
    """
    if not items:
        raise ValueError("Daftar Sales Order (SO) kosong!")

    total = len(items)
    success_count = 0
    fail_count = 0

    _safe_log(log_callback, f"[COUNTER-CANCEL] Memulai pembatalan {total} Sales Order via /NVA02 (Reason {rejection_reason})...")
    _safe_prog(progress_callback, 5, f"Membuka transaksi /NVA02 ({total} item)...")

    # Pastikan di menu utama
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA02"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1)
    dismiss_popups(session)

    for i, itm in enumerate(items):
        so_num = str(itm.get("so", "")).strip()
        pct = 5 + int(((i + 1) / total) * 85)

        _safe_prog(progress_callback, pct, f"[{i+1}/{total}] Membatalkan SO: {so_num} (Reason {rejection_reason})...")
        _safe_log(log_callback, f"[CANCEL {i+1}/{total}] Membatalkan Sales Order: {so_num}")

        try:
            # 1. Buka SO
            session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA02"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            session.findById("wnd[0]/usr/ctxtVBAK-VBELN").text = so_num
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            # Cek modal error jika SO terkunci
            if session.Children.Count > 1:
                top_wnd = session.Children(session.Children.Count - 1)
                top_wnd.sendVKey(0)
                time.sleep(0.5)

            # 2. Select All Items
            try:
                session.findById("wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/subSUBSCREEN_BUTTONS:SAPMV45A:4050/btnBT_MKAL").press()
            except Exception:
                pass

            # 3. Menu Bar: Edit -> Fast change of... -> Reason for rejection
            session.findById("wnd[0]/mbar/menu[1]/menu[1]/menu[0]").select()
            time.sleep(0.5)

            # 4. Set Reason for rejection
            session.findById("wnd[1]/usr/cmbRV45A-S_ABGRU").Key = str(rejection_reason).strip()
            session.findById("wnd[1]/tbar[0]/btn[7]").press()
            time.sleep(0.5)

            # 5. Dismiss any warnings/popups (wnd[2], wnd[3])
            while session.Children.Count > 2:
                try:
                    top_wnd = session.Children(session.Children.Count - 1)
                    top_wnd.findById("tbar[0]/btn[0]").press()
                except Exception:
                    break

            # 6. Save (Ctrl+S / VKey 11)
            session.findById("wnd[0]").sendVKey(11)
            time.sleep(0.5)

            # Tunggu session busy
            while session.Busy:
                time.sleep(0.2)

            # Tangani status bar dan incomplete log jika ada
            try:
                sbar = session.findById("wnd[0]/sbar")
                status_msg = sbar.text if sbar else ""
            except Exception:
                status_msg = ""

            if status_msg:
                try:
                    session.findById("wnd[0]").sendVKey(0)
                    if session.Children.Count > 1:
                        session.findById("wnd[1]/usr/btnSPOP-VAROPTION1").press()
                except Exception:
                    pass

            itm["status"] = f"Cancelled ({rejection_reason})"
            itm["message"] = f"Reason {rejection_reason} berhasil diterapkan"
            success_count += 1
            _safe_log(log_callback, f"  [OK] SO {so_num} berhasil dibatalkan (Reason {rejection_reason}).")

        except Exception as cancel_err:
            fail_count += 1
            itm["status"] = "Gagal"
            itm["message"] = str(cancel_err)
            _safe_log(log_callback, f"  [ERROR] SO {so_num} gagal dibatalkan: {cancel_err}")
            dismiss_popups(session)

    _safe_prog(progress_callback, 100, f"Process Cancellation selesai ({success_count} berhasil, {fail_count} gagal)")
    _safe_log(log_callback, f"[COUNTER-CANCEL] Selesai: {success_count} SO berhasil dibatalkan, {fail_count} gagal.")

    return {
        "total": total,
        "success_count": success_count,
        "fail_count": fail_count,
        "items": items
    }


# =========================================================================
# 3. CREATE DELIVERY (/NVL10C)
# =========================================================================

def execute_create_delivery(
    session,
    plant="1346",
    sloc="dmdv",
    so_start="2340000000",
    so_end="2349999999",
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan transaksi /NVL10C untuk membuat Outbound Delivery di background.
    """
    _safe_prog(progress_callback, 15, "Membuka transaksi /NVL10C (Delivery Creation)...")
    _safe_log(log_callback, f"[COUNTER] Membuka /NVL10C: Plant={plant}, Sloc={sloc}, Range SO={so_start}-{so_end}")

    dismiss_popups(session)

    session.findById("wnd[0]/tbar[0]/okcd").text = "/NVL10C"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)
    dismiss_popups(session)

    # Kosongkan delivery date
    try:
        session.findById("wnd[0]/usr/ctxtST_LEDAT-LOW").text = ""
        session.findById("wnd[0]/usr/ctxtST_LEDAT-HIGH").text = ""
    except Exception:
        pass

    # Tab Order Criteria 2: Range SO
    _safe_prog(progress_callback, 35, "Mengisi kriteria rentang Sales Order...")
    try:
        session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB2").select()
        session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB2/ssub%_SUBSCREEN_ORDER_CRITERIA:RVV50R10C:1020/ctxtST_VBELN-LOW").text = str(so_start).strip()
        session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB2/ssub%_SUBSCREEN_ORDER_CRITERIA:RVV50R10C:1020/ctxtST_VBELN-HIGH").text = str(so_end).strip()
    except Exception as ex:
        _safe_log(log_callback, f"[COUNTER] Peringatan rentang SO: {ex}")

    # Tab Order Criteria 3: Plant & Sloc
    _safe_prog(progress_callback, 55, f"Mengisi Plant {plant} & Sloc {sloc}...")
    try:
        session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB3").select()
        session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB3/ssub%_SUBSCREEN_ORDER_CRITERIA:RVV50R10C:1040/ctxtST_WERKS-LOW").text = str(plant).strip()
        session.findById("wnd[0]/usr/tabsTABSTRIP_ORDER_CRITERIA/tabpS0S_TAB3/ssub%_SUBSCREEN_ORDER_CRITERIA:RVV50R10C:1040/ctxtST_LGORT-LOW").text = str(sloc).strip()
    except Exception as ex:
        _safe_log(log_callback, f"[COUNTER] Peringatan Plant/Sloc: {ex}")

    # Eksekusi (btn[8] / F8)
    _safe_prog(progress_callback, 75, "Mengeksekusi pembuatan Delivery di background...")
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    time.sleep(2)

    # Select All (btn[5]) & Background Delivery (btn[19])
    try:
        session.findById("wnd[0]/tbar[1]/btn[5]").press()
        time.sleep(0.5)
        session.findById("wnd[0]/tbar[1]/btn[19]").press()
        time.sleep(2)
    except Exception as ex:
        _safe_log(log_callback, f"[COUNTER] Info: Tidak ada item delivery yang perlu diproses ({ex})")

    # Tutup jendela dan konfirmasi
    try:
        session.findById("wnd[0]").close()
        if session.Children.Count > 1:
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
    except Exception:
        pass

    _safe_prog(progress_callback, 100, "Pembuatan Delivery (/NVL10C) selesai.")
    _safe_log(log_callback, "[COUNTER] Proses /NVL10C telah selesai.")
    return True


# =========================================================================
# 4. MONITOR DELIVERY, PICKING & GOODS ISSUE (/NVL06O)
# =========================================================================

def execute_picking_and_gi(
    session,
    so_list,
    date_so,
    plant="1346",
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan /NVL06O untuk:
    1. Monitor Outbound Delivery dan menyalin nomor delivery dari SO list
    2. Eksekusi Picking (Create Transfer Order, adopt pick qty = 1)
    3. Eksekusi Post Goods Issue (adopt qty = 2)
    """
    if not so_list:
        raise ValueError("Daftar nomor SO kosong!")

    _safe_prog(progress_callback, 10, f"Menyalin {len(so_list)} nomor SO ke clipboard...")
    _safe_log(log_callback, f"[COUNTER] Memulai alur Picking & GI untuk {len(so_list)} SO...")
    sh.copy_orders_to_clipboard(so_list)

    dismiss_popups(session)

    # 1. Buka VL06O
    _safe_prog(progress_callback, 20, "Membuka transaksi /NVL06O (Outbound Delivery Monitor)...")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NVL06O"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.5)
    dismiss_popups(session)

    # Tombol 6: List Outbound Deliveries
    session.findById("wnd[0]/usr/btnBUTTON6").press()
    time.sleep(1)

    try:
        session.findById("wnd[0]/usr/ctxtIF_VSTEL-LOW").text = str(plant).strip()
        session.findById("wnd[0]/usr/ctxtIT_WADAT-LOW").text = ""
        session.findById("wnd[0]/usr/ctxtIT_WADAT-HIGH").text = ""
        if date_so:
            session.findById("wnd[0]/usr/ctxtIT_ERDAT-LOW").text = str(date_so).strip()
    except Exception:
        pass

    # Filter Purchasing Document / Sales Order dari Clipboard
    _safe_prog(progress_callback, 35, "Memfilter nomor SO di Delivery Monitor...")
    try:
        session.findById("wnd[0]/tbar[1]/btn[18]").press()
        time.sleep(0.5)
        session.findById("wnd[0]/tbar[1]/btn[29]").press()
        time.sleep(0.5)
        session.findById("wnd[1]/usr/btnB_SEARCH").press()
        session.findById("wnd[2]/usr/txtGD_SEARCHSTR").text = "Purchasing Document"
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        session.findById("wnd[1]/usr/btnAPP_WL_SING").press()
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        session.findById("wnd[1]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/btn%_%%DYN001_%_APP_%-VALU_PUSH").press()
        session.findById("wnd[2]/tbar[0]/btn[24]").press() # Paste dari clipboard
        session.findById("wnd[2]/tbar[0]/btn[8]").press()
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception as ex:
        _safe_log(log_callback, f"[COUNTER] Info filter SO: {ex}")

    # Eksekusi (F8)
    _safe_prog(progress_callback, 50, "Mengekstrak daftar Delivery Number...")
    try:
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        time.sleep(2)
    except Exception:
        pass

    # Ekspor Delivery list ke file temporary
    temp_dir = config.get_output_dir("sap")
    os.makedirs(temp_dir, exist_ok=True)
    temp_check = os.path.join(temp_dir, f"check_dlv_{time.strftime('%H%M%S')}.xlsx")

    delivery_numbers = []
    try:
        session.findById("wnd[0]/tbar[1]/btn[45]").press()
        time.sleep(1)
        session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").select()
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = temp_dir
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = os.path.basename(temp_check)
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(2)
    except Exception:
        pass

    # Ambil nomor delivery dari ALV grid di layar jika ekspor gagal
    try:
        grid = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell/shellcont[1]/shell")
        row_cnt = getattr(grid, "RowCount", 0)
        for r in range(row_cnt):
            dlv_val = str(grid.getCellValue(r, "VBELN")).strip()
            if dlv_val and dlv_val not in delivery_numbers:
                delivery_numbers.append(dlv_val)
    except Exception:
        pass

    _safe_log(log_callback, f"[COUNTER] Terdeteksi {len(delivery_numbers)} Outbound Delivery.")

    # 2. PROSES PICKING (/NVL06O -> BUTTON 1)
    _safe_prog(progress_callback, 65, "Menjalankan proses Picking (Transfer Order)...")
    _safe_log(log_callback, "[COUNTER] Menjalankan Picking (/NVL06O -> Button 1)...")
    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/NVL06O"
        session.findById("wnd[0]").sendVKey(0)
        time.sleep(1)

        session.findById("wnd[0]/usr/btnBUTTON1").press() # Button Picking
        time.sleep(1)
        session.findById("wnd[0]/usr/ctxtIF_VSTEL-LOW").text = str(plant).strip()
        session.findById("wnd[0]/usr/ctxtIT_KODAT-LOW").text = ""
        session.findById("wnd[0]/usr/ctxtIT_KODAT-HIGH").text = ""
        session.findById("wnd[0]/tbar[1]/btn[19]").press()

        # Paste nomor delivery jika ada
        if delivery_numbers:
            sh.copy_orders_to_clipboard(delivery_numbers)
            session.findById("wnd[0]/usr/btn%_IT_VBELN_%_APP_%-VALU_PUSH").press()
            session.findById("wnd[1]/tbar[0]/btn[24]").press()
            session.findById("wnd[1]/tbar[0]/btn[8]").press()

        session.findById("wnd[0]/tbar[1]/btn[8]").press() # F8
        time.sleep(1.5)
        session.findById("wnd[0]/tbar[1]/btn[5]").press() # Select All
        session.findById("wnd[0]/tbar[1]/btn[7]").press() # Subsequent functions (TO)
        time.sleep(1)
        session.findById("wnd[1]/usr/ctxtRL03T-KOMIM").text = "1" # Adopt pick qty
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(2)
        _safe_log(log_callback, "  [OK] Picking Transfer Order berhasil dijalankan.")
    except Exception as pick_ex:
        _safe_log(log_callback, f"  [INFO] Picking dilewati atau selesai: {pick_ex}")

    # 3. PROSES GOODS ISSUE (/NVL06O -> BUTTON 3)
    _safe_prog(progress_callback, 85, "Menjalankan proses Post Goods Issue (GI)...")
    _safe_log(log_callback, "[COUNTER] Menjalankan Post Goods Issue (/NVL06O -> Button 3)...")
    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/NVL06O"
        session.findById("wnd[0]").sendVKey(0)
        time.sleep(1)

        session.findById("wnd[0]/usr/btnBUTTON3").press() # Button GI
        time.sleep(1)
        session.findById("wnd[0]/usr/ctxtIF_VSTEL-LOW").text = str(plant).strip()
        session.findById("wnd[0]/usr/ctxtIT_WADAT-LOW").text = ""
        session.findById("wnd[0]/usr/ctxtIT_WADAT-HIGH").text = ""
        session.findById("wnd[0]/tbar[1]/btn[19]").press()

        # Paste nomor delivery
        if delivery_numbers:
            sh.copy_orders_to_clipboard(delivery_numbers)
            session.findById("wnd[0]/usr/btn%_IT_VBELN_%_APP_%-VALU_PUSH").press()
            session.findById("wnd[1]/tbar[0]/btn[24]").press()
            session.findById("wnd[1]/tbar[0]/btn[8]").press()

        session.findById("wnd[0]/tbar[1]/btn[8]").press() # F8
        time.sleep(1.5)
        session.findById("wnd[0]/tbar[1]/btn[5]").press() # Select All
        session.findById("wnd[0]/tbar[1]/btn[7]").press() # Post GI
        time.sleep(1)
        session.findById("wnd[1]/usr/ctxtRL03T-KOMIM").text = "2"
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(2)
        _safe_log(log_callback, "  [OK] Post Goods Issue (GI) berhasil dijalankan.")
    except Exception as gi_ex:
        _safe_log(log_callback, f"  [INFO] Goods Issue dilewati atau selesai: {gi_ex}")

    _safe_prog(progress_callback, 100, "Proses Picking & Goods Issue selesai.")
    _safe_log(log_callback, "[COUNTER] Seluruh alur Picking & Goods Issue selesai.")
    return True


# =========================================================================
# 5. RUN ALL END-TO-END
# =========================================================================

def execute_run_all_counter(
    session,
    items,
    po_number,
    nbd_date,
    date_so,
    plant="1346",
    sloc="dmdv",
    log_callback=None,
    progress_callback=None
):
    """
    Eksekusi alur penuh Process SO -> Create Delivery -> Picking -> Goods Issue
    """
    _safe_log(log_callback, "==================================================")
    _safe_log(log_callback, "[COUNTER] MEMULAI ALUR RUN ALL (PROCESS + GI)")
    _safe_log(log_callback, "==================================================")

    # 1. Process SO
    res_so = execute_process_counter_so(
        session=session,
        items=items,
        po_number=po_number,
        nbd_date=nbd_date,
        log_callback=log_callback,
        progress_callback=lambda p, m: _safe_prog(progress_callback, int(p * 0.5), m)
    )

    # 2. Create Delivery
    execute_create_delivery(
        session=session,
        plant=plant,
        sloc=sloc,
        log_callback=log_callback,
        progress_callback=lambda p, m: _safe_prog(progress_callback, 50 + int(p * 0.2), m)
    )

    # 3. Picking & GI
    so_list = [itm["so"] for itm in items if itm.get("status") == "Sukses" or itm.get("so")]
    if so_list:
        execute_picking_and_gi(
            session=session,
            so_list=so_list,
            date_so=date_so,
            plant=plant,
            log_callback=log_callback,
            progress_callback=lambda p, m: _safe_prog(progress_callback, 70 + int(p * 0.3), m)
        )

    _safe_prog(progress_callback, 100, f"RUN ALL COUNTER SELESAI ({res_so['success_count']} sukses)")
    _safe_log(log_callback, "[COUNTER] Alur RUN ALL selesai diproses.")

    return res_so


# =========================================================================
# 6. CHANGE PO ONLY (/NVA02)
# =========================================================================

def execute_change_po_only(
    session,
    items,
    po_number,
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan /NVA02 khusus update nomor PO Customer (VBKD-BSTKD)
    tanpa merubah data delivery, NBD, reason, ataupun text Y002.
    """
    if not items:
        raise ValueError("Daftar Sales Order (SO) kosong!")
    if not po_number or not str(po_number).strip():
        raise ValueError("Nomor PO Customer tidak boleh kosong!")

    total = len(items)
    success_count = 0
    fail_count = 0
    clean_po = str(po_number).strip()

    _safe_log(log_callback, f"[CHANGE-PO] Memulai update PO '{clean_po}' untuk {total} Sales Order via /NVA02...")
    _safe_prog(progress_callback, 5, f"Membuka transaksi /NVA02 ({total} SO)...")

    # Pastikan di menu utama
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA02"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1)
    dismiss_popups(session)

    for i, itm in enumerate(items):
        so_num = str(itm.get("so", "")).strip()
        pct = 5 + int(((i + 1) / total) * 85)

        _safe_prog(progress_callback, pct, f"[{i+1}/{total}] Mengubah PO SO: {so_num}...")
        _safe_log(log_callback, f"[CHANGE-PO {i+1}/{total}] Memproses SO: {so_num}")

        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = "/NVA02"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            session.findById("wnd[0]/usr/ctxtVBAK-VBELN").text = so_num
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(0.5)

            if session.Children.Count > 1:
                top_wnd = session.Children(session.Children.Count - 1)
                top_wnd.sendVKey(0)
                time.sleep(0.5)

            # Update PO Customer
            session.findById("wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/txtVBKD-BSTKD").text = clean_po
            session.findById("wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/txtVBKD-BSTKD").setFocus()
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]").sendVKey(0)

            # Save (Ctrl+S / VKey 11)
            session.findById("wnd[0]").sendVKey(11)
            time.sleep(0.5)

            while session.Busy:
                time.sleep(0.2)

            t_code = getattr(getattr(session, "Info", None), "Transaction", "")
            screen_num = getattr(getattr(session, "Info", None), "ScreenNumber", "")
            if t_code == "VA02" and str(screen_num) == "102":
                pass
            else:
                try:
                    session.findById("wnd[0]").sendVKey(0)
                except Exception:
                    pass

            itm["status"] = "PO Updated"
            itm["message"] = f"PO diubah ke '{clean_po}'"
            success_count += 1
            _safe_log(log_callback, f"  [OK] SO {so_num} berhasil di-update PO.")

        except Exception as ex:
            fail_count += 1
            itm["status"] = "Gagal"
            itm["message"] = str(ex)
            _safe_log(log_callback, f"  [ERROR] SO {so_num} gagal: {ex}")
            dismiss_popups(session)

    _safe_prog(progress_callback, 100, f"Change PO selesai ({success_count} sukses, {fail_count} gagal)")
    _safe_log(log_callback, f"[CHANGE-PO] Selesai: {success_count} sukses, {fail_count} gagal.")

    return {
        "total": total,
        "success_count": success_count,
        "fail_count": fail_count,
        "items": items
    }


# =========================================================================
# 7. REPLACE PART NUMBER (/NZMIM_RPAVAIL) - ANTI-BLEED BUG FIXED
# =========================================================================

def execute_replace_part_number(
    session,
    part_items,
    plant="1346",
    log_callback=None,
    progress_callback=None
):
    """
    Mengecek part availability & part pengganti di transaksi /NZMIM_RPAVAIL.
    Memperbaiki bug klasik VBA di mana hasil part pertama bocor ke part berikutnya jika part berikutnya tidak memiliki replacement.
    """
    if not part_items:
        raise ValueError("Daftar Part Number kosong!")

    total = len(part_items)
    found_count = 0
    not_found_count = 0

    _safe_log(log_callback, f"[REPLACE-PN] Memulai pengecekan {total} Part Number di Plant {plant} via /NZMIM_RPAVAIL...")
    _safe_prog(progress_callback, 5, f"Membuka transaksi /NZMIM_RPAVAIL ({total} item)...")

    # Buka transaksi
    session.findById("wnd[0]/tbar[0]/okcd").text = "/NZMIM_RPAVAIL"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(1)
    dismiss_popups(session)

    for i, itm in enumerate(part_items):
        orig_pn = str(itm.get("original_pn", "")).strip()
        pct = 5 + int(((i + 1) / total) * 85)

        # RESET VARIABEL SETIAP ITERASI (ANTI-BLEED BUG FIX)
        replace_pn = "-"
        status = "Tidak Ada Pengganti"
        message = "Tidak ada part pengganti"

        _safe_prog(progress_callback, pct, f"[{i+1}/{total}] Mengecek PN: {orig_pn}...")
        _safe_log(log_callback, f"[PN {i+1}/{total}] Mengecek Part Number: {orig_pn}")

        try:
            # Pastikan di selection screen
            session.findById("wnd[0]/usr/ctxtP_PARTNO").text = orig_pn
            session.findById("wnd[0]/usr/ctxtP_PLANT").text = str(plant).strip()
            session.findById("wnd[0]/tbar[1]/btn[8]").press() # F8 Execute
            time.sleep(1)

            # Cek statusbar jika material invalid
            try:
                sbar = session.findById("wnd[0]/sbar")
                if sbar and getattr(sbar, "messageType", None) in ("E", "A"):
                    status = "Error"
                    message = sbar.text or "Material tidak valid"
                    _safe_log(log_callback, f"  [ERROR] {orig_pn}: {message}")
                    try:
                        session.findById("wnd[0]/tbar[0]/btn[3]").press()
                    except Exception:
                        pass
                    itm["replace_pn"] = "-"
                    itm["status"] = status
                    itm["message"] = message
                    not_found_count += 1
                    continue
            except Exception:
                pass

            # Tekan tombol Replacement/Succession (btn[18])
            popup_opened = False
            try:
                session.findById("wnd[0]/tbar[1]/btn[18]").press()
                time.sleep(0.8)
                if session.Children.Count > 1:
                    popup_opened = True
            except Exception:
                pass

            if popup_opened:
                try:
                    grid = session.findById("wnd[1]/usr/cntlCONT_ALV_POPUP/shellcont/shell")
                    row_count = getattr(grid, "RowCount", 0)
                    if row_count > 0:
                        succ_val = grid.GetCellValue(0, "SUCC_PART")
                        if succ_val and str(succ_val).strip():
                            replace_pn = str(succ_val).strip()
                            status = "Ditemukan"
                            message = f"Replace PN: {replace_pn}"
                            found_count += 1
                            _safe_log(log_callback, f"  [FOUND] {orig_pn} -> {replace_pn}")
                        else:
                            not_found_count += 1
                            _safe_log(log_callback, f"  [INFO] {orig_pn}: Kolom SUCC_PART kosong.")
                    else:
                        not_found_count += 1
                        _safe_log(log_callback, f"  [INFO] {orig_pn}: Popup tidak memiliki baris pengganti.")
                except Exception as g_err:
                    not_found_count += 1
                    _safe_log(log_callback, f"  [INFO] {orig_pn}: Tidak dapat membaca popup: {g_err}")
                finally:
                    # Tutup popup modal
                    try:
                        session.findById("wnd[1]").Close()
                        time.sleep(0.3)
                    except Exception:
                        pass
            else:
                not_found_count += 1
                _safe_log(log_callback, f"  [INFO] {orig_pn}: Tidak ada part pengganti (btn[18] tidak membuka popup).")

            # Kembali ke selection screen (/NZMIM_RPAVAIL)
            try:
                session.findById("wnd[0]/tbar[0]/btn[3]").press() # F3 Back
                time.sleep(0.5)
            except Exception:
                session.findById("wnd[0]/tbar[0]/okcd").text = "/NZMIM_RPAVAIL"
                session.findById("wnd[0]").sendVKey(0)
                time.sleep(0.5)

            itm["replace_pn"] = replace_pn
            itm["status"] = status
            itm["message"] = message

        except Exception as pn_err:
            not_found_count += 1
            itm["replace_pn"] = "-"
            itm["status"] = "Gagal"
            itm["message"] = str(pn_err)
            _safe_log(log_callback, f"  [FAIL] {orig_pn} error: {pn_err}")
            # Reset ke screen awal jika error
            try:
                session.findById("wnd[0]/tbar[0]/okcd").text = "/NZMIM_RPAVAIL"
                session.findById("wnd[0]").sendVKey(0)
            except Exception:
                pass
            dismiss_popups(session)

    _safe_prog(progress_callback, 100, f"Pengecekan Replace PN selesai ({found_count} ditemukan, {not_found_count} tanpa pengganti)")
    _safe_log(log_callback, f"[REPLACE-PN] Selesai: {found_count} part pengganti ditemukan, {not_found_count} tanpa pengganti.")

    return {
        "total": total,
        "found_count": found_count,
        "not_found_count": not_found_count,
        "items": part_items
    }

