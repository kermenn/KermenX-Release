"""
Module: stock_readiness_live_helper.py
Fungsi: Otomasi pengecekan ketersediaan stok live di SAP GUI via transaksi /NZMIM_RPAVAIL.
Fitur Unggulan:
1. Input Part Number & Qty Needed (Single Target Plant, default 1346).
2. Patokan utama: SLOC DMDV & Onhand ATP pada cabang target.
3. Kaskade hierarki stok 8 tingkat (Opsi B - Alokasi Partial & Bertingkat):
   - Tingkat 1: 5 HUB Utama (1S66 BJH, 1S67 SSH, 1S76 CKN, 1S81 SBH, 1F22 PLM)
   - Tingkat 2: 1H* & List (1456, 1454, 1341, 1861, 1862, 1342)
   - Tingkat 3: 1G* (e.g. 1G31, 1G32, 1G38)
   - Tingkat 4: SNG (Caterpillar Singapore Parts Depot)
   - Tingkat 5: 1B* (e.g. 1B40)
   - Tingkat 6: 1F* (selain 1F22)
   - Tingkat 7: 1A* (selain 1A11)
   - Tingkat 8: Selain yang disebutkan diatas
   - Filter mutlak skip: 1C50, 1A11, awalan 150*, awalan 2*
4. Kalkulasi Qty On-Order (Sum INORDER DMDV + BORD pada cabang target) & Total Stok Cabang (Sum CLABS).
5. Deteksi Deletion Indicator (LVORM Z1, Z2, dll) & auto lookup Part Pengganti (btn[18] -> SUCC_PART).
6. Lookup nama cabang/warehouse dari SQLite plant_tu.db.
7. Generator laporan Excel profesional berstandar KermenX (Navy Blue #1E3A8A).
"""

import os
import sys
import time
import sqlite3
import ctypes
import json

def _ensure_desktop():
    try:
        user32 = ctypes.windll.user32
        hDefault = user32.OpenDesktopW("Default", 0, False, 0x01FF)
        if hDefault:
            user32.SetThreadDesktop(hDefault)
    except Exception:
        pass

def get_live_sap_session(client="300"):
    """
    Mengaitkan langsung ke sesi SAP GUI aktif di Windows Desktop.
    """
    _ensure_desktop()
    try:
        import pythoncom
        pythoncom.CoInitialize()
        import win32com.client
        sap_rot = win32com.client.Dispatch("SapROTWr.SapROTWrapper")
        sap_gui = sap_rot.GetROTEntry("SAPGUI")
        if sap_gui:
            app = sap_gui.GetScriptingEngine
            if app and app.Children.Count > 0:
                for i in range(app.Children.Count):
                    conn = app.Children(i)
                    for j in range(conn.Children.Count):
                        sess = conn.Children(j)
                        info = getattr(sess, "Info", None)
                        if info:
                            c_client = str(getattr(info, "Client", "") or "")
                            if not client or c_client == str(client):
                                return sess
                return app.Children(0).Children(0)
    except Exception:
        pass
    return None

def load_plant_dictionary(db_path=None):
    if not db_path or not os.path.exists(db_path):
        candidate = r"C:\Users\Yusril Irgi\Downloads\Aplikasi\Database\plant_tu.db"
        if os.path.exists(candidate):
            db_path = candidate
        else:
            return {}

    plant_dict = {}
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("SELECT plant_code, warehouse_number, plant_name, city FROM plants")
        for row in cur.fetchall():
            code = str(row[0]).strip().upper()
            wh = str(row[1] or "").strip()
            name = str(row[2] or "").strip()
            city = str(row[3] or "").strip()
            label = wh if wh else (city if city else name)
            plant_dict[code] = label
        conn.close()
    except Exception as e:
        print(f"[WARN] Gagal membaca database plant: {e}")

    # Manual overrides & specials
    plant_dict["SNG"] = "Singapore"
    plant_dict["1346"] = "RTA"
    plant_dict["1S66"] = "BJH"
    plant_dict["1S67"] = "SSH"
    plant_dict["1S76"] = "CKN"
    plant_dict["1S81"] = "SBH"
    plant_dict["1F22"] = "PLM"
    return plant_dict


def is_plant_skipped(plant_code):
    p = str(plant_code).strip().upper()
    if p in ("1C50", "1A11"):
        return True
    if p.startswith("150"):
        return True
    if p.startswith("2"):
        return True
    return False


def get_plant_tier(plant_code):
    p = str(plant_code).strip().upper()
    if is_plant_skipped(p):
        return 999  # Skip

    # Tier 1: 5 HUB Utama
    hub_order = {"1S66": 11, "1S67": 12, "1S76": 13, "1S81": 14, "1F22": 15}
    if p in hub_order:
        return hub_order[p]

    # Tier 2: 1H* & list khusus
    tier2_specials = ("1456", "1454", "1341", "1861", "1862", "1342")
    if p.startswith("1H") or p in tier2_specials:
        return 20

    # Tier 3: 1G*
    if p.startswith("1G"):
        return 30

    # Tier 4: SNG (Singapore Depot)
    if p == "SNG":
        return 40

    # Tier 5: 1B*
    if p.startswith("1B"):
        return 50

    # Tier 6: 1F* (selain 1F22)
    if p.startswith("1F") and p != "1F22":
        return 60

    # Tier 7: 1A* (selain 1A11)
    if p.startswith("1A") and p != "1A11":
        return 70

    # Tier 8: Sisanya
    return 80


def execute_stock_readiness_live(
    session,
    part_items,
    target_plant="1346",
    plant_db_path=None,
    log_callback=None,
    progress_callback=None
):
    """
    Eksekusi live stock readiness pada SAP GUI /NZMIM_RPAVAIL.
    """
    _ensure_desktop()
    plant_dict = load_plant_dictionary(plant_db_path)
    target_plant = str(target_plant or "1346").strip().upper()

    def _log(msg):
        if log_callback:
            log_callback(msg)
        else:
            print(msg)

    def _prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    if session is None:
        session = get_live_sap_session(client="300")
        if session is None:
            try:
                try:
                    import modules.sap_helper as sh
                except ImportError:
                    import sap_helper as sh
                session = sh.get_active_or_new_sap_session()
            except Exception as e:
                _log(f"[WARN] Gagal mengaitkan session SAP GUI: {e}")

    if not part_items:
        raise ValueError("Daftar Part Number kosong!")

    total = len(part_items)
    results = []

    _log(f"[READINESS-LIVE] Memulai pengecekan {total} Part Number untuk Cabang Target {target_plant} ({plant_dict.get(target_plant, '')})...")
    _prog(5, f"Membuka transaksi /NZMIM_RPAVAIL ({total} item)...")

    # Pastikan SAP berada di layar selection /NZMIM_RPAVAIL
    try:
        session.findById("wnd[0]/tbar[0]/okcd").Text = "/NZMIM_RPAVAIL"
        session.findById("wnd[0]").SendVKey(0)
        time.sleep(1)
    except Exception as e:
        _log(f"[WARN] Error membuka /NZMIM_RPAVAIL: {e}")

    for idx, itm in enumerate(part_items):
        raw_pn = str(itm.get("pn") or itm.get("part_number") or "").strip()
        qty_needed = float(itm.get("qty") or itm.get("qty_needed") or 1.0)
        pct = 5 + int(((idx + 1) / total) * 90)

        _prog(pct, f"[{idx+1}/{total}] Mengecek PN: {raw_pn} (Kebutuhan: {qty_needed})...")
        _log(f"[PN {idx+1}/{total}] Mengecek {raw_pn} | Qty: {qty_needed} | Plant: {target_plant}")

        # Inisialisasi default output per item
        item_res = {
            "no": idx + 1,
            "part_number": raw_pn,
            "material_desc": "-",
            "order_method": "-",
            "uom": "-",
            "deletion_indicator": "",
            "qty_needed": qty_needed,
            "qty_on_order": 0.0,
            "total_stock_cabang": 0.0,
            "remarks_stock": "Error SAP",
            "replacement_part": "-",
            "status_badge": "Error"
        }

        try:
            # Pastikan di selection screen 1000
            if getattr(session.Info, "ScreenNumber", "") != "1000":
                session.findById("wnd[0]/tbar[0]/okcd").Text = "/NZMIM_RPAVAIL"
                session.findById("wnd[0]").SendVKey(0)
                time.sleep(0.5)

            # Input field selection
            session.findById("wnd[0]/usr/ctxtP_PARTNO").Text = raw_pn
            session.findById("wnd[0]/usr/ctxtP_PLANT").Text = target_plant
            session.findById("wnd[0]/usr/ctxtSO_LGORT-LOW").Text = "DMDV"
            session.findById("wnd[0]/usr/chkP_CATST").Selected = True

            # Tekan F8 (Execute)
            session.findById("wnd[0]/tbar[1]/btn[8]").Press()
            time.sleep(0.8)

            # Cek apakah ada popup peringatan (misal Material Not Found)
            if session.Children.Count > 1:
                w_modal = session.Children(1)
                modal_text = getattr(w_modal, "Text", "")
                _log(f"  [INFO] Muncul popup SAP: '{modal_text}'")
                try:
                    w_modal.sendVKey(0)
                except Exception:
                    try:
                        w_modal.close()
                    except Exception:
                        pass
                time.sleep(0.5)

            # Jika masih di screen 1000 berarti part tidak ditemukan / error
            if getattr(session.Info, "ScreenNumber", "") == "1000":
                sbar_msg = getattr(session.findById("wnd[0]/sbar"), "Text", "Part Number tidak ditemukan")
                item_res["remarks_stock"] = f"Tidak Ditemukan: {sbar_msg}"
                item_res["status_badge"] = "NoStock"
                results.append(item_res)
                continue

            # 1. Ambil data Header
            try:
                desc = session.findById("wnd[0]/usr/txtLV_MAKTX").Text.strip()
                item_res["material_desc"] = desc if desc else "-"
            except Exception:
                pass

            try:
                om = session.findById("wnd[0]/usr/txtLV_ORDER").Text.strip()
                item_res["order_method"] = om if om else "-"
            except Exception:
                pass

            try:
                uom_val = session.findById("wnd[0]/usr/txtLV_UOM").Text.strip()
                item_res["uom"] = uom_val if uom_val else "-"
            except Exception:
                pass

            try:
                lvorm_val = session.findById("wnd[0]/usr/ctxtLV_LVORM").Text.strip()
                item_res["deletion_indicator"] = lvorm_val
            except Exception:
                lvorm_val = ""

            try:
                rep_flag = session.findById("wnd[0]/usr/txtLV_REPLACEMENT").Text.strip()
            except Exception:
                rep_flag = "0"

            # 2. Cek Part Pengganti (Replacement Pop-up via btn[18])
            # Trigger jika LVORM terisi (Z1, Z2, dll) ATAU rep_flag != "0"
            succ_part = ""
            if lvorm_val or rep_flag not in ("", "0", "-"):
                try:
                    session.findById("wnd[0]/tbar[1]/btn[18]").Press()
                    time.sleep(0.6)
                    if session.Children.Count > 1:
                        w_pop = session.findById("wnd[1]")
                        grid_pop = w_pop.findById("usr/cntlCONT_ALV_POPUP/shellcont/shell")
                        if grid_pop and grid_pop.RowCount > 0:
                            succ_part = str(grid_pop.GetCellValue(0, "SUCC_PART") or "").strip()
                            if succ_part:
                                item_res["replacement_part"] = succ_part
                                _log(f"  [REPLACEMENT] Ditemukan part pengganti: {succ_part}")
                        # Tutup popup modal
                        try:
                            w_pop.findById("tbar[0]/btn[22]").Press()
                        except Exception:
                            try:
                                w_pop.sendVKey(12)
                            except Exception:
                                w_pop.close()
                        time.sleep(0.4)
                except Exception as e_rep:
                    _log(f"  [WARN] Gagal membaca replacement: {e_rep}")

            # 3. Baca ALV Grid Stok
            grid_alv = session.findById("wnd[0]/usr/cntlCONT_ALV/shellcont/shell")
            row_count = grid_alv.RowCount if grid_alv else 0

            target_dmdv_atp = 0.0
            target_inorder = 0.0
            target_clabs = 0.0

            # Kumpulkan seluruh baris plant lain yang valid (tidak diskip)
            outside_plants = []

            for r in range(row_count):
                p_code = str(grid_alv.GetCellValue(r, "PLANT") or "").strip().upper()
                sloc_code = str(grid_alv.GetCellValue(r, "SLOC") or "").strip().upper()
                
                try:
                    atp_val = float(grid_alv.GetCellValue(r, "ATP") or 0.0)
                except Exception:
                    atp_val = 0.0
                try:
                    inord_val = float(grid_alv.GetCellValue(r, "INORDER") or 0.0)
                except Exception:
                    inord_val = 0.0
                try:
                    clabs_val = float(grid_alv.GetCellValue(r, "CLABS") or 0.0)
                except Exception:
                    clabs_val = 0.0

                # Akumulasi untuk Cabang Target
                if p_code == target_plant:
                    if sloc_code == "DMDV":
                        target_dmdv_atp += atp_val
                    if sloc_code in ("DMDV", "BORD"):
                        target_inorder += inord_val
                    target_clabs += clabs_val
                    continue

                # Cek apakah plant luar ini diskip
                if is_plant_skipped(p_code):
                    continue

                tier = get_plant_tier(p_code)
                if tier < 999 and atp_val > 0:
                    outside_plants.append({
                        "plant": p_code,
                        "sloc": sloc_code,
                        "atp": atp_val,
                        "tier": tier
                    })

            item_res["qty_on_order"] = target_inorder
            item_res["total_stock_cabang"] = target_clabs

            # 4. Evaluasi Hierarki Opsi B (Alokasi Bertingkat)
            target_label = plant_dict.get(target_plant, target_plant)
            rep_suffix = f" [Discontinue: {lvorm_val} ➔ Ganti: {succ_part}]" if succ_part else (f" [Discontinue: {lvorm_val}]" if lvorm_val else "")

            # Kondisi A: Stok DMDV Cabang Target Penuh
            if target_dmdv_atp >= qty_needed:
                item_res["remarks_stock"] = f"Ready {target_plant} ({target_label}){rep_suffix}"
                item_res["status_badge"] = "Ready"

            # Kondisi B: Stok DMDV Cabang Target Kosong / Kurang -> Kaskade ke luar
            else:
                remaining = qty_needed - target_dmdv_atp
                allocations = []

                if target_dmdv_atp > 0:
                    q_str = f"{int(target_dmdv_atp)}" if target_dmdv_atp.is_integer() else f"{target_dmdv_atp}"
                    allocations.append(f"{target_plant} ({q_str})")

                # Urutkan plant luar berdasarkan:
                # 1. Tier terkecil (1 s/d 8)
                # 2. ATP terbesar di dalam tier yang sama
                outside_plants.sort(key=lambda x: (x["tier"], -x["atp"]))

                # Ambil stok secara bertingkat
                for p_item in outside_plants:
                    if remaining <= 0:
                        break
                    p_c = p_item["plant"]
                    p_atp = p_item["atp"]
                    take = min(p_atp, remaining)
                    if take > 0:
                        take_str = f"{int(take)}" if take.is_integer() else f"{take}"
                        p_lbl = plant_dict.get(p_c, p_c)
                        allocations.append(f"{p_c} {p_lbl} ({take_str})")
                        remaining -= take

                # Format status akhir
                if remaining <= 0:
                    # Terpenuhi 100%
                    if target_dmdv_atp == 0 and len(allocations) == 1:
                        # Penuh di 1 plant luar
                        single_plant = outside_plants[0]["plant"]
                        single_lbl = plant_dict.get(single_plant, single_plant)
                        item_res["remarks_stock"] = f"Ready {single_plant} ({single_lbl}){rep_suffix}"
                        item_res["status_badge"] = "ReadyHub" if outside_plants[0]["tier"] < 20 else "Ready"
                    else:
                        item_res["remarks_stock"] = f"Partial: {', '.join(allocations)}{rep_suffix}"
                        item_res["status_badge"] = "Partial"
                else:
                    # Masih defisit
                    if allocations:
                        rem_str = f"{int(remaining)}" if remaining.is_integer() else f"{remaining}"
                        oo_info = f" (Ada OO: {int(target_inorder) if target_inorder.is_integer() else target_inorder})" if target_inorder > 0 else ""
                        item_res["remarks_stock"] = f"Partial: {', '.join(allocations)} | Defisit: {rem_str}{oo_info}{rep_suffix}"
                        item_res["status_badge"] = "Partial"
                    else:
                        # Seluruh plant 0
                        if item_res["order_method"] in ("KT", "PT", "KH"):
                            item_res["remarks_stock"] = f"No Quota Import / Tidak Ada Stok{rep_suffix}"
                            item_res["status_badge"] = "NoStock"
                        elif target_inorder > 0:
                            oo_str = f"{int(target_inorder)}" if target_inorder.is_integer() else f"{target_inorder}"
                            item_res["remarks_stock"] = f"Tidak Ada Stok (Ada OO: {oo_str}){rep_suffix}"
                            item_res["status_badge"] = "NoStock"
                        else:
                            item_res["remarks_stock"] = f"Tidak Ada Stok{rep_suffix}"
                            item_res["status_badge"] = "NoStock"

            if succ_part and item_res["status_badge"] == "NoStock":
                item_res["status_badge"] = "Discontinued"

            _log(f"  -> Hasil: {item_res['remarks_stock']} | OO: {item_res['qty_on_order']} | Total Stok: {item_res['total_stock_cabang']}")

            # Kembali ke selection screen (F3 Back)
            try:
                session.findById("wnd[0]/tbar[0]/btn[3]").Press()
                time.sleep(0.5)
            except Exception:
                pass

        except Exception as e_row:
            _log(f"  [ERROR] Gagal proses PN {raw_pn}: {e_row}")
            item_res["remarks_stock"] = f"Error SAP: {e_row}"
            item_res["status_badge"] = "Error"
            try:
                session.findById("wnd[0]/tbar[0]/btn[3]").Press()
            except Exception:
                pass

        results.append(item_res)

    _prog(100, f"Selesai! Berhasil memproses {len(results)} Part Number.")
    _log(f"[READINESS-LIVE] Selesai memeriksa {len(results)} items.")

    return {
        "status": "success",
        "target_plant": target_plant,
        "total_items": len(results),
        "items": results
    }


def export_readiness_excel(items, target_plant="1346", output_path=None):
    """
    Ekspor hasil pengecekan live stock readiness ke berkas Excel resmi KermenX.
    """
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    if not output_path:
        out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output", "09_Live_Stock_Readiness")
        os.makedirs(out_dir, exist_ok=True)
        ts = time.strftime("%d%m%Y_%H%M%S")
        output_path = os.path.join(out_dir, f"Live_Stock_Readiness_{target_plant}_{ts}.xlsx")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Live Stock Readiness"
    ws.views.sheetView[0].showGridLines = True

    # Styling Palette KermenX Enterprise
    navy_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    header_fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    zebra_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")

    green_fill = PatternFill(start_color="D1FAE5", end_color="D1FAE5", fill_type="solid")
    green_font = Font(name="Segoe UI", size=9, bold=True, color="065F46")

    blue_fill = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")
    blue_font = Font(name="Segoe UI", size=9, bold=True, color="1E40AF")

    orange_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    orange_font = Font(name="Segoe UI", size=9, bold=True, color="92400E")

    red_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    red_font = Font(name="Segoe UI", size=9, bold=True, color="991B1B")

    gray_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
    gray_font = Font(name="Segoe UI", size=9, color="475569")

    thin_border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )

    # 1. Banner Judul
    ws.merge_cells("A1:K1")
    cell_title = ws["A1"]
    cell_title.value = f"KERMENX PRO — LIVE STOCK READINESS REPORT (PLANT TARGET: {target_plant})"
    cell_title.font = Font(name="Segoe UI", size=13, bold=True, color="FFFFFF")
    cell_title.fill = navy_fill
    cell_title.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 36

    ws.merge_cells("A2:K2")
    cell_sub = ws["A2"]
    cell_sub.value = f"Waktu Pengecekan: {time.strftime('%d-%m-%Y %H:%M:%S')} | SAP Transaksi: /NZMIM_RPAVAIL | Patokan: SLOC DMDV & Kaskade 8 Tingkat"
    cell_sub.font = Font(name="Segoe UI", size=9, italic=True, color="E2E8F0")
    cell_sub.fill = navy_fill
    cell_sub.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 20

    # 2. Table Headers (Row 4)
    headers = [
        "No", "Part Number", "Material Description", "Order Method", "UoM",
        "Del. Ind (LVORM)", "Qty Needed", "Qty On-Order", "Total Stok Cabang",
        "Remarks Stock", "Replacement Part"
    ]

    ws.row_dimensions[4].height = 26
    for col_idx, h in enumerate(headers, start=1):
        c = ws.cell(row=4, column=col_idx, value=h)
        c.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
        c.fill = header_fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = thin_border

    # 3. Data Rows
    for row_idx, itm in enumerate(items, start=5):
        ws.row_dimensions[row_idx].height = 20
        bg = zebra_fill if row_idx % 2 == 0 else white_fill

        ws.cell(row=row_idx, column=1, value=row_idx - 4).alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(row=row_idx, column=2, value=itm.get("part_number", "-")).alignment = Alignment(horizontal="left", vertical="center")
        ws.cell(row=row_idx, column=3, value=itm.get("material_desc", "-")).alignment = Alignment(horizontal="left", vertical="center")
        ws.cell(row=row_idx, column=4, value=itm.get("order_method", "-")).alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(row=row_idx, column=5, value=itm.get("uom", "-")).alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(row=row_idx, column=6, value=itm.get("deletion_indicator", "")).alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(row=row_idx, column=7, value=itm.get("qty_needed", 0.0)).alignment = Alignment(horizontal="right", vertical="center")
        ws.cell(row=row_idx, column=8, value=itm.get("qty_on_order", 0.0)).alignment = Alignment(horizontal="right", vertical="center")
        ws.cell(row=row_idx, column=9, value=itm.get("total_stock_cabang", 0.0)).alignment = Alignment(horizontal="right", vertical="center")

        # Remarks cell
        c_rem = ws.cell(row=row_idx, column=10, value=itm.get("remarks_stock", "-"))
        c_rem.alignment = Alignment(horizontal="left", vertical="center")

        badge = itm.get("status_badge", "")
        if badge in ("Ready", "ReadyHub"):
            c_rem.fill = green_fill
            c_rem.font = green_font
        elif badge == "Partial":
            c_rem.fill = orange_fill
            c_rem.font = orange_font
        elif badge == "Discontinued":
            c_rem.fill = red_fill
            c_rem.font = red_font
        elif badge == "NoStock":
            c_rem.fill = gray_fill
            c_rem.font = gray_font

        ws.cell(row=row_idx, column=11, value=itm.get("replacement_part", "-")).alignment = Alignment(horizontal="center", vertical="center")

        for c_i in range(1, 12):
            cell = ws.cell(row=row_idx, column=c_i)
            cell.border = thin_border
            if c_i != 10:
                cell.fill = bg
                cell.font = Font(name="Segoe UI", size=9)

    # Auto-adjust column width
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.row in (1, 2):
                continue
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 10)

    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 25
    ws.column_dimensions["J"].width = 38
    ws.column_dimensions["K"].width = 20

    wb.save(output_path)
    return output_path
