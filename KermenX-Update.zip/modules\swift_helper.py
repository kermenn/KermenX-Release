"""
Module: swift_helper.py
Pengolahan data terpadu untuk SWIFT (Smart Wear Indicator & Forecasting Tools) & Cloud Sync (Supabase).
Mengolah data inspeksi keausan alat berat (.xlsx, .xlsb, .csv):
1. Ingesti cepat menggunakan Rust Calamine / Pandas.
2. Pencocokan Master Database MEP (Major / Maintenance Equipment Population).
3. Kalkulasi Wear Percentage, Wear Rate per jam, Sisa Jam Kerja (RUL), dan Proyeksi Tanggal Ganti (Forecast Date).
4. Klasifikasi Severity (CRITICAL, WARNING, ATTENTION, NORMAL) & Rekomendasi Tindakan.
5. Export Laporan Excel Eksekutif & JSON.
6. Upload langsung ke Cloud Database Supabase via REST API (PostgREST Upsert).
"""
import os
import sys
import re
import json
import time
import socket
import datetime
import requests
import numpy as np
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Paksa koneksi IPv4 untuk mencegah ConnectionResetError (WinError 10054) pada jaringan Windows
try:
    import urllib3.util.connection as urllib_conn
    urllib_conn.allowed_gai_family = lambda: socket.AF_INET
except Exception:
    pass

import config
from config import get_output_dir


# =============================================================================
# 1. LOGGING & UTILITIES
# =============================================================================
def log_msg(callback, msg):
    timestamp = time.strftime("%H:%M:%S")
    formatted = f"[{timestamp}] {msg}"
    try:
        print(f"[*] {formatted}", flush=True)
    except Exception:
        try:
            print(f"[*] {str(formatted).encode('ascii', errors='replace').decode('ascii')}", flush=True)
        except Exception:
            pass
    if callback and callable(callback):
        try:
            callback(formatted)
        except Exception:
            pass


def clean_column_name(col):
    """Membersihkan dan menstandarkan nama kolom."""
    if col is None:
        return ""
    col_str = str(col).strip().lower()
    col_str = re.sub(r'[\s\.\-\/\(\)\%\:]+', '_', col_str)
    col_str = re.sub(r'_+', '_', col_str).strip('_')
    return col_str


def normalize_alphanumeric(val):
    if val is None or pd.isna(val):
        return ""
    s = str(val).strip().upper()
    return re.sub(r'[^A-Z0-9]', '', s)


def clean_unit_id(uid):
    s = normalize_alphanumeric(uid)
    if s.startswith("XCE") or s.startswith("XCD"):
        s = s[1:]
    return s


# =============================================================================
# 2. INGESTI DATA MENGGUNAKAN CALAMINE / PANDAS
# =============================================================================
def load_data_file(file_path, sheet_name=None, header_row=None, callback=None):
    """Membaca file data mentah (.xlsb, .xlsx, .csv) dengan engine Calamine / Pandas."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File tidak ditemukan: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()
    start_time = time.time()
    log_msg(callback, f"Membuka file: {os.path.basename(file_path)} ({ext})...")

    df = None
    if ext == ".csv":
        try:
            df = pd.read_csv(file_path, low_memory=False, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, low_memory=False, encoding="latin1")
    elif ext in [".xlsb", ".xlsx", ".xls"]:
        try:
            from python_calamine import CalamineWorkbook
            wb = CalamineWorkbook.from_path(file_path)
            available_sheets = wb.sheet_names
            target_sheet = available_sheets[0]
            if sheet_name is not None:
                if isinstance(sheet_name, int) and sheet_name < len(available_sheets):
                    target_sheet = available_sheets[sheet_name]
                elif isinstance(sheet_name, str) and sheet_name in available_sheets:
                    target_sheet = sheet_name
                else:
                    for s in available_sheets:
                        s_lower = s.lower()
                        if any(kw in s_lower for kw in ["wear", "inspect", "cts", "data", "sheet1", "raw"]):
                            target_sheet = s
                            break

            log_msg(callback, f"Mengekstrak data dari sheet: '{target_sheet}' via Calamine (Rust Engine)...")
            sheet_data = wb.get_sheet_by_name(target_sheet).to_python()
            if not sheet_data or len(sheet_data) == 0:
                raise ValueError(f"Sheet '{target_sheet}' kosong.")

            if header_row is None:
                header_row = 0
                max_non_empty = 0
                for idx, row in enumerate(sheet_data[:10]):
                    non_empty = sum(1 for cell in row if cell is not None and str(cell).strip() != "")
                    if non_empty > max_non_empty:
                        max_non_empty = non_empty
                        header_row = idx

            headers = [str(col).strip() if col is not None else f"Column_{i}" for i, col in enumerate(sheet_data[header_row])]
            raw_rows = sheet_data[header_row + 1:]
            df = pd.DataFrame(raw_rows, columns=headers)
        except Exception as e_calamine:
            log_msg(callback, f"Calamine fallback ke openpyxl ({e_calamine})...")
            df = pd.read_excel(file_path, sheet_name=sheet_name or 0)
    else:
        raise ValueError(f"Format {ext} tidak didukung. Gunakan .xlsb, .xlsx, atau .csv")

    df.dropna(how="all", inplace=True)
    df.reset_index(drop=True, inplace=True)
    elapsed = time.time() - start_time
    log_msg(callback, f"Berhasil membaca {len(df):,} baris data dalam {elapsed:.2f} detik.")
    return df


def get_sheet_list(file_path):
    if not os.path.exists(file_path):
        return []
    ext = os.path.splitext(file_path)[1].lower()
    if ext in [".xlsb", ".xlsx", ".xls"]:
        try:
            from python_calamine import CalamineWorkbook
            wb = CalamineWorkbook.from_path(file_path)
            return wb.sheet_names
        except Exception:
            try:
                import openpyxl
                wb = openpyxl.load_workbook(file_path, read_only=True)
                return wb.sheetnames
            except Exception:
                return []
    return []


# =============================================================================
# 3. MEP MASTER DATABASE & FILTERING
# =============================================================================
def load_mep_database(file_path=None, callback=None):
    if file_path is None or not os.path.exists(file_path):
        candidates = [
            os.path.join(config.BASE_DIR, "data", "mep_database.xlsx"),
            os.path.join(os.path.dirname(config.BASE_DIR), "SWIFT", "data", "mep_database.xlsx"),
            os.path.join(config.BASE_DIR, "data", "MEP Actual 2026.xlsx"),
        ]
        file_path = None
        for c in candidates:
            if os.path.exists(c):
                file_path = c
                break

    if not file_path or not os.path.exists(file_path):
        log_msg(callback, "Master Database MEP tidak ditemukan, filtering MEP dilewati.")
        return pd.DataFrame()

    try:
        df = pd.read_excel(file_path)
        col_mapping = {}
        for col in df.columns:
            c_lower = str(col).strip().lower().replace(" ", "_")
            if any(k in c_lower for k in ["id_unit", "unit_id", "id", "equipment", "cn"]):
                if "unit_id" not in col_mapping:
                    col_mapping["unit_id"] = col
            elif any(k in c_lower for k in ["serial", "sn", "no_seri"]):
                if "serial_number" not in col_mapping:
                    col_mapping["serial_number"] = col
            elif any(k in c_lower for k in ["model", "type", "tipe"]):
                if "model" not in col_mapping:
                    col_mapping["model"] = col
            elif any(k in c_lower for k in ["location", "lokasi", "site", "jobsite"]):
                if "location" not in col_mapping:
                    col_mapping["location"] = col

        rename_dict = {orig: std for std, orig in col_mapping.items()}
        df = df.rename(columns=rename_dict)
        if "unit_id" in df.columns:
            df["CLEAN_UNIT_ID"] = df["unit_id"].astype(str).apply(clean_unit_id)
        return df
    except Exception as e:
        log_msg(callback, f"Gagal membaca Database MEP: {e}")
        return pd.DataFrame()


# =============================================================================
# 4. WEAR CALCULATION & FORECAST ENGINE
# =============================================================================
COLUMN_SYNONYMS = {
    "unit_id": ["reference_number", "machine_serial_number", "equipment_no", "equipment_id", "unit_id", "unit", "equipment", "cn", "unit_no", "asset_no", "fleet_no"],
    "model": ["machine_model", "unit_model", "eq_model", "equipment_model", "model", "machine_model_type"],
    "site": ["job_site", "customer_name", "site", "location", "plant", "jobsite", "area", "sloc", "work_center"],
    "component": ["component", "part_name", "item_description", "part_desc", "compartment", "item", "description"],
    "position": ["position", "pos", "location_pos", "posisi"],
    "side": ["side", "side_pos", "posisi_samping"],
    "wear_pct": ["percent_worn", "wear_pct", "wear_%", "wear_percent", "wear_percentage", "pct_wear", "pct_worn", "keausan", "wear"],
    "condition": ["condition", "kondisi", "visual_condition", "comp_condition", "eval_condition", "appearance"],
    "current_smu": ["machine_hours", "hours_on_wear_surface", "smu", "hm", "current_smu", "hours", "component_hours", "lifetime_hours", "total_hours", "operating_hours"],
    "limit_dimension": ["wear_limit_mm", "wear_limit", "limit", "limit_val", "max_wear", "condemn_limit", "limit_dimension"],
    "current_dimension": ["measurement_mm", "measurement", "current_measurement", "actual", "reading", "current_val", "dimensi_aktual"],
    "initial_dimension": ["new_dimension_mm", "new_dimension", "initial", "original", "std_dimension", "nominal"],
    "inspection_date": ["inspection_date", "inspect_date", "tanggal_inspeksi", "last_inspection", "date", "tanggal"],
    "projected_date": ["projected_date_to_100", "projected_date_to_100_", "projected_date", "forecast_date"],
    "remaining_hours": ["remaining_life_100", "remaining_life_100_", "remaining_life", "remaining_hours"],
    "recommendations": ["recommendations", "recommendation", "action", "notes"],
    "pic": ["inspector_name", "pic", "pic_name", "planner", "engineer", "contact_person", "in_charge"],
    "category": ["inspection_type", "component_category", "category", "compartment_type", "system", "system_type", "group", "kategori"]
}


def classify_component_category(comp_name, inspection_type=None, equipment_type=None):
    itype = str(inspection_type or "").strip().lower()
    eq = str(equipment_type or "").strip().lower()
    comp = str(comp_name or "").strip().lower()

    if "undercarriage" in itype:
        return "UNDERCARRIAGE"
    if "bucket" in itype or "get" in itype or "bucket" in eq:
        return "GET"

    uc_keywords = [
        "track", "roller", "carrier", "idler", "sprocket", "segment",
        "link", "shoe", "grouser", "chain", "bushing", "pin", "recoil", "tensioner"
    ]
    if any(k in comp for k in uc_keywords):
        return "UNDERCARRIAGE"

    get_keywords = ["tip", "tooth", "teeth", "adapter", "shroud", "lip", "edge", "cutting", "blade", "corner", "beep"]
    if any(k in comp for k in get_keywords):
        return "GET"

    return "OTHER"


def detect_columns(df):
    clean_map = {col: clean_column_name(col) for col in df.columns}
    detected = {}
    for std_name, syn_list in COLUMN_SYNONYMS.items():
        found = False
        for syn in syn_list:
            for orig_col, clean_col in clean_map.items():
                if syn == clean_col:
                    detected[std_name] = orig_col
                    found = True
                    break
            if found:
                break
    for std_name, syn_list in COLUMN_SYNONYMS.items():
        if std_name not in detected:
            found = False
            for syn in syn_list:
                for orig_col, clean_col in clean_map.items():
                    if syn in clean_col:
                        detected[std_name] = orig_col
                        found = True
                        break
                if found:
                    break
    return detected


def calculate_swift_wear(
    df_raw,
    only_latest_inspection=True,
    filter_mep=True,
    component_filter="UNDERCARRIAGE",
    daily_operating_hours=16.0,
    mep_db_path=None,
    callback=None
):
    """
    Eksekusi kalkulasi keausan armada komprehensif (% Wear, Wear Rate, RUL Hours, Forecast Date).
    """
    if df_raw is None or len(df_raw) == 0:
        raise ValueError("Dataset mentah kosong.")

    total_raw_rows = len(df_raw)
    log_msg(callback, f"[1/5] Memulai analisis data mentah ({total_raw_rows:,} baris)...")

    detected = detect_columns(df_raw)
    unit_col = detected.get("unit_id")
    comp_col = detected.get("component")
    date_col = detected.get("inspection_date")
    wear_col = detected.get("wear_pct")
    smu_col = detected.get("current_smu")
    model_col = detected.get("model")
    site_col = detected.get("site")
    pos_col = detected.get("position")
    side_col = detected.get("side")
    recom_col = detected.get("recommendations")
    cond_col = detected.get("condition")
    pic_col = detected.get("pic")
    rem_hours_col = detected.get("remaining_hours")
    proj_date_col = detected.get("projected_date")

    if not unit_col or not comp_col:
        raise ValueError("Kolom Unit ID dan Component tidak terdeteksi dalam file raw data.")

    df = df_raw.copy()
    df = df[df[unit_col].notna() & df[comp_col].notna()].copy()
    df["CLEAN_UNIT_ID"] = df[unit_col].astype(str).apply(clean_unit_id)

    # 1. Filter MEP jika aktif
    mep_metrics = None
    if filter_mep:
        log_msg(callback, "[2/5] Mencocokkan armada terhadap Master Database MEP...")
        mep_df = load_mep_database(mep_db_path, callback=callback)
        if not mep_df.empty and "CLEAN_UNIT_ID" in mep_df.columns:
            mep_units = set(mep_df["CLEAN_UNIT_ID"].dropna().unique())
            initial_count = len(df)
            df = df[df["CLEAN_UNIT_ID"].isin(mep_units)].copy()
            filtered_count = len(df)
            matched_count = df["CLEAN_UNIT_ID"].nunique()
            mep_metrics = {
                "initial_rows": initial_count,
                "filtered_rows": filtered_count,
                "matched_units": matched_count,
                "total_mep_units": len(mep_units)
            }
            log_msg(callback, f"  -> Berhasil mencocokkan {matched_count}/{len(mep_units)} unit MEP ({filtered_count:,} baris inspeksi).")

    # 2. Filter Kategori Komponen
    norm_comp_filter = str(component_filter).strip().upper()
    cat_col = detected.get("category")
    eq_type_col = detected.get("model")

    unique_comps = df[comp_col].dropna().unique()
    cat_dict = {}
    for c_name in unique_comps:
        cat_dict[c_name] = classify_component_category(c_name)
    df["SWIFT_CATEGORY"] = df[comp_col].map(cat_dict).fillna("OTHER")

    if norm_comp_filter in ["UNDERCARRIAGE", "GET"]:
        df = df[df["SWIFT_CATEGORY"] == norm_comp_filter].copy()
        log_msg(callback, f"  -> Filter Kategori: {norm_comp_filter} ({len(df):,} baris)")

    # 3. Parse Tanggal & Filter Latest Inspection
    today = datetime.date.today()
    if date_col and date_col in df.columns:
        df["_PARSED_DATE"] = pd.to_datetime(df[date_col], errors="coerce")
    else:
        df["_PARSED_DATE"] = pd.to_datetime(today)

    if only_latest_inspection:
        log_msg(callback, "[3/5] Menyaring snapshot inspeksi paling mutakhir per komponen...")
        df.sort_values(by=["_PARSED_DATE"], ascending=False, inplace=True)
        group_keys = ["CLEAN_UNIT_ID", comp_col]
        if pos_col and pos_col in df.columns:
            group_keys.append(pos_col)
        if side_col and side_col in df.columns:
            group_keys.append(side_col)
        df.drop_duplicates(subset=group_keys, keep="first", inplace=True)
        log_msg(callback, f"  -> Snapshot aktif: {len(df):,} komponen aktif.")

    # 4. Standardisasi Kolom Utama
    log_msg(callback, "[4/5] Menghitung % keausan, laju aus, dan proyeksi pergantian...")
    df["SWIFT_UNIT_ID"] = df["CLEAN_UNIT_ID"]
    df["SWIFT_COMPONENT"] = df[comp_col].astype(str).str.strip()
    df["SWIFT_MODEL"] = df[model_col].astype(str).str.strip() if model_col else "HEAVY EQUIPMENT"
    df["SWIFT_SITE"] = df[site_col].astype(str).str.strip() if site_col else "SITE-DEFAULT"

    # Standarisasi Kondisi Visual (Condition)
    if cond_col and cond_col in df.columns:
        df["SWIFT_CONDITION"] = df[cond_col].astype(str).str.strip().replace({"nan": "-", "None": "-", "": "-"})
    else:
        df["SWIFT_CONDITION"] = "-"

    # Posisi Komponen
    if pos_col and side_col and pos_col in df.columns and side_col in df.columns:
        df["SWIFT_POSITION"] = (df[side_col].astype(str).str.strip() + " " + df[pos_col].astype(str).str.strip()).str.strip()
    elif pos_col and pos_col in df.columns:
        df["SWIFT_POSITION"] = df[pos_col].astype(str).str.strip()
    elif side_col and side_col in df.columns:
        df["SWIFT_POSITION"] = df[side_col].astype(str).str.strip()
    else:
        df["SWIFT_POSITION"] = "-"
    df["SWIFT_POSITION"] = df["SWIFT_POSITION"].replace({"nan": "-", "None": "-", "nan nan": "-"})

    df["SWIFT_INSPECT_DATE"] = df["_PARSED_DATE"].dt.date.fillna(today)

    # SMU
    if smu_col and smu_col in df.columns:
        df["SWIFT_SMU"] = pd.to_numeric(df[smu_col], errors="coerce").fillna(0.0)
    else:
        df["SWIFT_SMU"] = 0.0

    # Wear %
    if wear_col and wear_col in df.columns:
        wear_series = df[wear_col].astype(str).str.replace("%", "").str.strip()
        df["SWIFT_WEAR_PCT"] = pd.to_numeric(wear_series, errors="coerce").fillna(0.0)
    else:
        init_c = detected.get("initial_dimension")
        curr_c = detected.get("current_dimension")
        lim_c = detected.get("limit_dimension")
        if init_c and curr_c and lim_c:
            init_v = pd.to_numeric(df[init_c], errors="coerce")
            curr_v = pd.to_numeric(df[curr_c], errors="coerce")
            lim_v = pd.to_numeric(df[lim_c], errors="coerce")
            denom = (init_v - lim_v).abs()
            num = (init_v - curr_v).abs()
            df["SWIFT_WEAR_PCT"] = np.round(np.where(denom > 0, (num / denom) * 100.0, 0.0), 2)
        else:
            df["SWIFT_WEAR_PCT"] = 0.0
    df["SWIFT_WEAR_PCT"] = df["SWIFT_WEAR_PCT"].clip(lower=0.0)

    # Wear Rate & RUL
    default_lifetime_hours = 3000.0
    assumed_rate = 100.0 / default_lifetime_hours
    rate_series = np.where(df["SWIFT_SMU"] > 50.0, df["SWIFT_WEAR_PCT"] / df["SWIFT_SMU"], assumed_rate)
    rate_series = np.where(rate_series <= 0.0001, assumed_rate, rate_series)
    df["SWIFT_WEAR_RATE_PER_HR"] = np.round(rate_series, 5)

    remaining_wear = (100.0 - df["SWIFT_WEAR_PCT"]).clip(lower=0.0)
    df["SWIFT_REMAINING_WEAR_PCT"] = np.round(remaining_wear, 1)

    if rem_hours_col and rem_hours_col in df.columns:
        cts_rem = pd.to_numeric(df[rem_hours_col], errors="coerce")
        calc_rul = remaining_wear / df["SWIFT_WEAR_RATE_PER_HR"]
        df["SWIFT_RUL_HOURS"] = np.round(np.where(cts_rem.notna() & (cts_rem >= 0), cts_rem, calc_rul), 1)
    else:
        calc_rul = np.where(df["SWIFT_WEAR_PCT"] >= 100.0, 0.0, remaining_wear / df["SWIFT_WEAR_RATE_PER_HR"])
        df["SWIFT_RUL_HOURS"] = np.round(calc_rul, 1)

    # 4b. Evaluasi Khusus Komponen Sprockets Berbasis 'Condition' (Khusus Unit 320 - 395)
    # Pada armada excavator Caterpillar 320 - 395, keausan sprockets dinilai secara visual (Good / Worn / Sharp)
    # tanpa adanya angka percent_worn di lembar inspeksi Caterpillar CTS.
    excavator_patterns = ["320", "323", "330", "336", "345", "349", "352", "374", "390", "395"]
    sprocket_updated_count = 0

    status_overrides = {}
    action_overrides = {}

    for idx, row in df.iterrows():
        comp_str = str(row["SWIFT_COMPONENT"]).lower()
        if "sprocket" in comp_str:
            model_str = str(row["SWIFT_MODEL"]).upper()
            unit_str = str(row["SWIFT_UNIT_ID"]).upper()
            cond_str = str(row["SWIFT_CONDITION"]).strip().lower()
            curr_wear = row["SWIFT_WEAR_PCT"]
            is_320_395 = any(p in model_str for p in excavator_patterns) or any(p in unit_str for p in excavator_patterns)

            if cond_str == "sharp":
                # Sharp = Gigi aus lancip / knife-edge = 100% wear limit tercapai (CRITICAL)
                new_wear = 100.0 if curr_wear < 100.0 else curr_wear
                df.at[idx, "SWIFT_WEAR_PCT"] = new_wear
                status_overrides[idx] = "CRITICAL"
                df.at[idx, "SWIFT_RUL_HOURS"] = 0.0
                df.at[idx, "SWIFT_REMAINING_WEAR_PCT"] = 0.0
                action_overrides[idx] = "Sprocket aus tajam (Sharp). Segera jadwalkan penggantian suku cadang & safety stop (limit tercapai)."
                sprocket_updated_count += 1
            elif cond_str == "worn":
                # Worn = Gigi terindikasi aus kantong / pocket wear = 85% wear (WARNING)
                new_wear = 85.0 if (curr_wear == 0.0 or curr_wear < 80.0) else curr_wear
                df.at[idx, "SWIFT_WEAR_PCT"] = new_wear
                status_overrides[idx] = "WARNING"
                if df.at[idx, "SWIFT_RUL_HOURS"] > 350.0 or df.at[idx, "SWIFT_RUL_HOURS"] == 0.0:
                    df.at[idx, "SWIFT_RUL_HOURS"] = 250.0
                df.at[idx, "SWIFT_REMAINING_WEAR_PCT"] = round(100.0 - new_wear, 1)
                action_overrides[idx] = "Sprocket terindikasi aus (Worn). Buat Work Order penggantian & amankan ketersediaan stok spare part (PR/PO)."
                sprocket_updated_count += 1
            elif cond_str == "good":
                # Good = Kondisi prima / aus wajar = 25% wear (NORMAL)
                if curr_wear == 0.0:
                    df.at[idx, "SWIFT_WEAR_PCT"] = 25.0
                    status_overrides[idx] = "NORMAL"
                    df.at[idx, "SWIFT_RUL_HOURS"] = 2500.0
                    df.at[idx, "SWIFT_REMAINING_WEAR_PCT"] = 75.0
                    action_overrides[idx] = "Kondisi sprocket baik (Good). Lanjutkan operasional dan pemantauan rutin."
                sprocket_updated_count += 1
            elif cond_str in ["broken", "missing", "cracked"]:
                df.at[idx, "SWIFT_WEAR_PCT"] = 100.0
                status_overrides[idx] = "CRITICAL"
                df.at[idx, "SWIFT_RUL_HOURS"] = 0.0
                df.at[idx, "SWIFT_REMAINING_WEAR_PCT"] = 0.0
                action_overrides[idx] = f"Sprocket {cond_str.title()}. Segera jadwalkan penggantian unit & safety stop."
                sprocket_updated_count += 1
            elif cond_str in ["abnormal wear"]:
                new_wear = 85.0 if curr_wear < 80.0 else curr_wear
                df.at[idx, "SWIFT_WEAR_PCT"] = new_wear
                status_overrides[idx] = "WARNING"
                df.at[idx, "SWIFT_RUL_HOURS"] = 250.0
                df.at[idx, "SWIFT_REMAINING_WEAR_PCT"] = 15.0
                action_overrides[idx] = "Sprocket aus abnormal. Lakukan inspeksi visual menyeluruh & monitor pitch."
                sprocket_updated_count += 1
            elif is_320_395 and curr_wear == 0.0:
                df.at[idx, "SWIFT_WEAR_PCT"] = 20.0
                status_overrides[idx] = "NORMAL"
                df.at[idx, "SWIFT_RUL_HOURS"] = 2500.0
                df.at[idx, "SWIFT_REMAINING_WEAR_PCT"] = 80.0
                action_overrides[idx] = "Kondisi visual belum tercatat. Jadwalkan inspeksi visual pada jadwal servis."
                sprocket_updated_count += 1

    if sprocket_updated_count > 0:
        log_msg(callback, f"  -> Evaluasi Sprockets Berbasis Kondisi: {sprocket_updated_count} sprocket unit 320-395 dievaluasi.")

    # Forecast Replacement Date
    daily_hrs = float(daily_operating_hours) if daily_operating_hours and float(daily_operating_hours) > 0 else 16.0
    days_to_change = np.ceil(df["SWIFT_RUL_HOURS"] / daily_hrs)

    cts_dates = None
    if proj_date_col and proj_date_col in df.columns:
        cts_dates = pd.to_datetime(df[proj_date_col], errors="coerce").dt.date

    forecast_dates = []
    for idx, row in df.reset_index(drop=True).iterrows():
        b_date = row["SWIFT_INSPECT_DATE"]
        if cts_dates is not None and pd.notna(cts_dates.iloc[idx]) and row["SWIFT_WEAR_PCT"] < 100.0:
            forecast_dates.append(cts_dates.iloc[idx])
        elif row["SWIFT_WEAR_PCT"] >= 100.0:
            forecast_dates.append(b_date)
        else:
            d = int(days_to_change.iloc[idx])
            try:
                forecast_dates.append(b_date + datetime.timedelta(days=max(0, min(d, 3650))))
            except Exception:
                forecast_dates.append(b_date + datetime.timedelta(days=365))
    df["SWIFT_FORECAST_DATE"] = forecast_dates

    # Severity Classification
    crit_wear = getattr(config, 'DEFAULT_SWIFT_CRITICAL_WEAR', 100.0)
    warn_wear = getattr(config, 'DEFAULT_SWIFT_WARNING_WEAR', 80.0)
    attn_wear = getattr(config, 'DEFAULT_SWIFT_ATTENTION_WEAR', 60.0)
    crit_rul = getattr(config, 'DEFAULT_SWIFT_CRITICAL_RUL', 150.0)
    warn_rul = getattr(config, 'DEFAULT_SWIFT_WARNING_RUL', 350.0)

    conds = [
        (df["SWIFT_WEAR_PCT"] >= crit_wear) | (df["SWIFT_RUL_HOURS"] <= crit_rul),
        (df["SWIFT_WEAR_PCT"] >= warn_wear) | (df["SWIFT_RUL_HOURS"] <= warn_rul),
        (df["SWIFT_WEAR_PCT"] >= attn_wear),
    ]
    status_choices = ["CRITICAL", "WARNING", "ATTENTION"]
    action_choices = [
        "Segera jadwalkan penggantian unit & safety stop (Sudah mencapai limit).",
        "Buat Work Order penggantian & amankan ketersediaan stok spare part (PR/PO).",
        "Tingkatkan frekuensi pemantauan keausan pada jadwal inspeksi berikutnya.",
    ]
    df["SWIFT_STATUS"] = np.select(conds, status_choices, default="NORMAL")

    if recom_col and recom_col in df.columns:
        cts_recom = df[recom_col].astype(str).str.strip()
        has_custom = (cts_recom != "") & (cts_recom.str.lower() != "nan") & (cts_recom.str.lower() != "none")
        default_recom = np.select(conds, action_choices, default="Kondisi prima. Lanjutkan operasional rutin.")
        df["SWIFT_RECOMMENDED_ACTION"] = np.where(has_custom, cts_recom, default_recom)
    else:
        df["SWIFT_RECOMMENDED_ACTION"] = np.select(conds, action_choices, default="Kondisi prima. Lanjutkan operasional rutin.")

    # Terapkan Override Status & Rekomendasi dari Evaluasi Sprocket jika ada
    if status_overrides:
        for s_idx, st_val in status_overrides.items():
            df.at[s_idx, "SWIFT_STATUS"] = st_val
    if action_overrides:
        for a_idx, act_val in action_overrides.items():
            df.at[a_idx, "SWIFT_RECOMMENDED_ACTION"] = act_val

    if pic_col and pic_col in df.columns:
        df["SWIFT_PIC"] = df[pic_col].astype(str).str.strip().replace({"nan": "Unassigned", "": "Unassigned"})
    else:
        df["SWIFT_PIC"] = "Unassigned"

    # Buat Komposit Key Unik untuk PostgREST Upsert (id)
    comp_clean = df["SWIFT_COMPONENT"].astype(str).str.replace(r'[^A-Za-z0-9]', '_', regex=True).str.strip('_')
    pos_clean = df["SWIFT_POSITION"].astype(str).str.replace(r'[^A-Za-z0-9]', '_', regex=True).str.strip('_')
    df["SWIFT_COMP_ID"] = (df["SWIFT_UNIT_ID"].astype(str) + "_" + comp_clean + "_" + pos_clean).str.upper()

    # Summary Statistics
    total_records = len(df)
    total_units = df["SWIFT_UNIT_ID"].nunique()
    cnt_crit = int((df["SWIFT_STATUS"] == "CRITICAL").sum())
    cnt_warn = int((df["SWIFT_STATUS"] == "WARNING").sum())
    cnt_attn = int((df["SWIFT_STATUS"] == "ATTENTION").sum())
    cnt_norm = int((df["SWIFT_STATUS"] == "NORMAL").sum())
    avg_wear = float(np.round(df["SWIFT_WEAR_PCT"].mean(), 1)) if total_records > 0 else 0.0

    sprocket_mask = df["SWIFT_COMPONENT"].astype(str).str.lower().str.contains("sprocket")
    count_sprocket_total = int(sprocket_mask.sum())
    count_sprocket_sharp = int((sprocket_mask & (df["SWIFT_CONDITION"].astype(str).str.lower() == "sharp")).sum())
    count_sprocket_worn = int((sprocket_mask & (df["SWIFT_CONDITION"].astype(str).str.lower() == "worn")).sum())
    count_sprocket_good = int((sprocket_mask & (df["SWIFT_CONDITION"].astype(str).str.lower() == "good")).sum())

    summary_stats = {
        "total_records": total_records,
        "total_raw_rows": total_raw_rows,
        "total_units": total_units,
        "critical": cnt_crit,
        "warning": cnt_warn,
        "attention": cnt_attn,
        "normal": cnt_norm,
        "high_priority_total": cnt_crit + cnt_warn,
        "avg_wear_pct": avg_wear,
        "mep_metrics": mep_metrics,
        "sprocket_total": count_sprocket_total,
        "sprocket_sharp": count_sprocket_sharp,
        "sprocket_worn": count_sprocket_worn,
        "sprocket_good": count_sprocket_good,
        "last_sync_time": time.strftime("%d-%b-%Y %H:%M")
    }

    log_msg(callback, f"[5/5] Kalkulasi Selesai: {total_records:,} Komponen ({total_units} Unit). 🔴 Kritis: {cnt_crit}, 🟡 Warning: {cnt_warn}, 🟢 Normal: {cnt_norm}")
    return df, summary_stats


# =============================================================================
# 5. LOCAL EXPORTERS (EXCEL & JSON)
# =============================================================================
def export_swift_excel(df_proc, summary_stats, output_dir, callback=None):
    """Menyusun Executive Multi-Sheet Excel Report menggunakan openpyxl."""
    os.makedirs(output_dir, exist_ok=True)
    today_str = datetime.date.today().strftime("%d%m%Y")
    report_filename = f"SWIFT_Executive_Wear_Report_{today_str}.xlsx"
    report_path = os.path.join(output_dir, report_filename)

    log_msg(callback, f"Menyusun Executive Excel Report di: {report_path}...")
    wb = openpyxl.Workbook()
    thin_border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )

    # Sheet 1: Executive KPI Dashboard
    ws_dash = wb.active
    ws_dash.title = "Executive Summary"
    ws_dash.views.sheetView[0].showGridLines = True

    # Title Banner
    ws_dash.merge_cells("A1:G1")
    cell_title = ws_dash["A1"]
    cell_title.value = "SWIFT — SMART WEAR INDICATOR & FLEET FORECASTING"
    cell_title.font = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    cell_title.fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    cell_title.alignment = Alignment(horizontal="center", vertical="center")
    ws_dash.row_dimensions[1].height = 36

    # KPI Metrics Table
    kpis = [
        ("Total Armada Terpantau", f"{summary_stats['total_units']} Unit"),
        ("Total Komponen Aktif", f"{summary_stats['total_records']:,} Komponen"),
        ("Komponen Status CRITICAL (>=100% / RUL <=150h)", f"{summary_stats['critical']} Komponen"),
        ("Komponen Status WARNING (80-99% / RUL <=350h)", f"{summary_stats['warning']} Komponen"),
        ("Komponen Status ATTENTION (60-79%)", f"{summary_stats['attention']} Komponen"),
        ("Komponen Status NORMAL (<60%)", f"{summary_stats['normal']} Komponen"),
        ("Indeks Rata-Rata Keausan Armada", f"{summary_stats['avg_wear_pct']}%"),
        ("Waktu Sinkronisasi Terakhir", summary_stats['last_sync_time']),
    ]
    ws_dash["A3"] = "INDIKATOR KUNCI (KEY PERFORMANCE INDICATORS)"
    ws_dash["A3"].font = Font(name="Segoe UI", size=11, bold=True, color="1E3A8A")

    for idx, (label, val) in enumerate(kpis, start=4):
        ws_dash[f"B{idx}"] = label
        ws_dash[f"C{idx}"] = val
        ws_dash[f"B{idx}"].font = Font(name="Segoe UI", size=10, bold=(idx in [4, 6, 7]))
        ws_dash[f"C{idx}"].font = Font(name="Segoe UI", size=10, bold=True)
        ws_dash[f"B{idx}"].border = thin_border
        ws_dash[f"C{idx}"].border = thin_border
        if "CRITICAL" in label:
            ws_dash[f"C{idx}"].fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
            ws_dash[f"C{idx}"].font = Font(name="Segoe UI", size=10, bold=True, color="991B1B")
        elif "WARNING" in label:
            ws_dash[f"C{idx}"].fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
            ws_dash[f"C{idx}"].font = Font(name="Segoe UI", size=10, bold=True, color="92400E")

    # Sheet 2: High Priority Action List
    ws_crit = wb.create_sheet(title="Priority Action List")
    ws_crit.views.sheetView[0].showGridLines = True
    crit_cols = [
        "Unit ID", "Model", "Site", "Komponen", "Posisi", "Kondisi Visual", "Wear %",
        "RUL (Jam)", "Tgl Proyeksi Ganti", "Severity Status", "Rekomendasi Tindakan", "PIC"
    ]
    for col_idx, h in enumerate(crit_cols, start=1):
        cell = ws_crit.cell(row=1, column=col_idx, value=h)
        cell.font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="DC2626", end_color="DC2626", fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws_crit.row_dimensions[1].height = 28

    df_priority = df_proc[df_proc["SWIFT_STATUS"].isin(["CRITICAL", "WARNING"])].sort_values(by=["SWIFT_WEAR_PCT"], ascending=False)
    for row_idx, (_, r) in enumerate(df_priority.iterrows(), start=2):
        cond_val = r.get("SWIFT_CONDITION", "-") if pd.notna(r.get("SWIFT_CONDITION")) else "-"
        vals = [
            r["SWIFT_UNIT_ID"], r["SWIFT_MODEL"], r["SWIFT_SITE"], r["SWIFT_COMPONENT"], r["SWIFT_POSITION"],
            cond_val, f"{r['SWIFT_WEAR_PCT']:.1f}%", f"{r['SWIFT_RUL_HOURS']:.1f}", str(r["SWIFT_FORECAST_DATE"]),
            r["SWIFT_STATUS"], r["SWIFT_RECOMMENDED_ACTION"], r["SWIFT_PIC"]
        ]
        for c_idx, v in enumerate(vals, start=1):
            c = ws_crit.cell(row=row_idx, column=c_idx, value=v)
            c.font = Font(name="Segoe UI", size=9)
            c.border = thin_border
            if c_idx == 10:
                bg = "FEE2E2" if v == "CRITICAL" else "FEF3C7"
                fg = "991B1B" if v == "CRITICAL" else "92400E"
                c.fill = PatternFill(start_color=bg, end_color=bg, fill_type="solid")
                c.font = Font(name="Segoe UI", size=9, bold=True, color=fg)

    # Sheet 3: Complete Forecast Database
    ws_all = wb.create_sheet(title="All Components Forecast")
    ws_all.views.sheetView[0].showGridLines = True
    all_cols = [
        "Unit ID", "Model", "Site", "Komponen", "Posisi", "Kondisi Visual", "Tgl Inspeksi", "SMU/HM",
        "Wear %", "Wear Rate (/Hr)", "Sisa Wear %", "RUL (Jam)", "Tgl Ganti", "Status", "Rekomendasi", "PIC"
    ]
    for col_idx, h in enumerate(all_cols, start=1):
        cell = ws_all.cell(row=1, column=col_idx, value=h)
        cell.font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws_all.row_dimensions[1].height = 28

    for row_idx, (_, r) in enumerate(df_proc.iterrows(), start=2):
        cond_val = r.get("SWIFT_CONDITION", "-") if pd.notna(r.get("SWIFT_CONDITION")) else "-"
        vals = [
            r["SWIFT_UNIT_ID"], r["SWIFT_MODEL"], r["SWIFT_SITE"], r["SWIFT_COMPONENT"], r["SWIFT_POSITION"],
            cond_val, str(r["SWIFT_INSPECT_DATE"]), r["SWIFT_SMU"], r["SWIFT_WEAR_PCT"], r["SWIFT_WEAR_RATE_PER_HR"],
            r["SWIFT_REMAINING_WEAR_PCT"], r["SWIFT_RUL_HOURS"], str(r["SWIFT_FORECAST_DATE"]),
            r["SWIFT_STATUS"], r["SWIFT_RECOMMENDED_ACTION"], r["SWIFT_PIC"]
        ]
        for c_idx, v in enumerate(vals, start=1):
            c = ws_all.cell(row=row_idx, column=c_idx, value=v)
            c.font = Font(name="Segoe UI", size=9)
            c.border = thin_border

    # Auto-adjust column widths
    for sheet in [ws_dash, ws_crit, ws_all]:
        for col in sheet.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                val = str(cell.value or "")
                max_len = max(max_len, len(val))
            sheet.column_dimensions[col_letter].width = max(max_len + 3, 12)

    wb.save(report_path)
    log_msg(callback, f"Laporan Excel berhasil dibuat: {report_filename}")
    return report_path


def export_swift_json(df_proc, summary_stats, output_dir, callback=None):
    """Menyimpan data JSON lokal dan menyelaraskan ke web_visualizer jika tersedia."""
    os.makedirs(output_dir, exist_ok=True)
    json_path = os.path.join(output_dir, "swift_latest.json")

    def _json_serial(o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return str(o)

    cols = [
        "SWIFT_COMP_ID", "SWIFT_UNIT_ID", "SWIFT_MODEL", "SWIFT_SITE", "SWIFT_COMPONENT",
        "SWIFT_POSITION", "SWIFT_CONDITION", "SWIFT_INSPECT_DATE", "SWIFT_SMU", "SWIFT_WEAR_PCT",
        "SWIFT_WEAR_RATE_PER_HR", "SWIFT_REMAINING_WEAR_PCT", "SWIFT_RUL_HOURS",
        "SWIFT_FORECAST_DATE", "SWIFT_STATUS", "SWIFT_RECOMMENDED_ACTION", "SWIFT_PIC", "SWIFT_CATEGORY"
    ]
    cols = [c for c in cols if c in df_proc.columns]
    records = df_proc[cols].to_dict(orient="records")
    payload = {
        "summary": summary_stats,
        "records": records
    }

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, default=_json_serial, indent=2)
    log_msg(callback, f"File JSON lokal tersimpan: {os.path.basename(json_path)}")

    # Update web_visualizer/fleet_data.js jika direktori proyek SWIFT ada
    web_vis_dir = os.path.join(os.path.dirname(config.BASE_DIR), "SWIFT", "web_visualizer")
    if os.path.exists(web_vis_dir):
        fleet_js = os.path.join(web_vis_dir, "fleet_data.js")
        try:
            bundle = {
                "all_fleet": {
                    "id": "all_fleet",
                    "title": f"Seluruh Armada Sitarum BMB ({summary_stats.get('total_units', len(set(r.get('SWIFT_UNIT_ID') for r in records)))} Unit)",
                    "summary": summary_stats,
                    "records": records
                },
                "mep_fleet": {
                    "id": "mep_fleet",
                    "title": "Armada MEP Prioritas",
                    "summary": summary_stats,
                    "records": records
                }
            }
            with open(fleet_js, "w", encoding="utf-8") as f:
                f.write("// SWIFT Web Visualizer - Preloaded Fleet Datasets (Auto-synced by Kermen Tools)\n")
                f.write("window.SWIFT_DATASETS = ")
                json.dump(bundle, f, default=_json_serial, indent=2)
                f.write(";\n")
            log_msg(callback, "Web Visualizer (fleet_data.js) berhasil diselaraskan otomatis!")
        except Exception as e:
            log_msg(callback, f"Catatan: Penyelarasan fleet_data.js dilewati: {e}")

    return json_path


# =============================================================================
# 6. SUPABASE CLOUD REST API INTEGRATION (UPSERT)
# =============================================================================
def _get_supabase_session():
    """Membuat requests session dengan preferensi IPv4 untuk koneksi stabil di Windows."""
    import socket
    if not getattr(_get_supabase_session, "_patched", False):
        orig_getaddrinfo = socket.getaddrinfo
        def _ipv4_first_getaddrinfo(*args, **kwargs):
            try:
                res = orig_getaddrinfo(*args, **kwargs)
                v4 = [r for r in res if r[0] == socket.AF_INET]
                return v4 if v4 else res
            except Exception:
                return orig_getaddrinfo(*args, **kwargs)
        socket.getaddrinfo = _ipv4_first_getaddrinfo
        _get_supabase_session._patched = True

    session = requests.Session()
    adapter = requests.adapters.HTTPAdapter(max_retries=3)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def test_supabase_connection(supabase_url, supabase_key):
    """Menguji koneksi ke Supabase REST API endpoint."""
    if not supabase_url or not supabase_key:
        return False, "URL atau API Key Supabase belum diisi."

    url = supabase_url.strip().rstrip('/')
    if not url.startswith('http'):
        url = f"https://{url}"

    headers = {
        "apikey": supabase_key.strip(),
        "Authorization": f"Bearer {supabase_key.strip()}"
    }

    try:
        session = _get_supabase_session()
        resp = session.get(f"{url}/rest/v1/", headers=headers, timeout=12)
        if resp.status_code in (200, 204):
            return True, "Koneksi Supabase berhasil terhubung!"
        elif resp.status_code == 401:
            return False, "Autentikasi gagal (HTTP 401): API Key tidak valid. Salin seluruh karakter Anon / Service Role key."
        elif resp.status_code == 404:
            return True, "Server Supabase merespons (Status 404 pada root schema, namun REST API aktif)."
        else:
            return False, f"Server merespons status {resp.status_code}: {resp.text[:120]}"
    except requests.exceptions.RequestException as e:
        return False, f"Gagal menghubungi Supabase: {str(e)}"


def upload_swift_to_supabase(
    supabase_url,
    supabase_key,
    table_components,
    table_kpi,
    df_proc,
    summary_stats,
    callback=None,
    chunk_size=200
):
    """
    Mengunggah dataset komponen armada & ringkasan KPI ke Supabase via PostgREST REST API.
    """
    if not supabase_url or not supabase_key:
        log_msg(callback, "⚠️ Supabase URL / Key kosong, upload cloud dilewati.")
        return False

    url = supabase_url.strip().rstrip('/')
    if not url.startswith('http'):
        url = f"https://{url}"

    headers = {
        "apikey": supabase_key.strip(),
        "Authorization": f"Bearer {supabase_key.strip()}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates,return=minimal"
    }

    session = _get_supabase_session()

    # 1. Upload KPI Summary (id = 1)
    kpi_tbl = table_kpi.strip() if table_kpi else "swift_kpi"
    try:
        log_msg(callback, f"Mengunggah ringkasan KPI ke Supabase ({kpi_tbl})...")
        kpi_payload = [{
            "id": 1,
            "total_units": int(summary_stats.get("total_units", 0)),
            "total_components": int(summary_stats.get("total_records", 0)),
            "critical_count": int(summary_stats.get("critical", 0)),
            "warning_count": int(summary_stats.get("warning", 0)),
            "attention_count": int(summary_stats.get("attention", 0)),
            "normal_count": int(summary_stats.get("normal", 0)),
            "high_priority_total": int(summary_stats.get("high_priority_total", 0)),
            "avg_wear_pct": float(summary_stats.get("avg_wear_pct", 0.0)),
            "last_sync_time": str(summary_stats.get("last_sync_time", time.strftime("%d-%b-%Y %H:%M"))),
        }]
        resp_kpi = session.post(f"{url}/rest/v1/{kpi_tbl}", headers=headers, json=kpi_payload, timeout=25)
        if resp_kpi.status_code in (200, 201, 204):
            log_msg(callback, "  -> KPI Executive berhasil disinkronisasi ke Supabase!")
        else:
            log_msg(callback, f"  ⚠️ Gagal upload KPI (HTTP {resp_kpi.status_code}): {resp_kpi.text[:120]}")
    except Exception as e_kpi:
        log_msg(callback, f"  ⚠️ Error upload KPI ke Supabase: {e_kpi}")

    # 2. Upload Detail Komponen (Chunked Upsert)
    comp_tbl = table_components.strip() if table_components else "swift_components"
    endpoint_comp = f"{url}/rest/v1/{comp_tbl}"

    supabase_rows = []
    for _, r in df_proc.iterrows():
        inspect_d = str(r["SWIFT_INSPECT_DATE"]) if pd.notna(r["SWIFT_INSPECT_DATE"]) else None
        forecast_d = str(r["SWIFT_FORECAST_DATE"]) if pd.notna(r["SWIFT_FORECAST_DATE"]) else None
        supabase_rows.append({
            "id": str(r["SWIFT_COMP_ID"]),
            "unit_id": str(r["SWIFT_UNIT_ID"]),
            "model": str(r["SWIFT_MODEL"]),
            "site": str(r["SWIFT_SITE"]),
            "component_name": str(r["SWIFT_COMPONENT"]),
            "position": str(r["SWIFT_POSITION"]),
            "condition": str(r.get("SWIFT_CONDITION", "-")) if pd.notna(r.get("SWIFT_CONDITION")) else "-",
            "inspect_date": inspect_d,
            "smu_hours": float(r["SWIFT_SMU"]) if pd.notna(r["SWIFT_SMU"]) else 0.0,
            "wear_pct": float(r["SWIFT_WEAR_PCT"]) if pd.notna(r["SWIFT_WEAR_PCT"]) else 0.0,
            "wear_rate_per_hr": float(r["SWIFT_WEAR_RATE_PER_HR"]) if pd.notna(r["SWIFT_WEAR_RATE_PER_HR"]) else 0.0,
            "remaining_wear_pct": float(r["SWIFT_REMAINING_WEAR_PCT"]) if pd.notna(r["SWIFT_REMAINING_WEAR_PCT"]) else 0.0,
            "rul_hours": float(r["SWIFT_RUL_HOURS"]) if pd.notna(r["SWIFT_RUL_HOURS"]) else 0.0,
            "forecast_date": forecast_d,
            "severity_status": str(r["SWIFT_STATUS"]),
            "recommended_action": str(r["SWIFT_RECOMMENDED_ACTION"]),
            "pic_responsible": str(r["SWIFT_PIC"]),
            "category": str(r.get("SWIFT_CATEGORY", "UNDERCARRIAGE")),
        })

    total = len(supabase_rows)
    log_msg(callback, f"Mengunggah {total:,} data komponen ke Supabase ({comp_tbl}) dalam batch @{chunk_size}...")

    success_count = 0
    fail_count = 0
    for i in range(0, total, chunk_size):
        chunk = supabase_rows[i:i + chunk_size]
        try:
            resp = session.post(endpoint_comp, headers=headers, json=chunk, timeout=30)
            if resp.status_code in (200, 201, 204):
                success_count += len(chunk)
                pct = (success_count / total) * 100
                log_msg(callback, f"  ☁️ Supabase Upload: {success_count:,}/{total:,} baris ({pct:.0f}%)...")
            else:
                fail_count += len(chunk)
                log_msg(callback, f"  ⚠️ Gagal upload chunk {i//chunk_size + 1} (HTTP {resp.status_code}): {resp.text[:120]}")
        except Exception as e_chunk:
            fail_count += len(chunk)
            log_msg(callback, f"  ⚠️ Exception upload chunk {i//chunk_size + 1}: {e_chunk}")

    log_msg(callback, f"Sinkronisasi Cloud Selesai! Berhasil: {success_count:,}, Gagal: {fail_count:,}.")
    return success_count > 0
