"""
coupling_helper.py
Modul mesin pencarian spesifikasi coupling Caterpillar (CAT) untuk KermenX Suite.
Mendukung Single Search (detail + diagram WebP) dan Multiple/Batch Search (input dinamis + ekspor Excel resmi).
Versi 3: Enriched PECP5030-11 Ed. 11.2 (Smart Code, Coupling Type, Series, Category, Angle, Connector Dash, Thread & Head Size, O-Ring Seal).
"""
import os
import sys
import re
import sqlite3
import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(CURRENT_DIR)
ROOT_DIR = os.path.dirname(PARENT_DIR)


def find_db_path() -> str:
    """Mencari lokasi cat_couplings.db dari beberapa kemungkinan direktori"""
    candidates = [
        os.path.join(PARENT_DIR, "assets", "couplings", "cat_couplings.db"),
        os.path.join(CURRENT_DIR, "assets", "couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "KermenX", "engine", "assets", "couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "KermenX_Csharp", "Assets", "Couplings", "cat_couplings.db"),
        os.path.join(ROOT_DIR, "AndroHeld_Google", "app", "src", "main", "assets", "cat_couplings.db"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return os.path.abspath(p)
    return ""


def find_images_dir() -> str:
    """Mencari lokasi folder coupling_images"""
    candidates = [
        os.path.join(PARENT_DIR, "assets", "couplings", "images"),
        os.path.join(CURRENT_DIR, "assets", "couplings", "images"),
        os.path.join(ROOT_DIR, "KermenX", "engine", "assets", "couplings", "images"),
        os.path.join(ROOT_DIR, "KermenX_Csharp", "Assets", "Couplings", "images"),
        os.path.join(ROOT_DIR, "AndroHeld_Google", "app", "src", "main", "assets", "coupling_images"),
    ]
    for p in candidates:
        if os.path.exists(p) and os.path.isdir(p):
            return os.path.abspath(p)
    return ""


def clean_pn(raw: str) -> str:
    """Membersihkan string part number: buang suffix batch SAP (:AA, :01), spasi, tanda minus, uppercase"""
    if not raw:
        return ""
    val = str(raw).strip()
    # 1. Buang suffix batch SAP (misal :AA, :01, :BB)
    if ":" in val:
        val = val.split(":")[0].strip()
    # 2. Buang suffix slash jika bukan fraksi inch (misal /01 atau /A)
    if "/" in val and not re.match(r"^[0-9]+/[0-9]+", val):
        val = val.split("/")[0].strip()
    # 3. Buang karakter non-alphanumeric selain teks inti
    return val.replace("-", "").replace(" ", "").replace(".", "").upper()


def generate_pn_variants(raw: str) -> list:
    """Menghasilkan variasi pencarian cerdas part number (toleransi leading zero dan variasi strip)"""
    cln = clean_pn(raw)
    if not cln:
        return []
    variants = [cln]

    # Hilangkan leading zero (misal 0016286 -> 16286)
    stripped = cln.lstrip("0")
    if stripped and stripped not in variants:
        variants.append(stripped)

    # Tambahkan leading zero standar Caterpillar (misal 16286 -> 0016286)
    if len(cln) < 7 and cln.isalnum():
        z7 = cln.zfill(7)
        if z7 not in variants:
            variants.append(z7)
    if stripped and len(stripped) < 7 and stripped.isalnum():
        z7_strip = stripped.zfill(7)
        if z7_strip not in variants:
            variants.append(z7_strip)

    return variants


def get_db_connection():
    db_path = find_db_path()
    if not db_path:
        raise FileNotFoundError("Berkas database 'cat_couplings.db' tidak ditemukan di direktori aset KermenX!")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def search_single_coupling(query: str) -> dict:
    """
    Pencarian fleksibel single part number, smart code, atau deskripsi fitting coupling.
    Mengembalikan data spesifikasi detail, gambar diagram, dan daftar equivalent parts.
    """
    raw_query = str(query or "").strip()
    if not raw_query:
        return {"found": False, "message": "Part Number atau kata kunci pencarian tidak boleh kosong."}

    conn = get_db_connection()
    cursor = conn.cursor()

    variants = generate_pn_variants(raw_query)
    rows = []

    # 1. Coba exact match ke seluruh varian Part Number atau Smart Code
    if variants:
        placeholders = ",".join(["?"] * len(variants))
        cursor.execute(f"""
            SELECT * FROM cat_couplings
            WHERE REPLACE(part_number, '-', '') IN ({placeholders})
               OR part_number = ?
               OR smart_code LIKE ?
            LIMIT 5
        """, (*variants, raw_query, f"%{raw_query}%"))
        rows = cursor.fetchall()

    # 2. Jika belum ketemu dan ada varian part number, coba prefix/substring LIKE
    if not rows and variants and len(variants[0]) >= 3:
        cursor.execute("""
            SELECT * FROM cat_couplings
            WHERE REPLACE(part_number, '-', '') LIKE ?
               OR smart_code LIKE ?
            LIMIT 5
        """, (f"{variants[0]}%", f"%{raw_query}%"))
        rows = cursor.fetchall()

    # 3. Jika belum ketemu, coba pencarian berbasis multi-kata kunci (Fitting Style, Smart Code, Category, Head Size)
    if not rows:
        cleaned_words = re.sub(r"[^a-zA-Z0-9/°]", " ", raw_query)
        keywords = [w.strip() for w in cleaned_words.split() if len(w.strip()) >= 2]
        if keywords:
            where_clauses = []
            params = []
            for kw in keywords:
                where_clauses.append("(smart_code LIKE ? OR fitting_style LIKE ? OR category LIKE ? OR head_or_thread_size LIKE ?)")
                params.extend([f"%{kw}%", f"%{kw}%", f"%{kw}%", f"%{kw}%"])
            where_sql = " AND ".join(where_clauses)
            cursor.execute(f"""
                SELECT * FROM cat_couplings
                WHERE {where_sql}
                LIMIT 5
            """, params)
            rows = cursor.fetchall()

    if not rows:
        conn.close()
        return {
            "found": False,
            "query": raw_query,
            "message": f"Part Number atau spesifikasi '{raw_query}' tidak ditemukan di katalog coupling Caterpillar."
        }

    # Ambil baris pertama sebagai hasil utama
    r = rows[0]
    img_dir = find_images_dir()
    diagram_filename = r["diagram_image"] or ""
    diagram_full_path = ""
    if diagram_filename and img_dir:
        cand_img = os.path.join(img_dir, diagram_filename)
        if os.path.exists(cand_img):
            diagram_full_path = cand_img

    item = {
        "id": r["id"],
        "part_number": r["part_number"],
        "smart_code": r["smart_code"] or "-",
        "coupling_type": r["coupling_type"] or "-",
        "series": r["series"] or "-",
        "category": r["category"] or "-",
        "angle_style": r["angle_style"] or "-",
        "pdf_page": r["pdf_page"],
        "catalog_page": r["catalog_page"],
        "section_title": r["section_title"] or "-",
        "fitting_style": r["fitting_style"] or "-",
        "hose_dash": r["hose_dash"] or "-",
        "connector_dash": r["connector_dash"] or "-",
        "hose_id_mm": r["hose_id_mm"],
        "hose_id_inch": r["hose_id_inch"] if r["hose_id_inch"] is not None else "-",
        "thread_size": r["thread_size"] or "-",
        "head_size": r["head_size"] or "-",
        "head_or_thread_size": r["head_or_thread_size"] or "-",
        "end_dash": r["end_dash"] or "-",
        "tube_od_mm": r["tube_od_mm"],
        "tube_od_inch": r["tube_od_inch"] if r["tube_od_inch"] is not None else "-",
        "length_b_mm": r["length_b_mm"],
        "length_b_inch": r["length_b_inch"],
        "cutoff_c_mm": r["cutoff_c_mm"],
        "cutoff_c_inch": r["cutoff_c_inch"],
        "drop_d_mm": r["drop_d_mm"],
        "drop_d_inch": r["drop_d_inch"],
        "mating_seal_pn": r["mating_seal_pn"] or "-",
        "diagram_image": diagram_filename,
        "diagram_image_path": diagram_full_path
    }

    # Cari equivalent parts (Dash & Head Size sama, PN berbeda)
    alternatives = []
    dash = r["hose_dash"]
    head = r["head_or_thread_size"]
    pn = r["part_number"]
    if dash and head and head != "-":
        cursor.execute("""
            SELECT part_number, smart_code, series, fitting_style, hose_dash, head_or_thread_size, cutoff_c_mm, drop_d_mm, mating_seal_pn
            FROM cat_couplings
            WHERE hose_dash = ? AND head_or_thread_size = ? AND part_number != ?
            GROUP BY part_number
            ORDER BY part_number ASC
            LIMIT 15
        """, (dash, head, pn))
        alt_rows = cursor.fetchall()
        for ar in alt_rows:
            alternatives.append({
                "part_number": ar["part_number"],
                "smart_code": ar["smart_code"] or "-",
                "series": ar["series"] or "-",
                "fitting_style": ar["fitting_style"] or "-",
                "hose_dash": ar["hose_dash"] or "-",
                "head_or_thread_size": ar["head_or_thread_size"] or "-",
                "cutoff_c_mm": ar["cutoff_c_mm"],
                "drop_d_mm": ar["drop_d_mm"],
                "mating_seal_pn": ar["mating_seal_pn"] or "-"
            })

    conn.close()

    return {
        "found": True,
        "query": raw_query,
        "item": item,
        "alternatives": alternatives,
        "total_matches": len(rows)
    }


def batch_search_couplings(pn_list: list) -> list:
    """
    Pencarian massal cerdas daftar part number (toleransi suffix SAP :AA, leading zero, dll).
    Mengembalikan list berisi spesifikasi lengkap atau status Tidak Ditemukan.
    """
    if not pn_list:
        return []

    conn = get_db_connection()
    cursor = conn.cursor()

    results = []
    for idx, raw_pn in enumerate(pn_list, start=1):
        raw_str = str(raw_pn or "").strip()
        variants = generate_pn_variants(raw_str)
        if not variants:
            continue

        row = None
        # 1. Coba exact match seluruh varian (dengan/tanpa leading zero, tanpa strip)
        placeholders = ",".join(["?"] * len(variants))
        cursor.execute(f"""
            SELECT part_number, smart_code, coupling_type, series, category, angle_style,
                   section_title, fitting_style, hose_dash, connector_dash, hose_id_inch,
                   thread_size, head_size, head_or_thread_size,
                   cutoff_c_mm, cutoff_c_inch, drop_d_mm, drop_d_inch,
                   length_b_mm, mating_seal_pn
            FROM cat_couplings
            WHERE REPLACE(part_number, '-', '') IN ({placeholders})
               OR part_number = ?
            LIMIT 1
        """, (*variants, raw_str))
        row = cursor.fetchone()

        # 2. Jika belum ketemu, coba prefix LIKE jika panjang karakter >= 4
        if not row and len(variants[0]) >= 4:
            cursor.execute("""
                SELECT part_number, smart_code, coupling_type, series, category, angle_style,
                       section_title, fitting_style, hose_dash, connector_dash, hose_id_inch,
                       thread_size, head_size, head_or_thread_size,
                       cutoff_c_mm, cutoff_c_inch, drop_d_mm, drop_d_inch,
                       length_b_mm, mating_seal_pn
                FROM cat_couplings
                WHERE REPLACE(part_number, '-', '') LIKE ?
                LIMIT 1
            """, (f"{variants[0]}%",))
            row = cursor.fetchone()

        if row:
            results.append({
                "no": idx,
                "input_pn": raw_str,
                "part_number": row["part_number"],
                "smart_code": row["smart_code"] or "-",
                "coupling_type": row["coupling_type"] or "-",
                "series": row["series"] or "-",
                "category": row["category"] or "-",
                "angle_style": row["angle_style"] or "-",
                "section_title": row["section_title"] or "-",
                "fitting_style": row["fitting_style"] or "-",
                "hose_dash": row["hose_dash"] or "-",
                "connector_dash": row["connector_dash"] or "-",
                "hose_id_inch": str(row["hose_id_inch"]) if row["hose_id_inch"] is not None else "-",
                "thread_size": row["thread_size"] or "-",
                "head_size": row["head_size"] or "-",
                "head_or_thread_size": row["head_or_thread_size"] or "-",
                "cutoff_c_mm": str(row["cutoff_c_mm"]) if row["cutoff_c_mm"] is not None else "-",
                "cutoff_c_inch": str(row["cutoff_c_inch"]) if row["cutoff_c_inch"] is not None else "-",
                "drop_d_mm": str(row["drop_d_mm"]) if row["drop_d_mm"] is not None else "-",
                "drop_d_inch": str(row["drop_d_inch"]) if row["drop_d_inch"] is not None else "-",
                "length_b_mm": str(row["length_b_mm"]) if row["length_b_mm"] is not None else "-",
                "mating_seal_pn": row["mating_seal_pn"] or "-",
                "status": "Ditemukan",
                "is_found": True
            })
        else:
            results.append({
                "no": idx,
                "input_pn": raw_str,
                "part_number": "-",
                "smart_code": "-",
                "coupling_type": "-",
                "series": "-",
                "category": "-",
                "angle_style": "-",
                "section_title": "-",
                "fitting_style": "-",
                "hose_dash": "-",
                "connector_dash": "-",
                "hose_id_inch": "-",
                "thread_size": "-",
                "head_size": "-",
                "head_or_thread_size": "-",
                "cutoff_c_mm": "-",
                "cutoff_c_inch": "-",
                "drop_d_mm": "-",
                "drop_d_inch": "-",
                "length_b_mm": "-",
                "mating_seal_pn": "-",
                "status": "Tidak Ditemukan",
                "is_found": False
            })

    conn.close()
    return results


def export_coupling_excel(items: list, output_dir: str = "") -> str:
    """
    Ekspor hasil batch search ke format Excel (.xlsx) resmi KermenX.
    Header Dark Navy #1E3A8A, font Segoe UI, borders rapi, zebra striping, dan kolom auto-fit.
    """
    if not output_dir or not os.path.exists(output_dir):
        output_dir = os.path.join(ROOT_DIR, "Output")
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"Katalog_Coupling_Batch_{timestamp}.xlsx"
    file_path = os.path.join(output_dir, filename)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Katalog Coupling CAT"

    # Style Definitions
    navy_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    accent_fill = PatternFill(start_color="3B82F6", end_color="3B82F6", fill_type="solid")
    zebra_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")

    font_banner = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=10, italic=True, color="E2E8F0")
    font_header = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    font_data = Font(name="Segoe UI", size=9.5, color="0F172A")
    font_cutoff = Font(name="Segoe UI", size=10, bold=True, color="1E3A8A")
    font_smart = Font(name="Segoe UI", size=9.5, bold=True, color="0284C7")
    font_found = Font(name="Segoe UI", size=9.5, bold=True, color="059669")
    font_not_found = Font(name="Segoe UI", size=9.5, bold=True, color="DC2626")

    align_center = Alignment(horizontal="center", vertical="center")
    align_left = Alignment(horizontal="left", vertical="center")
    align_right = Alignment(horizontal="right", vertical="center")

    thin_border_side = Side(border_style="thin", color="CBD5E1")
    thin_border = Border(left=thin_border_side, right=thin_border_side, top=thin_border_side, bottom=thin_border_side)

    # 1. Banner Header (Row 1-2)
    total_cols = 18
    last_col_letter = get_column_letter(total_cols)
    ws.merge_cells(f"A1:{last_col_letter}1")
    banner_cell = ws["A1"]
    banner_cell.value = "KATALOG SPESIFIKASI COUPLING CATERPILLAR (CAT) - PECP5030-11 ED. 11.2"
    banner_cell.font = font_banner
    banner_cell.fill = navy_fill
    banner_cell.alignment = align_center
    ws.row_dimensions[1].height = 34

    ws.merge_cells(f"A2:{last_col_letter}2")
    sub_cell = ws["A2"]
    now_str = datetime.datetime.now().strftime("%d %b %Y %H:%M WIB")
    found_count = sum(1 for it in items if it.get("is_found", False))
    sub_cell.value = f"Total Part: {len(items)} Item | Ditemukan: {found_count} | Tidak Ditemukan: {len(items) - found_count} | Waktu Ekspor: {now_str}"
    sub_cell.font = font_sub
    sub_cell.fill = navy_fill
    sub_cell.alignment = align_center
    ws.row_dimensions[2].height = 22

    # Row 3 kosong pemisah
    ws.row_dimensions[3].height = 10

    # 2. Table Headers (Row 4)
    headers = [
        "No", "Input PN", "Part Number Resmi", "Smart Code", "Tipe Coupling",
        "Series", "Kategori / Family", "Sudut / Bentuk", "Hose Dash", "Conn Dash",
        "Hose ID (Inch)", "Thread Size", "Flange Head Size",
        "Cutoff C (mm)", "Drop D (mm)", "Length B (mm)", "Mating Seal PN", "Status"
    ]
    ws.row_dimensions[4].height = 26

    for col_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=col_idx, value=h)
        cell.font = font_header
        cell.fill = accent_fill
        cell.alignment = align_center
        cell.border = thin_border

    # 3. Data Rows (Row 5+)
    for row_idx, itm in enumerate(items, start=5):
        ws.row_dimensions[row_idx].height = 20
        is_even = (row_idx % 2 == 0)
        curr_fill = zebra_fill if is_even else white_fill

        is_found = itm.get("is_found", False)
        status_text = "Ditemukan" if is_found else "Tidak Ditemukan"

        row_values = [
            itm.get("no", row_idx - 4),
            itm.get("input_pn", "-"),
            itm.get("part_number", "-"),
            itm.get("smart_code", "-"),
            itm.get("coupling_type", "-"),
            itm.get("series", "-"),
            itm.get("category", itm.get("section_title", "-")),
            itm.get("angle_style", "-"),
            itm.get("hose_dash", "-"),
            itm.get("connector_dash", "-"),
            itm.get("hose_id_inch", "-"),
            itm.get("thread_size", "-"),
            itm.get("head_size", "-"),
            itm.get("cutoff_c_mm", "-"),
            itm.get("drop_d_mm", "-"),
            itm.get("length_b_mm", "-"),
            itm.get("mating_seal_pn", "-"),
            status_text
        ]

        for col_idx, val in enumerate(row_values, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.fill = curr_fill
            cell.border = thin_border

            # Alignment & Font Rules
            if col_idx in (1, 5, 6, 9, 10, 11, 17, 18):
                cell.alignment = align_center
            elif col_idx in (14, 15, 16):
                cell.alignment = align_right
            else:
                cell.alignment = align_left

            if col_idx == 18:
                cell.font = font_found if is_found else font_not_found
            elif col_idx == 4:  # Smart Code
                cell.font = font_smart
            elif col_idx == 14:  # Cutoff C
                cell.font = font_cutoff
            else:
                cell.font = font_data

    # 4. Auto-fit Column Width
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            # Lewati merge banner row 1 & 2
            if cell.row in (1, 2, 3):
                continue
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 11)

    # Khusus kolom deskripsi berikan ruang lebih
    ws.column_dimensions["D"].width = max(ws.column_dimensions["D"].width, 24)
    ws.column_dimensions["G"].width = max(ws.column_dimensions["G"].width, 28)

    wb.save(file_path)
    return os.path.abspath(file_path)
