"""
Module: cache_helper.py
Mengelola kalkulasi, pembersihan, dan manajemen cache aplikasi Kermen Tools:
1. File output laporan Excel di folder output/ (dengan penanganan proteksi file yang sedang terbuka di Excel).
2. Cache Windows COM (gen_py) untuk SAP GUI Scripting & Microsoft Outlook.
3. Reset riwayat form & path input di seluruh tab.
4. Reset akun & kredensial SAP tersimpan.
5. Pembebasan memori RAM (In-Memory Catalog Cache & Garbage Collector).
"""
import os
import sys
import gc
import shutil
import tempfile
import config
from modules.settings_helper import load_settings, save_settings


def format_size(bytes_num):
    """Mengubah ukuran bytes menjadi format string yang mudah dibaca (B, KB, MB, GB)"""
    if bytes_num is None or bytes_num < 0:
        return "0 B"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_num < 1024.0:
            return f"{bytes_num:.1f} {unit}"
        bytes_num /= 1024.0
    return f"{bytes_num:.1f} PB"


def get_output_stats():
    """
    Menghitung jumlah dan ukuran file yang tersimpan di direktori output/
    (mencakup semua sub-folder: 01_Part_Readiness, 02_OTIF_Report, dst.)
    Returns:
        dict: {"count": int, "size_bytes": int, "size_formatted": str, "files": list}
    """
    out_dir = config.get_base_output_dir() if hasattr(config, 'get_base_output_dir') else getattr(config, 'OUTPUT_DIR', os.path.join(config.BASE_DIR, "output"))
    if not os.path.exists(out_dir):
        return {"count": 0, "size_bytes": 0, "size_formatted": "0 B", "files": []}

    total_bytes = 0
    files_list = []

    try:
        for root, dirs, files in os.walk(out_dir):
            for fname in files:
                f_path = os.path.join(root, fname)
                try:
                    f_size = os.path.getsize(f_path)
                    total_bytes += f_size
                    files_list.append(f_path)
                except Exception:
                    pass
    except Exception as e:
        print(f"[Warning] Gagal membaca direktori output: {e}")

    return {
        "count": len(files_list),
        "size_bytes": total_bytes,
        "size_formatted": format_size(total_bytes),
        "files": files_list
    }



def clear_output_files():
    """
    Menghapus semua file di folder output/.
    Dilengkapi error-handling jika file sedang dibuka oleh Microsoft Excel (PermissionError).
    Returns:
        dict: {
            "deleted_count": int,
            "skipped_count": int,
            "freed_bytes": int,
            "freed_formatted": str,
            "skipped_files": list
        }
    """
    stats = get_output_stats()
    deleted_count = 0
    skipped_count = 0
    freed_bytes = 0
    skipped_files = []

    for f_path in stats["files"]:
        try:
            f_size = os.path.getsize(f_path)
            os.remove(f_path)
            deleted_count += 1
            freed_bytes += f_size
        except (PermissionError, OSError) as e:
            skipped_count += 1
            skipped_files.append(os.path.basename(f_path))
            print(f"[Info] File {os.path.basename(f_path)} dilewati (sedang digunakan): {e}")
        except Exception as e:
            skipped_count += 1
            skipped_files.append(os.path.basename(f_path))
            print(f"[Warning] Gagal menghapus {f_path}: {e}")

    return {
        "deleted_count": deleted_count,
        "skipped_count": skipped_count,
        "freed_bytes": freed_bytes,
        "freed_formatted": format_size(freed_bytes),
        "skipped_files": skipped_files
    }


def get_gen_py_path():
    """Mendapatkan path folder cache Windows COM (gen_py)"""
    try:
        temp_dir = tempfile.gettempdir()
        gen_py = os.path.join(temp_dir, "gen_py")
        if os.path.exists(gen_py):
            return gen_py
    except Exception:
        pass
    
    # Fallback ke C:\Users\<user>\AppData\Local\Temp\gen_py
    local_appdata = os.environ.get("LOCALAPPDATA", "")
    if local_appdata:
        fallback = os.path.join(local_appdata, "Temp", "gen_py")
        if os.path.exists(fallback):
            return fallback

    return None


def get_com_cache_stats():
    """
    Mengecek eksistensi dan ukuran folder gen_py (Windows COM cache).
    """
    path = get_gen_py_path()
    if not path or not os.path.exists(path):
        return {
            "exists": False,
            "path": path or "Tidak terdeteksi",
            "count": 0,
            "size_bytes": 0,
            "size_formatted": "0 B"
        }

    total_bytes = 0
    file_count = 0
    try:
        for root, dirs, files in os.walk(path):
            for f in files:
                fp = os.path.join(root, f)
                try:
                    total_bytes += os.path.getsize(fp)
                    file_count += 1
                except Exception:
                    pass
    except Exception:
        pass

    return {
        "exists": True,
        "path": path,
        "count": file_count,
        "size_bytes": total_bytes,
        "size_formatted": format_size(total_bytes)
    }


def clear_com_cache():
    """
    Menghapus folder cache gen_py untuk menyelesaikan masalah COM corrupt pada SAP GUI / Outlook.
    """
    path = get_gen_py_path()
    if not path or not os.path.exists(path):
        return {"success": True, "message": "Cache COM sudah bersih (tidak ditemukan folder gen_py)", "freed_formatted": "0 B"}

    stats = get_com_cache_stats()
    freed_str = stats["size_formatted"]

    try:
        # Reset objek win32com gencache jika sedang aktif di memori
        if "win32com.client.gencache" in sys.modules:
            try:
                import win32com.client.gencache
                win32com.client.gencache.is_readonly = False
            except Exception:
                pass

        shutil.rmtree(path, ignore_errors=True)
        return {
            "success": True,
            "message": f"Cache COM berhasil dihapus ({freed_str})",
            "freed_formatted": freed_str
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Gagal menghapus cache COM: {e}",
            "freed_formatted": "0 B"
        }


def reset_form_inputs(app=None):
    """
    Mengosongkan riwayat input file di settings (Readiness, OTIF, Posture, STO)
    tanpa menghapus tema atau akun SAP.
    Jika app diberikan, mereset langsung UI yang sedang terbuka.
    """
    settings = load_settings() or {}
    
    # Kosongkan sub-dictionary path form
    settings["readiness"] = {}
    settings["otif"] = {}
    settings["posture"] = {}
    settings["sto"] = {}

    save_settings(settings)

    if app:
        try:
            if hasattr(app, 'tab_readiness') and hasattr(app.tab_readiness, 'apply_state'):
                app.tab_readiness.apply_state({})
            if hasattr(app, 'tab_otif') and hasattr(app.tab_otif, 'apply_state'):
                app.tab_otif.apply_state({})
            if hasattr(app, 'tab_stock_posture') and hasattr(app.tab_stock_posture, 'apply_state'):
                app.tab_stock_posture.apply_state({})
            if hasattr(app, 'tab_sto') and hasattr(app.tab_sto, 'apply_state'):
                app.tab_sto.apply_state({})
        except Exception as e:
            print(f"[Warning] Gagal reset form UI: {e}")

    return True


def clear_sap_credentials(app=None):
    """
    Menghapus riwayat User ID dan password SAP yang tersimpan di settings.
    """
    settings = load_settings() or {}
    if "sap" in settings and isinstance(settings["sap"], dict):
        settings["sap"]["pass"] = ""
        settings["sap"]["recent_users"] = []
        settings["sap"]["saved_accounts"] = {}
        save_settings(settings)

    if app and hasattr(app, 'tab_sap'):
        try:
            tab = app.tab_sap
            if hasattr(tab, 'txt_pass'):
                tab.txt_pass.delete(0, "end")
            if hasattr(tab, 'saved_accounts'):
                tab.saved_accounts = {}
            if hasattr(tab, 'txt_user'):
                if hasattr(tab.txt_user, 'configure'):
                    tab.txt_user.configure(values=[""])
                if hasattr(tab.txt_user, 'set'):
                    tab.txt_user.set("")
                elif hasattr(tab.txt_user, 'delete'):
                    tab.txt_user.delete(0, "end")
        except Exception as e:
            print(f"[Warning] Gagal reset kredensial SAP di UI: {e}")

    return True


def clear_ram_cache():
    """
    Membersihkan memori in-memory cache dan menjalankan garbage collector.
    """
    freed_items = 0
    try:
        import modules.sto_helper as sto_mod
        if hasattr(sto_mod, '_VALTYPE_CATALOG'):
            freed_items += len(sto_mod._VALTYPE_CATALOG)
            sto_mod._VALTYPE_CATALOG = {}
            sto_mod._CATALOG_LOADED = False
    except Exception:
        pass

    gc.collect()
    return {"freed_items": freed_items}
