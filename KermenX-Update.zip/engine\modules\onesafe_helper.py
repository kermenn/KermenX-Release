"""
onesafe_helper.py
Modul mesin pencarian spesifikasi hardware Caterpillar One Safe Source (OSS) untuk KermenX Suite.
Mendukung pencarian O-Ring Seals, Hex Bolts, Hex Nuts, Washers, dan Screws & Studs.
Menghitung hardware mating (baut + mur + ring yang cocok) serta part equivalent.
"""
import os
import sys
import re
import sqlite3

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(CURRENT_DIR)
ROOT_DIR = os.path.dirname(PARENT_DIR)


def find_db_path() -> str:
    """Mencari lokasi onesafesource.db dari beberapa kemungkinan direktori"""
    candidates = [
        os.path.join(PARENT_DIR, "assets", "onesafesource", "onesafesource.db"),
        os.path.join(CURRENT_DIR, "assets", "onesafesource", "onesafesource.db"),
        os.path.join(ROOT_DIR, "KermenX", "engine", "assets", "onesafesource", "onesafesource.db"),
        os.path.join(ROOT_DIR, "KermenX_Csharp", "Assets", "onesafesource.db"),
        os.path.join(ROOT_DIR, "AndroHeld_Google", "app", "src", "main", "assets", "onesafesource.db"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return os.path.abspath(p)
    return ""


def clean_pn(raw: str) -> str:
    """Membersihkan string part number: buang suffix batch SAP, strip, spasi, uppercase"""
    if not raw:
        return ""
    val = str(raw).strip()
    if ":" in val:
        val = val.split(":")[0].strip()
    if "/" in val and not re.match(r"^[0-9]+/[0-9]+", val):
        val = val.split("/")[0].strip()
    return val.replace("-", "").replace(" ", "").replace(".", "").upper()


def get_stats() -> dict:
    """Mengambil jumlah total records per kategori di database One Safe Source"""
    db_path = find_db_path()
    if not db_path:
        return {"error": "Database onesafesource.db tidak ditemukan", "total": 0}

    try:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        counts = {
            "O-Ring": c.execute("SELECT COUNT(*) FROM oring_catalog").fetchone()[0],
            "Bolt": c.execute("SELECT COUNT(*) FROM bolts_catalog").fetchone()[0],
            "Nut": c.execute("SELECT COUNT(*) FROM nuts_catalog").fetchone()[0],
            "Washer": c.execute("SELECT COUNT(*) FROM washers_catalog").fetchone()[0],
            "Screw": c.execute("SELECT COUNT(*) FROM screws_catalog").fetchone()[0],
        }
        counts["total"] = sum(counts.values())
        conn.close()
        return {"status": "success", "counts": counts}
    except Exception as e:
        return {"error": str(e), "total": 0}


def search_onesafe(query: str, category: str = "ALL", limit: int = 60) -> dict:
    """
    Pencarian suku cadang One Safe Source lintas kategori atau kategori spesifik.
    category: ALL, O-RING, BOLT, NUT, WASHER, SCREW
    """
    db_path = find_db_path()
    if not db_path:
        return {"status": "error", "message": "Database onesafesource.db tidak ditemukan", "results": []}

    q = query.strip()
    q_clean = clean_pn(q)
    cat_upper = category.upper().strip()

    results = []

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        # 1. O-RING
        if cat_upper in ("ALL", "O-RING", "ORING"):
            sql = """
                SELECT id, part_number, part_number_clean, standard_type, standard_size,
                       cross_section_mm, cross_section_inch, inner_dia_mm, inner_dia_inch,
                       outer_dia_mm, outer_dia_inch, material, material_family, durometer, catalog_page, pdf_page
                FROM oring_catalog
                WHERE part_number LIKE ? OR part_number_clean LIKE ? OR standard_size LIKE ?
                ORDER BY CASE WHEN part_number_clean = ? THEN 0 WHEN part_number_clean LIKE ? THEN 1 ELSE 2 END, part_number ASC
                LIMIT ?
            """
            rows = c.execute(sql, (f"%{q}%", f"%{q_clean}%", f"%{q}%", q_clean, f"{q_clean}%", limit)).fetchall()
            for r in rows:
                item = dict(r)
                cs_str = f"{item['cross_section_mm']:.2f}mm" if item.get('cross_section_mm') else "-"
                id_str = f"{item['inner_dia_mm']:.2f}mm" if item.get('inner_dia_mm') else "-"
                results.append({
                    "category": "O-RING",
                    "id": item["id"],
                    "part_number": item["part_number"],
                    "part_number_clean": item.get("part_number_clean", ""),
                    "title": item["part_number"],
                    "subtitle": f"{item.get('material', 'O-Ring')} | CS: {cs_str} | ID: {id_str} | Size: {item.get('standard_size') or '-'}",
                    "details": item
                })

        # 2. BOLTS
        if cat_upper in ("ALL", "BOLT", "BOLTS") and len(results) < limit:
            rem = limit - len(results)
            sql = """
                SELECT id, part_number, part_number_clean, bolt_type, unit_system, thread_size,
                       pitch_mm, length_oal_in, length_oal_mm, length_oal_text, grip_length_in,
                       grip_length_mm, head_type, coating, mating_nut_pn, mating_washer_pn,
                       catalog_page, pdf_page, class_or_grade, material
                FROM bolts_catalog
                WHERE part_number LIKE ? OR part_number_clean LIKE ? OR thread_size LIKE ?
                ORDER BY CASE WHEN part_number_clean = ? THEN 0 WHEN part_number_clean LIKE ? THEN 1 ELSE 2 END, part_number ASC
                LIMIT ?
            """
            rows = c.execute(sql, (f"%{q}%", f"%{q_clean}%", f"%{q}%", q_clean, f"{q_clean}%", rem)).fetchall()
            for r in rows:
                item = dict(r)
                len_str = item.get("length_oal_text") or (f"{item['length_oal_mm']}mm" if item.get("length_oal_mm") else "-")
                results.append({
                    "category": "BOLT",
                    "id": item["id"],
                    "part_number": item["part_number"],
                    "part_number_clean": item.get("part_number_clean", ""),
                    "title": item["part_number"],
                    "subtitle": f"{item.get('bolt_type', 'Bolt')} | Thread: {item.get('thread_size') or '-'} | OAL: {len_str} | Head: {item.get('head_type') or '-'}",
                    "details": item
                })

        # 3. NUTS
        if cat_upper in ("ALL", "NUT", "NUTS") and len(results) < limit:
            rem = limit - len(results)
            sql = """
                SELECT id, part_number, part_number_clean, nut_type, unit_system, thread_size,
                       height_a_in, height_a_mm, height_a_text, width_b_in, width_b_mm, width_b_text,
                       coating, catalog_page, pdf_page, class_or_grade, material
                FROM nuts_catalog
                WHERE part_number LIKE ? OR part_number_clean LIKE ? OR thread_size LIKE ?
                ORDER BY CASE WHEN part_number_clean = ? THEN 0 WHEN part_number_clean LIKE ? THEN 1 ELSE 2 END, part_number ASC
                LIMIT ?
            """
            rows = c.execute(sql, (f"%{q}%", f"%{q_clean}%", f"%{q}%", q_clean, f"{q_clean}%", rem)).fetchall()
            for r in rows:
                item = dict(r)
                results.append({
                    "category": "NUT",
                    "id": item["id"],
                    "part_number": item["part_number"],
                    "part_number_clean": item.get("part_number_clean", ""),
                    "title": item["part_number"],
                    "subtitle": f"{item.get('nut_type', 'Hex Nut')} | Thread: {item.get('thread_size') or '-'} | Grade: {item.get('class_or_grade') or '-'}",
                    "details": item
                })

        # 4. WASHERS
        if cat_upper in ("ALL", "WASHER", "WASHERS") and len(results) < limit:
            rem = limit - len(results)
            sql = """
                SELECT id, part_number, part_number_clean, washer_type, unit_system,
                       bolt_diameter_in, bolt_diameter_mm, bolt_diameter_text, inside_dia_in,
                       inside_dia_mm, inside_dia_text, outside_dia_in, outside_dia_mm, outside_dia_text,
                       thickness_a_in, thickness_a_mm, thickness_a_text, catalog_page, pdf_page, class_or_grade, material
                FROM washers_catalog
                WHERE part_number LIKE ? OR part_number_clean LIKE ? OR bolt_diameter_text LIKE ?
                ORDER BY CASE WHEN part_number_clean = ? THEN 0 WHEN part_number_clean LIKE ? THEN 1 ELSE 2 END, part_number ASC
                LIMIT ?
            """
            rows = c.execute(sql, (f"%{q}%", f"%{q_clean}%", f"%{q}%", q_clean, f"{q_clean}%", rem)).fetchall()
            for r in rows:
                item = dict(r)
                results.append({
                    "category": "WASHER",
                    "id": item["id"],
                    "part_number": item["part_number"],
                    "part_number_clean": item.get("part_number_clean", ""),
                    "title": item["part_number"],
                    "subtitle": f"{item.get('washer_type', 'Washer')} | Bolt Dia: {item.get('bolt_diameter_text') or '-'} | ID: {item.get('inside_dia_text') or '-'} | OD: {item.get('outside_dia_text') or '-'}",
                    "details": item
                })

        # 5. SCREWS & STUDS
        if cat_upper in ("ALL", "SCREW", "SCREWS") and len(results) < limit:
            rem = limit - len(results)
            sql = """
                SELECT id, part_number, part_number_clean, screw_type, unit_system, thread_size,
                       screw_length_in, screw_length_mm, screw_length_text, drive_type,
                       catalog_page, pdf_page, class_or_grade, material, coating
                FROM screws_catalog
                WHERE part_number LIKE ? OR part_number_clean LIKE ? OR thread_size LIKE ?
                ORDER BY CASE WHEN part_number_clean = ? THEN 0 WHEN part_number_clean LIKE ? THEN 1 ELSE 2 END, part_number ASC
                LIMIT ?
            """
            rows = c.execute(sql, (f"%{q}%", f"%{q_clean}%", f"%{q}%", q_clean, f"{q_clean}%", rem)).fetchall()
            for r in rows:
                item = dict(r)
                results.append({
                    "category": "SCREW",
                    "id": item["id"],
                    "part_number": item["part_number"],
                    "part_number_clean": item.get("part_number_clean", ""),
                    "title": item["part_number"],
                    "subtitle": f"{item.get('screw_type', 'Screw')} | Thread: {item.get('thread_size') or '-'} | Len: {item.get('screw_length_text') or '-'} | Drive: {item.get('drive_type') or '-'}",
                    "details": item
                })

        conn.close()
        return {"status": "success", "query": q, "category": cat_upper, "total": len(results), "results": results}
    except Exception as e:
        return {"status": "error", "message": str(e), "results": []}


def get_item_detail(category: str, part_number: str) -> dict:
    """
    Mengambil detail komprehensif satu suku cadang One Safe Source beserta mating hardware & equivalent parts.
    """
    db_path = find_db_path()
    if not db_path:
        return {"found": False, "message": "Database onesafesource.db tidak ditemukan."}

    pn = part_number.strip()
    pn_clean = clean_pn(pn)
    cat = category.upper().strip()

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        tbl_map = {
            "O-RING": "oring_catalog",
            "BOLT": "bolts_catalog",
            "NUT": "nuts_catalog",
            "WASHER": "washers_catalog",
            "SCREW": "screws_catalog"
        }
        tbl = tbl_map.get(cat, "")
        if not tbl:
            # Auto-detect table
            for k, t in tbl_map.items():
                row = c.execute(f"SELECT id FROM {t} WHERE part_number = ? OR part_number_clean = ?", (pn, pn_clean)).fetchone()
                if row:
                    tbl = t
                    cat = k
                    break

        if not tbl:
            conn.close()
            return {"found": False, "message": f"Part number '{pn}' tidak ditemukan di One Safe Source."}

        row = c.execute(f"SELECT * FROM {tbl} WHERE part_number = ? OR part_number_clean = ?", (pn, pn_clean)).fetchone()
        if not row:
            conn.close()
            return {"found": False, "message": f"Part number '{pn}' tidak ditemukan."}

        item = dict(row)
        equivalents = []
        mating_nut = None
        mating_washer = None

        # Jika O-Ring: cari equivalent O-Ring
        if cat == "O-RING":
            eq_sql = """
                SELECT b.part_number, b.material, b.standard_type, b.standard_size,
                       b.cross_section_mm, b.inner_dia_mm
                FROM oring_catalog a
                JOIN oring_catalog b 
                  ON (
                      (a.standard_size IS NOT NULL AND a.standard_size != '' AND a.standard_size = b.standard_size)
                      OR (
                          ABS(a.cross_section_mm - b.cross_section_mm) < 0.05 
                          AND ABS(a.inner_dia_mm - b.inner_dia_mm) < 0.1
                      )
                  )
                  AND b.part_number != a.part_number
                WHERE a.part_number = ? OR a.part_number_clean = ?
                LIMIT 20
            """
            for eq_r in c.execute(eq_sql, (pn, pn_clean)).fetchall():
                equivalents.append(dict(eq_r))

        # Jika Bolt: cari mating nut & washer serta equivalent bolts
        elif cat == "BOLT":
            # Mating Nut
            nut_pn = item.get("mating_nut_pn")
            if nut_pn:
                nut_row = c.execute("SELECT * FROM nuts_catalog WHERE part_number = ? OR part_number_clean = ?", (nut_pn, clean_pn(nut_pn))).fetchone()
                if nut_row:
                    mating_nut = dict(nut_row)

            # Mating Washer
            wash_pn = item.get("mating_washer_pn")
            if wash_pn:
                wash_row = c.execute("SELECT * FROM washers_catalog WHERE part_number = ? OR part_number_clean = ?", (wash_pn, clean_pn(wash_pn))).fetchone()
                if wash_row:
                    mating_washer = dict(wash_row)

            # Equivalent Bolts
            eq_sql = """
                SELECT b.part_number, b.coating, b.thread_size,
                       COALESCE(b.length_oal_in, b.length_oal_mm) AS length_value,
                       b.unit_system, b.head_type, b.bolt_type
                FROM bolts_catalog a
                JOIN bolts_catalog b 
                  ON a.thread_size = b.thread_size
                  AND (
                      (a.length_oal_in IS NOT NULL AND ABS(a.length_oal_in - b.length_oal_in) < 0.01)
                      OR (a.length_oal_mm IS NOT NULL AND ABS(a.length_oal_mm - b.length_oal_mm) < 0.5)
                  )
                  AND b.part_number != a.part_number
                WHERE a.part_number = ? OR a.part_number_clean = ?
                LIMIT 20
            """
            for eq_r in c.execute(eq_sql, (pn, pn_clean)).fetchall():
                equivalents.append(dict(eq_r))

        conn.close()
        return {
            "found": True,
            "category": cat,
            "item": item,
            "mating_nut": mating_nut,
            "mating_washer": mating_washer,
            "equivalents": equivalents
        }
    except Exception as e:
        return {"found": False, "message": str(e)}
