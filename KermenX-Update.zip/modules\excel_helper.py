import os
import time
import pandas as pd
import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from python_calamine import CalamineWorkbook
from modules.wo_readiness_helper import find_matching_kuota_file, clean_hs_code
import config


def load_kuota_import_lookup(kuota_file_path, log=print):
    """
    Membaca file Update Kuota Import (.xlsx / .xlsb) dan mengekstrak:
    df_kuota_lookup dengan kolom ['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF']
    """
    if not kuota_file_path or not os.path.exists(kuota_file_path):
        return pd.DataFrame(columns=['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF']), False

    try:
        wb_k = CalamineWorkbook.from_path(kuota_file_path)
        k_target_sheet = wb_k.sheet_names[0]
        for s in wb_k.sheet_names:
            if 'SUMMARY' in s.upper():
                k_target_sheet = s
                break

        rows_k = wb_k.get_sheet_by_name(k_target_sheet).to_python()
        if not rows_k or len(rows_k) < 2:
            return pd.DataFrame(columns=['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF']), False

        hdr_k = [str(h).strip() for h in rows_k[0]]
        df_k = pd.DataFrame(rows_k[1:], columns=hdr_k)

        k_hs_col = next((c for c in ['HS Code', 'HSCode', 'HS_Code', 'HS CODE'] if c in df_k.columns), None)
        if not k_hs_col:
            for c in df_k.columns:
                if 'HS' in str(c).upper() and 'CODE' in str(c).upper():
                    k_hs_col = c
                    break

        k_af_col = next((c for c in df_k.columns if 'AIR' in str(c).upper() or 'AF' in str(c).upper()), None)
        k_sf_col = next((c for c in df_k.columns if 'SEA' in str(c).upper() or 'SF' in str(c).upper()), None)

        if k_hs_col and (k_af_col or k_sf_col):
            df_k['HS_Key'] = df_k[k_hs_col].apply(clean_hs_code)
            df_k = df_k[df_k['HS_Key'] != ''].drop_duplicates(subset=['HS_Key']).copy()

            cols_to_keep = ['HS_Key']
            rename_kuota = {}
            if k_af_col:
                cols_to_keep.append(k_af_col)
                rename_kuota[k_af_col] = 'Kuota_Import_AF'
            if k_sf_col:
                cols_to_keep.append(k_sf_col)
                rename_kuota[k_sf_col] = 'Kuota_Import_SF'

            df_kuota_lookup = df_k[cols_to_keep].rename(columns=rename_kuota)
            if 'Kuota_Import_AF' not in df_kuota_lookup.columns:
                df_kuota_lookup['Kuota_Import_AF'] = ''
            if 'Kuota_Import_SF' not in df_kuota_lookup.columns:
                df_kuota_lookup['Kuota_Import_SF'] = ''

            log(f"Kuota Import: Sukses memuat {len(df_kuota_lookup):,} HS Code unik dari sheet '{k_target_sheet}'.")
            return df_kuota_lookup, True
        else:
            log(f"Peringatan: Kolom HS Code / Quota Air / Sea tidak ditemukan di sheet '{k_target_sheet}'.")
            return pd.DataFrame(columns=['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF']), False
    except Exception as e:
        log(f"Peringatan: Gagal membaca file Kuota Import ({str(e)}). Melanjutkan tanpa Kuota Import.")
        return pd.DataFrame(columns=['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF']), False


def process_inventory_excel(input_file_path, kuota_file_path=None, output_file_path=None, status_callback=None):
    """
    Mengolah data mentah hasil download SAP ZMMM_STOCK_INFO:
    1. Filter Val. Type: hanya CATNEW, NCATNEW, RPRODUCT, PXPRODUCT, PEPRODUCT, KITNEW.
    2. Hapus baris jika (Val. Type == 'NCATNEW') & (SNSKI == 'N') & (On-hand Stock == 0).
    3. Hitung kolom baru:
       - Inventory Value = On-hand Stock * Landed Cost Product
       - Surplus Value = Surplus (ATP) * Landed Cost Product
       - Is Surplus = Surplus (ATP) > 0
       - Stock Status = 'Critical' jika On-hand Stock (ATP) < Min, else 'Safe'
       - Deficit vs MIN = max(0, Min - On-hand Stock (ATP))
    4. Lookup Kuota Import berdasarkan HS Code: Kuota Import AF & SF.
    5. Buat Sheet 'Summary' berisi KPI Cards & Pivot Table Breakdown per Val. Type.
    6. Buat Sheet 'Critical Parts' berisi part-part di bawah MIN (Critical) terurut dari defisit tertinggi.
    7. Simpan Sheet 'Data' berisi data bersih yang sudah difilter & dihitung.
    """
    def log(msg):
        print(msg)
        if status_callback:
            status_callback(msg)

    if not os.path.exists(input_file_path):
        raise FileNotFoundError(f"File tidak ditemukan: {input_file_path}")

    # Auto-detect file Kuota Import jika tidak diberikan secara eksplisit
    has_kuota_info = False
    if kuota_file_path is None:
        detected_kuota = find_matching_kuota_file(input_file_path)
        if detected_kuota:
            kuota_file_path = detected_kuota
            log(f"Auto-detect Kuota Import ditemukan: {os.path.basename(kuota_file_path)}")
    elif kuota_file_path and not os.path.exists(kuota_file_path):
        log(f"Peringatan: File Kuota Import tidak ditemukan ({kuota_file_path}). Melanjutkan tanpa Kuota Import.")
        kuota_file_path = None

    df_kuota_lookup = pd.DataFrame(columns=['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF'])
    if kuota_file_path and os.path.exists(kuota_file_path):
        log(f"Membaca file Kuota Import: {os.path.basename(kuota_file_path)}...")
        df_kuota_lookup, has_kuota_info = load_kuota_import_lookup(kuota_file_path, log=log)

    if output_file_path is None:
        dir_name = os.path.dirname(input_file_path)
        base_name = os.path.splitext(os.path.basename(input_file_path))[0]
        output_file_path = os.path.join(dir_name, f"{base_name} - SUMMARY & PROCESSED.xlsx")

    # Handle jika file target sedang dibuka di aplikasi Excel
    if os.path.exists(output_file_path):
        try:
            with open(output_file_path, "a"):
                pass
        except PermissionError:
            dir_name = os.path.dirname(output_file_path)
            base_name, ext = os.path.splitext(os.path.basename(output_file_path))
            output_file_path = os.path.join(dir_name, f"{base_name} ({time.strftime('%H%M%S')}){ext}")
            log(f"Perhatian: File target sedang dibuka di Excel. Menyimpan ke nama baru: {os.path.basename(output_file_path)}")

    log(f"Membaca file data dengan engine Calamine: {os.path.basename(input_file_path)}...")
    try:
        wb_in = CalamineWorkbook.from_path(input_file_path)
        sheet_data = wb_in.get_sheet_by_name(wb_in.sheet_names[0]).to_python()
        df = pd.DataFrame(sheet_data[1:], columns=sheet_data[0])
    except Exception as e:
        log(f"Fallback membaca dengan pandas ({e})...")
        df = pd.read_excel(input_file_path)
    initial_count = len(df)

    # Standardize column names
    df.columns = [str(c).strip() for c in df.columns]

    # Convert numeric columns
    numeric_cols = ['On-hand Stock', 'Landed Cost Product', 'Surplus (ATP)', 'On-hand Stock (ATP)', 'Min', 'Max']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # 1. Filter Val. Type
    log("Menerapkan Filter 1: Val. Type...")
    allowed_val_types = [vt for vt in getattr(config, 'STO_VALUATION_TYPES', []) if vt != "Auto"]
    if not allowed_val_types:
        allowed_val_types = ['CATNEW', 'NCATNEW', 'RPRODUCT', 'PXPRODUCT', 'PEPRODUCT', 'KITNEW', 'CATUSED']
    df['Val. Type'] = df['Val. Type'].astype(str).str.strip().str.upper()
    df = df[df['Val. Type'].isin(allowed_val_types)].copy()

    # 2. Filter NCATNEW + SNSKI 'N' + On-hand Stock == 0
    log("Menerapkan Filter 2: Menghapus NCATNEW + SNSKI N + Stock 0...")
    if 'SNSKI' in df.columns:
        df['SNSKI'] = df['SNSKI'].astype(str).str.strip()
        cond_delete = (df['Val. Type'] == 'NCATNEW') & (df['SNSKI'] == 'N') & (df['On-hand Stock'] == 0)
        df = df[~cond_delete].copy()

    final_count = len(df)
    deleted_count = initial_count - final_count

    # 3. Hitung Kolom Tambahan (Value, Surplus, & Stock Status)
    log("Menghitung status Critical vs Safe & Deficit vs MIN...")
    df['Inventory Value'] = df['On-hand Stock'] * df['Landed Cost Product']
    df['Surplus (ATP)'] = df['Surplus (ATP)'].clip(lower=0)
    df['Surplus Value'] = df['Surplus (ATP)'] * df['Landed Cost Product']
    df['Is Surplus'] = df['Surplus (ATP)'] > 0

    # Status: 'Critical' jika ATP < Min, else 'Safe'
    df['Stock Status'] = np.where(df['On-hand Stock (ATP)'] < df['Min'], 'Critical', 'Safe')
    df['Deficit vs MIN'] = np.maximum(0, df['Min'] - df['On-hand Stock (ATP)'])

    # 4. Lookup Kuota Import berdasarkan HS Code (AF & SF)
    log("Mencocokkan Kuota Import (AF & SF) berdasarkan HS Code...")
    hs_col = next((c for c in ['HS Code', 'HSCode', 'HS_Code', 'HS CODE'] if c in df.columns), None)
    if not hs_col:
        for c in df.columns:
            if 'HS' in str(c).upper() and 'CODE' in str(c).upper():
                hs_col = c
                break

    if hs_col and has_kuota_info and not df_kuota_lookup.empty:
        df['_Clean_HS'] = df[hs_col].apply(clean_hs_code)
        df = pd.merge(df, df_kuota_lookup, left_on='_Clean_HS', right_on='HS_Key', how='left')
        df['Kuota Import AF'] = df['Kuota_Import_AF'].fillna('')
        df['Kuota Import SF'] = df['Kuota_Import_SF'].fillna('')
        df.drop(columns=['_Clean_HS', 'HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF'], errors='ignore', inplace=True)
    else:
        df['Kuota Import AF'] = ''
        df['Kuota Import SF'] = ''

    # Posisikan kolom Kuota Import AF & SF tepat setelah kolom HS Code
    if hs_col and hs_col in df.columns:
        col_order = list(df.columns)
        col_order.remove('Kuota Import AF')
        col_order.remove('Kuota Import SF')
        hs_idx = col_order.index(hs_col)
        col_order.insert(hs_idx + 1, 'Kuota Import AF')
        col_order.insert(hs_idx + 2, 'Kuota Import SF')
        df = df[col_order].copy()

    # Dataframe khusus Critical Parts
    critical_df = df[df['Stock Status'] == 'Critical'].sort_values(by='Deficit vs MIN', ascending=False).copy()

    # 5. Agregasi Pivot per Val. Type
    pivot_df = df.groupby('Val. Type').agg(
        Total_Items=('Material Number', 'count'),
        Total_Onhand_Qty=('On-hand Stock', 'sum'),
        Total_Inventory_Value=('Inventory Value', 'sum'),
        Critical_Items=('Stock Status', lambda x: int((x == 'Critical').sum())),
        Safe_Items=('Stock Status', lambda x: int((x == 'Safe').sum())),
        Surplus_Items=('Is Surplus', lambda x: int((x == True).sum())),
        Total_Surplus_Qty=('Surplus (ATP)', 'sum'),
        Total_Surplus_Value=('Surplus Value', 'sum')
    ).reindex(allowed_val_types).fillna(0).reset_index()

    total_inv_val = df['Inventory Value'].sum()
    pivot_df['Share_Value_Pct'] = np.where(total_inv_val > 0, pivot_df['Total_Inventory_Value'] / total_inv_val, 0)

    # Summary Metrics
    kpi_total_items = final_count
    kpi_total_qty = df['On-hand Stock'].sum()
    kpi_total_val = total_inv_val
    kpi_critical_items = len(critical_df)
    kpi_safe_items = final_count - kpi_critical_items
    kpi_surplus_items = int((df['Is Surplus'] == True).sum())
    kpi_surplus_qty = df['Surplus (ATP)'].sum()
    kpi_surplus_val = df['Surplus Value'].sum()

    log("Menyusun Workbook Excel dengan Sheet Summary, Critical Parts, & Data...")

    # Tulis ke Excel dengan openpyxl engine
    with pd.ExcelWriter(output_file_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Data', index=False)
        critical_df.to_excel(writer, sheet_name='Critical Parts', index=False)

        # Akses workbook langsung via writer.book (tanpa reload XML)
        wb = writer.book
        # Buat Sheet Summary di posisi paling depan (index 0)
        ws_summary = wb.create_sheet(title='Summary', index=0)
        ws_summary.views.sheetView[0].showGridLines = True

        # Styling Palettes
        navy_dark = "1E3A8A"
        blue_header = "2563EB"
        blue_light = "EFF6FF"
        teal_card = "0D9488"
        teal_light = "F0FDFA"
        red_card = "DC2626"
        red_light = "FEF2F2"
        amber_card = "D97706"
        amber_light = "FFFBEB"
        gray_border = "D1D5DB"
        gray_total = "E2E8F0"

        font_title = Font(name="Segoe UI", size=16, bold=True, color="FFFFFF")
        font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
        font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
        font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
        font_kpi_val = Font(name="Segoe UI", size=14, bold=True, color="1F2937")
        font_tbl_hdr = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
        font_tbl_body = Font(name="Segoe UI", size=9)
        font_tbl_total = Font(name="Segoe UI", size=9, bold=True, color="1F2937")

        fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
        fill_tbl_hdr = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
        fill_tbl_alt = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
        fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")
        fill_kpi1 = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
        fill_kpi2 = PatternFill(start_color=teal_light, end_color=teal_light, fill_type="solid")
        fill_kpi3 = PatternFill(start_color=red_light, end_color=red_light, fill_type="solid")
        fill_kpi4 = PatternFill(start_color=amber_light, end_color=amber_light, fill_type="solid")

        thin_border = Border(
            left=Side(style='thin', color=gray_border),
            right=Side(style='thin', color=gray_border),
            top=Side(style='thin', color=gray_border),
            bottom=Side(style='thin', color=gray_border)
        )
        total_border = Border(
            top=Side(style='thin', color="4B5563"),
            bottom=Side(style='double', color="4B5563"),
            left=Side(style='thin', color=gray_border),
            right=Side(style='thin', color=gray_border)
        )

        # -------------------------------------------------------------------------
        # 1. HEADER BANNER (Baris 2-3)
        # -------------------------------------------------------------------------
        ws_summary.merge_cells("B2:K2")
        ws_summary["B2"] = "INVENTORY EXECUTIVE DASHBOARD & SUMMARY"
        ws_summary["B2"].font = font_title
        ws_summary["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

        ws_summary.merge_cells("B3:K3")
        kuota_src_label = f"  |  Kuota Import: {os.path.basename(kuota_file_path)}" if (kuota_file_path and has_kuota_info) else ""
        ws_summary["B3"] = f"Generated Date: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  Source File: {os.path.basename(input_file_path)}{kuota_src_label}  |  Total Data: {final_count:,} items"
        ws_summary["B3"].font = font_sub
        ws_summary["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

        for r in range(2, 4):
            for c in range(2, 12):
                ws_summary.cell(row=r, column=c).fill = fill_banner

        # -------------------------------------------------------------------------
        # 2. KPI CARDS (Baris 5-7)
        # -------------------------------------------------------------------------
        # Card 1: TOTAL INVENTORY OVERVIEW (B5:C7)
        ws_summary.merge_cells("B5:C5")
        ws_summary["B5"] = "📦 TOTAL INVENTORY"
        ws_summary["B5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
        ws_summary["B5"].fill = fill_kpi1

        ws_summary["B6"] = "Total Value:"
        ws_summary["B6"].font = font_kpi_label
        ws_summary["B6"].fill = fill_kpi1
        ws_summary["C6"] = kpi_total_val
        ws_summary["C6"].font = font_kpi_val
        ws_summary["C6"].number_format = "#,##0.00"
        ws_summary["C6"].fill = fill_kpi1

        ws_summary["B7"] = "Total Items / Qty:"
        ws_summary["B7"].font = font_kpi_label
        ws_summary["B7"].fill = fill_kpi1
        ws_summary["C7"] = f"{kpi_total_items:,} items | {kpi_total_qty:,.0f} qty"
        ws_summary["C7"].font = Font(name="Segoe UI", size=9, bold=True, color="374151")
        ws_summary["C7"].fill = fill_kpi1

        # Card 2: STOCK HEALTH (CRITICAL vs SAFE) (D5:E7)
        ws_summary.merge_cells("D5:E5")
        ws_summary["D5"] = "🚨 STOCK HEALTH (ATP vs MIN)"
        ws_summary["D5"].font = Font(name="Segoe UI", size=9, bold=True, color=red_card)
        ws_summary["D5"].fill = fill_kpi3

        ws_summary["D6"] = "Critical (< MIN):"
        ws_summary["D6"].font = font_kpi_label
        ws_summary["D6"].fill = fill_kpi3
        ws_summary["E6"] = f"{kpi_critical_items:,} items"
        ws_summary["E6"].font = Font(name="Segoe UI", size=13, bold=True, color=red_card)
        ws_summary["E6"].fill = fill_kpi3

        ws_summary["D7"] = "Safe (>= MIN):"
        ws_summary["D7"].font = font_kpi_label
        ws_summary["D7"].fill = fill_kpi3
        ws_summary["E7"] = f"{kpi_safe_items:,} items"
        ws_summary["E7"].font = Font(name="Segoe UI", size=9, bold=True, color="059669")
        ws_summary["E7"].fill = fill_kpi3

        # Card 3: SURPLUS STOCK OVERVIEW (F5:H7)
        ws_summary.merge_cells("F5:H5")
        ws_summary["F5"] = "⚠️ SURPLUS STOCK (ATP)"
        ws_summary["F5"].font = Font(name="Segoe UI", size=9, bold=True, color=teal_card)
        ws_summary["F5"].fill = fill_kpi2

        ws_summary["F6"] = "Surplus Value:"
        ws_summary["F6"].font = font_kpi_label
        ws_summary["F6"].fill = fill_kpi2
        ws_summary.merge_cells("G6:H6")
        ws_summary["G6"] = kpi_surplus_val
        ws_summary["G6"].font = font_kpi_val
        ws_summary["G6"].number_format = "#,##0.00"
        ws_summary["G6"].fill = fill_kpi2

        ws_summary["F7"] = "Surplus Items / Qty:"
        ws_summary["F7"].font = font_kpi_label
        ws_summary["F7"].fill = fill_kpi2
        ws_summary.merge_cells("G7:H7")
        ws_summary["G7"] = f"{kpi_surplus_items:,} items | {kpi_surplus_qty:,.0f} qty"
        ws_summary["G7"].font = Font(name="Segoe UI", size=9, bold=True, color="374151")
        ws_summary["G7"].fill = fill_kpi2

        # Card 4: FILTER SUMMARY (I5:K7)
        ws_summary.merge_cells("I5:K5")
        ws_summary["I5"] = "🔍 FILTER SUMMARY"
        ws_summary["I5"].font = Font(name="Segoe UI", size=9, bold=True, color=amber_card)
        ws_summary["I5"].fill = fill_kpi4

        ws_summary["I6"] = "Valid Data:"
        ws_summary["I6"].font = font_kpi_label
        ws_summary["I6"].fill = fill_kpi4
        ws_summary.merge_cells("J6:K6")
        ws_summary["J6"] = f"{final_count:,} baris"
        ws_summary["J6"].font = font_kpi_val
        ws_summary["J6"].fill = fill_kpi4

        ws_summary["I7"] = "Baris Dihapus:"
        ws_summary["I7"].font = font_kpi_label
        ws_summary["I7"].fill = fill_kpi4
        ws_summary.merge_cells("J7:K7")
        ws_summary["J7"] = f"{deleted_count:,} tereliminasi"
        ws_summary["J7"].font = Font(name="Segoe UI", size=9, color="DC2626")
        ws_summary["J7"].fill = fill_kpi4

        # Border untuk semua sel KPI
        for r in range(5, 8):
            for c in range(2, 12):
                ws_summary.cell(row=r, column=c).border = thin_border

        # -------------------------------------------------------------------------
        # 3. PIVOT TABLE BREAKDOWN PER VAL. TYPE (Mulai Baris 9)
        # -------------------------------------------------------------------------
        ws_summary["B9"] = "📊 Breakdown Berdasarkan Valuation Type (Val. Type)"
        ws_summary["B9"].font = font_section

        headers = [
            "Val. Type",
            "Total Items",
            "On-hand Qty",
            "Total Inventory Value",
            "% Value Share",
            "Critical Items (< MIN)",
            "Safe Items (>= MIN)",
            "Surplus Items",
            "Surplus Qty",
            "Surplus Value"
        ]

        header_row = 11
        for i, h in enumerate(headers, start=2):
            cell = ws_summary.cell(row=header_row, column=i, value=h)
            cell.font = font_tbl_hdr
            cell.fill = fill_tbl_hdr
            cell.alignment = Alignment(horizontal="center" if i != 2 else "left", vertical="center", wrap_text=True)
            cell.border = thin_border

        curr_row = header_row + 1
        for idx, row in pivot_df.iterrows():
            val_type = row['Val. Type']
            items = row['Total_Items']
            onhand_qty = row['Total_Onhand_Qty']
            inv_val = row['Total_Inventory_Value']
            val_share = row['Share_Value_Pct']
            crit_items = row['Critical_Items']
            safe_items = row['Safe_Items']
            surplus_items = row['Surplus_Items']
            surplus_qty = row['Total_Surplus_Qty']
            surplus_val = row['Total_Surplus_Value']

            fill_row = fill_tbl_alt if (idx % 2 == 1) else None

            values = [
                (val_type, "@", "left"),
                (items, "#,##0", "right"),
                (onhand_qty, "#,##0.00", "right"),
                (inv_val, "#,##0.00", "right"),
                (val_share, "0.0%", "right"),
                (crit_items, "#,##0", "right"),
                (safe_items, "#,##0", "right"),
                (surplus_items, "#,##0", "right"),
                (surplus_qty, "#,##0.00", "right"),
                (surplus_val, "#,##0.00", "right"),
            ]

            for col_idx, (val, fmt, align) in enumerate(values, start=2):
                cell = ws_summary.cell(row=curr_row, column=col_idx, value=val)
                cell.font = font_tbl_body
                cell.number_format = fmt
                cell.alignment = Alignment(horizontal=align, vertical="center")
                cell.border = thin_border
                if fill_row:
                    cell.fill = fill_row

            # Beri warna merah jika ada critical items
            if crit_items > 0:
                ws_summary.cell(row=curr_row, column=7).font = Font(name="Segoe UI", size=9, bold=True, color=red_card)

            curr_row += 1

        # TOTAL ROW (Baris Akhir Pivot Table)
        total_values = [
            ("GRAND TOTAL", "@", "left"),
            (f"=SUM(C12:C{curr_row-1})", "#,##0", "right"),
            (f"=SUM(D12:D{curr_row-1})", "#,##0.00", "right"),
            (f"=SUM(E12:E{curr_row-1})", "#,##0.00", "right"),
            (1.0, "0.0%", "right"),
            (f"=SUM(G12:G{curr_row-1})", "#,##0", "right"),
            (f"=SUM(H12:H{curr_row-1})", "#,##0", "right"),
            (f"=SUM(I12:I{curr_row-1})", "#,##0", "right"),
            (f"=SUM(J12:J{curr_row-1})", "#,##0.00", "right"),
            (f"=SUM(K12:K{curr_row-1})", "#,##0.00", "right"),
        ]

        for col_idx, (val, fmt, align) in enumerate(total_values, start=2):
            cell = ws_summary.cell(row=curr_row, column=col_idx, value=val)
            cell.font = font_tbl_total
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = total_border
            cell.fill = fill_total

        # Atur Lebar Kolom Otomatis di Sheet Summary
        col_widths = {
            'A': 3,
            'B': 16, # Val Type
            'C': 13, # Items
            'D': 16, # Qty
            'E': 22, # Value
            'F': 14, # Share
            'G': 17, # Critical Items
            'H': 17, # Safe Items
            'I': 14, # Surplus Items
            'J': 16, # Surplus Qty
            'K': 22, # Surplus Value
        }
        for col_letter, width in col_widths.items():
            ws_summary.column_dimensions[col_letter].width = width

        # -------------------------------------------------------------------------
        # 4. STYLING SHEET 'Critical Parts' & 'Data'
        # -------------------------------------------------------------------------
        col_width_map = {
            'Plant': 10,
            'Material Number': 20,
            'Material Description': 35,
            'Storage Location': 14,
            'GR Last Date': 14,
            'Val. Type': 14,
            'SNSKI': 10,
            'Min': 12,
            'Max': 12,
            'On-hand Stock (ATP)': 20,
            'UOM': 8,
            'Surplus (ATP)': 16,
            'On-hand Stock': 16,
            'On Hand Reserve Stock': 20,
            'Total Availability (TA)': 20,
            'On-Order Qty': 16,
            'In-Transit STO': 16,
            'Package Qty': 14,
            'Commodity Code': 16,
            'BE Code': 12,
            'Terr Dec Avail': 14,
            'Order Method': 14,
            'Landed Cost Product': 18,
            'Deletion Indicator': 16,
            'HS Code': 16,
            'Kuota Import AF': 18,
            'Kuota Import SF': 18,
            'Inventory Value': 20,
            'Surplus Value': 18,
            'Is Surplus': 12,
            'Stock Status': 14,
            'Deficit vs MIN': 16
        }

        if 'Critical Parts' in writer.sheets:
            ws_crit = writer.sheets['Critical Parts']
            ws_crit.views.sheetView[0].showGridLines = True
            ws_crit.freeze_panes = "A2"
            ws_crit.auto_filter.ref = ws_crit.dimensions

            for col in range(1, len(critical_df.columns) + 1):
                cell = ws_crit.cell(row=1, column=col)
                cell.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
                cell.fill = PatternFill(start_color=red_card, end_color=red_card, fill_type="solid")
                cell.alignment = Alignment(horizontal="center", vertical="center")

                col_name = str(cell.value or '').strip()
                ws_crit.column_dimensions[get_column_letter(col)].width = col_width_map.get(col_name, max(len(col_name) + 3, 14))

        ws_data = writer.sheets['Data']
        ws_data.views.sheetView[0].showGridLines = True
        ws_data.freeze_panes = "A2"
        ws_data.auto_filter.ref = ws_data.dimensions

        for col in range(1, len(df.columns) + 1):
            cell = ws_data.cell(row=1, column=col)
            cell.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center")

            col_name = str(cell.value or '').strip()
            ws_data.column_dimensions[get_column_letter(col)].width = col_width_map.get(col_name, max(len(col_name) + 3, 14))

        log('Menyimpan file hasil olahan...')

    log(f'Selesai! File tersimpan di: {output_file_path}')

    return {
        "output_path": output_file_path,
        "total_items": kpi_total_items,
        "total_qty": kpi_total_qty,
        "total_inventory_value": kpi_total_val,
        "critical_items": kpi_critical_items,
        "safe_items": kpi_safe_items,
        "surplus_items": kpi_surplus_items,
        "surplus_qty": kpi_surplus_qty,
        "surplus_val": kpi_surplus_val,
        "deleted_count": deleted_count,
        "has_kuota_info": has_kuota_info,
        "kuota_file_path": kuota_file_path
    }


if __name__ == "__main__":
    # Test run
    test_file = r"D:\Users\yusril.i.wafir\Downloads\Inventory 02102026.XLSX"
    if os.path.exists(test_file):
        res = process_inventory_excel(test_file)
        print("Success:", res)
