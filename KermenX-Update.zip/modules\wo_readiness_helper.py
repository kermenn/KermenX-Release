"""
Module: wo_readiness_helper.py
Khusus pengolahan dan pencocokan data Work Order (AS57D) terhadap:
1. Stok Aktual Gudang Khusus (MB52 - Special Stock 'S')
2. Stok Bebas Internal SAP (Stock Info - ATP)
3. Komitmen Pesanan Berjalan (On-Order Qty + In-Transit STO = OO)

Alur Proses:
1. Membaca Sheet AS57D & MB52 dari file RAW DATA (.xlsb / .xlsx) dengan engine Calamine.
2. Filter MB52: Hanya Special Stock 'S', pivot per Material Number.
3. Filter & Transformasi AS57D:
   - Hapus Batch Number 'OCORE' dan 'RECON'.
   - Pisahkan Material Description menjadi kolom 'Manufacture' & 'PN' (hapus '-' dan tambah suffix ':AA').
   - Filter Manufacture hanya yang mengandung kata 'CAT' atau 'Loctite'.
4. Pembagian Data Kebutuhan:
   - Kelompok 1: All WO User Status (Semua status: COMP, PROG, RELE, OUTS).
   - Kelompok 2: Filtered Status COMP, PROG & RELE.
5. Lookup Stock Info SAP & Kuota Import:
   - Mencari kolom ATP, On-Order Qty, In-Transit STO (Total OO), Material Description, HS Code, & Deletion Indicator.
   - Lookup Kuota Import berdasarkan HS Code -> Quota Air Remaining (AF) & Quota Sea Remaining (SF).
   - Cocokkan PN (format :AA) dan fallback base part number dengan Material Number di Stock Info.
6. Hitung Gabungan Ketersediaan & Analisis Remarks:
   - Total Available Stock = Stock MB52 (S) + Stock ATP TU
   - Balance / Deficit = Total Available Stock - Requirement Qty
   - Status: 'Ready / Sufficient' (hijau) vs 'Not Ready' (merah)
   - Logika Remarks Otomatis:
     * Jika Ready Stock: "Ready stock"
     * Jika Not Ready & (Total Available Stock + OO >= Req Qty): "Follow up STO."
     * Jika Not Ready & (Total Available Stock + OO < Req Qty): "Need refill stock"
7. Output Workbook Excel disesuaikan dengan pilihan output_mode ('both', 'all', 'filtered'):
   - Sheet Part Readiness (All dan/atau COMP PROG RELE) dengan kolom On Order (OO) & Remarks otomatis
   - Sheet Hose Consist Analysis (Analisis kesiapan rakit komponen Hose Assy & akumulasi coupling)
   - Sheet Stock Info ATP (Dilengkapi On-Order, In-Transit STO, Total OO, Material Description, Order Method (BB & PT), HS Code, Kuota Import AF & SF, & Deletion Indicator)
   - Sheet Data AS57D Clean (Data transaksi lengkap hasil filter)
"""
import os
import re
import time
import pandas as pd
import numpy as np
from python_calamine import CalamineWorkbook
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import config



# Pemetaan khusus Part Number (PN) override jika suffix atau penamaan berbeda dari standar :AA
CUSTOM_PN_MAPPING = {
    'HP426PIB:AA': 'HP426PI B:LS',
    'HP426PIB': 'HP426PI B:LS',
    'HP-426PIB': 'HP426PI B:LS',
    'HP426PI B:AA': 'HP426PI B:LS',
    'HP426 PLUS:AA': 'HP426 PLUS B:LS',
    'HP426 PLUS': 'HP426 PLUS B:LS',
    'HP426PLUS:AA': 'HP426 PLUS B:LS',
    'HP426PLUS': 'HP426 PLUS B:LS',
    'HP426 PLUS B:AA': 'HP426 PLUS B:LS',
    'HP426 B:AA': 'HP426 B:LS',
    'HP426 B': 'HP426 B:LS',
    'HP426B:AA': 'HP426 B:LS',
    'HP426B': 'HP426 B:LS',
    'HP427PI:AA': 'HP427PI B:LS',
    'HP427PI': 'HP427PI B:LS',
    'HP-427PI': 'HP427PI B:LS',
    'HP427 B:AA': 'HP427 B:LS',
    'HP427 B': 'HP427 B:LS',
    'HP428 B:AA': 'HP428 B:LS',
    'HP428 B': 'HP428 B:LS',
    'HP428B:AA': 'HP428 B:LS',
    'HP428B': 'HP428 B:LS',
    'HP429 B:AA': 'HP429 B:LS',
    'HP429 B': 'HP429 B:LS',
    '230592:AA': '230592:HI',
    '230592': '230592:HI',
    '555354:AA': '555354:HI',
    '555354': '555354:HI',
    '232077:AA': '232077:HI',
    '232077': '232077:HI',
    '2153634:AA': '2153634-T:NM',
    '2153634': '2153634-T:NM',
    '215-3634:AA': '2153634-T:NM',
    '215-3634': '2153634-T:NM',
    '2153634-T:AA': '2153634-T:NM',
    '2153634-T': '2153634-T:NM',
}

try:
    import config
    if hasattr(config, 'CUSTOM_PN_MAPPING') and isinstance(config.CUSTOM_PN_MAPPING, dict):
        CUSTOM_PN_MAPPING.update(config.CUSTOM_PN_MAPPING)
except Exception:
    pass

try:
    from modules.settings_helper import load_settings
    _settings = load_settings()
    if _settings and "custom_pn_mapping" in _settings and isinstance(_settings["custom_pn_mapping"], dict):
        CUSTOM_PN_MAPPING.update(_settings["custom_pn_mapping"])
    elif _settings and "readiness" in _settings and isinstance(_settings.get("readiness"), dict):
        if "custom_pn_mapping" in _settings["readiness"] and isinstance(_settings["readiness"]["custom_pn_mapping"], dict):
            CUSTOM_PN_MAPPING.update(_settings["readiness"]["custom_pn_mapping"])
except Exception:
    pass


def parse_material_desc(desc):
    """
    Memecah Material Description yang berformat:
    'DRIVE GP;478-0706;CAT' -> Manufacture: 'CAT', PN: '4780706:AA', Base PN: '4780706'
    'BRAKE GP:SERVICE:339-8807;CAT' -> Manufacture: 'CAT', PN: '3398807:AA', Base PN: '3398807'
    'SOS;HP-426PIB;CAT' -> Manufacture: 'CAT', PN: 'HP426PI B:LS', Base PN: 'HP426PI B'
    'BOTTLE,OIL SAMPLE;HP426 PLUS;CAT' -> Manufacture: 'CAT', PN: 'HP426 PLUS B:LS', Base PN: 'HP426 PLUS B'
    'SOS;HP-427PI;CAT' -> Manufacture: 'CAT', PN: 'HP427PI B:LS', Base PN: 'HP427PI B'
    'ANALYSIS;COOLANT;HP428 B;CAT' -> Manufacture: 'CAT', PN: 'HP428 B:LS', Base PN: 'HP428 B'
    'SOS;HP426 B;CAT' -> Manufacture: 'CAT', PN: 'HP426 B:LS', Base PN: 'HP426 B'
    'THREADLOCKER;230592;LOCTITE' -> Manufacture: 'LOCTITE', PN: '230592:HI', Base PN: '230592'
    'SEALANT;555354;LOCTITE' -> Manufacture: 'LOCTITE', PN: '555354:HI', Base PN: '555354'
    'THREADLOCKER;232077;LOCTITE' -> Manufacture: 'LOCTITE', PN: '232077:HI', Base PN: '232077'
    'ELEMENT;215-3634;CAT' -> Manufacture: 'CAT', PN: '2153634-T:NM', Base PN: '2153634-T'
    """
    raw_str = str(desc).strip()
    if not raw_str or raw_str.lower() == 'nan':
        return '', '', ''

    parts_semi = [p.strip() for p in raw_str.split(';') if p.strip()]
    if len(parts_semi) >= 2:
        mfr = parts_semi[-1]
        candidate_block = parts_semi[-2]
    elif len(parts_semi) == 1:
        mfr = ''
        candidate_block = parts_semi[0]
    else:
        return '', '', ''

    # Jika string input langsung terdaftar di custom mapping
    if raw_str in CUSTOM_PN_MAPPING:
        formatted = CUSTOM_PN_MAPPING[raw_str]
        base = formatted.split(':')[0].strip() if ':' in formatted else formatted
        return mfr, formatted, base

    colon_tokens = [c.strip() for c in candidate_block.split(':') if c.strip()]
    raw_pn = colon_tokens[-1] if colon_tokens else candidate_block

    clean_pn = raw_pn.replace('-', '').strip()
    # Suffix default: jika Loctite gunakan :HI, selain itu (CAT dll) gunakan :AA
    default_suffix = ':HI' if mfr.upper() == 'LOCTITE' else ':AA'
    formatted_pn = f"{clean_pn}{default_suffix}" if clean_pn else ""

    # Cek override mapping untuk format part number khusus (misal suffix :LS atau :HI)
    if formatted_pn in CUSTOM_PN_MAPPING:
        formatted_pn = CUSTOM_PN_MAPPING[formatted_pn]
        clean_pn = formatted_pn.split(':')[0].strip() if ':' in formatted_pn else formatted_pn
    elif clean_pn in CUSTOM_PN_MAPPING:
        formatted_pn = CUSTOM_PN_MAPPING[clean_pn]
        clean_pn = formatted_pn.split(':')[0].strip() if ':' in formatted_pn else formatted_pn
    elif raw_pn in CUSTOM_PN_MAPPING:
        formatted_pn = CUSTOM_PN_MAPPING[raw_pn]
        clean_pn = formatted_pn.split(':')[0].strip() if ':' in formatted_pn else formatted_pn
    elif candidate_block in CUSTOM_PN_MAPPING:
        formatted_pn = CUSTOM_PN_MAPPING[candidate_block]
        clean_pn = formatted_pn.split(':')[0].strip() if ':' in formatted_pn else formatted_pn
    else:
        # Fallback pencocokan normalized (case-insensitive & whitespace/strip agnostic)
        norm_c = clean_pn.upper().replace(' ', '').replace('-', '')
        norm_f = formatted_pn.upper().replace(' ', '').replace('-', '')
        norm_r = raw_pn.upper().replace(' ', '').replace('-', '')
        norm_cb = candidate_block.upper().replace(' ', '').replace('-', '')
        for k, v in CUSTOM_PN_MAPPING.items():
            k_norm = k.upper().replace(' ', '').replace('-', '')
            if k_norm in (norm_f, norm_c, norm_r, norm_cb):
                formatted_pn = v
                clean_pn = formatted_pn.split(':')[0].strip() if ':' in formatted_pn else formatted_pn
                break

    return mfr, formatted_pn, clean_pn


def find_matching_stock_info(raw_file_path):
    """
    Mencari file Stock Info yang cocok secara otomatis berdasarkan pola tanggal DDMMYYYY
    pada nama file RAW DATA. Memprioritaskan file raw SAP export (contoh: Inventory 02102026.XLSX).
    """
    match = re.search(r'(\d{8})', os.path.basename(raw_file_path))
    if not match:
        return None

    date_str = match.group(1)
    search_dirs = [
        os.path.dirname(raw_file_path),
        config.get_output_dir("sap"),
        config.get_base_output_dir(),
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"D:\Users\yusril.i.wafir\Downloads"
    ]


    for d in search_dirs:
        if not os.path.exists(d):
            continue
        for ext in ['.XLSX', '.xlsx', '.xlsb']:
            for prefix in ['Inventory', 'INVENTORY', 'inventory']:
                candidate = os.path.join(d, f"{prefix} {date_str}{ext}")
                if os.path.exists(candidate):
                    return candidate

    for d in search_dirs:
        if not os.path.exists(d):
            continue
        for fname in os.listdir(d):
            fname_upper = fname.upper()
            if "INVENTORY" in fname_upper and date_str in fname_upper:
                if "PART READINESS" not in fname_upper and fname.endswith(('.xlsx', '.XLSX', '.xlsb')):
                    return os.path.join(d, fname)

    return None


def clean_hs_code(val):
    """
    Membersihkan dan menstandarisasi format HS Code:
    Menghapus suffix .0, spasi, titik, dan strip tanda hubung.
    """
    if val is None or pd.isna(val):
        return ""
    s = str(val).strip()
    if s.endswith('.0'):
        s = s[:-2]
    s = s.replace('.', '').replace(' ', '').replace('-', '')
    return s if s.lower() != 'nan' else ""


def find_matching_kuota_file(raw_file_path=None):
    """
    Mencari file Update Kuota Import terbaru secara otomatis:
    - Di Desktop (Desktop user, OneDrive Desktop)
    - Di Downloads
    - Di direktori yang sama dengan raw_file_path (jika diberikan)
    Mencari file dengan nama mengandung 'KUOTA' dan ekstensi .xlsx / .xlsb,
    diurutkan berdasarkan waktu modifikasi terbaru.
    """
    search_dirs = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop"),
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
    ]
    if raw_file_path and os.path.exists(raw_file_path):
        search_dirs.insert(0, os.path.dirname(raw_file_path))

    candidates = []
    seen = set()
    for d in search_dirs:
        if not os.path.exists(d) or d in seen:
            continue
        seen.add(d)
        try:
            for fname in os.listdir(d):
                fname_upper = fname.upper()
                if "KUOTA" in fname_upper and not fname.startswith("~$"):
                    if fname.endswith((".xlsx", ".XLSX", ".xlsb", ".XLSB")):
                        full_path = os.path.join(d, fname)
                        candidates.append(full_path)
        except Exception:
            continue

    if not candidates:
        return None

    candidates.sort(key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
    return candidates[0]


def find_matching_consist_file(raw_file_path=None):
    r"""
    Mencari file Master Consist Hose Assy secara otomatis:
    - Di Desktop (D:\Users\yusril.i.wafir\Desktop, Desktop user, OneDrive Desktop)
    - Di direktori yang sama dengan raw_file_path (jika diberikan)
    - Di Downloads
    Memprioritaskan file dengan kata kunci 'CONSIST' & 'HOSE', terutama yang bertanda 'Cleaned'.
    """
    search_dirs = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop"),
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
    ]
    if raw_file_path and os.path.exists(raw_file_path):
        search_dirs.insert(0, os.path.dirname(raw_file_path))

    candidates = []
    seen = set()
    for d in search_dirs:
        if not os.path.exists(d) or d in seen:
            continue
        seen.add(d)
        try:
            for fname in os.listdir(d):
                fname_upper = fname.upper()
                if ("CONSIST" in fname_upper and "HOSE" in fname_upper) and not fname.startswith("~$"):
                    if fname.endswith((".xlsx", ".XLSX", ".xlsb", ".XLSB")):
                        full_path = os.path.join(d, fname)
                        is_cleaned = 1 if "CLEANED" in fname_upper else 0
                        mtime = os.path.getmtime(full_path) if os.path.exists(full_path) else 0
                        candidates.append((full_path, is_cleaned, mtime))
        except Exception:
            continue

    if not candidates:
        return None

    # Prioritaskan versi 'Cleaned', lalu file terbaru berdasarkan waktu modifikasi
    candidates.sort(key=lambda x: (x[1], x[2]), reverse=True)
    return candidates[0][0]


def load_consist_hose_data(consist_file_path):
    """
    Memuat data Master Consist Hose Assy dari Excel:
    Mendukung sheet 'Consist (Coupling & Hose)', 'Consist (All Active Components)',
    atau sheet pertama file raw (dengan auto-clean Stem & Sleeve ganda dan memprioritaskan Coupling).
    Mengembalikan dictionary: {PN_HOSE_ASSY: {'hose': {...}, 'couplings': [...]}}
    """
    if not consist_file_path or not os.path.exists(consist_file_path):
        return {}

    excel_file = pd.ExcelFile(consist_file_path)
    sheet_names = excel_file.sheet_names

    if "Consist (Coupling & Hose)" in sheet_names:
        df = pd.read_excel(consist_file_path, sheet_name="Consist (Coupling & Hose)")
    elif "Consist (All Active Components)" in sheet_names:
        df = pd.read_excel(consist_file_path, sheet_name="Consist (All Active Components)")
        if 'Category' in df.columns:
            df = df[df['Category'].isin(['COUPLING', 'HOSE'])].copy()
    else:
        df = pd.read_excel(consist_file_path, sheet_name=sheet_names[0])
        def categorize(desc):
            if not isinstance(desc, str): return 'BLANK'
            d = desc.upper()
            if 'COUPLING' in d: return 'COUPLING'
            if 'HOSE' in d: return 'HOSE'
            if 'STEM' in d: return 'STEM'
            if 'SLEEVE' in d: return 'SLEEVE'
            return 'OTHER'
        df['Category'] = df['BOM component'].apply(categorize)
        df = df[df['Category'].isin(['COUPLING', 'HOSE'])].copy()
        dual_mats = ['1549001:AA', '8W0958:AA', '8W2277:AA']
        df = df[~((df['Material'].isin(dual_mats)) & (df['Item'] == 20))].copy()

    consist_dict = {}
    for mat, group in df.groupby('Material'):
        mat_str = str(mat).strip().upper()
        base_mat = mat_str.split(':')[0].strip()

        # Hose row
        cat_col = 'Category' if 'Category' in group.columns else 'BOM component'
        h_rows = group[group[cat_col].astype(str).str.upper().str.contains('HOSE')]
        if not h_rows.empty:
            hr = h_rows.iloc[0]
            hose_data = {
                'pn': str(hr['Component']).strip().upper(),
                'desc': str(hr['BOM component']).strip(),
                'cut_length': float(hr['Quantity']),
                'un': str(hr.get('Un', 'CM')).strip()
            }
        else:
            hose_data = None

        # Coupling rows
        c_rows = group[group[cat_col].astype(str).str.upper().str.contains('COUPL')]
        couplings = []
        for _, cr in c_rows.iterrows():
            couplings.append({
                'pn': str(cr['Component']).strip().upper(),
                'desc': str(cr['BOM component']).strip(),
                'qty': float(cr['Quantity']),
                'un': str(cr.get('Un', 'PC')).strip()
            })

        item_data = {
            'material': mat_str,
            'base_material': base_mat,
            'hose': hose_data,
            'couplings': couplings
        }
        consist_dict[mat_str] = item_data
        if base_mat not in consist_dict:
            consist_dict[base_mat] = item_data

    return consist_dict


def build_consist_allocation_engine(df_as57d_clean, consist_master, pivot_inv, pivot_inv_base, has_mp_info=False):
    """
    Melakukan alokasi stok Bulk Hose (cut length) dan Couplings secara berurutan (FIFO Priority):
    1. Kebutuhan Hose Assy pada Work Order Monthly Plan (MP) dialokasikan terlebih dahulu (Priority 1).
    2. Sisa stok setelah alokasi MP dialokasikan ke backlog Work Order lainnya (Priority 2).
    3. Setiap kali komponen digunakan, kuota stok ATP dikurangkan (deducted) agar tidak over-promise.
    Menghasilkan:
    - df_consist_analysis (Tabel 1: Rincian per Hose Assembly dengan status rakit & sisa stok)
    - df_component_summary (Tabel 2: Rekapitulasi Akumulasi Kebutuhan Komponen vs Stok ATP)
    - hose_alloc_map: Dictionary pemetaan status untuk updating sheet utama
    """
    if df_as57d_clean.empty or not consist_master:
        return pd.DataFrame(), pd.DataFrame(), {}

    inv_map_exact = {}
    inv_map_base = {}
    inv_desc_map = {}

    if pivot_inv is not None and not pivot_inv.empty and 'Stock_Info_ATP' in pivot_inv.columns:
        inv_map_exact = pivot_inv.set_index('Material_Key')['Stock_Info_ATP'].to_dict()
        if 'Material_Description' in pivot_inv.columns:
            inv_desc_map = pivot_inv.set_index('Material_Key')['Material_Description'].to_dict()

    if pivot_inv_base is not None and not pivot_inv_base.empty and 'Stock_Info_Base' in pivot_inv_base.columns:
        inv_map_base = pivot_inv_base.set_index('Base_Key')['Stock_Info_Base'].to_dict()

    def get_comp_initial_stock(pn_str):
        p_clean = str(pn_str).strip().upper()
        if p_clean in inv_map_exact and pd.notna(inv_map_exact[p_clean]):
            return float(inv_map_exact[p_clean])
        b_key = p_clean.split(':')[0].strip()
        if b_key in inv_map_base and pd.notna(inv_map_base[b_key]):
            return float(inv_map_base[b_key])
        return 0.0

    def get_comp_description(pn_str):
        p_clean = str(pn_str).strip().upper()
        if p_clean in inv_desc_map and pd.notna(inv_desc_map[p_clean]):
            return str(inv_desc_map[p_clean]).strip()
        return ""

    # Filter hanya baris Hose Assy yang terdaftar di consist_master
    hose_rows = []
    for idx, r in df_as57d_clean.iterrows():
        pn = str(r.get('PN', '')).strip().upper()
        base_pn = str(r.get('Base_PN', pn.split(':')[0].strip())).strip().upper()
        info = consist_master.get(pn) or consist_master.get(base_pn)
        if info:
            hose_rows.append({
                'Material Number': str(r.get('Material Number', pn)).strip(),
                'PN': pn,
                'Base_PN': base_pn,
                'Material Description': str(r.get('Material Description', '')).strip(),
                'Requirement Quantity': float(r.get('Requirement Quantity', 0.0)),
                'Is_Monthly_Plan': bool(r.get('Is_Monthly_Plan', False))
            })

    if not hose_rows:
        return pd.DataFrame(), pd.DataFrame(), {}

    df_hoses = pd.DataFrame(hose_rows)
    piv_hoses = df_hoses.groupby(
        ['Material Number', 'PN', 'Base_PN', 'Material Description', 'Is_Monthly_Plan'], as_index=False
    ).agg(Requirement_Qty=('Requirement Quantity', 'sum'))

    # Prioritaskan MP terlebih dahulu (True sebelum False), kemudian kebutuhan terbesar
    piv_hoses = piv_hoses.sort_values(by=['Is_Monthly_Plan', 'Requirement_Qty'], ascending=[False, False]).reset_index(drop=True)

    # Inisialisasi pool stok awal untuk semua komponen
    running_stock = {}
    orig_stock = {}
    comp_total_req = {}
    comp_alloc_stock = {}
    comp_used_by = {}
    comp_type = {}
    comp_desc = {}
    comp_uom = {}

    for _, r in piv_hoses.iterrows():
        pn = r['PN']
        base = r['Base_PN']
        info = consist_master.get(pn) or consist_master.get(base)
        if not info:
            continue
        h_d = info.get('hose')
        if h_d:
            hpn = h_d['pn']
            if hpn not in orig_stock:
                stk = get_comp_initial_stock(hpn)
                orig_stock[hpn] = stk
                running_stock[hpn] = stk
                comp_type[hpn] = 'BULK HOSE'
                comp_uom[hpn] = 'CM'
                comp_desc[hpn] = h_d.get('desc') or get_comp_description(hpn) or 'BULK HOSE'

        for c in info.get('couplings', []):
            cpn = c['pn']
            if cpn not in orig_stock:
                stk = get_comp_initial_stock(cpn)
                orig_stock[cpn] = stk
                running_stock[cpn] = stk
                comp_type[cpn] = 'COUPLING'
                comp_uom[cpn] = 'PC'
                comp_desc[cpn] = c.get('desc') or get_comp_description(cpn) or 'COUPLING'

    table1_rows = []
    hose_alloc_map = {}

    for idx, r in piv_hoses.iterrows():
        pn = r['PN']
        base = r['Base_PN']
        mat_no = r['Material Number']
        desc = r['Material Description']
        is_mp = r['Is_Monthly_Plan']
        req_qty = r['Requirement_Qty']
        info = consist_master.get(pn) or consist_master.get(base)

        prio_label = "⭐ Monthly Plan (MP)" if is_mp else "📋 Backlog WO"
        hose_data = info.get('hose')
        couplings = info.get('couplings', [])

        # Kebutuhan Bulk Hose
        if hose_data:
            hpn = hose_data['pn']
            cut_len = hose_data['cut_length']
            tot_cut = cut_len * req_qty
            comp_total_req[hpn] = comp_total_req.get(hpn, 0.0) + tot_cut
            comp_used_by.setdefault(hpn, set()).add(pn)
            h_orig = orig_stock.get(hpn, 0.0)
            h_rem = running_stock.get(hpn, 0.0)
        else:
            hpn, cut_len, tot_cut, h_orig, h_rem = '-', 0.0, 0.0, 0.0, 0.0

        # Kebutuhan Coupling 1
        c1_pn, c1_req, c1_orig, c1_rem = '-', 0.0, 0.0, 0.0
        if len(couplings) >= 1:
            c1 = couplings[0]
            c1_pn = c1['pn']
            c1_req = c1['qty'] * req_qty
            comp_total_req[c1_pn] = comp_total_req.get(c1_pn, 0.0) + c1_req
            comp_used_by.setdefault(c1_pn, set()).add(pn)
            c1_orig = orig_stock.get(c1_pn, 0.0)
            c1_rem = running_stock.get(c1_pn, 0.0)

        # Kebutuhan Coupling 2
        c2_pn, c2_req, c2_orig, c2_rem = '-', 0.0, 0.0, 0.0
        if len(couplings) >= 2:
            c2 = couplings[1]
            c2_pn = c2['pn']
            c2_req = c2['qty'] * req_qty
            comp_total_req[c2_pn] = comp_total_req.get(c2_pn, 0.0) + c2_req
            comp_used_by.setdefault(c2_pn, set()).add(pn)
            c2_orig = orig_stock.get(c2_pn, 0.0)
            c2_rem = running_stock.get(c2_pn, 0.0)

        # Evaluasi Ketersediaan Sisa Stok
        can_assemble = True
        missing_notes = []

        if hose_data and (h_rem < tot_cut):
            can_assemble = False
            missing_notes.append(f"Hose {hpn} butuh {tot_cut:.1f} CM, sisa {h_rem:.1f} CM (defisit {tot_cut - h_rem:.1f} CM)")

        if len(couplings) >= 1 and (c1_rem < c1_req):
            can_assemble = False
            missing_notes.append(f"Coupling {c1_pn} butuh {c1_req:.0f} PC, sisa {c1_rem:.0f} PC (defisit {c1_req - c1_rem:.0f} PC)")

        if len(couplings) >= 2 and (c2_rem < c2_req):
            can_assemble = False
            missing_notes.append(f"Coupling {c2_pn} butuh {c2_req:.0f} PC, sisa {c2_rem:.0f} PC (defisit {c2_req - c2_rem:.0f} PC)")

        if can_assemble:
            consist_status = "READY TO ASSEMBLE"
            status_remarks = "Ready to Assemble (Consist OK: Hose & Couplings in stock)"
            # Potong Kuota Stok ATP
            if hose_data:
                running_stock[hpn] -= tot_cut
                comp_alloc_stock[hpn] = comp_alloc_stock.get(hpn, 0.0) + tot_cut
                h_after = running_stock[hpn]
            else:
                h_after = 0.0

            if len(couplings) >= 1:
                running_stock[c1_pn] -= c1_req
                comp_alloc_stock[c1_pn] = comp_alloc_stock.get(c1_pn, 0.0) + c1_req
                c1_after = running_stock[c1_pn]
            else:
                c1_after = 0.0

            if len(couplings) >= 2:
                running_stock[c2_pn] -= c2_req
                comp_alloc_stock[c2_pn] = comp_alloc_stock.get(c2_pn, 0.0) + c2_req
                c2_after = running_stock[c2_pn]
            else:
                c2_after = 0.0
        else:
            consist_status = "CONSIST SHORTAGE"
            status_remarks = "Consist Shortage: " + "; ".join(missing_notes)
            h_after = h_rem
            c1_after = c1_rem
            c2_after = c2_rem

        # Simpan pemetaan status untuk updating merged_df
        hose_alloc_map[(pn, is_mp)] = {
            'status': consist_status,
            'remarks': status_remarks,
            'can_assemble': can_assemble,
            'req_qty': req_qty
        }
        hose_alloc_map[(base, is_mp)] = hose_alloc_map[(pn, is_mp)]

        table1_rows.append({
            'Material Number': mat_no,
            'Part Number (PN)': pn,
            'Material Description': desc,
            'Prioritas / Kategori': prio_label,
            'WO Requirement Qty': req_qty,
            'Assy On-hand Stock': 0.0,
            'Consist Status': consist_status,
            'Bulk Hose PN': hpn,
            'Cut Length (CM)': cut_len,
            'Total Hose Req (CM)': tot_cut,
            'Hose Stock ATP Awal (CM)': h_orig,
            'Hose Sisa Stok (CM)': h_after,
            'Coupling 1 PN': c1_pn,
            'Coupling 1 Req Qty': c1_req,
            'Coupling 1 Stock ATP Awal': c1_orig,
            'Coupling 1 Sisa Stok': c1_after,
            'Coupling 2 PN': c2_pn,
            'Coupling 2 Req Qty': c2_req,
            'Coupling 2 Stock ATP Awal': c2_orig,
            'Coupling 2 Sisa Stok': c2_after,
            'Consist Remarks / Shortage Detail': status_remarks
        })

    df_consist_analysis = pd.DataFrame(table1_rows)

    # Tabel 2: Rekapitulasi Akumulasi Kebutuhan Komponen
    table2_rows = []
    for cpn, dem in comp_total_req.items():
        ctype = comp_type.get(cpn, 'PART')
        cuom = comp_uom.get(cpn, 'PC')
        cdesc = comp_desc.get(cpn, '')
        s_orig = orig_stock.get(cpn, 0.0)
        s_alloc = comp_alloc_stock.get(cpn, 0.0)
        s_rem = running_stock.get(cpn, 0.0)
        net_bal = s_orig - dem
        is_deficit = net_bal < 0
        status_str = "🔴 DEFICIT" if is_deficit else "🟢 SUFFICIENT"
        deficit_val = abs(net_bal) if is_deficit else 0.0
        used_str = ", ".join(sorted(comp_used_by.get(cpn, [])))

        table2_rows.append({
            'Tipe Komponen': ctype,
            'Part Number (PN)': cpn,
            'Deskripsi Komponen': cdesc,
            'Total Akumulasi Kebutuhan': dem,
            'Satuan (UOM)': cuom,
            'UOM': cuom,
            'Stok ATP Awal': s_orig,
            'Total Teralokasi': s_alloc,
            'Sisa Stok ATP': s_rem,
            'Net Balance': net_bal,
            'Status Ketersediaan': status_str,
            'Defisit Qty': deficit_val,
            'Digunakan Pada Hose Assembly': used_str
        })

    df_component_summary = pd.DataFrame(table2_rows)
    if not df_component_summary.empty:
        df_component_summary['Sort_Key'] = df_component_summary['Status Ketersediaan'].apply(lambda x: 0 if 'DEFICIT' in x else 1)
        df_component_summary = df_component_summary.sort_values(
            by=['Sort_Key', 'Defisit Qty'], ascending=[True, False]
        ).drop(columns=['Sort_Key']).reset_index(drop=True)

    return df_consist_analysis, df_component_summary, hose_alloc_map


def apply_consist_status_to_merged(merged_df, hose_alloc_map, is_mp_sheet=False):
    """
    Memperbarui kolom Status dan Remarks pada merged_df berdasarkan hasil alokasi consist stok.
    """
    if merged_df is None or merged_df.empty or not hose_alloc_map:
        return merged_df

    updated = merged_df.copy()
    status_col = 'Status' if 'Status' in updated.columns else 'Status Ketersediaan'

    for idx, row in updated.iterrows():
        pn = str(row.get('PN', row.get('Part Number (PN)', ''))).strip().upper()
        base_pn = str(row.get('Base_PN', pn.split(':')[0].strip())).strip().upper()
        curr_status = str(row.get(status_col, ''))

        if 'Not Ready' not in curr_status:
            continue

        alloc_info = None
        if is_mp_sheet:
            alloc_info = hose_alloc_map.get((pn, True)) or hose_alloc_map.get((base_pn, True))
        else:
            alloc_info_mp = hose_alloc_map.get((pn, True)) or hose_alloc_map.get((base_pn, True))
            alloc_info_bl = hose_alloc_map.get((pn, False)) or hose_alloc_map.get((base_pn, False))
            if alloc_info_mp and alloc_info_bl:
                if alloc_info_mp['can_assemble'] and alloc_info_bl['can_assemble']:
                    alloc_info = alloc_info_mp
                elif alloc_info_mp['can_assemble']:
                    alloc_info = {
                        'can_assemble': False,
                        'status': 'CONSIST SHORTAGE',
                        'remarks': f"Consist Partial: Kebutuhan MP siap rakit ({alloc_info_mp['req_qty']:.0f} qty), backlog kurang ({alloc_info_bl['remarks']})"
                    }
                else:
                    alloc_info = alloc_info_mp
            elif alloc_info_mp:
                alloc_info = alloc_info_mp
            elif alloc_info_bl:
                alloc_info = alloc_info_bl

        if alloc_info:
            if alloc_info['can_assemble']:
                updated.at[idx, status_col] = 'Ready (Consist OK)'
                updated.at[idx, 'Remarks'] = 'Ready to Assemble (Consist OK: Hose & Couplings in stock)'
            else:
                updated.at[idx, 'Remarks'] = alloc_info['remarks']

    return updated


def populate_hose_consist_sheet(ws, df_consist, df_components, input_file_path, consist_file_path, stock_info_path):
    """
    Menata format Sheet Khusus 'Hose Consist Analysis':
    - Header Banner & 4 KPI Cards (Total Komponen, Sufficient, Deficit, Hose Siap Rakit)
    - Tabel Utama: Rekapitulasi Akumulasi Kebutuhan Komponen (Coupling & Bulk Hose Summary)
    """
    tot_comps = len(df_components) if df_components is not None and not df_components.empty else 0
    deficit_comps = int((df_components['Status Ketersediaan'] == '🔴 DEFICIT').sum()) if tot_comps > 0 else 0
    suff_comps = tot_comps - deficit_comps
    pct_def = (deficit_comps / tot_comps) if tot_comps > 0 else 0.0
    pct_suff = (suff_comps / tot_comps) if tot_comps > 0 else 0.0
    total_comp_dem = float(df_components['Total Akumulasi Kebutuhan'].sum()) if tot_comps > 0 else 0.0

    total_assys = len(df_consist) if df_consist is not None and not df_consist.empty else 0
    ready_count = int((df_consist['Consist Status'] == 'READY TO ASSEMBLE').sum()) if total_assys > 0 else 0
    shortage_count = int((df_consist['Consist Status'] == 'CONSIST SHORTAGE').sum()) if total_assys > 0 else 0
    pct_ready = (ready_count / total_assys) if total_assys > 0 else 0.0

    navy_dark = "1E3A8A"
    teal_header = "0F766E"
    green_card = "059669"
    red_card = "DC2626"
    amber_card = "D97706"
    gray_border = "D1D5DB"
    gray_total = "E2E8F0"

    font_title = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
    font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
    font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
    font_kpi_val = Font(name="Segoe UI", size=12, bold=True, color="1F2937")
    font_tbl_hdr = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
    font_tbl_body = Font(name="Segoe UI", size=9)

    fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_tbl_hdr = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    fill_blue = PatternFill(start_color="EFF6FF", end_color="EFF6FF", fill_type="solid")
    fill_green = PatternFill(start_color="ECFDF5", end_color="ECFDF5", fill_type="solid")
    fill_red = PatternFill(start_color="FEF2F2", end_color="FEF2F2", fill_type="solid")
    fill_soft_teal = PatternFill(start_color="F0FDF4", end_color="F0FDF4", fill_type="solid")

    thin_border = Border(
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border),
        top=Side(style='thin', color=gray_border),
        bottom=Side(style='thin', color=gray_border)
    )

    # 1. HEADER BANNER (B2:N2 & B3:N3)
    ws.views.sheetView[0].showGridLines = True
    ws.merge_cells("B2:N2")
    ws["B2"] = "🔧 REKAPITULASI AKUMULASI KEBUTUHAN KOMPONEN HOSE (COUPLING & BULK HOSE)"
    ws["B2"].font = font_title
    ws["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    c_src = f"  |  Master Consist: {os.path.basename(consist_file_path)}" if consist_file_path else ""
    inv_src = f"  |  Stock Info: {os.path.basename(stock_info_path)}" if stock_info_path else ""
    ws.merge_cells("B3:N3")
    ws["B3"] = f"Generated: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  RAW DATA: {os.path.basename(input_file_path)}{c_src}{inv_src}  |  Total Komponen: {tot_comps:,}  |  Defisit: {deficit_comps:,}"
    ws["B3"].font = font_sub
    ws["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    for r in range(2, 4):
        for c in range(2, 15):  # B (2) to N (14)
            ws.cell(row=r, column=c).fill = fill_banner

    # 2. KPI CARDS (B5:N7)
    # Card 1: TOTAL KOMPONEN (B5:D7)
    ws.merge_cells("B5:D5")
    ws["B5"] = "📋 TOTAL KOMPONEN"
    ws["B5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
    ws["B5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("B6:C6")
    ws["B6"] = "Total Part Unik:"
    ws["B6"].font = font_kpi_label
    ws["B6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D6"] = f"{tot_comps:,} parts"
    ws["D6"].font = font_kpi_val
    ws["D6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("B7:C7")
    ws["B7"] = "Total Akumulasi Req:"
    ws["B7"].font = font_kpi_label
    ws["B7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D7"] = f"{total_comp_dem:,.0f} qty"
    ws["D7"].font = font_kpi_val
    ws["D7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 2: SUFFICIENT (E5:G7)
    ws.merge_cells("E5:G5")
    ws["E5"] = "🟢 SUFFICIENT (STOK CUKUP)"
    ws["E5"].font = Font(name="Segoe UI", size=9, bold=True, color=green_card)
    ws["E5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("E6:F6")
    ws["E6"] = "Komponen Cukup:"
    ws["E6"].font = font_kpi_label
    ws["E6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["G6"] = f"{suff_comps:,} parts"
    ws["G6"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["G6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("E7:F7")
    ws["E7"] = "Sufficient Rate:"
    ws["E7"].font = font_kpi_label
    ws["E7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["G7"] = f"{pct_suff:.1%}"
    ws["G7"].font = Font(name="Segoe UI", size=14, bold=True, color=green_card)
    ws["G7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 3: DEFICIT (H5:J7)
    ws.merge_cells("H5:J5")
    ws["H5"] = "🔴 DEFICIT (STOK KURANG)"
    ws["H5"].font = Font(name="Segoe UI", size=9, bold=True, color=red_card)
    ws["H5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("H6:I6")
    ws["H6"] = "Komponen Defisit:"
    ws["H6"].font = font_kpi_label
    ws["H6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["J6"] = f"{deficit_comps:,} parts"
    ws["J6"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws["J6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("H7:I7")
    ws["H7"] = "Deficit Rate:"
    ws["H7"].font = font_kpi_label
    ws["H7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["J7"] = f"{pct_def:.1%}"
    ws["J7"].font = Font(name="Segoe UI", size=14, bold=True, color=red_card)
    ws["J7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 4: HOSE SIAP RAKIT (K5:N7)
    ws.merge_cells("K5:N5")
    ws["K5"] = "🔧 HOSE SIAP RAKIT (CONSIST)"
    ws["K5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
    ws["K5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("K6:L6")
    ws["K6"] = "Ready to Assemble:"
    ws["K6"].font = font_kpi_label
    ws["K6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.merge_cells("M6:N6")
    ws["M6"] = f"{ready_count:,} items ({pct_ready:.1%})"
    ws["M6"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["M6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("K7:L7")
    ws["K7"] = "Consist Shortage:"
    ws["K7"].font = font_kpi_label
    ws["K7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.merge_cells("M7:N7")
    ws["M7"] = f"{shortage_count:,} items"
    ws["M7"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card if shortage_count > 0 else "4B5563")
    ws["M7"].alignment = Alignment(horizontal="center", vertical="center")

    for r in range(5, 8):
        for c in range(2, 5):   # B - D
            ws.cell(row=r, column=c).fill = fill_blue
        for c in range(5, 8):   # E - G
            ws.cell(row=r, column=c).fill = fill_green
        for c in range(8, 11):  # H - J
            ws.cell(row=r, column=c).fill = fill_red
        for c in range(11, 15): # K - N
            ws.cell(row=r, column=c).fill = fill_soft_teal
        for c in range(2, 15):
            ws.cell(row=r, column=c).border = thin_border

    # 3. SECTION TITLE (B9)
    ws["B9"] = "📦 REKAPITULASI AKUMULASI KEBUTUHAN KOMPONEN (COUPLING & BULK HOSE SUMMARY)"
    ws["B9"].font = font_section

    # 4. TABEL HEADERS (Row 11, Kolom B sampai N)
    headers = [
        "No",
        "Tipe Komponen",
        "Part Number (PN)",
        "Deskripsi Komponen",
        "Total Akumulasi Kebutuhan",
        "Satuan (UOM)",
        "Stok ATP Awal",
        "Total Teralokasi (Ready)",
        "Sisa Stok ATP",
        "Net Balance",
        "Status Ketersediaan",
        "Defisit Qty",
        "Digunakan Pada Hose Assembly"
    ]

    h_row = 11
    for i, h in enumerate(headers, start=2):
        c = ws.cell(row=h_row, column=i, value=h)
        c.font = font_tbl_hdr
        c.fill = fill_tbl_hdr
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = thin_border
    ws.row_dimensions[h_row].height = 28

    curr_r = h_row + 1
    if df_components is not None and not df_components.empty:
        for idx, r in df_components.iterrows():
            is_def = ('DEFICIT' in str(r['Status Ketersediaan']))
            st_color = red_card if is_def else green_card

            t_cells = [
                (idx + 1, "#,##0", "center", None),
                (r['Tipe Komponen'], "@", "center", Font(name="Segoe UI", size=9, bold=True, color="1E3A8A" if r['Tipe Komponen'] == 'BULK HOSE' else "0F766E")),
                (r['Part Number (PN)'], "@", "center", Font(name="Segoe UI", size=9, bold=True)),
                (r['Deskripsi Komponen'], "@", "left", None),
                (r['Total Akumulasi Kebutuhan'], "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True)),
                (r.get('Satuan (UOM)', r.get('UOM', 'PC')), "@", "center", None),
                (r['Stok ATP Awal'], "#,##0.00", "right", None),
                (r['Total Teralokasi'], "#,##0.00", "right", None),
                (r['Sisa Stok ATP'], "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True)),
                (r['Net Balance'], "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True, color=red_card if r['Net Balance'] < 0 else green_card)),
                (r['Status Ketersediaan'], "@", "center", Font(name="Segoe UI", size=9, bold=True, color=st_color)),
                (r['Defisit Qty'], "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True, color=red_card if r['Defisit Qty'] > 0 else "4B5563")),
                (r['Digunakan Pada Hose Assembly'], "@", "left", None)
            ]

            for col_i, (v, fmt, align, custom_font) in enumerate(t_cells, start=2):
                cell = ws.cell(row=curr_r, column=col_i, value=v)
                cell.font = custom_font or font_tbl_body
                cell.number_format = fmt
                cell.alignment = Alignment(horizontal=align, vertical="center")
                cell.border = thin_border
                if is_def:
                    cell.fill = PatternFill(start_color="FEF2F2", end_color="FEF2F2", fill_type="solid")
                elif idx % 2 == 1:
                    cell.fill = fill_alt

            ws.row_dimensions[curr_r].height = 20
            curr_r += 1

    col_widths = {
        2: 6,   # No
        3: 16,  # Tipe Komponen
        4: 16,  # Part Number (PN)
        5: 32,  # Deskripsi Komponen
        6: 18,  # Total Akumulasi Kebutuhan
        7: 12,  # Satuan (UOM)
        8: 16,  # Stok ATP Awal
        9: 16,  # Total Teralokasi (Ready)
        10: 16, # Sisa Stok ATP
        11: 16, # Net Balance
        12: 18, # Status Ketersediaan
        13: 16, # Defisit Qty
        14: 45  # Digunakan Pada Hose Assembly
    }
    for c_idx, w in col_widths.items():
        ws.column_dimensions[get_column_letter(c_idx)].width = w

    ws.freeze_panes = "B12"
    ws.auto_filter.ref = f"B11:N{curr_r - 1}"


def clean_order_no(val):
    """
    Membersihkan dan menstandarisasi nomor Work Order (Order Number):
    Menghapus suffix .0 (dari float Excel), spasi, dan menangani nilai kosong/NaN.
    """
    if val is None or pd.isna(val):
        return ""
    s = str(val).strip()
    if s.lower() == 'nan':
        return ""
    if s.endswith('.0'):
        s = s[:-2]
    return s


def find_matching_mp_file(raw_file_path=None):
    """
    Mencari file Monthly Plan (MP) secara otomatis:
    - Di direktori raw_file_path (jika ada)
    - Di folder Downloads
    - Di folder Desktop
    Memprioritaskan file dengan kata kunci 'LIST WO MP', mencocokkan bulan/tahun dari raw_file_path jika ada,
    serta file terbaru berdasarkan waktu modifikasi.
    """
    month_map = {
        '01': ['JAN', 'JANUARI', 'JANUARY'],
        '02': ['FEB', 'FEBRUARI', 'FEBRUARY'],
        '03': ['MAR', 'MARET', 'MARCH'],
        '04': ['APR', 'APRIL'],
        '05': ['MEI', 'MAY'],
        '06': ['JUN', 'JUNI', 'JUNE'],
        '07': ['JUL', 'JULI', 'JULY'],
        '08': ['AGU', 'AGUSTUS', 'AUG', 'AUGUST'],
        '09': ['SEP', 'SEPTEMBER'],
        '10': ['OKT', 'OKTOBER', 'OCT', 'OCTOBER'],
        '11': ['NOV', 'NOVEMBER'],
        '12': ['DES', 'DESEMBER', 'DEC', 'DECEMBER']
    }

    target_month_words = []
    target_year = ""
    if raw_file_path:
        match_date = re.search(r'(\d{2})(\d{2})(\d{4})', os.path.basename(raw_file_path))
        if match_date:
            m_code = match_date.group(2)
            target_year = match_date.group(3)
            target_month_words = month_map.get(m_code, [])

    search_dirs = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop"),
    ]
    if raw_file_path and os.path.exists(raw_file_path):
        search_dirs.insert(0, os.path.dirname(raw_file_path))

    candidates = []
    seen = set()
    for d in search_dirs:
        if not os.path.exists(d) or d in seen:
            continue
        seen.add(d)
        try:
            for fname in os.listdir(d):
                if fname.startswith("~$"):
                    continue
                fu = fname.upper()
                if not fname.endswith(('.xlsx', '.XLSX', '.xlsb', '.XLSB')):
                    continue
                if "LIST WO MP" in fu or ("WO" in fu and "MP" in fu) or "MONTHLY PLAN" in fu:
                    full_p = os.path.join(d, fname)
                    score = 0
                    if "LIST WO MP" in fu:
                        score += 50
                    if target_year and target_year in fu:
                        score += 30
                    if any(w in fu for w in target_month_words):
                        score += 40
                    candidates.append((score, os.path.getmtime(full_p) if os.path.exists(full_p) else 0, full_p))
        except Exception:
            continue

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return candidates[0][2]


def load_monthly_plan_orders(mp_file_path):
    """
    Membaca file Monthly Plan (.xlsb / .xlsx) dan mengekstrak:
    - mp_orders: set of clean Order Numbers
    - mp_meta: dict mapping clean Order Number -> { 'Room': ..., 'Header Text': ..., 'Status WO': ... }
    - target_sheet_name: nama sheet yang digunakan (prioritas sheet mengandung 'MP')
    """
    if not mp_file_path or not os.path.exists(mp_file_path):
        return set(), {}, None

    wb = CalamineWorkbook.from_path(mp_file_path)
    target_sheet = None

    # Cari sheet dengan nama mengandung 'MP' (kecuali MB51)
    for s in wb.sheet_names:
        su = s.upper()
        if 'MP' in su and 'MB51' not in su:
            target_sheet = s
            break

    # Fallback: cari sheet yang baris pertamanya memiliki 'Order Number'
    if not target_sheet:
        for s in wb.sheet_names:
            try:
                sample = wb.get_sheet_by_name(s).to_python()
                if sample and len(sample) > 0:
                    hdr_line = ' '.join(str(c).upper() for c in sample[0])
                    if 'ORDER NUMBER' in hdr_line:
                        target_sheet = s
                        break
            except Exception:
                pass

    if not target_sheet:
        target_sheet = wb.sheet_names[0]

    rows = wb.get_sheet_by_name(target_sheet).to_python()
    if not rows or len(rows) < 2:
        return set(), {}, target_sheet

    hdr = [str(h).strip() for h in rows[0]]
    ord_idx = next((i for i, h in enumerate(hdr) if 'ORDER NUMBER' in h.upper() or 'ORDER' in h.upper()), 0)
    room_idx = next((i for i, h in enumerate(hdr) if 'ROOM' in h.upper()), None)
    desc_idx = next((i for i, h in enumerate(hdr) if 'HEADER TEXT' in h.upper() or 'DESC' in h.upper()), None)
    status_idx = next((i for i, h in enumerate(hdr) if 'STATUS WO' in h.upper() or 'STATUS' in h.upper()), None)

    mp_orders = set()
    mp_meta = {}
    for r in rows[1:]:
        if len(r) <= ord_idx:
            continue
        o = clean_order_no(r[ord_idx])
        if not o:
            continue
        mp_orders.add(o)
        if o not in mp_meta:
            mp_meta[o] = {
                'Room': str(r[room_idx]).strip() if room_idx is not None and len(r) > room_idx and r[room_idx] is not None and str(r[room_idx]).lower() != 'nan' else '',
                'Header Text': str(r[desc_idx]).strip() if desc_idx is not None and len(r) > desc_idx and r[desc_idx] is not None and str(r[desc_idx]).lower() != 'nan' else '',
                'Status WO': str(r[status_idx]).strip() if status_idx is not None and len(r) > status_idx and r[status_idx] is not None and str(r[status_idx]).lower() != 'nan' else ''
            }

    return mp_orders, mp_meta, target_sheet


def merge_readiness_data(pivot_req, pivot_mb52, pivot_inv, pivot_inv_base, has_stock_info):
    """
    Menggabungkan pivot kebutuhan AS57D dengan pivot MB52 (Stock S) dan Stock Info (ATP & OO).
    """
    if pivot_req.empty:
        return pd.DataFrame(columns=[
            'Material Number', 'PN', 'Base_PN', 'Material Description',
            'Requirement_Qty', 'Stock_MB52_S', 'Stock_Info_ATP', 'Stock_Info_OO',
            'Total_Available_Stock', 'Balance / Deficit', 'Status', 'Remarks'
        ])

    merged = pd.merge(pivot_req, pivot_mb52, left_on='Material Number', right_on='Material', how='left')
    merged['Stock_MB52_S'] = merged['Stock_MB52_S'].fillna(0.0)

    # Pastikan PN dan Base_PN di merged mengikuti CUSTOM_PN_MAPPING jika ada
    if 'PN' in merged.columns:
        for k, v in CUSTOM_PN_MAPPING.items():
            mask = (merged['PN'] == k)
            if mask.any():
                merged.loc[mask, 'PN'] = v
                if 'Base_PN' in merged.columns:
                    b_val = v.split(':')[0].strip() if ':' in v else v
                    merged.loc[mask, 'Base_PN'] = b_val

    if has_stock_info and not pivot_inv.empty:
        cols_to_pull = ['Material_Key', 'Stock_Info_ATP']
        if 'Stock_Info_OO' in pivot_inv.columns:
            cols_to_pull.append('Stock_Info_OO')

        inv_lookup = pivot_inv[cols_to_pull].drop_duplicates(subset=['Material_Key'])
        merged = pd.merge(merged, inv_lookup, left_on='PN', right_on='Material_Key', how='left')

        base_cols_to_pull = ['Base_Key', 'Stock_Info_Base']
        if 'Stock_Info_Base_OO' in pivot_inv_base.columns:
            base_cols_to_pull.append('Stock_Info_Base_OO')

        merged = pd.merge(merged, pivot_inv_base[base_cols_to_pull], left_on='Base_PN', right_on='Base_Key', how='left')

        # Fallback Base PN jika exact match PN (:AA) NaN
        merged['Stock_Info_ATP'] = np.where(
            merged['Stock_Info_ATP'].notna(),
            merged['Stock_Info_ATP'],
            merged['Stock_Info_Base'].fillna(0.0)
        )

        if 'Stock_Info_OO' in merged.columns:
            base_oo = merged['Stock_Info_Base_OO'].fillna(0.0) if 'Stock_Info_Base_OO' in merged.columns else 0.0
            merged['Stock_Info_OO'] = np.where(
                merged['Stock_Info_OO'].notna(),
                merged['Stock_Info_OO'],
                base_oo
            )
            merged['Stock_Info_OO'] = merged['Stock_Info_OO'].fillna(0.0)
        else:
            merged['Stock_Info_OO'] = 0.0
    else:
        merged['Stock_Info_ATP'] = 0.0
        merged['Stock_Info_OO'] = 0.0

    merged['Total_Available_Stock'] = merged['Stock_MB52_S'] + merged['Stock_Info_ATP']
    merged['Balance / Deficit'] = merged['Total_Available_Stock'] - merged['Requirement_Qty']
    merged['Status'] = np.where(merged['Balance / Deficit'] >= 0, 'Ready / Sufficient', 'Not Ready')

    # Logika Remarks Otomatis:
    # 1. Jika Ready Stock -> "Ready stock"
    # 2. Jika Not Ready & Total Stock + OO >= req qty -> "Follow up STO."
    # 3. Jika Not Ready & Total Stock + OO < req qty -> "Need refill stock"
    cond_ready = (merged['Status'] == 'Ready / Sufficient')
    cond_followup_sto = (~cond_ready) & ((merged['Total_Available_Stock'] + merged['Stock_Info_OO']) >= merged['Requirement_Qty'])

    merged['Remarks'] = np.where(
        cond_ready,
        'Ready stock',
        np.where(cond_followup_sto, 'Follow up STO.', 'Need refill stock')
    )

    # Urutkan: Not Ready di atas, lalu defisit terbesar
    merged = merged.sort_values(by=['Status', 'Balance / Deficit'], ascending=[True, True]).copy()
    return merged


def populate_readiness_sheet(ws, merged_df, title_text, input_file_path, stock_info_path, has_stock_info, kuota_file_path=None, has_kuota_info=False, mp_file_path=None, has_mp_info=False, is_mp_sheet=False):
    """
    Menata format Sheet Part Readiness (Banner B-L, KPI Cards B-L, Tabel B-L termasuk OO & Remarks otomatis).
    Mendukung tampilan khusus Monthly Plan (is_mp_sheet=True).
    """
    total_parts_required = len(merged_df)
    total_req_qty = float(merged_df['Requirement_Qty'].sum()) if total_parts_required > 0 else 0.0
    parts_ready = int((merged_df['Status'].astype(str).str.startswith('Ready')).sum()) if total_parts_required > 0 else 0
    parts_ready_onhand = int((merged_df['Status'] == 'Ready / Sufficient').sum()) if total_parts_required > 0 else 0
    parts_ready_consist = int((merged_df['Status'] == 'Ready (Consist OK)').sum()) if total_parts_required > 0 else 0
    parts_not_ready = int((merged_df['Status'].astype(str).str.startswith('Not Ready')).sum()) if total_parts_required > 0 else 0
    pct_ready = (parts_ready / total_parts_required) if total_parts_required > 0 else 0.0
    pct_not_ready = (parts_not_ready / total_parts_required) if total_parts_required > 0 else 0.0

    # Palette Warna
    navy_dark = "1E3A8A"
    blue_header = "2563EB"
    blue_light = "EFF6FF"
    green_card = "059669"
    green_light = "ECFDF5"
    red_card = "DC2626"
    red_light = "FEF2F2"
    amber_card = "D97706"
    gray_border = "D1D5DB"
    gray_total = "E2E8F0"

    font_title = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
    font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
    font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
    font_kpi_val = Font(name="Segoe UI", size=12, bold=True, color="1F2937")
    font_tbl_hdr = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    font_tbl_body = Font(name="Segoe UI", size=9)
    font_tbl_total = Font(name="Segoe UI", size=9, bold=True, color="1F2937")

    fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_tbl_hdr = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
    fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")

    thin_border = Border(
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border),
        top=Side(style='thin', color=gray_border),
        bottom=Side(style='thin', color=gray_border)
    )
    total_border = Border(
        top=Side(style='thin', color="4B5563"),
        bottom=Side(style='double', color="4B5563"),
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border)
    )

    # 1. HEADER BANNER (Baris 2-3, Kolom B sampai L)
    ws.merge_cells("B2:L2")
    ws["B2"] = title_text
    ws["B2"].font = font_title
    ws["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    inv_src_label = f"  |  Stock Info: {os.path.basename(stock_info_path)}" if has_stock_info else "  |  Stock Info: (None)"
    kuota_src_label = f"  |  Kuota: {os.path.basename(kuota_file_path)}" if (kuota_file_path and has_kuota_info) else ""
    mp_src_label = f"  |  Monthly Plan: {os.path.basename(mp_file_path)}" if (mp_file_path and has_mp_info) else ""
    ws.merge_cells("B3:L3")
    ws["B3"] = f"Generated: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  RAW DATA: {os.path.basename(input_file_path)}{mp_src_label}{inv_src_label}{kuota_src_label}  |  Total Items: {total_parts_required:,}"
    ws["B3"].font = font_sub
    ws["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    for r in range(2, 4):
        for c in range(2, 13):  # Kolom B (2) s/d L (12)
            ws.cell(row=r, column=c).fill = fill_banner

    # 2. KPI CARDS (Baris 5-7, Kolom B sampai L)
    card1_title = "📋 TOTAL MP REQUIREMENT" if is_mp_sheet else "📋 TOTAL WO REQUIREMENT"
    card2_title = "🟢 READY / SUFFICIENT MP" if is_mp_sheet else "🟢 READY / SUFFICIENT"
    card3_title = "🔴 SHORTAGE / NOT READY MP" if is_mp_sheet else "🔴 SHORTAGE / NOT READY"

    # Card 1: TOTAL REQUIREMENT (B5:D7) -> 3 cols
    ws.merge_cells("B5:D5")
    ws["B5"] = card1_title
    ws["B5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
    ws["B5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("B6:C6")
    ws["B6"] = "Total Part Numbers:"
    ws["B6"].font = font_kpi_label
    ws["B6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D6"] = f"{total_parts_required:,} items"
    ws["D6"].font = font_kpi_val
    ws["D6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("B7:C7")
    ws["B7"] = "Total Requirement Qty:"
    ws["B7"].font = font_kpi_label
    ws["B7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D7"] = f"{total_req_qty:,.0f} qty"
    ws["D7"].font = font_kpi_val
    ws["D7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 2: READY PARTS (E5:H7) -> 4 cols (E, F, G, H)
    ws.merge_cells("E5:H5")
    ws["E5"] = card2_title
    ws["E5"].font = Font(name="Segoe UI", size=9, bold=True, color=green_card)
    ws["E5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("E6:G6")
    ws["E6"] = "Total Parts Ready:"
    ws["E6"].font = font_kpi_label
    ws["E6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["H6"] = f"{parts_ready:,} items"
    ws["H6"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["H6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("E7:G7")
    ws["E7"] = "Fulfillment Rate:"
    ws["E7"].font = font_kpi_label
    ws["E7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["H7"] = f"{pct_ready:.1%}"
    ws["H7"].font = Font(name="Segoe UI", size=14, bold=True, color=green_card)
    ws["H7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 3: SHORTAGE / NOT READY PARTS (I5:L7) -> 4 cols (I, J, K, L)
    ws.merge_cells("I5:L5")
    ws["I5"] = card3_title
    ws["I5"].font = Font(name="Segoe UI", size=9, bold=True, color=red_card)
    ws["I5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("I6:K6")
    ws["I6"] = "Total Parts Shortage:"
    ws["I6"].font = font_kpi_label
    ws["I6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["L6"] = f"{parts_not_ready:,} items"
    ws["L6"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws["L6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("I7:K7")
    ws["I7"] = "Shortage Rate:"
    ws["I7"].font = font_kpi_label
    ws["I7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["L7"] = f"{pct_not_ready:.1%}"
    ws["L7"].font = Font(name="Segoe UI", size=14, bold=True, color=red_card)
    ws["L7"].alignment = Alignment(horizontal="center", vertical="center")

    fill_blue = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
    fill_green = PatternFill(start_color=green_light, end_color=green_light, fill_type="solid")
    fill_red = PatternFill(start_color=red_light, end_color=red_light, fill_type="solid")

    for r in range(5, 8):
        for c in range(2, 5):
            ws.cell(row=r, column=c).fill = fill_blue
        for c in range(5, 9):
            ws.cell(row=r, column=c).fill = fill_green
        for c in range(9, 13):
            ws.cell(row=r, column=c).fill = fill_red
        for c in range(2, 13):
            ws.cell(row=r, column=c).border = thin_border

    # 3. TABEL PERBANDINGAN BERDAMPINGAN (Baris 9)
    ws["B9"] = "📊 Part Requirement vs Customer MB52, Onhand ATP & On-Order (Sorted by Shortage)"
    ws["B9"].font = font_section

    tbl_headers = [
        "Material Number",
        "Part Number (PN)",
        "Material Description",
        "Requirement Qty (AS57D)",
        "Stock MB52 (S)",
        "Onhand ATP",
        "Total Available Stock",
        "Balance / Deficit",
        "Readiness Status",
        "On Order (OO)",
        "Remarks"
    ]

    h_row = 11
    for i, h in enumerate(tbl_headers, start=2):
        c = ws.cell(row=h_row, column=i, value=h)
        c.font = font_tbl_hdr
        c.fill = fill_tbl_hdr
        c.alignment = Alignment(horizontal="center" if i not in [4, 12] else "left", vertical="center")
        c.border = thin_border

    curr_r = h_row + 1
    for idx, r in merged_df.iterrows():
        mat_no = r['Material Number']
        pn = r['PN']
        desc = r['Material Description']
        req_q = r['Requirement_Qty']
        mb52_q = r['Stock_MB52_S']
        info_q = r['Stock_Info_ATP']
        oo_q = r.get('Stock_Info_OO', 0.0)
        bal = r['Balance / Deficit']
        status = r['Status']
        remarks_val = r.get('Remarks', '')

        is_not_ready = (status == 'Not Ready') or str(status).startswith('Not Ready')
        is_consist_ready = (status == 'Ready (Consist OK)')
        fill_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid") if (idx % 2 == 1) else None

        # Format warna remarks
        if remarks_val == "Ready stock":
            font_rem = Font(name="Segoe UI", size=9, bold=True, color=green_card)
        elif is_consist_ready or "Ready to Assemble" in str(remarks_val):
            font_rem = Font(name="Segoe UI", size=9, bold=True, color="0D9488")
        elif remarks_val == "Follow up STO.":
            font_rem = Font(name="Segoe UI", size=9, bold=True, color=amber_card)
        else:
            font_rem = Font(name="Segoe UI", size=9, bold=True, color=red_card)

        if is_consist_ready:
            status_text = "🔧 Ready (Consist OK)"
            status_color = "0D9488"
        elif is_not_ready:
            status_text = "🔴 Not Ready"
            status_color = red_card
        else:
            status_text = "🟢 Ready"
            status_color = green_card

        row_defs = [
            (mat_no, "@", "center", None),
            (pn, "@", "center", Font(name="Segoe UI", size=9, bold=True)),
            (desc, "@", "left", None),
            (req_q, "#,##0.00", "right", None),
            (mb52_q, "#,##0.00", "right", None),
            (info_q, "#,##0.00", "right", None),
            (f"=F{curr_r}+G{curr_r}", "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True)),
            (f"=H{curr_r}-E{curr_r}", "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True, color=red_card if is_not_ready else ("0D9488" if is_consist_ready else green_card))),
            (status_text, "@", "center", Font(name="Segoe UI", size=9, bold=True, color=status_color)),
            (oo_q, "#,##0.00", "right", Font(name="Segoe UI", size=9)),
            (remarks_val, "@", "left", font_rem)
        ]

        for col_i, (v, fmt, align, custom_font) in enumerate(row_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = custom_font or font_tbl_body
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = thin_border
            if fill_alt and not is_not_ready:
                cell.fill = fill_alt

        curr_r += 1

    # GRAND TOTAL ROW
    if curr_r > h_row + 1:
        total_row_defs = [
            ("GRAND TOTAL", "@", "left"),
            ("", "@", "center"),
            (f"{total_parts_required:,} items", "@", "left"),
            (f"=SUM(E12:E{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(F12:F{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(G12:G{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(H12:H{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(I12:I{curr_r-1})", "#,##0.00", "right"),
            (f"{parts_ready} Ready | {parts_not_ready} Not Ready", "@", "center"),
            (f"=SUM(K12:K{curr_r-1})", "#,##0.00", "right"),
            ("", "@", "left")
        ]
        for col_i, (v, fmt, align) in enumerate(total_row_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = font_tbl_total
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = total_border
            cell.fill = fill_total
        filter_end = curr_r - 1
    else:
        filter_end = 12

    # Atur Lebar Kolom
    col_w = {
        'A': 3,
        'B': 22,  # Material Number
        'C': 18,  # PN
        'D': 35,  # Description
        'E': 22,  # Requirement Qty (AS57D)
        'F': 18,  # Stock MB52 (S)
        'G': 20,  # Stock ATP TU
        'H': 20,  # Total Available Stock
        'I': 18,  # Balance / Deficit
        'J': 20,  # Status Ketersediaan
        'K': 18,  # On Order (OO)
        'L': 25,  # Remarks
    }
    for c_l, w in col_w.items():
        ws.column_dimensions[c_l].width = w

    ws.freeze_panes = "B12"
    ws.auto_filter.ref = f"B11:L{filter_end}"
    ws.views.sheetView[0].showGridLines = True


def populate_all_wo_with_mp_sheet(ws, merged_df, title_text, input_file_path, stock_info_path, has_stock_info, kuota_file_path=None, has_kuota_info=False, mp_file_path=None, has_mp_info=False):
    """
    Menata format Sheet Part Readiness - All WO dengan identifikasi Monthly Plan (Kolom B-N).
    Kolom:
    B: Material Number
    C: Part Number (PN)
    D: Material Description
    E: Monthly Plan? (🟢 YES (MP) / ⚪ NO)
    F: Req Qty MP
    G: Requirement Qty (All)
    H: Stock MB52 (S)
    I: Stock ATP TU
    J: Total Available Stock
    K: Balance / Deficit
    L: Status Ketersediaan
    M: On Order (OO)
    N: Remarks
    """
    total_parts_required = len(merged_df)
    total_req_qty = float(merged_df['Requirement_Qty'].sum()) if total_parts_required > 0 else 0.0
    parts_ready = int((merged_df['Status'].astype(str).str.startswith('Ready')).sum()) if total_parts_required > 0 else 0
    parts_not_ready = int((merged_df['Status'].astype(str).str.startswith('Not Ready')).sum()) if total_parts_required > 0 else 0
    pct_ready = (parts_ready / total_parts_required) if total_parts_required > 0 else 0.0
    pct_not_ready = (parts_not_ready / total_parts_required) if total_parts_required > 0 else 0.0
    mp_items_cnt = int((merged_df.get('Monthly_Plan_Tag', pd.Series(dtype=object)) == '🟢 YES (MP)').sum()) if total_parts_required > 0 and 'Monthly_Plan_Tag' in merged_df.columns else 0

    # Palette Warna
    navy_dark = "1E3A8A"
    blue_header = "2563EB"
    blue_light = "EFF6FF"
    green_card = "059669"
    green_light = "ECFDF5"
    red_card = "DC2626"
    red_light = "FEF2F2"
    amber_card = "D97706"
    gray_border = "D1D5DB"
    gray_total = "E2E8F0"

    font_title = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
    font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
    font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
    font_kpi_val = Font(name="Segoe UI", size=12, bold=True, color="1F2937")
    font_tbl_hdr = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    font_tbl_body = Font(name="Segoe UI", size=9)
    font_tbl_total = Font(name="Segoe UI", size=9, bold=True, color="1F2937")

    fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_tbl_hdr = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
    fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")

    thin_border = Border(
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border),
        top=Side(style='thin', color=gray_border),
        bottom=Side(style='thin', color=gray_border)
    )
    total_border = Border(
        top=Side(style='thin', color="4B5563"),
        bottom=Side(style='double', color="4B5563"),
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border)
    )

    # 1. HEADER BANNER (Baris 2-3, Kolom B sampai N)
    ws.merge_cells("B2:N2")
    ws["B2"] = title_text
    ws["B2"].font = font_title
    ws["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    inv_src_label = f"  |  Stock Info: {os.path.basename(stock_info_path)}" if has_stock_info else "  |  Stock Info: (None)"
    kuota_src_label = f"  |  Kuota: {os.path.basename(kuota_file_path)}" if (kuota_file_path and has_kuota_info) else ""
    mp_src_label = f"  |  Monthly Plan: {os.path.basename(mp_file_path)}" if (mp_file_path and has_mp_info) else ""
    ws.merge_cells("B3:N3")
    ws["B3"] = f"Generated: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  RAW DATA: {os.path.basename(input_file_path)}{mp_src_label}{inv_src_label}{kuota_src_label}  |  Total Items: {total_parts_required:,}"
    ws["B3"].font = font_sub
    ws["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    for r in range(2, 4):
        for c in range(2, 15):  # Kolom B (2) s/d N (14)
            ws.cell(row=r, column=c).fill = fill_banner

    # 2. KPI CARDS (Baris 5-7, Kolom B sampai N)
    # Card 1: TOTAL KEBUTUHAN ALL WO (B5:E7) -> 4 cols (B, C, D, E)
    ws.merge_cells("B5:E5")
    ws["B5"] = "📋 TOTAL KEBUTUHAN ALL WO"
    ws["B5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
    ws["B5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("B6:D6")
    ws["B6"] = "Total Part Number:"
    ws["B6"].font = font_kpi_label
    ws["B6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["E6"] = f"{total_parts_required:,} items"
    ws["E6"].font = font_kpi_val
    ws["E6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("B7:D7")
    ws["B7"] = "Total Requirement:"
    ws["B7"].font = font_kpi_label
    ws["B7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["E7"] = f"{total_req_qty:,.0f} qty"
    ws["E7"].font = font_kpi_val
    ws["E7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 2: READY PARTS (F5:I7) -> 4 cols (F, G, H, I)
    ws.merge_cells("F5:I5")
    ws["F5"] = "🟢 READY / SUFFICIENT"
    ws["F5"].font = Font(name="Segoe UI", size=9, bold=True, color=green_card)
    ws["F5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("F6:H6")
    ws["F6"] = "Total Part Ready:"
    ws["F6"].font = font_kpi_label
    ws["F6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["I6"] = f"{parts_ready:,} items"
    ws["I6"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["I6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("F7:H7")
    ws["F7"] = "Fulfillment Rate:"
    ws["F7"].font = font_kpi_label
    ws["F7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["I7"] = f"{pct_ready:.1%}"
    ws["I7"].font = Font(name="Segoe UI", size=14, bold=True, color=green_card)
    ws["I7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 3: NOT READY PARTS (J5:N7) -> 5 cols (J, K, L, M, N)
    ws.merge_cells("J5:N5")
    ws["J5"] = "🔴 NOT READY"
    ws["J5"].font = Font(name="Segoe UI", size=9, bold=True, color=red_card)
    ws["J5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("J6:L6")
    ws["J6"] = "Total Part Not Ready:"
    ws["J6"].font = font_kpi_label
    ws["J6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["N6"] = f"{parts_not_ready:,} items"
    ws["N6"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws["N6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("J7:L7")
    ws["J7"] = "Not Ready Rate:"
    ws["J7"].font = font_kpi_label
    ws["J7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["N7"] = f"{pct_not_ready:.1%}"
    ws["N7"].font = Font(name="Segoe UI", size=14, bold=True, color=red_card)
    ws["N7"].alignment = Alignment(horizontal="center", vertical="center")

    fill_blue = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
    fill_green = PatternFill(start_color=green_light, end_color=green_light, fill_type="solid")
    fill_red = PatternFill(start_color=red_light, end_color=red_light, fill_type="solid")

    for r in range(5, 8):
        for c in range(2, 6):   # B - E
            ws.cell(row=r, column=c).fill = fill_blue
        for c in range(6, 10):  # F - I
            ws.cell(row=r, column=c).fill = fill_green
        for c in range(10, 15): # J - N
            ws.cell(row=r, column=c).fill = fill_red
        for c in range(2, 15):
            ws.cell(row=r, column=c).border = thin_border

    # 3. TABEL DETAIL (Baris 9-11)
    ws["B9"] = "📊 Detail Seluruh Kebutuhan WO Aktif (Dilengkapi Identifikasi Monthly Plan & Kebutuhan MP)"
    ws["B9"].font = font_section

    tbl_headers = [
        "Material Number",
        "Part Number (PN)",
        "Material Description",
        "Monthly Plan?",
        "Req Qty MP",
        "Requirement Qty (All)",
        "Stock MB52 (S)",
        "Stock ATP TU",
        "Total Available Stock",
        "Balance / Deficit",
        "Status Ketersediaan",
        "On Order (OO)",
        "Remarks"
    ]

    h_row = 11
    for i, h in enumerate(tbl_headers, start=2):
        c = ws.cell(row=h_row, column=i, value=h)
        c.font = font_tbl_hdr
        c.fill = fill_tbl_hdr
        c.alignment = Alignment(horizontal="center" if i not in [4, 14] else "left", vertical="center")
        c.border = thin_border

    curr_r = h_row + 1
    for idx, r in merged_df.iterrows():
        mat_no = r['Material Number']
        pn = r['PN']
        desc = r['Material Description']
        is_mp_item = (r.get('Monthly_Plan_Tag') == '🟢 YES (MP)')
        req_mp = float(r.get('Req_Qty_MP', 0.0))
        req_q = float(r['Requirement_Qty'])
        mb52_q = float(r['Stock_MB52_S'])
        info_q = float(r['Stock_Info_ATP'])
        oo_q = float(r.get('Stock_Info_OO', 0.0))
        bal = float(r['Balance / Deficit'])
        status = r['Status']
        remarks_val = r.get('Remarks', '')

        is_not_ready = (status == 'Not Ready') or str(status).startswith('Not Ready')
        is_consist_ready = (status == 'Ready (Consist OK)')
        fill_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid") if (idx % 2 == 1) else None

        font_mp_tag = Font(name="Segoe UI", size=9, bold=True, color="059669" if is_mp_item else "6B7280")

        if remarks_val == "Ready stock":
            font_rem = Font(name="Segoe UI", size=9, bold=True, color=green_card)
        elif is_consist_ready or "Ready to Assemble" in str(remarks_val):
            font_rem = Font(name="Segoe UI", size=9, bold=True, color="0D9488")
        elif remarks_val == "Follow up STO.":
            font_rem = Font(name="Segoe UI", size=9, bold=True, color=amber_card)
        else:
            font_rem = Font(name="Segoe UI", size=9, bold=True, color=red_card)

        if is_consist_ready:
            status_text = "🔧 Ready (Consist OK)"
            status_color = "0D9488"
        elif is_not_ready:
            status_text = "🔴 Not Ready"
            status_color = red_card
        else:
            status_text = "🟢 Ready"
            status_color = green_card

        row_defs = [
            (mat_no, "@", "center", None),
            (pn, "@", "center", Font(name="Segoe UI", size=9, bold=True)),
            (desc, "@", "left", None),
            (r.get('Monthly_Plan_Tag', '⚪ NO'), "@", "center", font_mp_tag),
            (req_mp, "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True if is_mp_item else False)),
            (req_q, "#,##0.00", "right", None),
            (mb52_q, "#,##0.00", "right", None),
            (info_q, "#,##0.00", "right", None),
            (f"=H{curr_r}+I{curr_r}", "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True)),
            (f"=J{curr_r}-G{curr_r}", "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True, color=red_card if is_not_ready else ("0D9488" if is_consist_ready else green_card))),
            (status_text, "@", "center", Font(name="Segoe UI", size=9, bold=True, color=status_color)),
            (oo_q, "#,##0.00", "right", Font(name="Segoe UI", size=9)),
            (remarks_val, "@", "left", font_rem)
        ]

        for col_i, (v, fmt, align, custom_font) in enumerate(row_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = custom_font or font_tbl_body
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = thin_border
            if fill_alt and not is_not_ready:
                cell.fill = fill_alt

        curr_r += 1

    # GRAND TOTAL ROW
    if curr_r > h_row + 1:
        total_row_defs = [
            ("GRAND TOTAL", "@", "left"),
            ("", "@", "center"),
            (f"{total_parts_required:,} items", "@", "left"),
            (f"{mp_items_cnt:,} MP | {total_parts_required - mp_items_cnt:,} Non-MP", "@", "center"),
            (f"=SUM(F12:F{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(G12:G{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(H12:H{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(I12:I{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(J12:J{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(K12:K{curr_r-1})", "#,##0.00", "right"),
            (f"{parts_ready} Ready | {parts_not_ready} Not Ready", "@", "center"),
            (f"=SUM(M12:M{curr_r-1})", "#,##0.00", "right"),
            ("", "@", "left")
        ]
        for col_i, (v, fmt, align) in enumerate(total_row_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = font_tbl_total
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = total_border
            cell.fill = fill_total
        filter_end = curr_r - 1
    else:
        filter_end = 12

    col_w = {
        'A': 3,
        'B': 20,  # Material Number
        'C': 18,  # PN
        'D': 35,  # Description
        'E': 16,  # Monthly Plan?
        'F': 16,  # Req Qty MP
        'G': 20,  # Requirement Qty (All)
        'H': 18,  # Stock MB52 (S)
        'I': 20,  # Stock ATP TU
        'J': 20,  # Total Available Stock
        'K': 18,  # Balance / Deficit
        'L': 20,  # Status Ketersediaan
        'M': 18,  # On Order (OO)
        'N': 25,  # Remarks
    }
    for c_l, w in col_w.items():
        ws.column_dimensions[c_l].width = w

    ws.freeze_panes = "B12"
    ws.auto_filter.ref = f"B11:N{filter_end}"
    ws.views.sheetView[0].showGridLines = True


def populate_wo_summary_sheet(ws, df_wo_summary, title_text, input_file_path, mp_file_path=None, has_mp_info=False):
    """
    Menata format Sheet WO Readiness Summary (Unit & Backlog Tracking).
    Kolom:
    B: Order Number
    C: Monthly Plan?
    D: Room / Unit
    E: WO Description / Header Text
    F: WO User Status
    G: Total Parts
    H: Total Req Qty
    I: Ready Parts
    J: Shortage Parts
    K: Readiness %
    L: Status Kesiapan Unit (🟢 Ready 100% / 🟡 Partial / 🔴 Not Ready)
    M: Shortage Part Numbers
    """
    total_wos = len(df_wo_summary)
    mp_wos = int((df_wo_summary['Monthly Plan?'] == '🟢 YES (MP)').sum()) if total_wos > 0 else 0
    ready_wos = int((df_wo_summary['Readiness'] == '🟢 Ready 100%').sum()) if total_wos > 0 else 0
    partial_wos = int((df_wo_summary['Readiness'] == '🟡 Partial').sum()) if total_wos > 0 else 0
    not_ready_wos = int((df_wo_summary['Readiness'] == '🔴 Not Ready').sum()) if total_wos > 0 else 0
    short_wos = partial_wos + not_ready_wos
    pct_ready_wos = (ready_wos / total_wos) if total_wos > 0 else 0.0
    pct_short_wos = (short_wos / total_wos) if total_wos > 0 else 0.0

    # Palette Warna
    navy_dark = "1E3A8A"
    blue_header = "2563EB"
    blue_light = "EFF6FF"
    green_card = "059669"
    green_light = "ECFDF5"
    red_card = "DC2626"
    red_light = "FEF2F2"
    amber_card = "D97706"
    gray_border = "D1D5DB"
    gray_total = "E2E8F0"

    font_title = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
    font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
    font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
    font_kpi_val = Font(name="Segoe UI", size=12, bold=True, color="1F2937")
    font_tbl_hdr = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    font_tbl_body = Font(name="Segoe UI", size=9)
    font_tbl_total = Font(name="Segoe UI", size=9, bold=True, color="1F2937")

    fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_tbl_hdr = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
    fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")

    thin_border = Border(
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border),
        top=Side(style='thin', color=gray_border),
        bottom=Side(style='thin', color=gray_border)
    )
    total_border = Border(
        top=Side(style='thin', color="4B5563"),
        bottom=Side(style='double', color="4B5563"),
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border)
    )

    # 1. HEADER BANNER (Baris 2-3, Kolom B sampai M)
    ws.merge_cells("B2:M2")
    ws["B2"] = title_text
    ws["B2"].font = font_title
    ws["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    mp_src_label = f"  |  Monthly Plan: {os.path.basename(mp_file_path)}" if (mp_file_path and has_mp_info) else ""
    ws.merge_cells("B3:M3")
    ws["B3"] = f"Generated: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  RAW DATA: {os.path.basename(input_file_path)}{mp_src_label}  |  Total Work Orders: {total_wos:,}"
    ws["B3"].font = font_sub
    ws["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    for r in range(2, 4):
        for c in range(2, 14):  # Kolom B (2) s/d M (13)
            ws.cell(row=r, column=c).fill = fill_banner

    # 2. KPI CARDS (Baris 5-7, Kolom B sampai M)
    # Card 1: TOTAL WORK ORDERS (B5:D7) -> 3 cols (B, C, D)
    ws.merge_cells("B5:D5")
    ws["B5"] = "📋 TOTAL WORK ORDERS"
    ws["B5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
    ws["B5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("B6:C6")
    ws["B6"] = "Total Work Orders:"
    ws["B6"].font = font_kpi_label
    ws["B6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D6"] = f"{total_wos:,} WOs"
    ws["D6"].font = font_kpi_val
    ws["D6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("B7:C7")
    ws["B7"] = "Monthly Plan WOs:"
    ws["B7"].font = font_kpi_label
    ws["B7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D7"] = f"{mp_wos:,} WOs"
    ws["D7"].font = font_kpi_val
    ws["D7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 2: FULLY READY WORK ORDERS (E5:H7) -> 4 cols (E, F, G, H)
    ws.merge_cells("E5:H5")
    ws["E5"] = "🟢 FULLY READY WORK ORDERS (100%)"
    ws["E5"].font = Font(name="Segoe UI", size=9, bold=True, color=green_card)
    ws["E5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("E6:G6")
    ws["E6"] = "Total Ready 100%:"
    ws["E6"].font = font_kpi_label
    ws["E6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["H6"] = f"{ready_wos:,} WOs"
    ws["H6"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["H6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("E7:G7")
    ws["E7"] = "Ready Rate:"
    ws["E7"].font = font_kpi_label
    ws["E7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["H7"] = f"{pct_ready_wos:.1%}"
    ws["H7"].font = Font(name="Segoe UI", size=14, bold=True, color=green_card)
    ws["H7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 3: SHORTAGE / PARTIAL WORK ORDERS (I5:M7) -> 5 cols (I, J, K, L, M)
    ws.merge_cells("I5:M5")
    ws["I5"] = "🔴 BOTTLENECK / SHORTAGE WORK ORDERS"
    ws["I5"].font = Font(name="Segoe UI", size=9, bold=True, color=red_card)
    ws["I5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("I6:K6")
    ws["I6"] = "Total Shortage / Partial:"
    ws["I6"].font = font_kpi_label
    ws["I6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["M6"] = f"{short_wos:,} WOs"
    ws["M6"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws["M6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("I7:K7")
    ws["I7"] = "Shortage Rate:"
    ws["I7"].font = font_kpi_label
    ws["I7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["M7"] = f"{pct_short_wos:.1%}"
    ws["M7"].font = Font(name="Segoe UI", size=14, bold=True, color=red_card)
    ws["M7"].alignment = Alignment(horizontal="center", vertical="center")

    fill_blue = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
    fill_green = PatternFill(start_color=green_light, end_color=green_light, fill_type="solid")
    fill_red = PatternFill(start_color=red_light, end_color=red_light, fill_type="solid")

    for r in range(5, 8):
        for c in range(2, 5):   # B - D
            ws.cell(row=r, column=c).fill = fill_blue
        for c in range(5, 9):   # E - H
            ws.cell(row=r, column=c).fill = fill_green
        for c in range(9, 14):  # I - M
            ws.cell(row=r, column=c).fill = fill_red
        for c in range(2, 14):
            ws.cell(row=r, column=c).border = thin_border

    # 3. TABEL DETAIL WO (Baris 9-11)
    ws["B9"] = "📊 Unit & Work Order Readiness Summary (Sorted by Monthly Plan & Shortage)"
    ws["B9"].font = font_section

    tbl_headers = [
        "Order Number",
        "Monthly Plan?",
        "Room / Unit",
        "WO Description / Header Text",
        "WO Status",
        "Total Parts",
        "Total Req Qty",
        "Ready Parts",
        "Shortage Parts",
        "Readiness %",
        "Unit Readiness Status",
        "Shortage Part Numbers"
    ]

    h_row = 11
    for i, h in enumerate(tbl_headers, start=2):
        c = ws.cell(row=h_row, column=i, value=h)
        c.font = font_tbl_hdr
        c.fill = fill_tbl_hdr
        c.alignment = Alignment(horizontal="center" if i not in [5, 13] else "left", vertical="center")
        c.border = thin_border

    curr_r = h_row + 1
    for idx, r in df_wo_summary.iterrows():
        ord_no = r['Order Number']
        is_mp = (r.get('Monthly Plan?') == '🟢 YES (MP)')
        room = r.get('Room', '')
        desc = r.get('Description', '')
        wo_status = r.get('Status', '')
        total_p = int(r.get('Total_Parts', 0))
        total_q = float(r.get('Total_Req', 0.0))
        ready_p = int(r.get('Ready_Parts', 0))
        short_p = int(r.get('Shortage_Parts', 0))
        readiness_label = r.get('Readiness', '')
        short_pns = r.get('Shortage_PNs', '')

        fill_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid") if (idx % 2 == 1) else None
        font_mp_tag = Font(name="Segoe UI", size=9, bold=True, color="059669" if is_mp else "6B7280")

        if readiness_label == "🟢 Ready 100%":
            font_st = Font(name="Segoe UI", size=9, bold=True, color=green_card)
        elif readiness_label == "🟡 Partial":
            font_st = Font(name="Segoe UI", size=9, bold=True, color=amber_card)
        else:
            font_st = Font(name="Segoe UI", size=9, bold=True, color=red_card)

        row_defs = [
            (ord_no, "@", "center", None),
            (r.get('Monthly Plan?', '⚪ NO'), "@", "center", font_mp_tag),
            (room, "@", "center", None),
            (desc, "@", "left", None),
            (wo_status, "@", "center", None),
            (total_p, "#,##0", "right", None),
            (total_q, "#,##0.00", "right", None),
            (ready_p, "#,##0", "right", None),
            (short_p, "#,##0", "right", None),
            (f"=I{curr_r}/G{curr_r}" if total_p > 0 else 0.0, "0.0%", "center", font_st),
            (readiness_label, "@", "center", font_st),
            (short_pns, "@", "left", Font(name="Segoe UI", size=8, color="991B1B" if short_p > 0 else "4B5563"))
        ]

        for col_i, (v, fmt, align, custom_font) in enumerate(row_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = custom_font or font_tbl_body
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = thin_border
            if fill_alt and readiness_label == "🟢 Ready 100%":
                cell.fill = fill_alt

        curr_r += 1

    # GRAND TOTAL ROW
    if curr_r > h_row + 1:
        total_row_defs = [
            ("GRAND TOTAL", "@", "left"),
            (f"{mp_wos:,} MP | {total_wos - mp_wos:,} Non-MP", "@", "center"),
            ("", "@", "center"),
            (f"{total_wos:,} Work Orders", "@", "left"),
            ("", "@", "center"),
            (f"=SUM(G12:G{curr_r-1})", "#,##0", "right"),
            (f"=SUM(H12:H{curr_r-1})", "#,##0.00", "right"),
            (f"=SUM(I12:I{curr_r-1})", "#,##0", "right"),
            (f"=SUM(J12:J{curr_r-1})", "#,##0", "right"),
            (f"=AVERAGE(K12:K{curr_r-1})", "0.0%", "center"),
            (f"{ready_wos} Ready | {partial_wos} Partial | {not_ready_wos} Shortage", "@", "center"),
            ("", "@", "left")
        ]
        for col_i, (v, fmt, align) in enumerate(total_row_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = font_tbl_total
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = total_border
            cell.fill = fill_total
        filter_end = curr_r - 1
    else:
        filter_end = 12

    col_w = {
        'A': 3,
        'B': 18,  # Order Number
        'C': 16,  # Monthly Plan?
        'D': 14,  # Room / Unit
        'E': 38,  # WO Description
        'F': 14,  # Status WO
        'G': 14,  # Total Parts
        'H': 16,  # Total Req Qty
        'I': 14,  # Ready Parts
        'J': 15,  # Shortage Parts
        'K': 15,  # Readiness %
        'L': 20,  # Status Kesiapan Unit
        'M': 42,  # Shortage Part Numbers
    }
    for c_l, w in col_w.items():
        ws.column_dimensions[c_l].width = w

    ws.freeze_panes = "B12"
    ws.auto_filter.ref = f"B11:M{filter_end}"
    ws.views.sheetView[0].showGridLines = True


def build_part_release_evaluation(pivot_mb52, pivot_inv, pivot_all):
    """
    Menyusun Master Evaluasi Kesiapan Rilis Part Antar-Cabang (Opsi A: Seluruh part fisik cabang ATP > 0).
    Sesuai SOP Trakindo:
    - Master part 100% bersumber dari Onhand ATP Cabang (Stock Info / INVENTORY sheet Data).
    - Stok MB52 (Special Stock 'S') adalah milik customer (konsinyasi/proyek) sehingga TIDAK dimasukkan sebagai stok rilis cabang.
    - Kebutuhan WO customer dari AS57D dipetakan berdasarkan PN Caterpillar/Trakindo (bukan nomor material customer 9xxxxxxxxx).
    - Jika customer memiliki stok MB52 'S', kebutuhan WO customer akan dipenuhi terlebih dahulu dari stok MB52 mereka,
      sehingga hanya defisit WO (netto) yang mengunci Onhand ATP cabang kita.
    """
    records = {}

    # 1. Masukkan semua part dari Stock Info (INVENTORY) yang memiliki stok ATP > 0
    if pivot_inv is not None and not pivot_inv.empty:
        for _, r in pivot_inv.iterrows():
            mat_key = str(r.get('Material_Key', '')).strip()
            if not mat_key or mat_key.lower() == 'nan':
                continue
            atp_val = float(r.get('Stock_Info_ATP', 0.0) or 0.0)

            # Opsi A: Hanya part dengan stok fisik cabang > 0
            if atp_val <= 0:
                continue

            base_key = str(r.get('Base_Key', mat_key.split(':')[0])).strip()
            oo_val = float(r.get('On_Order_Qty', 0.0) or 0.0)
            sto_val = float(r.get('In_Transit_STO', 0.0) or 0.0)
            tot_oo = float(r.get('Stock_Info_OO', 0.0) or (oo_val + sto_val))
            desc_val = str(r.get('Material_Description', '') or '').strip()
            uom_val = str(r.get('UOM', 'PC') or 'PC').strip()
            if not uom_val or uom_val.lower() == 'nan':
                uom_val = 'PC'
            order_mth = str(r.get('Order_Method', '') or '').strip().upper()
            min_val = float(r.get('Min_Stock', 0.0) or 0.0)
            max_val = float(r.get('Max_Stock', 0.0) or 0.0)
            d1_val = float(r.get('Demand_1', 0.0) or 0.0)
            d12_val = float(r.get('Total_12M_Demand', 0.0) or 0.0)
            amd_val = float(r.get('AMD', 0.0) or (d12_val / 12.0))
            sloc_val = str(r.get('Storage_Location', '') or '').strip()
            gr_val = str(r.get('GR_Last_Date', '') or '').strip()

            records[mat_key] = {
                'Material_Number': mat_key,
                'PN': mat_key,
                'Base_PN': base_key,
                'Material_Description': desc_val,
                'UOM': uom_val,
                'Storage_Location': sloc_val,
                'Order_Method': order_mth,
                'Stock_Info_ATP': atp_val,
                'Total_SOH': atp_val,
                'On_Order_Qty': oo_val,
                'In_Transit_STO': sto_val,
                'Total_OO': tot_oo,
                'Min_Stock': min_val,
                'Max_Stock': max_val,
                'Demand_1': d1_val,
                'Total_12M_Demand': d12_val,
                'AMD': amd_val,
                'GR_Last_Date': gr_val,
                'WO_Allocation': 0.0
            }

    if not records:
        return pd.DataFrame()

    df_eval = pd.DataFrame(list(records.values()))

    # 2. Petakan Kebutuhan Alokasi WO (AS57D All Status), net terhadap stok MB52 customer
    mb52_cust_map = {}
    if pivot_mb52 is not None and not pivot_mb52.empty:
        for _, r in pivot_mb52.iterrows():
            m_cust = str(r.get('Material', '')).strip()
            if m_cust and m_cust.lower() != 'nan':
                mb52_cust_map[m_cust] = float(r.get('Stock_MB52_S', 0.0) or 0.0)

    wo_exact_map = {}
    wo_base_map = {}
    if pivot_all is not None and not pivot_all.empty:
        for _, r in pivot_all.iterrows():
            m_no = str(r.get('Material Number', '')).strip()
            pn_val = str(r.get('PN', '')).strip()
            base_val = str(r.get('Base_PN', '')).strip()
            rq = float(r.get('Requirement_Qty', 0.0) or 0.0)

            # Stok MB52 customer untuk material ini
            cust_stock = mb52_cust_map.get(m_no, 0.0)
            # Kebutuhan riil WO yang membebani stok ATP cabang (setelah dipenuhi stok MB52 customer)
            net_rq = max(0.0, rq - cust_stock)

            if pn_val:
                wo_exact_map[pn_val] = wo_exact_map.get(pn_val, 0.0) + net_rq
            if base_val:
                wo_base_map[base_val] = wo_base_map.get(base_val, 0.0) + net_rq

        for idx, row in df_eval.iterrows():
            pn_n = row['PN']
            base_n = row['Base_PN']

            alloc_q = 0.0
            if pn_n in wo_exact_map:
                alloc_q = wo_exact_map[pn_n]
            elif base_n in wo_base_map:
                alloc_q = wo_base_map[base_n]

            df_eval.at[idx, 'WO_Allocation'] = alloc_q

    # 3. Evaluasi Baris per Baris (Dynamic Safety Stock & Recommendation)
    move_classes = []
    dyn_safeties = []
    safe_qtys = []
    rec_statuses = []
    remarks_list = []

    for idx, r in df_eval.iterrows():
        soh = float(r['Total_SOH'])
        wo = float(r['WO_Allocation'])
        min_s = float(r['Min_Stock'])
        max_s = float(r['Max_Stock'])
        d1 = float(r['Demand_1'])
        d12 = float(r['Total_12M_Demand'])
        amd = float(r['AMD'])
        mth = str(r['Order_Method']).strip().upper()
        oo = float(r['Total_OO'])
        uom_str = str(r.get('UOM', 'PC') or 'PC').strip()

        # TIER 1: DEAD STOCK (Demand 12 Bulan = 0 DAN Tidak ada Alokasi WO)
        if d12 == 0 and wo == 0:
            m_cls = "💎 DEAD STOCK"
            dyn_s = 0.0
            s_qty = soh
            status = "💎 PRIORITY (DEAD STOCK)"
            rem = f"Dead stock (0 demand 12M & 0 WO). Full Onhand ATP ({soh:,.0f} {uom_str}) safe to release."

        # TIER 2: SLOW MOVING (Demand 12 Bulan <= 2 DAN Tidak ada Alokasi WO)
        elif d12 <= 2 and wo == 0:
            m_cls = "🐢 SLOW MOVING"
            if mth == 'BB':
                dyn_s = 0.0
            else:
                dyn_s = min(min_s, 1.0) if min_s > 0 else 0.0

            s_qty = max(0.0, soh - dyn_s)
            if s_qty > 0:
                status = "🟢 SAFE TO RELEASE"
                rem = f"Slow moving ({d12:,.0f} 12M demand). Safe to release {s_qty:,.0f} {uom_str}, safety buffer {dyn_s:,.0f} {uom_str}."
            else:
                status = "🔴 DO NOT RELEASE"
                rem = f"Slow moving. Full Onhand ATP ({soh:,.0f} {uom_str}) retained as safety buffer."

        # TIER 3: ACTIVE DEMAND (Ada Alokasi WO > 0 ATAU Demand 12 Bulan > 2)
        else:
            m_cls = "⚡ FAST MOVING" if d12 >= 24 else "🟢 ACTIVE DEMAND"

            if mth == 'BB':
                lt_buf = float(np.ceil(amd * 0.5))
                dyn_s = min(min_s, lt_buf) if min_s > 0 else lt_buf
            else:
                lt_buf = float(np.ceil(amd * 1.5))
                dyn_s = max(min_s, lt_buf) if (min_s > 0 or lt_buf > 0) else 0.0

            s_qty = max(0.0, soh - wo - dyn_s)
            if s_qty > 0:
                status = "🟢 SAFE TO RELEASE"
                rem = f"Safe to release up to {s_qty:,.0f} {uom_str}. WO allocation ({wo:,.0f} {uom_str}) & safety stock ({dyn_s:,.0f} {uom_str}) fully covered."
            else:
                if (soh + oo) > (wo + dyn_s):
                    status = "🟡 CONDITIONAL (PIPELINE)"
                    rem = f"Onhand ATP committed to WO/safety stock, but pipeline (OO) available {oo:,.0f} {uom_str}. Conditional release if urgent."
                else:
                    status = "🔴 DO NOT RELEASE"
                    if wo > 0:
                        rem = f"Do not release! Committed to WO allocation ({wo:,.0f} {uom_str})."
                    else:
                        rem = f"Do not release! Onhand ATP ({soh:,.0f} {uom_str}) below safety stock ({dyn_s:,.0f} {uom_str})."

        move_classes.append(m_cls)
        dyn_safeties.append(dyn_s)
        safe_qtys.append(s_qty)
        rec_statuses.append(status)
        remarks_list.append(rem)

    df_eval['Movement_Class'] = move_classes
    df_eval['Dynamic_Safety_Stock'] = dyn_safeties
    df_eval['Safe_Qty_to_Release'] = safe_qtys
    df_eval['Net_Available_WO'] = df_eval['Total_SOH'] - df_eval['WO_Allocation']
    df_eval['Status_Recommendation'] = rec_statuses
    df_eval['Remarks_Evaluation'] = remarks_list

    # 4. Sorting Cerdas
    status_sort_map = {
        '💎 PRIORITY (DEAD STOCK)': 1,
        '🟢 SAFE TO RELEASE': 2,
        '🟡 CONDITIONAL (PIPELINE)': 3,
        '🔴 DO NOT RELEASE': 4
    }
    df_eval['Sort_Rank'] = df_eval['Status_Recommendation'].map(status_sort_map).fillna(5)
    df_eval = df_eval.sort_values(by=['Sort_Rank', 'Safe_Qty_to_Release', 'Total_SOH'], ascending=[True, False, False]).reset_index(drop=True)
    df_eval.drop(columns=['Sort_Rank'], inplace=True)

    return df_eval


def populate_part_release_sheet(ws, df_eval, input_file_path, stock_info_path):
    """
    Menata format Sheet Part Release Evaluation (Ramping 14 Kolom):
    - Banner B1:O3
    - KPI Cards B5:O7 (4 Cards: Onhand ATP, Dead Stock, Safe to Release, Restricted / WO)
    - Section title B9
    - Tabel Detail B11:O{N} (14 Kolom bersih dan operasional)
    """
    tot_items = len(df_eval) if df_eval is not None else 0
    tot_soh = float(df_eval['Total_SOH'].sum()) if tot_items > 0 else 0.0
    tot_wo = float(df_eval['WO_Allocation'].sum()) if tot_items > 0 else 0.0

    dead_items = int((df_eval['Status_Recommendation'] == '💎 PRIORITY (DEAD STOCK)').sum()) if tot_items > 0 else 0
    dead_qty = float(df_eval[df_eval['Status_Recommendation'] == '💎 PRIORITY (DEAD STOCK)']['Total_SOH'].sum()) if tot_items > 0 else 0.0
    dead_pct = (dead_items / tot_items) if tot_items > 0 else 0.0

    safe_items = int((df_eval['Status_Recommendation'] == '🟢 SAFE TO RELEASE').sum()) if tot_items > 0 else 0
    safe_qty_tot = float(df_eval['Safe_Qty_to_Release'].sum()) if tot_items > 0 else 0.0
    safe_pct = (safe_items / tot_items) if tot_items > 0 else 0.0

    cond_items = int((df_eval['Status_Recommendation'] == '🟡 CONDITIONAL (PIPELINE)').sum()) if tot_items > 0 else 0
    reject_items = int((df_eval['Status_Recommendation'] == '🔴 DO NOT RELEASE').sum()) if tot_items > 0 else 0
    reject_pct = (reject_items / tot_items) if tot_items > 0 else 0.0

    # Palette Warna Executive Modern
    navy_dark = "1E3A8A"
    blue_header = "2563EB"
    blue_light = "EFF6FF"
    green_card = "059669"
    green_light = "ECFDF5"
    purple_card = "7C3AED"
    purple_light = "F5F3FF"
    red_card = "DC2626"
    red_light = "FEF2F2"
    amber_card = "D97706"
    amber_light = "FFFBEB"
    gray_border = "D1D5DB"
    gray_total = "E2E8F0"

    font_title = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
    font_section = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
    font_kpi_label = Font(name="Segoe UI", size=9, color="4B5563")
    font_kpi_val = Font(name="Segoe UI", size=12, bold=True, color=navy_dark)
    font_tbl_hdr = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
    font_tbl_body = Font(name="Segoe UI", size=9)
    font_tbl_total = Font(name="Segoe UI", size=9, bold=True, color="1F2937")

    fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_blue = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
    fill_purple = PatternFill(start_color=purple_light, end_color=purple_light, fill_type="solid")
    fill_green = PatternFill(start_color=green_light, end_color=green_light, fill_type="solid")
    fill_red = PatternFill(start_color=red_light, end_color=red_light, fill_type="solid")
    fill_tbl_hdr = PatternFill(start_color=blue_header, end_color=blue_header, fill_type="solid")
    fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")

    thin_border = Border(
        left=Side(style="thin", color=gray_border),
        right=Side(style="thin", color=gray_border),
        top=Side(style="thin", color=gray_border),
        bottom=Side(style="thin", color=gray_border)
    )
    total_border = Border(
        top=Side(style="thin", color=navy_dark),
        bottom=Side(style="double", color=navy_dark),
        left=Side(style="thin", color=gray_border),
        right=Side(style="thin", color=gray_border)
    )

    # 1. BANNER HEADER (B1:O3) -> 14 Kolom
    ws.merge_cells("B1:O2")
    ws["B1"] = "PART RELEASE EVALUATION - INTER-BRANCH TRANSFER"
    ws["B1"].font = font_title
    ws["B1"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("B3:O3")
    raw_fname = os.path.basename(input_file_path) if input_file_path else "RAW DATA"
    inv_fname = os.path.basename(stock_info_path) if stock_info_path else "INVENTORY SAP"
    ws["B3"] = f"Evaluation of Onhand ATP, AS57D WO Allocation, MIN-MAX Parameters & Dynamic Safety Stock | Source: {raw_fname} & {inv_fname} | {time.strftime('%d-%m-%Y %H:%M')}"
    ws["B3"].font = font_sub
    ws["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    for r in range(1, 4):
        for c in range(2, 16):  # Kolom B (2) s/d O (15)
            ws.cell(row=r, column=c).fill = fill_banner

    # 2. KPI CARDS (Baris 5-7): 4 Cards (B sampai O = 14 Kolom)
    # Card 1: ONHAND ATP (B5:D7) -> 3 cols
    ws.merge_cells("B5:D5")
    ws["B5"] = "📦 ONHAND ATP"
    ws["B5"].font = Font(name="Segoe UI", size=9, bold=True, color=navy_dark)
    ws["B5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("B6:C6")
    ws["B6"] = "Total Part (ATP > 0):"
    ws["B6"].font = font_kpi_label
    ws["B6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D6"] = f"{tot_items:,} items"
    ws["D6"].font = font_kpi_val
    ws["D6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("B7:C7")
    ws["B7"] = "Total Qty Onhand ATP:"
    ws["B7"].font = font_kpi_label
    ws["B7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["D7"] = f"{tot_soh:,.0f} qty"
    ws["D7"].font = font_kpi_val
    ws["D7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 2: DEAD STOCK (E5:G7) -> 3 cols
    ws.merge_cells("E5:G5")
    ws["E5"] = "💎 DEAD STOCK (100% AVAILABLE)"
    ws["E5"].font = Font(name="Segoe UI", size=9, bold=True, color=purple_card)
    ws["E5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("E6:F6")
    ws["E6"] = "Parts 0 Demand 12M:"
    ws["E6"].font = font_kpi_label
    ws["E6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["G6"] = f"{dead_items:,} ({dead_pct:.1%})"
    ws["G6"].font = Font(name="Segoe UI", size=12, bold=True, color=purple_card)
    ws["G6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("E7:F7")
    ws["E7"] = "Total Dead Stock Qty:"
    ws["E7"].font = font_kpi_label
    ws["E7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws["G7"] = f"{dead_qty:,.0f} qty"
    ws["G7"].font = Font(name="Segoe UI", size=12, bold=True, color=purple_card)
    ws["G7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 3: SAFE TO RELEASE (H5:K7) -> 4 cols (H, I, J, K)
    ws.merge_cells("H5:K5")
    ws["H5"] = "🟢 SAFE TO RELEASE"
    ws["H5"].font = Font(name="Segoe UI", size=9, bold=True, color=green_card)
    ws["H5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("H6:I6")
    ws["H6"] = "Parts Safe to Release:"
    ws["H6"].font = font_kpi_label
    ws["H6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.merge_cells("J6:K6")
    ws["J6"] = f"{safe_items:,} ({safe_pct:.1%})"
    ws["J6"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["J6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("H7:I7")
    ws["H7"] = "Total Qty to Release:"
    ws["H7"].font = font_kpi_label
    ws["H7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.merge_cells("J7:K7")
    ws["J7"] = f"{safe_qty_tot:,.0f} qty"
    ws["J7"].font = Font(name="Segoe UI", size=12, bold=True, color=green_card)
    ws["J7"].alignment = Alignment(horizontal="center", vertical="center")

    # Card 4: RESTRICTED / WO (L5:O7) -> 4 cols (L, M, N, O)
    ws.merge_cells("L5:O5")
    ws["L5"] = "🔴 RESTRICTED / WO ALLOCATION"
    ws["L5"].font = Font(name="Segoe UI", size=9, bold=True, color=red_card)
    ws["L5"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws.merge_cells("L6:M6")
    ws["L6"] = "Parts Restricted / Hold:"
    ws["L6"].font = font_kpi_label
    ws["L6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.merge_cells("N6:O6")
    ws["N6"] = f"{reject_items:,} ({reject_pct:.1%})"
    ws["N6"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws["N6"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("L7:M7")
    ws["L7"] = "Total WO Allocation:"
    ws["L7"].font = font_kpi_label
    ws["L7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws.merge_cells("N7:O7")
    ws["N7"] = f"{tot_wo:,.0f} qty"
    ws["N7"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws["N7"].alignment = Alignment(horizontal="center", vertical="center")

    for r in range(5, 8):
        for c in range(2, 5):   # B - D
            ws.cell(row=r, column=c).fill = fill_blue
        for c in range(5, 8):   # E - G
            ws.cell(row=r, column=c).fill = fill_purple
        for c in range(8, 12):  # H - K
            ws.cell(row=r, column=c).fill = fill_green
        for c in range(12, 16): # L - O
            ws.cell(row=r, column=c).fill = fill_red
        for c in range(2, 16):
            ws.cell(row=r, column=c).border = thin_border

    # 3. SECTION TITLE (B9)
    ws["B9"] = "📋 PART RELEASE EVALUATION & ONHAND ATP SUMMARY"
    ws["B9"].font = font_section

    # 4. TABEL HEADERS (Row 11, Kolom B sampai O -> 14 Kolom Ramping)
    headers = [
        "No",
        "Material Number",
        "Material Description",
        "UOM",
        "Sloc",
        "Order Method",
        "Onhand ATP",
        "WO Allocation",
        "12M Demand",
        "Safety Stock",
        "Pipeline (OO)",
        "Safe Qty to Release",
        "Recommendation Status",
        "Remarks"
    ]

    h_row = 11
    for i, h in enumerate(headers, start=2):
        c = ws.cell(row=h_row, column=i, value=h)
        c.font = font_tbl_hdr
        c.fill = fill_tbl_hdr
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = thin_border
    ws.row_dimensions[h_row].height = 28

    curr_r = h_row + 1
    if df_eval is not None and not df_eval.empty:
        for idx, r in df_eval.iterrows():
            st_text = str(r.get('Status_Recommendation', ''))
            safe_q = float(r.get('Safe_Qty_to_Release', 0.0) or 0.0)
            order_mth = str(r.get('Order_Method', '') or '').strip().upper()
            uom_val = str(r.get('UOM', 'PC') or 'PC').strip()

            # Format Font Warna Status
            if "PRIORITY" in st_text:
                st_font = Font(name="Segoe UI", size=9, bold=True, color=purple_card)
            elif "SAFE" in st_text:
                st_font = Font(name="Segoe UI", size=9, bold=True, color=green_card)
            elif "CONDITIONAL" in st_text:
                st_font = Font(name="Segoe UI", size=9, bold=True, color=amber_card)
            else:
                st_font = Font(name="Segoe UI", size=9, bold=True, color=red_card)

            font_safe = Font(name="Segoe UI", size=9, bold=True, color=green_card if safe_q > 0 else "4B5563")
            font_mth = Font(name="Segoe UI", size=9, bold=True, color="1E3A8A" if order_mth == 'BB' else ("D97706" if order_mth == 'PT' else "4B5563"))
            fill_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid") if (idx % 2 == 1) else None

            row_cells = [
                (idx + 1, "#,##0", "center", None),
                (r.get('Material_Number', ''), "@", "center", None),
                (r.get('Material_Description', ''), "@", "left", None),
                (uom_val, "@", "center", None),
                (r.get('Storage_Location', ''), "@", "center", None),
                (order_mth, "@", "center", font_mth),
                (float(r.get('Stock_Info_ATP', 0.0) or 0.0), "#,##0.00", "right", None),
                (float(r.get('WO_Allocation', 0.0) or 0.0), "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True, color=red_card if float(r.get('WO_Allocation', 0.0) or 0.0) > 0 else "4B5563")),
                (float(r.get('Total_12M_Demand', 0.0) or 0.0), "#,##0.00", "right", None),
                (float(r.get('Dynamic_Safety_Stock', 0.0) or 0.0), "#,##0.00", "right", Font(name="Segoe UI", size=9, bold=True)),
                (float(r.get('Total_OO', 0.0) or 0.0), "#,##0.00", "right", None),
                (safe_q, "#,##0.00", "right", font_safe),
                (st_text, "@", "center", st_font),
                (r.get('Remarks_Evaluation', ''), "@", "left", Font(name="Segoe UI", size=8, color="1F2937"))
            ]

            for col_i, (v, fmt, align, custom_font) in enumerate(row_cells, start=2):
                cell = ws.cell(row=curr_r, column=col_i, value=v)
                cell.font = custom_font or font_tbl_body
                cell.number_format = fmt
                cell.alignment = Alignment(horizontal=align, vertical="center")
                cell.border = thin_border
                if fill_alt:
                    cell.fill = fill_alt

            curr_r += 1

    # GRAND TOTAL ROW (14 Kolom)
    if curr_r > h_row + 1:
        total_defs = [
            ("GRAND TOTAL", "@", "left"),
            ("", "@", "center"),
            (f"{tot_items:,} items evaluated", "@", "left"),
            ("", "@", "center"),
            ("", "@", "center"),
            ("", "@", "center"),
            (f"=SUM(H12:H{curr_r-1})", "#,##0.00", "right"),  # Onhand ATP
            (f"=SUM(I12:I{curr_r-1})", "#,##0.00", "right"),  # WO Allocation
            (f"=SUM(J12:J{curr_r-1})", "#,##0.00", "right"),  # 12M Demand
            (f"=SUM(K12:K{curr_r-1})", "#,##0.00", "right"),  # Safety Stock
            (f"=SUM(L12:L{curr_r-1})", "#,##0.00", "right"),  # Pipeline (OO)
            (f"=SUM(M12:M{curr_r-1})", "#,##0.00", "right"),  # Safe Qty
            (f"{safe_items + dead_items} Safe/Priority | {reject_items} Restricted", "@", "center"),
            ("", "@", "left")
        ]
        for col_i, (v, fmt, align) in enumerate(total_defs, start=2):
            cell = ws.cell(row=curr_r, column=col_i, value=v)
            cell.font = font_tbl_total
            cell.number_format = fmt
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = total_border
            cell.fill = fill_total
        filter_end = curr_r - 1
    else:
        filter_end = 12

    # Atur Lebar Kolom (14 Kolom)
    col_w = {
        'A': 3,
        'B': 6,   # No
        'C': 18,  # Material Number
        'D': 36,  # Material Description
        'E': 8,   # UOM
        'F': 10,  # Storage Location
        'G': 14,  # Order Method
        'H': 16,  # Onhand ATP
        'I': 16,  # WO Allocation
        'J': 16,  # 12M Demand
        'K': 16,  # Safety Stock
        'L': 16,  # Pipeline (OO)
        'M': 18,  # Safe Qty to Release
        'N': 26,  # Recommendation Status
        'O': 48,  # Remarks
    }
    for c_l, w in col_w.items():
        ws.column_dimensions[c_l].width = w

    ws.freeze_panes = "C12"
    ws.auto_filter.ref = f"B11:O{filter_end}"
    ws.views.sheetView[0].showGridLines = True


def process_wo_readiness(input_file_path, stock_info_path=None, kuota_file_path=None, mp_file_path=None, consist_file_path=None, output_file_path=None, output_mode="both", status_callback=None):
    """
    Memproses Part Readiness WO AS57D vs MB52 (Stock S) dan Stock Info SAP (ATP, OO, Kuota Import)
    serta integrasi Monthly Plan (MP) dan Analisis Consist Hose Assy.
    output_mode:
      - 'both'     : Membuat 2 sheet standar (All & COMP PROG RELE) jika tanpa file MP
      - 'all'      : Membuat sheet All saja
      - 'filtered' : Membuat sheet COMP PROG RELE saja
    Jika file Monthly Plan disediakan / terdeteksi otomatis:
      - Sheet 1: 'Part Readiness - Monthly Plan' (Fokus Utama Kebutuhan MP)
      - Sheet 2: 'Part Readiness - All WO' (Seluruh WO aktif dengan kolom Monthly Plan?)
      - Sheet 3: 'WO Readiness Summary' (Ringkasan per Unit/WO & pelacakan status kesiapan)
    Sheet Tambahan Analisis:
      - Sheet 'Hose Consist Analysis' (Analisis kesiapan rakit potongan hose & coupling)
      - Sheet Pendukung: Stock Info ATP, Data AS57D Clean
    """
    def log(msg):
        print(msg)
        if status_callback:
            status_callback(msg)

    if not os.path.exists(input_file_path):
        raise FileNotFoundError(f"File RAW DATA tidak ditemukan: {input_file_path}")

    # Auto-detect file Stock Info jika belum diisi atau tidak valid
    if not stock_info_path or not os.path.exists(stock_info_path):
        detected = find_matching_stock_info(input_file_path)
        if detected:
            stock_info_path = detected
            log(f"Auto-detect Stock Info ditemukan: {os.path.basename(stock_info_path)}")

    # Auto-detect file Kuota Import jika parameter adalah None (belum diisi)
    if kuota_file_path is None:
        detected_kuota = find_matching_kuota_file(input_file_path)
        if detected_kuota:
            kuota_file_path = detected_kuota
            log(f"Auto-detect Kuota Import ditemukan: {os.path.basename(kuota_file_path)}")
    elif kuota_file_path and not os.path.exists(kuota_file_path):
        log(f"Peringatan: File Kuota Import tidak ditemukan ({kuota_file_path}). Melanjutkan tanpa Kuota Import.")
        kuota_file_path = None

    # Auto-detect file Master Consist Hose Assy jika parameter adalah None (belum diisi)
    has_consist_info = False
    consist_master = {}
    if consist_file_path is None:
        detected_consist = find_matching_consist_file(input_file_path)
        if detected_consist:
            consist_file_path = detected_consist
            log(f"Auto-detect Master Consist Hose ditemukan: {os.path.basename(consist_file_path)}")
    elif consist_file_path and not os.path.exists(consist_file_path):
        log(f"Peringatan: File Master Consist Hose tidak ditemukan ({consist_file_path}). Melanjutkan tanpa analisis consist.")
        consist_file_path = None

    if consist_file_path and os.path.exists(consist_file_path):
        try:
            consist_master = load_consist_hose_data(consist_file_path)
            if consist_master:
                has_consist_info = True
                log(f"Consist Hose: Sukses memuat master Hose Assy dari {os.path.basename(consist_file_path)}.")
        except Exception as e:
            log(f"Peringatan: Gagal memuat Consist Hose ({e}). Melanjutkan tanpa analisis consist.")
            has_consist_info = False

    # Auto-detect file Monthly Plan jika parameter adalah None (belum diisi)
    has_mp_info = False
    mp_orders = set()
    mp_meta = {}
    mp_sheet = None

    if mp_file_path is None:
        detected_mp = find_matching_mp_file(input_file_path)
        if detected_mp:
            mp_file_path = detected_mp
            log(f"Auto-detect Monthly Plan ditemukan: {os.path.basename(mp_file_path)}")
    elif mp_file_path and not os.path.exists(mp_file_path):
        log(f"Peringatan: File Monthly Plan tidak ditemukan ({mp_file_path}). Melanjutkan tanpa Monthly Plan.")
        mp_file_path = None

    if mp_file_path and os.path.exists(mp_file_path):
        log(f"Membaca file Monthly Plan: {os.path.basename(mp_file_path)}...")
        try:
            mp_orders, mp_meta, mp_sheet = load_monthly_plan_orders(mp_file_path)
            if mp_orders:
                has_mp_info = True
                log(f"Monthly Plan: Sukses memuat {len(mp_orders):,} Work Order unik dari sheet '{mp_sheet}'.")
            else:
                log(f"Peringatan: Tidak ada data Order Number valid di file Monthly Plan.")
        except Exception as e:
            log(f"Peringatan: Gagal membaca file Monthly Plan ({str(e)}). Melanjutkan tanpa Monthly Plan.")
            has_mp_info = False

    if output_file_path is None:
        out_dir = config.get_output_dir("readiness")
        base_name = os.path.splitext(os.path.basename(input_file_path))[0]
        if output_mode == "all":
            output_file_path = os.path.join(out_dir, f"{base_name} - PART READINESS (ALL STATUS).xlsx")
        elif output_mode == "filtered":
            output_file_path = os.path.join(out_dir, f"{base_name} - PART READINESS (COMP PROG RELE).xlsx")
        else:
            output_file_path = os.path.join(out_dir, f"{base_name} - PART READINESS (AS57D vs MB52).xlsx")


    # Handle file lock jika sedang dibuka di Excel
    if os.path.exists(output_file_path):
        try:
            with open(output_file_path, "a"):
                pass
        except PermissionError:
            dir_name = os.path.dirname(output_file_path)
            base_name, ext = os.path.splitext(os.path.basename(output_file_path))
            output_file_path = os.path.join(dir_name, f"{base_name} ({time.strftime('%H%M%S')}){ext}")
            log(f"Perhatian: File target sedang dibuka di Excel. Menyimpan ke: {os.path.basename(output_file_path)}")

    t0 = time.time()
    log("Membuka file RAW DATA dengan engine Calamine...")
    wb_calamine = CalamineWorkbook.from_path(input_file_path)
    sheet_names = wb_calamine.sheet_names

    if 'AS57D' not in sheet_names or 'MB52' not in sheet_names:
        raise ValueError(f"File harus memiliki sheet 'AS57D' dan 'MB52'! Sheet yang ditemukan: {sheet_names}")

    # -------------------------------------------------------------------------
    # 1. PENGOLAHAN SHEET MB52 (Stok Aktual Khusus 'S')
    # -------------------------------------------------------------------------
    log("Membaca dan memfilter Sheet MB52 (Special Stock 'S')...")
    s_mb52_data = wb_calamine.get_sheet_by_name('MB52').to_python()
    headers_mb52 = [str(h).strip() for h in s_mb52_data[0]]
    df_mb52 = pd.DataFrame(s_mb52_data[1:], columns=headers_mb52)

    # Filter Special Stock == 'S'
    if 'Special Stock' in df_mb52.columns:
        df_mb52_s = df_mb52[df_mb52['Special Stock'].astype(str).str.strip().str.upper() == 'S'].copy()
    else:
        df_mb52_s = df_mb52.copy()

    df_mb52_s['Unrestricted'] = pd.to_numeric(df_mb52_s['Unrestricted'], errors='coerce').fillna(0.0)
    df_mb52_s['Material'] = df_mb52_s['Material'].astype(str).str.strip()

    # Pivot MB52 berdasarkan Material Number
    pivot_mb52 = df_mb52_s.groupby('Material', as_index=False).agg(
        Stock_MB52_S=('Unrestricted', 'sum')
    )
    log(f"MB52: Ditemukan {len(df_mb52_s):,} baris stok S ({len(pivot_mb52):,} material unik).")

    # -------------------------------------------------------------------------
    # 2. PENGOLAHAN SHEET AS57D (Kebutuhan Work Order)
    # -------------------------------------------------------------------------
    log("Membaca dan memproses Sheet AS57D...")
    s_as57d_data = wb_calamine.get_sheet_by_name('AS57D').to_python()
    headers_as57d = [str(h).strip() for h in s_as57d_data[0]]
    df_as57d = pd.DataFrame(s_as57d_data[1:], columns=headers_as57d)

    # Filter: Hapus Batch Number 'OCORE' dan 'RECON'
    drop_mask = pd.Series(False, index=df_as57d.index)
    if 'Batch Number' in df_as57d.columns:
        b_upper = df_as57d['Batch Number'].astype(str).str.strip().str.upper()
        drop_mask |= b_upper.isin(['OCORE', 'RECON'])

    removed_cnt = int(drop_mask.sum())
    df_as57d = df_as57d[~drop_mask].copy()
    log(f"AS57D: Membersihkan {removed_cnt:,} baris tidak relevan (Batch: OCORE & RECON).")

    # Pisahkan Material Description -> Manufacture, PN (:AA), & Base PN
    log("Membuat kolom 'Manufacture' & 'PN' (tambah suffix :AA)...")
    parsed = df_as57d['Material Description'].apply(parse_material_desc)
    df_as57d['Manufacture'] = [p[0] for p in parsed]
    df_as57d['PN'] = [p[1] for p in parsed]
    df_as57d['Base_PN'] = [p[2] for p in parsed]

    # Filter: Hanya Manufacture yang mengandung 'CAT' atau 'Loctite', atau part terdaftar di CUSTOM_PN_MAPPING
    log("Memfilter Manufacture: hanya CAT & Loctite...")
    cond_cat_loctite = df_as57d['Manufacture'].str.contains('CAT|LOCTITE', case=False, na=False)
    cond_custom_pn = df_as57d['PN'].isin(CUSTOM_PN_MAPPING.values()) | df_as57d['PN'].isin(CUSTOM_PN_MAPPING.keys())
    df_as57d_clean = df_as57d[cond_cat_loctite | cond_custom_pn].copy()

    df_as57d_clean['Requirement Quantity'] = pd.to_numeric(df_as57d_clean['Requirement Quantity'], errors='coerce').fillna(0.0)
    df_as57d_clean['Material Number'] = df_as57d_clean['Material Number'].astype(str).str.strip()

    # Bersihkan Order Number & tandai Monthly Plan
    if 'Order Number' in df_as57d_clean.columns:
        df_as57d_clean['Clean_Order'] = df_as57d_clean['Order Number'].apply(clean_order_no)
    else:
        df_as57d_clean['Clean_Order'] = ''

    if has_mp_info:
        df_as57d_clean['Is_Monthly_Plan'] = df_as57d_clean['Clean_Order'].isin(mp_orders)
        df_as57d_clean['Monthly_Plan_Tag'] = np.where(df_as57d_clean['Is_Monthly_Plan'], '🟢 YES (MP)', '⚪ NO')
    else:
        df_as57d_clean['Is_Monthly_Plan'] = False
        df_as57d_clean['Monthly_Plan_Tag'] = '⚪ NO'

    # Identifikasi kolom status WO
    status_col = next((c for c in ['WO User Status', 'User Status', 'Status'] if c in df_as57d_clean.columns), None)
    if not status_col:
        for c in df_as57d_clean.columns:
            if 'USER STATUS' in str(c).upper():
                status_col = c
                break

    # Filtered Status COMP, PROG, RELE (Active Backlog)
    if status_col:
        target_statuses = ['COMP', 'PROG', 'RELE']
        cond_status = df_as57d_clean[status_col].astype(str).str.strip().str.upper().isin(target_statuses)
        df_as57d_filtered = df_as57d_clean[cond_status].copy()
        log(f"AS57D (COMP, PROG, RELE): Tersaring {len(df_as57d_filtered):,} baris.")
    else:
        log("Peringatan: Kolom 'WO User Status' tidak ditemukan di AS57D, kelompok kedua menggunakan seluruh data.")
        df_as57d_filtered = df_as57d_clean.copy()

    # Kelompok 1: All WO User Status
    pivot_all = pd.DataFrame()
    if output_mode in ("both", "all"):
        pivot_all = df_as57d_clean.groupby(
            ['Material Number', 'PN', 'Base_PN', 'Material Description'], as_index=False
        ).agg(
            Requirement_Qty=('Requirement Quantity', 'sum')
        )
        log(f"AS57D (All Status): Tersaring {len(df_as57d_clean):,} baris ({len(pivot_all):,} material unik).")

    # Kelompok 2: Filtered Status COMP, PROG, RELE
    pivot_filtered = pd.DataFrame()
    if output_mode in ("both", "filtered"):
        pivot_filtered = df_as57d_filtered.groupby(
            ['Material Number', 'PN', 'Base_PN', 'Material Description'], as_index=False
        ).agg(
            Requirement_Qty=('Requirement Quantity', 'sum')
        )
        log(f"AS57D (COMP, PROG, RELE): {len(pivot_filtered):,} material unik.")

    # Kelompok Tambahan: Monthly Plan (Semua Part Kebutuhan Order Monthly Plan)
    pivot_mp = pd.DataFrame()
    if has_mp_info:
        df_as57d_mp = df_as57d_clean[df_as57d_clean['Is_Monthly_Plan']].copy()
        pivot_mp = df_as57d_mp.groupby(
            ['Material Number', 'PN', 'Base_PN', 'Material Description'], as_index=False
        ).agg(
            Requirement_Qty=('Requirement Quantity', 'sum')
        )
        log(f"AS57D (Monthly Plan): Tersaring {len(df_as57d_mp):,} baris ({len(pivot_mp):,} material unik).")

    # -------------------------------------------------------------------------
    # 3. PENGOLAHAN FILE STOCK INFO (Internal SAP - ATP & OO)
    # -------------------------------------------------------------------------
    has_stock_info = False
    pivot_inv = pd.DataFrame(columns=['Material_Key', 'Stock_Info_ATP', 'Stock_Info_OO'])
    pivot_inv_base = pd.DataFrame(columns=['Base_Key', 'Stock_Info_Base', 'Stock_Info_Base_OO'])

    if stock_info_path and os.path.exists(stock_info_path):
        log(f"Membaca file Stock Info: {os.path.basename(stock_info_path)}...")
        try:
            wb_inv = CalamineWorkbook.from_path(stock_info_path)

            target_sheet = None
            for s in wb_inv.sheet_names:
                if s.lower() in ['data', 'sheet1', 'inventory', 'stock_info']:
                    target_sheet = s
                    break

            if not target_sheet:
                for s in wb_inv.sheet_names:
                    try:
                        rows_sample = wb_inv.get_sheet_by_name(s).to_python()
                        if rows_sample and len(rows_sample) > 0:
                            hdr_sample = " ".join([str(h).upper() for h in rows_sample[0]])
                            if ("MATERIAL" in hdr_sample or "PART" in hdr_sample) and ("ATP" in hdr_sample or "STOCK" in hdr_sample):
                                target_sheet = s
                                break
                    except Exception:
                        continue

            if not target_sheet:
                target_sheet = wb_inv.sheet_names[0]

            log(f"Mengekstrak data Stock Info dari sheet: '{target_sheet}'...")
            s_inv_data = wb_inv.get_sheet_by_name(target_sheet).to_python()
            headers_inv = [str(h).strip() for h in s_inv_data[0]]
            df_inv = pd.DataFrame(s_inv_data[1:], columns=headers_inv)

            # Cari kolom Material Number
            mat_col = next((c for c in ['Material Number', 'Material', 'Part Number', 'PN'] if c in df_inv.columns), None)
            if not mat_col:
                for c in df_inv.columns:
                    if 'MATERIAL' in str(c).upper():
                        mat_col = c
                        break

            # Cari kolom ATP
            atp_col = next((c for c in ['On-hand Stock (ATP)', 'ATP', 'Surplus (ATP)', 'On-hand Stock'] if c in df_inv.columns), None)
            if not atp_col:
                for c in df_inv.columns:
                    if 'ATP' in str(c).upper():
                        atp_col = c
                        break

            # Cari kolom On-Order Qty
            on_order_col = next((c for c in df_inv.columns if 'on-order' in str(c).lower() or 'on order' in str(c).lower()), None)

            # Cari kolom In-Transit STO
            transit_col = next((c for c in df_inv.columns if 'in-transit sto' in str(c).lower() or 'in transit sto' in str(c).lower() or 'transit sto' in str(c).lower() or 'intransit sto' in str(c).lower()), None)

            # Cari kolom Material Description
            desc_col = next((c for c in ['Material Description', 'Description', 'Material Desc', 'Part Description'] if c in df_inv.columns), None)
            if not desc_col:
                for c in df_inv.columns:
                    if 'DESCRIPTION' in str(c).upper() or 'DESC' in str(c).upper():
                        desc_col = c
                        break

            # Cari kolom Deletion Indicator
            del_col = next((c for c in ['Deletion Indicator', 'Deletion Ind', 'Del. Ind.', 'Del Indicator', 'DEL'] if c in df_inv.columns), None)
            if not del_col:
                for c in df_inv.columns:
                    if 'DELETION' in str(c).upper() or 'DELETE' in str(c).upper():
                        del_col = c
                        break

            # Cari kolom Order Method
            order_method_col = next((c for c in ['Order Method', 'OrderMethod', 'Order_Method'] if c in df_inv.columns), None)
            if not order_method_col:
                for c in df_inv.columns:
                    if 'ORDER' in str(c).upper() and 'METHOD' in str(c).upper():
                        order_method_col = c
                        break

            # Cari kolom HS Code
            hs_col = next((c for c in ['HS Code', 'HSCode', 'HS_Code', 'HS CODE'] if c in df_inv.columns), None)
            if not hs_col:
                for c in df_inv.columns:
                    if 'HS' in str(c).upper() and 'CODE' in str(c).upper():
                        hs_col = c
                        break

            # Cari kolom Min (Safety Stock)
            min_col = next((c for c in ['Min', 'MIN', 'Safety Stock', 'Min Stock'] if c in df_inv.columns), None)
            if not min_col:
                for c in df_inv.columns:
                    if str(c).strip().upper() == 'MIN':
                        min_col = c
                        break

            # Cari kolom Max
            max_col = next((c for c in ['Max', 'MAX', 'Max Stock'] if c in df_inv.columns), None)
            if not max_col:
                for c in df_inv.columns:
                    if str(c).strip().upper() == 'MAX':
                        max_col = c
                        break

            # Cari kolom UOM / Base Unit of Measure
            uom_col = next((c for c in ['Base Unit of Measure', 'Base unit of measure', 'UoM', 'UOM', 'Unit', 'MEINS'] if c in df_inv.columns), None)
            if not uom_col:
                for c in df_inv.columns:
                    if 'UNIT OF MEASURE' in str(c).upper() or str(c).strip().upper() == 'UOM':
                        uom_col = c
                        break

            # Cari kolom Storage Location
            sloc_col = next((c for c in ['Storage Location', 'Sloc', 'SLOC', 'Stor Loc'] if c in df_inv.columns), None)

            # Cari kolom GR Last Date
            gr_date_col = next((c for c in ['GR Last Date', 'GR Date', 'Last GR Date', 'GR_Date'] if c in df_inv.columns), None)

            # Cari kolom Demand 1 s/d Demand 12
            demand_cols_found = []
            for i in range(1, 13):
                c_found = next((c for c in df_inv.columns if str(c).strip().lower().replace(' ', '') == f'demand{i}'), None)
                if c_found:
                    demand_cols_found.append(c_found)

            if mat_col and atp_col:
                df_inv['Material_Key'] = df_inv[mat_col].astype(str).str.strip()
                df_inv['Base_Key'] = df_inv['Material_Key'].apply(lambda x: x.split(':')[0] if ':' in x else x)
                df_inv['ATP_Val'] = pd.to_numeric(df_inv[atp_col], errors='coerce').fillna(0.0)

                # Hitung On-Order Qty, In-Transit STO, dan Total OO
                on_order_series = pd.to_numeric(df_inv[on_order_col], errors='coerce').fillna(0.0) if on_order_col else pd.Series(0.0, index=df_inv.index)
                transit_series = pd.to_numeric(df_inv[transit_col], errors='coerce').fillna(0.0) if transit_col else pd.Series(0.0, index=df_inv.index)

                df_inv['On_Order_Val'] = on_order_series
                df_inv['In_Transit_STO_Val'] = transit_series
                df_inv['OO_Val'] = on_order_series + transit_series

                # Hitung Min, Max, Demand
                df_inv['Min_Val'] = pd.to_numeric(df_inv[min_col], errors='coerce').fillna(0.0) if min_col else 0.0
                df_inv['Max_Val'] = pd.to_numeric(df_inv[max_col], errors='coerce').fillna(0.0) if max_col else 0.0

                d1_col = next((c for c in demand_cols_found if str(c).strip().lower().replace(' ', '') == 'demand1'), None)
                df_inv['Demand_1_Val'] = pd.to_numeric(df_inv[d1_col], errors='coerce').fillna(0.0) if d1_col else 0.0

                if demand_cols_found:
                    df_inv['Total_12M_Demand_Val'] = df_inv[demand_cols_found].apply(pd.to_numeric, errors='coerce').fillna(0.0).sum(axis=1)
                else:
                    df_inv['Total_12M_Demand_Val'] = 0.0
                df_inv['AMD_Val'] = df_inv['Total_12M_Demand_Val'] / 12.0

                agg_dict = {
                    'Stock_Info_ATP': ('ATP_Val', 'sum'),
                    'On_Order_Qty': ('On_Order_Val', 'sum'),
                    'In_Transit_STO': ('In_Transit_STO_Val', 'sum'),
                    'Stock_Info_OO': ('OO_Val', 'sum'),
                    'Min_Stock': ('Min_Val', 'max'),
                    'Max_Stock': ('Max_Val', 'max'),
                    'Demand_1': ('Demand_1_Val', 'sum'),
                    'Total_12M_Demand': ('Total_12M_Demand_Val', 'sum'),
                    'AMD': ('AMD_Val', 'sum'),
                }
                if desc_col:
                    df_inv['Inv_Desc'] = df_inv[desc_col].astype(str).str.strip().replace('nan', '')
                    agg_dict['Material_Description'] = ('Inv_Desc', 'first')
                if del_col:
                    df_inv['Inv_Del'] = df_inv[del_col].astype(str).str.strip().replace('nan', '')
                    agg_dict['Deletion_Indicator'] = ('Inv_Del', 'first')
                if order_method_col:
                    def clean_order_method(val):
                        if pd.isna(val):
                            return ''
                        s = str(val).strip().upper()
                        return s if s in ('BB', 'PT') else ''

                    df_inv['Order_Method_Clean'] = df_inv[order_method_col].apply(clean_order_method)
                    agg_dict['Order_Method'] = ('Order_Method_Clean', 'max')
                if hs_col:
                    df_inv['Clean_HS_Code'] = df_inv[hs_col].apply(clean_hs_code)
                    agg_dict['HS_Code'] = ('Clean_HS_Code', 'max')
                if uom_col:
                    df_inv['Inv_UOM'] = df_inv[uom_col].astype(str).str.strip().replace('nan', '')
                    agg_dict['UOM'] = ('Inv_UOM', 'first')
                if sloc_col:
                    df_inv['Inv_Sloc'] = df_inv[sloc_col].astype(str).str.strip().replace('nan', '')
                    agg_dict['Storage_Location'] = ('Inv_Sloc', 'first')
                if gr_date_col:
                    df_inv['Inv_GR_Date'] = df_inv[gr_date_col].astype(str).str.strip().replace('nan', '')
                    agg_dict['GR_Last_Date'] = ('Inv_GR_Date', 'first')

                # Pivot 1: Berdasarkan Material Number lengkap (contoh: 4780706:AA)
                pivot_inv = df_inv.groupby('Material_Key', as_index=False).agg(**agg_dict)

                # Pivot 2: Berdasarkan Base PN (sebagai cadangan)
                pivot_inv_base = df_inv.groupby('Base_Key', as_index=False).agg(
                    Stock_Info_Base=('ATP_Val', 'sum'),
                    Stock_Info_Base_OO=('OO_Val', 'sum')
                )
                has_stock_info = True
                log(f"Stock Info: Sukses memuat {len(df_inv):,} baris ({len(pivot_inv):,} material unik) dari sheet '{target_sheet}'. Total OO terdeteksi: {pivot_inv['Stock_Info_OO'].sum():,.2f}.")
            else:
                log(f"Peringatan: Kolom Material ({mat_col}) atau ATP ({atp_col}) tidak ditemukan di sheet '{target_sheet}'.")

        except Exception as e:
            log(f"Peringatan: Gagal membaca file Stock Info ({str(e)}). Melanjutkan tanpa data Stock Info.")

    # -------------------------------------------------------------------------
    # 3b. PENGOLAHAN FILE KUOTA IMPORT
    # -------------------------------------------------------------------------
    has_kuota_info = False
    df_kuota_lookup = pd.DataFrame(columns=['HS_Key', 'Kuota_Import_AF', 'Kuota_Import_SF'])

    if kuota_file_path and os.path.exists(kuota_file_path):
        log(f"Membaca file Kuota Import: {os.path.basename(kuota_file_path)}...")
        try:
            wb_k = CalamineWorkbook.from_path(kuota_file_path)
            k_target_sheet = wb_k.sheet_names[0]
            for s in wb_k.sheet_names:
                if 'SUMMARY' in s.upper():
                    k_target_sheet = s
                    break

            rows_k = wb_k.get_sheet_by_name(k_target_sheet).to_python()
            if rows_k and len(rows_k) > 1:
                hdr_k = [str(h).strip() for h in rows_k[0]]
                df_k = pd.DataFrame(rows_k[1:], columns=hdr_k)

                k_hs_col = next((c for c in ['HS Code', 'HSCode', 'HS_Code', 'HS CODE'] if c in df_k.columns), None)
                if not k_hs_col:
                    for c in df_k.columns:
                        if 'HS' in str(c).upper():
                            k_hs_col = c
                            break

                k_af_col = next((c for c in df_k.columns if 'AIR' in str(c).upper() or 'AF' in str(c).upper()), None)
                k_sf_col = next((c for c in df_k.columns if 'SEA' in str(c).upper() or 'SF' in str(c).upper()), None)

                if k_hs_col and (k_af_col or k_sf_col):
                    df_k['HS_Key'] = df_k[k_hs_col].apply(clean_hs_code)
                    df_k = df_k[df_k['HS_Key'] != ''].drop_duplicates(subset=['HS_Key']).copy()

                    cols_to_keep = ['HS_Key']
                    rename_kuota = {}
                    if k_af_col:
                        cols_to_keep.append(k_af_col)
                        rename_kuota[k_af_col] = 'Kuota_Import_AF'
                    if k_sf_col:
                        cols_to_keep.append(k_sf_col)
                        rename_kuota[k_sf_col] = 'Kuota_Import_SF'

                    df_kuota_lookup = df_k[cols_to_keep].rename(columns=rename_kuota)
                    if 'Kuota_Import_AF' not in df_kuota_lookup.columns:
                        df_kuota_lookup['Kuota_Import_AF'] = ''
                    if 'Kuota_Import_SF' not in df_kuota_lookup.columns:
                        df_kuota_lookup['Kuota_Import_SF'] = ''

                    has_kuota_info = True
                    log(f"Kuota Import: Sukses memuat {len(df_kuota_lookup):,} HS Code unik dari sheet '{k_target_sheet}'.")
                else:
                    log(f"Peringatan: Kolom HS Code / Quota Air / Sea tidak ditemukan di sheet '{k_target_sheet}'.")
        except Exception as e:
            log(f"Peringatan: Gagal membaca file Kuota Import ({str(e)}). Melanjutkan tanpa Kuota Import.")

    # Gabungkan data Kuota Import ke pivot_inv jika ada
    if has_stock_info and not pivot_inv.empty:
        if 'HS_Code' not in pivot_inv.columns:
            pivot_inv['HS_Code'] = ''

        if has_kuota_info and not df_kuota_lookup.empty:
            pivot_inv = pd.merge(pivot_inv, df_kuota_lookup, left_on='HS_Code', right_on='HS_Key', how='left')
            pivot_inv['Kuota_Import_AF'] = pivot_inv['Kuota_Import_AF'].fillna('')
            pivot_inv['Kuota_Import_SF'] = pivot_inv['Kuota_Import_SF'].fillna('')
            if 'HS_Key' in pivot_inv.columns:
                pivot_inv.drop(columns=['HS_Key'], inplace=True)
        else:
            pivot_inv['Kuota_Import_AF'] = ''
            pivot_inv['Kuota_Import_SF'] = ''

    # -------------------------------------------------------------------------
    # 4. PENGGABUNGAN DATA (AS57D + MB52 + STOCK INFO)
    # -------------------------------------------------------------------------
    log("Mencocokkan kebutuhan part AS57D dengan stok MB52 (S) & Stock Info (ATP & OO)...")

    merged_all = None
    merged_filtered = None
    merged_mp = None

    if output_mode in ("both", "all") and not pivot_all.empty:
        merged_all = merge_readiness_data(pivot_all, pivot_mb52, pivot_inv, pivot_inv_base, has_stock_info)

    if output_mode in ("both", "filtered") and not pivot_filtered.empty:
        merged_filtered = merge_readiness_data(pivot_filtered, pivot_mb52, pivot_inv, pivot_inv_base, has_stock_info)

    if has_mp_info and not pivot_mp.empty:
        merged_mp = merge_readiness_data(pivot_mp, pivot_mb52, pivot_inv, pivot_inv_base, has_stock_info)

    # 4b. Analisis Ketersediaan Consist Hose Assy (Akumulasi Stok & Prioritas MP)
    df_consist_analysis = pd.DataFrame()
    df_component_summary = pd.DataFrame()

    if has_consist_info and consist_master:
        log("Menganalisis ketersediaan Consist Hose Assy (Akumulasi Stok & Prioritas MP)...")
        df_consist_analysis, df_component_summary, hose_alloc_map = build_consist_allocation_engine(
            df_as57d_clean, consist_master, pivot_inv, pivot_inv_base, has_mp_info=has_mp_info
        )
        if merged_mp is not None and not merged_mp.empty:
            merged_mp = apply_consist_status_to_merged(merged_mp, hose_alloc_map, is_mp_sheet=True)
        if merged_filtered is not None and not merged_filtered.empty:
            merged_filtered = apply_consist_status_to_merged(merged_filtered, hose_alloc_map, is_mp_sheet=False)
        if merged_all is not None and not merged_all.empty:
            merged_all = apply_consist_status_to_merged(merged_all, hose_alloc_map, is_mp_sheet=False)

    # 4c. Evaluasi Kesiapan Rilis Part Antar-Cabang (Dynamic Safety Stock & WO Allocation)
    df_release_eval = pd.DataFrame()
    log("Menyusun Master Evaluasi Kesiapan Rilis Part Antar-Cabang (Dynamic Safety Stock)...")
    try:
        df_release_eval = build_part_release_evaluation(pivot_mb52, pivot_inv, pivot_all)
        log(f"Part Release Evaluation: Berhasil mengevaluasi {len(df_release_eval):,} part dengan stok fisik > 0.")
    except Exception as e:
        log(f"Peringatan: Gagal menyusun Part Release Evaluation ({e}). Melanjutkan proses...")
        df_release_eval = pd.DataFrame()

    log(f"Menyusun Workbook Excel (output_mode: {output_mode}, MP Tambahan: {has_mp_info})...")

    # Siapkan Data Export untuk Sheet Stock Info ATP
    if has_stock_info:
        export_cols = ['Material_Key']
        rename_map = {
            'Material_Key': 'Material Number',
            'Stock_Info_ATP': 'Onhand ATP',
            'On_Order_Qty': 'On-Order Qty',
            'In_Transit_STO': 'In-Transit STO',
            'Stock_Info_OO': 'Pipeline (On Order)'
        }
        if 'Material_Description' in pivot_inv.columns:
            export_cols.append('Material_Description')
            rename_map['Material_Description'] = 'Material Description'

        export_cols.append('Stock_Info_ATP')
        export_cols.append('On_Order_Qty')
        export_cols.append('In_Transit_STO')
        export_cols.append('Stock_Info_OO')

        if 'Order_Method' in pivot_inv.columns:
            export_cols.append('Order_Method')
            rename_map['Order_Method'] = 'Order Method'
        else:
            pivot_inv['Order_Method'] = ''
            export_cols.append('Order_Method')
            rename_map['Order_Method'] = 'Order Method'

        if 'HS_Code' in pivot_inv.columns:
            export_cols.append('HS_Code')
            rename_map['HS_Code'] = 'HS Code'
        else:
            pivot_inv['HS_Code'] = ''
            export_cols.append('HS_Code')
            rename_map['HS_Code'] = 'HS Code'

        if 'Kuota_Import_AF' in pivot_inv.columns:
            export_cols.append('Kuota_Import_AF')
            rename_map['Kuota_Import_AF'] = 'Kuota Import AF'
        else:
            pivot_inv['Kuota_Import_AF'] = ''
            export_cols.append('Kuota_Import_AF')
            rename_map['Kuota_Import_AF'] = 'Kuota Import AF'

        if 'Kuota_Import_SF' in pivot_inv.columns:
            export_cols.append('Kuota_Import_SF')
            rename_map['Kuota_Import_SF'] = 'Kuota Import SF'
        else:
            pivot_inv['Kuota_Import_SF'] = ''
            export_cols.append('Kuota_Import_SF')
            rename_map['Kuota_Import_SF'] = 'Kuota Import SF'

        if 'Deletion_Indicator' in pivot_inv.columns:
            export_cols.append('Deletion_Indicator')
            rename_map['Deletion_Indicator'] = 'Deletion Indicator'

        df_inv_export = pivot_inv[export_cols].rename(columns=rename_map)
    else:
        df_inv_export = pd.DataFrame()

    # Tulis data ke Excel dengan openpyxl engine
    with pd.ExcelWriter(output_file_path, engine='openpyxl') as writer:
        if has_stock_info and not df_inv_export.empty:
            df_inv_export.to_excel(writer, sheet_name='Stock Info ATP', index=False)
        df_as57d_clean.to_excel(writer, sheet_name='Data AS57D Clean', index=False)

    # Styling Workbook dengan openpyxl
    wb = openpyxl.load_workbook(output_file_path)

    sheet_insert_idx = 0

    # 1. Sheet Tambahan: Part Readiness - Monthly Plan (jika ada file Monthly Plan)
    if has_mp_info and merged_mp is not None and not merged_mp.empty:
        ws_mp = wb.create_sheet(title='Part Readiness - Monthly Plan', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Part Readiness - Monthly Plan...")
        mp_title = f"WO ALLOCATION READINESS - MONTHLY PLAN ({mp_sheet or 'PLAN'})"
        populate_readiness_sheet(
            ws_mp,
            merged_mp,
            mp_title,
            input_file_path,
            stock_info_path,
            has_stock_info,
            kuota_file_path=kuota_file_path,
            has_kuota_info=has_kuota_info,
            mp_file_path=mp_file_path,
            has_mp_info=True,
            is_mp_sheet=True
        )

    # 2. Sheet Standar Berdasarkan Pilihan output_mode (Keduanya, All Status Saja, atau COMP PROG RELE)
    if output_mode == "both":
        ws_all = wb.create_sheet(title='Part Readiness - All', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Part Readiness - All...")
        populate_readiness_sheet(
            ws_all,
            merged_all,
            "WO ALLOCATION READINESS - ALL STATUS",
            input_file_path,
            stock_info_path,
            has_stock_info,
            kuota_file_path=kuota_file_path,
            has_kuota_info=has_kuota_info
        )

        ws_filtered = wb.create_sheet(title='Part Readiness - COMP PROG RELE', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Part Readiness - COMP PROG RELE...")
        populate_readiness_sheet(
            ws_filtered,
            merged_filtered,
            "WO ALLOCATION READINESS - STATUS COMP, PROG & RELE",
            input_file_path,
            stock_info_path,
            has_stock_info,
            kuota_file_path=kuota_file_path,
            has_kuota_info=has_kuota_info
        )

    elif output_mode == "all":
        ws_all = wb.create_sheet(title='Part Readiness - All', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Part Readiness - All...")
        populate_readiness_sheet(
            ws_all,
            merged_all,
            "WO ALLOCATION READINESS - ALL STATUS",
            input_file_path,
            stock_info_path,
            has_stock_info,
            kuota_file_path=kuota_file_path,
            has_kuota_info=has_kuota_info
        )

    elif output_mode == "filtered":
        ws_filtered = wb.create_sheet(title='Part Readiness - COMP PROG RELE', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Part Readiness - COMP PROG RELE...")
        populate_readiness_sheet(
            ws_filtered,
            merged_filtered,
            "WO ALLOCATION READINESS - STATUS COMP, PROG & RELE",
            input_file_path,
            stock_info_path,
            has_stock_info,
            kuota_file_path=kuota_file_path,
            has_kuota_info=has_kuota_info
        )

    # 2b. Sheet Tambahan: Hose Consist Analysis (jika ada data consist)
    if has_consist_info and df_consist_analysis is not None and not df_consist_analysis.empty:
        ws_consist = wb.create_sheet(title='Hose Consist Analysis', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Hose Consist Analysis...")
        populate_hose_consist_sheet(
            ws_consist,
            df_consist_analysis,
            df_component_summary,
            input_file_path,
            consist_file_path,
            stock_info_path
        )

    # 2c. Sheet Tambahan: Part Release Evaluation (Transfer Antar Cabang)
    if df_release_eval is not None and not df_release_eval.empty:
        ws_release = wb.create_sheet(title='Part Release Evaluation', index=sheet_insert_idx)
        sheet_insert_idx += 1
        log("Membuat Sheet: Part Release Evaluation...")
        populate_part_release_sheet(
            ws_release,
            df_release_eval,
            input_file_path,
            stock_info_path
        )

    # Styling Sheet Pendukung
    navy_dark = "1E3A8A"
    for s_name in ['Stock Info ATP', 'Data AS57D Clean']:
        if s_name in wb.sheetnames:
            ws = wb[s_name]
            ws.views.sheetView[0].showGridLines = True
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for c in range(1, ws.max_column + 1):
                cell = ws.cell(row=1, column=c)
                cell.font = Font(name="Segoe UI", size=9, bold=True, color="FFFFFF")
                cell.fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Atur lebar kolom khusus untuk Stock Info ATP
            if s_name == 'Stock Info ATP':
                col_width_map = {
                    'Material Number': 20,
                    'Material Description': 35,
                    'Onhand ATP': 18,
                    'On-Order Qty': 16,
                    'In-Transit STO': 16,
                    'Pipeline (On Order)': 18,
                    'Order Method': 16,
                    'HS Code': 16,
                    'Kuota Import AF': 18,
                    'Kuota Import SF': 18,
                    'Deletion Indicator': 18
                }
                for c_idx in range(1, ws.max_column + 1):
                    col_name = str(ws.cell(row=1, column=c_idx).value or '').strip()
                    ws.column_dimensions[get_column_letter(c_idx)].width = col_width_map.get(col_name, 16)

    log("Menyimpan file hasil olahan Part Readiness...")
    wb.save(output_file_path)
    wb.close()
    log(f"Selesai! File tersimpan di: {output_file_path}")

    # Susun ringkasan hasil untuk reporting & notification
    active_merged = merged_mp if (has_mp_info and merged_mp is not None and not merged_mp.empty) else (merged_filtered if merged_filtered is not None and not merged_filtered.empty else merged_all)

    return {
        "output_path": output_file_path,
        "output_mode": output_mode,
        "has_mp_info": has_mp_info,
        "mp_target_sheet": mp_sheet,
        "mp_parts_required": len(merged_mp) if has_mp_info and merged_mp is not None else 0,
        "mp_req_qty": float(merged_mp['Requirement_Qty'].sum()) if has_mp_info and merged_mp is not None and len(merged_mp) > 0 else 0.0,
        "mp_ready": int((merged_mp['Status'].astype(str).str.startswith('Ready')).sum()) if has_mp_info and merged_mp is not None and len(merged_mp) > 0 else 0,
        "mp_not_ready": int((merged_mp['Status'].astype(str).str.startswith('Not Ready')).sum()) if has_mp_info and merged_mp is not None and len(merged_mp) > 0 else 0,
        "mp_shortage": int((merged_mp['Status'].astype(str).str.startswith('Not Ready')).sum()) if has_mp_info and merged_mp is not None and len(merged_mp) > 0 else 0,
        "all_parts_required": len(merged_all) if merged_all is not None else 0,
        "all_req_qty": float(merged_all['Requirement_Qty'].sum()) if merged_all is not None and len(merged_all) > 0 else 0.0,
        "all_ready": int((merged_all['Status'].astype(str).str.startswith('Ready')).sum()) if merged_all is not None and len(merged_all) > 0 else 0,
        "all_not_ready": int((merged_all['Status'].astype(str).str.startswith('Not Ready')).sum()) if merged_all is not None and len(merged_all) > 0 else 0,
        "all_shortage": int((merged_all['Status'].astype(str).str.startswith('Not Ready')).sum()) if merged_all is not None and len(merged_all) > 0 else 0,
        "filtered_parts_required": len(merged_filtered) if merged_filtered is not None else 0,
        "filtered_req_qty": float(merged_filtered['Requirement_Qty'].sum()) if merged_filtered is not None and len(merged_filtered) > 0 else 0.0,
        "filtered_ready": int((merged_filtered['Status'].astype(str).str.startswith('Ready')).sum()) if merged_filtered is not None and len(merged_filtered) > 0 else 0,
        "filtered_not_ready": int((merged_filtered['Status'].astype(str).str.startswith('Not Ready')).sum()) if merged_filtered is not None and len(merged_filtered) > 0 else 0,
        "filtered_shortage": int((merged_filtered['Status'].astype(str).str.startswith('Not Ready')).sum()) if merged_filtered is not None and len(merged_filtered) > 0 else 0,
        "total_stock_mb52": float(pivot_mb52['Stock_MB52_S'].sum()),
        "total_stock_info": float(pivot_inv['Stock_Info_ATP'].sum()) if has_stock_info and not pivot_inv.empty else 0.0,
        "total_stock_oo": float(pivot_inv['Stock_Info_OO'].sum()) if has_stock_info and not pivot_inv.empty else 0.0,
        "has_stock_info": has_stock_info,
        "has_kuota_info": has_kuota_info,
        "has_consist_info": has_consist_info,
        "consist_file_path": consist_file_path,
        "consist_total_analyzed": len(df_consist_analysis) if (has_consist_info and df_consist_analysis is not None and not df_consist_analysis.empty) else 0,
        "consist_ready_to_assemble": int((df_consist_analysis['Consist Status'] == 'READY TO ASSEMBLE').sum()) if (has_consist_info and df_consist_analysis is not None and not df_consist_analysis.empty) else 0,
        "consist_shortage": int((df_consist_analysis['Consist Status'] == 'CONSIST SHORTAGE').sum()) if (has_consist_info and df_consist_analysis is not None and not df_consist_analysis.empty) else 0,
        "consist_deficit_components": int((df_component_summary['Status Ketersediaan'] == '🔴 DEFICIT').sum()) if (has_consist_info and df_component_summary is not None and not df_component_summary.empty) else 0,
        "release_total_evaluated": len(df_release_eval) if df_release_eval is not None else 0,
        "release_safe_items": int((df_release_eval['Status_Recommendation'] == '🟢 SAFE TO RELEASE').sum()) if (df_release_eval is not None and not df_release_eval.empty) else 0,
        "release_deadstock_items": int((df_release_eval['Status_Recommendation'] == '💎 PRIORITY (DEAD STOCK)').sum()) if (df_release_eval is not None and not df_release_eval.empty) else 0,
        "release_conditional_items": int((df_release_eval['Status_Recommendation'] == '🟡 CONDITIONAL (PIPELINE)').sum()) if (df_release_eval is not None and not df_release_eval.empty) else 0,
        "release_reject_items": int((df_release_eval['Status_Recommendation'] == '🔴 DO NOT RELEASE').sum()) if (df_release_eval is not None and not df_release_eval.empty) else 0,
        "release_safe_qty": float(df_release_eval['Safe_Qty_to_Release'].sum()) if (df_release_eval is not None and not df_release_eval.empty) else 0.0,
        "elapsed_time": time.time() - t0
    }


if __name__ == "__main__":
    test_raw = r"D:\Users\yusril.i.wafir\Downloads\RAW DATA 02102026.xlsb"
    test_inv = r"D:\Users\yusril.i.wafir\Downloads\Inventory 02102026.XLSX"
    if os.path.exists(test_raw):
        r = process_wo_readiness(test_raw, test_inv, output_mode="both")
        print("Success:", r)
