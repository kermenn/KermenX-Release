"""
GIT Monitoring Helper (Goods In Transit)
Menggabungkan ekstraksi SAP (/NZMPU_PO_MONI) dan automated tracking CKB Logistics.

Aturan Kategori Rekomendasi Tindakan:
1. MERAH (Urgent): "Need GR segera"
   -> Jika status CKB adalah "Delivered" atau "Hand over Rantau" (Barang fisik sudah tiba di site/gudang).
2. KUNING: "Need follow up to sending branch for create shipment"
   -> Jika kolom Shipment Number kosong / belum ada resi dari cabang pengirim.
3. BIRU: "Need follow up shipment to ckb"
   -> Jika nomor resi ada dan status masih berjalan di CKB.
"""

import os
import sys
import time
import re
from datetime import datetime
from typing import Dict, List, Optional, Callable
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from modules import ckb_tracking_helper as ckb
import config


def _parse_date_safe(d_str):
    if not d_str or str(d_str).strip() in ("-", "", "nan", "None"):
        return None
    clean = str(d_str).strip().split("(")[0].strip()
    for fmt in ("%d-%b-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d.%m.%Y", "%b %d %Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(clean, fmt).date()
        except Exception:
            pass
    return None


def download_sap_git_export(
    session,
    plant: str = "1346",
    selpa: str = "WE101",
    variant: str = "/yusril",
    save_dir: Optional[str] = None,
    filename: Optional[str] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None
) -> str:
    """
    Menjalankan otomasi transaksi SAP /NZMPU_PO_MONI dan mengekspor spreadsheet ALV.
    """
    def _log(msg):
        if log_callback:
            log_callback(msg)

    def _prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    if not save_dir:
        save_dir = config.get_output_dir("sap")
    os.makedirs(save_dir, exist_ok=True)

    if not filename:
        filename = f"SAP_GIT_EXPORT_{plant}_{time.strftime('%Y%m%d_%H%M%S')}.XLSX"
    if not filename.upper().endswith(".XLSX"):
        filename += ".XLSX"

    target_file = os.path.abspath(os.path.join(save_dir, filename))
    if os.path.exists(target_file):
        try:
            os.remove(target_file)
        except Exception:
            pass

    _log(f"[SAP GIT] Membuka transaksi /NZMPU_PO_MONI (Plant: {plant}, Scope: {selpa})...")
    _prog(10, "Mengakses transaksi /NZMPU_PO_MONI...")

    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nzmpu_po_moni"
        session.findById("wnd[0]").sendVKey(0)
    except Exception:
        session.findById("wnd[0]/tbar[0]/okcd").text = "zmpu_po_moni"
        session.findById("wnd[0]").sendVKey(0)
    time.sleep(1.0)

    # 1. Isi parameter form
    _log("[SAP GIT] Mengisi kriteria pencarian...")
    try:
        session.findById("wnd[0]/usr/ctxtSELPA-LOW").text = selpa
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_WERKS-LOW").text = plant
    except Exception:
        pass

    _prog(25, "Menjalankan query di SAP (F8)...")
    _log("[SAP GIT] Menjalankan query (F8)...")
    session.findById("wnd[0]").sendVKey(8)
    time.sleep(2.5)

    # Cek pesan error di Status Bar jika data kosong
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and sbar.messageType in ("E", "A"):
            raise RuntimeError(f"SAP Error: {sbar.text}")
    except Exception as ex:
        if "SAP Error:" in str(ex):
            raise

    # 2. Pemilihan Layout ALV
    _prog(40, f"Memilih layout ALV Variant {variant}...")
    _log(f"[SAP GIT] Menerapkan layout variant: {variant}")
    try:
        session.findById("wnd[0]/tbar[1]/btn[33]").press()
        time.sleep(1.2)

        # Dialog Select Layout
        layout_shell = session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell")
        layout_shell.currentCellRow = -1
        layout_shell.selectColumn("VARIANT")
        layout_shell.contextMenu()
        layout_shell.selectContextMenuItem("&FILTER")
        time.sleep(0.8)

        # Input filter variant
        session.findById("wnd[2]/usr/ssub%_SUBSCREEN_FREESEL:SAPLSSEL:1105/ctxt%%DYN001-LOW").text = variant
        session.findById("wnd[2]").sendVKey(0)
        time.sleep(0.8)

        # Klik baris 0
        layout_shell.currentCellColumn = "TEXT"
        layout_shell.selectedRows = "0"
        layout_shell.clickCurrentCell()
        time.sleep(1.5)
    except Exception as ex:
        _log(f"[SAP GIT] Info pemilihan layout variant: {ex} (Melanjutkan dengan layout saat ini)")

    # 3. Export Spreadsheet &XXL
    _prog(55, "Mengekspor spreadsheet Excel dari SAP (&XXL)...")
    _log("[SAP GIT] Mengekspor grid ALV ke Excel...")
    try:
        grid = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
        grid.setCurrentCell(0, "EBELN")
        grid.selectedRows = "0"
        grid.contextMenu()
        grid.selectContextMenuItem("&XXL")
    except Exception:
        # Fallback tombol toolbar export jika context menu berbeda
        session.findById("wnd[0]/mbar/mprg/memu[1]/subm[0]").select()

    time.sleep(1.5)

    # Konfirmasi format dialog 1 (Excel Spreadsheet)
    try:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        time.sleep(1.2)
    except Exception:
        pass

    # Dialog simpan file
    try:
        session.findById("wnd[1]/usr/ctxtDY_PATH").text = save_dir
        session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = filename
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception as ex:
        _log(f"[SAP GIT] Dialog simpan file: {ex}")

    _prog(65, "Menunggu file ekspor tersimpan di disk...")
    # Tunggu file selesai ditulis hingga 15 detik
    for _ in range(30):
        if os.path.exists(target_file) and os.path.getsize(target_file) > 1000:
            break
        time.sleep(0.5)

    if not os.path.exists(target_file):
        # Coba cek apakah tersimpan di C:\TEMP\EXPORT.XLSX
        temp_export = r"C:\TEMP\EXPORT.XLSX"
        if os.path.exists(temp_export):
            import shutil
            shutil.copy2(temp_export, target_file)
            _log(f"[SAP GIT] Mengambil hasil dari fallback C:\\TEMP\\EXPORT.XLSX ke {target_file}")
        else:
            raise FileNotFoundError(f"File ekspor SAP tidak ditemukan di {target_file}!")

    _log(f"[SAP GIT] Berkas ekspor SAP berhasil diunduh: {target_file} ({os.path.getsize(target_file):,} bytes)")
    return target_file


def process_git_monitoring(
    excel_path: str,
    output_dir: Optional[str] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> dict:
    """
    Membaca data ekspor SAP, melakukan tracking otomatis ke web CKB,
    mengklasifikasikan rekomendasi tindakan, dan menyusun laporan Excel resmi.
    """
    def _log(msg):
        if log_callback:
            log_callback(msg)

    def _prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"Berkas Excel tidak ditemukan: {excel_path}")

    _log(f"[GIT MONITORING] Membaca berkas data: {excel_path}")
    _prog(15, "Membaca berkas data PO/STO...")

    df = pd.read_excel(excel_path)
    total_rows = len(df)
    _log(f"[GIT MONITORING] Berhasil membaca {total_rows} baris data.")

    # Deteksi kolom penting
    col_shipment = None
    col_po = None
    col_mat = None
    col_desc = None
    col_qty = None

    for c in df.columns:
        c_low = str(c).lower()
        if "shipment" in c_low and "number" in c_low:
            col_shipment = c
        elif not col_shipment and "shipment" in c_low:
            col_shipment = c
        elif "purchasing" in c_low and "document" in c_low and "type" not in c_low:
            col_po = c
        elif not col_po and "ebeln" in c_low:
            col_po = c
        elif "material" in c_low and not col_mat:
            col_mat = c
        elif "short" in c_low and "text" in c_low and not col_desc:
            col_desc = c
        elif ("order" in c_low and "quantity" in c_low) or c_low == "menge":
            col_qty = c

    if not col_shipment:
        # Fallback cari kolom yang mengandung kata resi/ship
        for c in df.columns:
            if "ship" in str(c).lower() or "br" in str(c).lower():
                col_shipment = c
                break

    if not col_shipment:
        raise ValueError("Kolom 'Shipment Number' tidak ditemukan di berkas Excel SAP!")

    _log(f"[GIT MONITORING] Kolom terpetakan -> PO: {col_po}, Part: {col_mat}, Shipment: {col_shipment}")

    # 1. Ekstrak daftar BR unik (ambil bagian sebelum tanda '-')
    unique_br_map = {}  # clean_br -> list of indices
    row_br_cleaned = []

    for idx, raw_val in enumerate(df[col_shipment]):
        s_val = str(raw_val).strip()
        if not s_val or s_val.lower() in ("nan", "none", "-", ""):
            row_br_cleaned.append("")
        else:
            # Ambil bagian sebelum '-'
            br_clean = s_val.split("-")[0].strip()
            row_br_cleaned.append(br_clean)
            if br_clean not in unique_br_map:
                unique_br_map[br_clean] = []
            unique_br_map[br_clean].append(idx)

    total_br_unique = len(unique_br_map)
    count_without_shipment = sum(1 for b in row_br_cleaned if not b)
    _log(f"[GIT MONITORING] Terdeteksi {total_br_unique} nomor unik BR CKB. {count_without_shipment} baris belum memiliki resi.")

    # 2. Jalankan Scraping CKB
    ckb_results = {}
    if total_br_unique > 0:
        _prog(25, f"Melacak {total_br_unique} nomor resi unik di web CKB...")
        ckb_results = ckb.track_multiple_brs(
            br_list=list(unique_br_map.keys()),
            progress_callback=lambda p, m: _prog(25 + int(0.55 * p), m),
            log_callback=lambda m: _log(m)
        )

    # 3. Klasifikasi Kategori Rekomendasi Tindakan
    _prog(80, "Mengklasifikasikan status tindakan (Merah/Kuning/Biru)...")
    _log("[GIT MONITORING] Menyusun status rekomendasi tindakan...")

    actions = []
    priorities = []
    cn_numbers = []
    ship_dates = []
    ship_froms = []
    ship_tos = []
    ckb_statuses = []
    agings = []

    count_need_gr = 0
    count_need_branch = 0
    count_need_ckb = 0

    items_preview = []

    for idx in range(total_rows):
        br = row_br_cleaned[idx]
        po_val = str(df[col_po].iloc[idx]) if col_po else ""
        mat_val = str(df[col_mat].iloc[idx]) if col_mat else ""
        desc_val = str(df[col_desc].iloc[idx]) if col_desc else ""
        qty_val = str(df[col_qty].iloc[idx]) if col_qty else ""
        raw_ship_val = str(df[col_shipment].iloc[idx]) if pd.notna(df[col_shipment].iloc[idx]) else ""

        if not br:
            # KUNING: Tidak ada nomor resi
            act = "Need follow up to sending branch for create shipment"
            prio = "YELLOW"
            cn = "-"
            s_date = "-"
            s_from = "-"
            s_to = "-"
            st_ckb = "Belum Ada Resi"
            del_date = "-"
            aging_str = "-"
            aging_days = 0
            count_need_branch += 1
        else:
            info = ckb_results.get(br, {})
            cn = info.get("cn_number", "-")
            s_date = info.get("ship_date", "-")
            s_from = info.get("ship_from", "-")
            s_to = info.get("ship_to", "-")
            st_ckb = info.get("ckb_status", "Belum Terlacak")
            del_date = info.get("delivered_date", "-")
            has_handover = info.get("has_handover_rantau", False)

            # Cek apakah Delivered atau Hand over Rantau
            is_delivered = "delivered" in st_ckb.lower() or "hand over" in st_ckb.lower() or has_handover or "handover" in st_ckb.lower()

            if is_delivered:
                # MERAH (Paling Urgent): Barang sudah sampai di site!
                act = "Need GR segera"
                prio = "RED"
                count_need_gr += 1

                # Hitung Aging Hari sejak tiba di site
                today_dt = datetime.now().date()
                parsed_del = _parse_date_safe(del_date) or _parse_date_safe(s_date)
                if parsed_del:
                    diff = (today_dt - parsed_del).days
                    aging_days = max(0, diff)
                    aging_str = f"{aging_days} Hari"
                else:
                    aging_days = 0
                    aging_str = "0 Hari"
            else:
                # BIRU: Barang masih berjalan di CKB
                act = "Need follow up shipment to ckb"
                prio = "BLUE"
                aging_str = "-"
                aging_days = 0
                count_need_ckb += 1

        actions.append(act)
        priorities.append(prio)
        cn_numbers.append(cn)
        ship_dates.append(s_date)
        ship_froms.append(s_from)
        ship_tos.append(s_to)
        ckb_statuses.append(st_ckb)
        agings.append(aging_str)

        # Simpan ke item preview (untuk UI tabel KermenX)
        if idx < 300:
            items_preview.append({
                "no": idx + 1,
                "po": po_val,
                "material": mat_val,
                "description": desc_val,
                "qty": qty_val,
                "raw_shipment": raw_ship_val,
                "br_number": br or "-",
                "cn_number": cn,
                "ship_date": s_date,
                "ship_from": s_from,
                "ship_to": s_to,
                "ckb_status": st_ckb,
                "action": act,
                "priority": prio,
                "aging": aging_str,
                "aging_days": aging_days
            })

    # Tambahkan kolom-kolom baru ke DataFrame
    df["BR Number (CKB)"] = [b or "-" for b in row_br_cleaned]
    df["CN Number (CKB)"] = cn_numbers
    df["Tanggal Kirim (CKB)"] = ship_dates
    df["Ship From (CKB)"] = ship_froms
    df["Ship To (CKB)"] = ship_tos
    df["Status CKB Terkini"] = ckb_statuses
    df["Rekomendasi Tindakan"] = actions
    df["Aging (Hari)"] = agings
    df["Prioritas"] = priorities

    # 4. Buat File Excel Laporan Resmi Berwarna
    _prog(90, "Menyusun berkas laporan Excel GIT berformat eksekutif...")
    if not output_dir:
        output_dir = config.get_output_dir("git")
    os.makedirs(output_dir, exist_ok=True)

    timestamp_str = time.strftime("%Y%m%d_%H%M%S")
    out_filename = f"LAPORAN_GIT_MONITORING_{timestamp_str}.XLSX"
    out_filepath = os.path.abspath(os.path.join(output_dir, out_filename))

    _save_styled_excel(df, out_filepath, count_need_gr, count_need_branch, count_need_ckb, total_br_unique)
    _log(f"[GIT MONITORING] Laporan selesai disimpan di: {out_filepath}")
    _prog(100, "Pemantauan GIT Selesai!")

    return {
        "status": "success",
        "output_path": out_filepath,
        "total_rows": total_rows,
        "total_br_unique": total_br_unique,
        "count_need_gr": count_need_gr,
        "count_need_branch": count_need_branch,
        "count_need_ckb": count_need_ckb,
        "items": items_preview
    }


def _save_styled_excel(df: pd.DataFrame, file_path: str, cnt_gr: int, cnt_br: int, cnt_ckb: int, total_br_unique: int = 0):
    """
    Menyimpan DataFrame ke berkas Excel dengan styling eksekutif ala WO Readiness menggunakan openpyxl:
    - Sheet 1: Summary GIT (Banner Navy Blue, 3 Kartu KPI Ringkasan, & Tabel Rekapitulasi Status)
    - Sheet 2: GIT Monitoring (Data Tabular Detail Lengkap dengan Kolom Aging)
    """
    wb = openpyxl.Workbook()

    # =========================================================================
    # SHEET 1: Summary GIT (Format Visual Eksekutif Ala WO Readiness)
    # =========================================================================
    ws_sum = wb.active
    ws_sum.title = "Summary GIT"
    ws_sum.views.sheetView[0].showGridLines = True

    navy_dark = "1E3A8A"
    blue_header = "2563EB"
    blue_light = "EFF6FF"
    green_card = "059669"
    green_light = "ECFDF5"
    red_card = "DC2626"
    red_light = "FEF2F2"
    amber_card = "D97706"
    amber_light = "FEF3C7"
    gray_border = "CBD5E1"
    gray_total = "E2E8F0"

    font_title = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    font_sub = Font(name="Segoe UI", size=9, italic=True, color="E0E7FF")
    font_sec = Font(name="Segoe UI", size=11, bold=True, color=navy_dark)
    font_kpi_lbl = Font(name="Segoe UI", size=9, color="4B5563")
    font_tbl_hdr = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    font_tbl_body = Font(name="Segoe UI", size=9.5)
    font_tbl_total = Font(name="Segoe UI", size=9.5, bold=True, color="1F2937")

    fill_banner = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_tbl_hdr = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    fill_total = PatternFill(start_color=gray_total, end_color=gray_total, fill_type="solid")

    thin_border = Border(
        left=Side(style="thin", color=gray_border),
        right=Side(style="thin", color=gray_border),
        top=Side(style="thin", color=gray_border),
        bottom=Side(style="thin", color=gray_border)
    )

    total_all = cnt_gr + cnt_br + cnt_ckb
    pct_gr = (cnt_gr / total_all * 100) if total_all > 0 else 0
    pct_br = (cnt_br / total_all * 100) if total_all > 0 else 0
    pct_ckb = (cnt_ckb / total_all * 100) if total_all > 0 else 0

    # 1. Header Banner (B2:G3)
    ws_sum.merge_cells("B2:G2")
    ws_sum["B2"] = "MONITORING GOODS IN TRANSIT (GIT) - PLANT 1346"
    ws_sum["B2"].font = font_title
    ws_sum["B2"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    ws_sum.merge_cells("B3:G3")
    ws_sum["B3"] = f"Generated: {time.strftime('%d-%b-%Y %H:%M:%S')}  |  Plant: 1346  |  Total Dokumen GIT: {total_all:,} items  |  Resi Unik CKB: {total_br_unique:,}"
    ws_sum["B3"].font = font_sub
    ws_sum["B3"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

    for r in range(2, 4):
        ws_sum.row_dimensions[r].height = 25 if r == 2 else 20
        for c in range(2, 8):  # Kolom B (2) s/d G (7)
            ws_sum.cell(row=r, column=c).fill = fill_banner

    # 2. 3 Kartu KPI Ringkasan Status (Baris 5-7)
    # Card 1: NEED GR SEGERA (B5:C7)
    ws_sum.merge_cells("B5:C5")
    ws_sum["B5"] = "🔴 NEED GR SEGERA"
    ws_sum["B5"].font = Font(name="Segoe UI", size=9.5, bold=True, color=red_card)
    ws_sum["B5"].alignment = Alignment(horizontal="center", vertical="center")
    ws_sum["B6"] = "Total Items:"
    ws_sum["B6"].font = font_kpi_lbl
    ws_sum["B6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum["C6"] = f"{cnt_gr:,} items"
    ws_sum["C6"].font = Font(name="Segoe UI", size=12, bold=True, color=red_card)
    ws_sum["C6"].alignment = Alignment(horizontal="right", vertical="center")
    ws_sum["B7"] = "Persentase:"
    ws_sum["B7"].font = font_kpi_lbl
    ws_sum["B7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum["C7"] = f"{pct_gr:.1f}%"
    ws_sum["C7"].font = Font(name="Segoe UI", size=13, bold=True, color=red_card)
    ws_sum["C7"].alignment = Alignment(horizontal="right", vertical="center")
    fill_card_red = PatternFill(start_color=red_light, end_color=red_light, fill_type="solid")
    for r in range(5, 8):
        for c in (2, 3):
            ws_sum.cell(row=r, column=c).fill = fill_card_red
            ws_sum.cell(row=r, column=c).border = thin_border

    # Card 2: FOLLOW UP BRANCH (D5:E7)
    ws_sum.merge_cells("D5:E5")
    ws_sum["D5"] = "🟡 FOLLOW UP BRANCH"
    ws_sum["D5"].font = Font(name="Segoe UI", size=9.5, bold=True, color=amber_card)
    ws_sum["D5"].alignment = Alignment(horizontal="center", vertical="center")
    ws_sum["D6"] = "Total Items:"
    ws_sum["D6"].font = font_kpi_lbl
    ws_sum["D6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum["E6"] = f"{cnt_br:,} items"
    ws_sum["E6"].font = Font(name="Segoe UI", size=12, bold=True, color=amber_card)
    ws_sum["E6"].alignment = Alignment(horizontal="right", vertical="center")
    ws_sum["D7"] = "Persentase:"
    ws_sum["D7"].font = font_kpi_lbl
    ws_sum["D7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum["E7"] = f"{pct_br:.1f}%"
    ws_sum["E7"].font = Font(name="Segoe UI", size=13, bold=True, color=amber_card)
    ws_sum["E7"].alignment = Alignment(horizontal="right", vertical="center")
    fill_card_amber = PatternFill(start_color=amber_light, end_color=amber_light, fill_type="solid")
    for r in range(5, 8):
        for c in (4, 5):
            ws_sum.cell(row=r, column=c).fill = fill_card_amber
            ws_sum.cell(row=r, column=c).border = thin_border

    # Card 3: FOLLOW UP CKB (F5:G7)
    ws_sum.merge_cells("F5:G5")
    ws_sum["F5"] = "🔵 FOLLOW UP CKB"
    ws_sum["F5"].font = Font(name="Segoe UI", size=9.5, bold=True, color="1E40AF")
    ws_sum["F5"].alignment = Alignment(horizontal="center", vertical="center")
    ws_sum["F6"] = "Total Items:"
    ws_sum["F6"].font = font_kpi_lbl
    ws_sum["F6"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum["G6"] = f"{cnt_ckb:,} items"
    ws_sum["G6"].font = Font(name="Segoe UI", size=12, bold=True, color="1E40AF")
    ws_sum["G6"].alignment = Alignment(horizontal="right", vertical="center")
    ws_sum["F7"] = "Persentase:"
    ws_sum["F7"].font = font_kpi_lbl
    ws_sum["F7"].alignment = Alignment(horizontal="left", vertical="center", indent=1)
    ws_sum["G7"] = f"{pct_ckb:.1f}%"
    ws_sum["G7"].font = Font(name="Segoe UI", size=13, bold=True, color="1E40AF")
    ws_sum["G7"].alignment = Alignment(horizontal="right", vertical="center")
    fill_card_blue = PatternFill(start_color=blue_light, end_color=blue_light, fill_type="solid")
    for r in range(5, 8):
        for c in (6, 7):
            ws_sum.cell(row=r, column=c).fill = fill_card_blue
            ws_sum.cell(row=r, column=c).border = thin_border

    for r in (5, 6, 7):
        ws_sum.row_dimensions[r].height = 20

    # 3. Section Title & Tabel Ringkasan Tindakan (Baris 9 s/d 14)
    ws_sum.merge_cells("B9:G9")
    ws_sum["B9"] = "📊 RINGKASAN STATUS & REKOMENDASI TINDAKAN:"
    ws_sum["B9"].font = font_sec
    ws_sum.row_dimensions[9].height = 24

    ws_sum["B10"] = "Kategori Status"
    ws_sum["C10"] = "Jumlah Item"
    ws_sum["D10"] = "Persentase"
    ws_sum.merge_cells("E10:G10")
    ws_sum["E10"] = "Keterangan & Rekomendasi Tindakan"
    ws_sum.row_dimensions[10].height = 24

    for col_idx in (2, 3, 4, 5, 6, 7):
        c = ws_sum.cell(row=10, column=col_idx)
        c.font = font_tbl_hdr
        c.fill = fill_tbl_hdr
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = thin_border

    table_rows = [
        ("🔴 Need GR Segera", cnt_gr, f"{pct_gr:.1f}%", "Fisik barang telah tiba di site (Delivered / Handover). Segera lakukan GR di SAP!", fill_card_red, Font(name="Segoe UI", size=9.5, bold=True, color=red_card)),
        ("🟡 Follow Up Cabang Pengirim", cnt_br, f"{pct_br:.1f}%", "Belum memiliki nomor resi pengiriman. Follow up cabang pembuat STO.", fill_card_amber, Font(name="Segoe UI", size=9.5, bold=True, color=amber_card)),
        ("🔵 Follow Up Ekspedisi CKB", cnt_ckb, f"{pct_ckb:.1f}%", "Nomor resi terbit, pengiriman aktif dalam perjalanan (transit) CKB Logistics.", fill_card_blue, Font(name="Segoe UI", size=9.5, bold=True, color="1E40AF")),
        ("Total Seluruh Dokumen GIT", total_all, "100.0%", "Total keseluruhan baris dokumen PO / STO Good In Transit.", fill_total, font_tbl_total),
    ]

    for idx_t, (cat, cnt_val, pct_val, desc_val, row_fill, row_font) in enumerate(table_rows, start=11):
        ws_sum.row_dimensions[idx_t].height = 22
        ws_sum[f"B{idx_t}"] = cat
        ws_sum[f"B{idx_t}"].font = row_font
        ws_sum[f"B{idx_t}"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

        ws_sum[f"C{idx_t}"] = cnt_val
        ws_sum[f"C{idx_t}"].font = row_font
        ws_sum[f"C{idx_t}"].alignment = Alignment(horizontal="right", vertical="center")

        ws_sum[f"D{idx_t}"] = pct_val
        ws_sum[f"D{idx_t}"].font = row_font
        ws_sum[f"D{idx_t}"].alignment = Alignment(horizontal="center", vertical="center")

        ws_sum.merge_cells(f"E{idx_t}:G{idx_t}")
        ws_sum[f"E{idx_t}"] = desc_val
        ws_sum[f"E{idx_t}"].font = row_font if idx_t == 14 else Font(name="Segoe UI", size=9)
        ws_sum[f"E{idx_t}"].alignment = Alignment(horizontal="left", vertical="center", indent=1)

        for col_c in range(2, 8):
            cell_t = ws_sum.cell(row=idx_t, column=col_c)
            cell_t.border = thin_border
            if row_fill and (col_c in (2, 3) or idx_t == 14):
                cell_t.fill = row_fill

    ws_sum.column_dimensions["A"].width = 3
    ws_sum.column_dimensions["B"].width = 28
    ws_sum.column_dimensions["C"].width = 16
    ws_sum.column_dimensions["D"].width = 15
    ws_sum.column_dimensions["E"].width = 20
    ws_sum.column_dimensions["F"].width = 20
    ws_sum.column_dimensions["G"].width = 30

    # =========================================================================
    # SHEET 2: GIT Monitoring (Data Tabular Detail Lengkap dengan Kolom Aging)
    # =========================================================================
    ws = wb.create_sheet(title="GIT Monitoring")
    ws.views.sheetView[0].showGridLines = True

    # Header Tabular
    header_font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")  # Dark Slate

    # Action Status Fills & Fonts
    red_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    red_font = Font(name="Segoe UI", size=9.5, bold=True, color="991B1B")

    yellow_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    yellow_font = Font(name="Segoe UI", size=9.5, bold=True, color="92400E")

    blue_fill = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")
    blue_font = Font(name="Segoe UI", size=9.5, bold=True, color="1E40AF")

    data_font = Font(name="Segoe UI", size=9.5)
    data_align = Alignment(vertical="center")

    # Baris 1: Table Headers
    start_row = 1
    cols = list(df.columns)
    # Hapus kolom Prioritas dari tampilan jika hanya untuk styling
    if "Prioritas" in cols:
        cols.remove("Prioritas")

    for col_idx, col_name in enumerate(cols, start=1):
        cell = ws.cell(row=start_row, column=col_idx, value=str(col_name))
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border

    ws.row_dimensions[start_row].height = 26

    # Tulis Data Rows
    act_col_idx = cols.index("Rekomendasi Tindakan") + 1 if "Rekomendasi Tindakan" in cols else None
    aging_col_idx = cols.index("Aging (Hari)") + 1 if "Aging (Hari)" in cols else None

    for r_idx, (_, row) in enumerate(df.iterrows(), start=start_row + 1):
        ws.row_dimensions[r_idx].height = 20
        act_val = str(row.get("Rekomendasi Tindakan", ""))
        prio_val = str(row.get("Prioritas", ""))
        aging_val = str(row.get("Aging (Hari)", "-"))

        for c_idx, col_name in enumerate(cols, start=1):
            val = row[col_name]
            cell = ws.cell(row=r_idx, column=c_idx, value=val if pd.notna(val) else "-")
            cell.font = data_font
            cell.alignment = data_align
            cell.border = thin_border

            # Highlight khusus pada kolom Rekomendasi Tindakan
            if c_idx == act_col_idx:
                if prio_val == "RED":
                    cell.fill = red_fill
                    cell.font = red_font
                elif prio_val == "YELLOW":
                    cell.fill = yellow_fill
                    cell.font = yellow_font
                elif prio_val == "BLUE":
                    cell.fill = blue_fill
                    cell.font = blue_font

            # Format kolom Aging (Hari)
            if c_idx == aging_col_idx:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                if prio_val == "RED" and aging_val != "-" and aging_val != "0 Hari":
                    cell.fill = red_fill
                    cell.font = red_font

    # Auto-fit lebar kolom
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            v_str = str(cell.value or "")
            if len(v_str) > max_len:
                max_len = len(v_str)
        ws.column_dimensions[col_letter].width = min(max(max_len + 3, 11), 45)

    ws.freeze_panes = "A2"

    wb.save(file_path)

