"""
Module: turnover_helper.py
Khusus pengolahan dan analisa Turn Over Parts (Inventory Turnover Analysis).
Fitur:
1. Mode File Excel: Membaca histori inventory (Parts SOH, GIT, GINI, Core PX) dan data TO/COGS.
   - Menghitung Total Inventory per bulan
   - Rolling Average Stock 6 Bulan & 12 Bulan
   - Turn Over (TO) bergulir: Total COGS 12 Bulan / Rata-rata Stock 6 Bulan
   - Months of Supply (MOS = 12 / TO) & Days on Hand (DOH = 365 / TO)
   - Evaluasi Gap vs Target Budget & Rekomendasi Level Stok Maksimal
   - Export Laporan Eksekutif Excel (.xlsx) dengan visualisasi & formatting profesional.
2. Mode Kalkulasi Cepat / Manual:
   - Input langsung Total COGS 12 Bulan dan Stock 6 Bulan (bisa langsung angka rata-rata atau rincian 6 bulan)
   - Hasil instan dengan analisa status (Optimal / Lean, Mendekati Target, Overstock)
"""
import os
import re
import time
from datetime import datetime
import pandas as pd
import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import config
from modules import turnover_db


def find_matching_inventory_history_file(reference_dir=None):
    """
    Mencari file histori inventory (seperti 'Parts Inventory History.xlsx')
    secara otomatis di Desktop, Downloads, atau reference_dir.
    """
    search_dirs = []
    if reference_dir and os.path.exists(reference_dir):
        search_dirs.append(reference_dir)

    desktop_paths = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        r"C:\Users\yusril.i.wafir\Desktop"
    ]
    download_paths = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"C:\Users\yusril.i.wafir\Downloads"
    ]

    for p in desktop_paths + download_paths:
        if os.path.exists(p) and p not in search_dirs:
            search_dirs.append(p)

    candidates = []
    for d in search_dirs:
        try:
            for fname in os.listdir(d):
                if fname.startswith("~$") or "report" in fname.lower() or "summary" in fname.lower():
                    continue
                lower = fname.lower()
                if lower.endswith((".xlsx", ".xlsb", ".xls")):
                    score = 0
                    if "parts inventory history" in lower:
                        score = 50
                    elif "inventory history" in lower:
                        score = 40
                    elif "parts inventory" in lower:
                        score = 30
                    elif "inventory" in lower and "posture" not in lower:
                        score = 15

                    if score > 0:
                        full_path = os.path.join(d, fname)
                        candidates.append((score, os.path.getmtime(full_path), full_path))
        except Exception:
            pass

    if candidates:
        candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return candidates[0][2]
    return ""


def find_matching_cogs_file(reference_dir=None):
    """
    Mencari file Data COGS (seperti 'COGS.xlsx' atau 'Data COGS.xlsx')
    secara otomatis di Desktop, Downloads, atau reference_dir.
    """
    search_dirs = []
    if reference_dir and os.path.exists(reference_dir):
        search_dirs.append(reference_dir)

    desktop_paths = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        r"C:\Users\yusril.i.wafir\Desktop"
    ]
    download_paths = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"C:\Users\yusril.i.wafir\Downloads"
    ]

    for p in desktop_paths + download_paths:
        if os.path.exists(p) and p not in search_dirs:
            search_dirs.append(p)

    candidates = []
    for d in search_dirs:
        try:
            for fname in os.listdir(d):
                if fname.startswith("~$") or "report" in fname.lower() or "summary" in fname.lower():
                    continue
                lower = fname.lower()
                if lower.endswith((".xlsx", ".xlsb", ".xls")):
                    score = 0
                    if lower == "cogs.xlsx" or lower.startswith("cogs.") or lower.startswith("cogs "):
                        score = 80
                    elif "cogs" in lower:
                        score = 60
                    elif "hpp" in lower or "cost" in lower:
                        score = 30

                    if score > 0:
                        full_path = os.path.join(d, fname)
                        candidates.append((score, os.path.getmtime(full_path), full_path))
        except Exception:
            pass

    if candidates:
        candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return candidates[0][2]
    return ""


def find_matching_to_file(reference_dir=None):
    """
    Mencari file Data TO atau Target Budget (seperti 'Data TO.xlsx')
    secara otomatis di Desktop, Downloads, atau reference_dir.
    """
    search_dirs = []
    if reference_dir and os.path.exists(reference_dir):
        search_dirs.append(reference_dir)

    desktop_paths = [
        r"D:\Users\yusril.i.wafir\Desktop",
        os.path.join(os.path.expanduser("~"), "Desktop"),
        r"C:\Users\yusril.i.wafir\Desktop"
    ]
    download_paths = [
        r"D:\Users\yusril.i.wafir\Downloads",
        os.path.join(os.path.expanduser("~"), "Downloads"),
        r"C:\Users\yusril.i.wafir\Downloads"
    ]

    for p in desktop_paths + download_paths:
        if os.path.exists(p) and p not in search_dirs:
            search_dirs.append(p)

    candidates = []
    for d in search_dirs:
        try:
            for fname in os.listdir(d):
                if fname.startswith("~$") or "report" in fname.lower() or "summary" in fname.lower():
                    continue
                lower = fname.lower()
                if lower.endswith((".xlsx", ".xlsb", ".xls")):
                    score = 0
                    if "data to" in lower:
                        score = 70
                    elif "to parts" in lower or "parts to" in lower:
                        score = 50
                    elif "budget to" in lower or "target to" in lower:
                        score = 45
                    elif "turnover" in lower or "turn over" in lower:
                        score = 40
                    elif lower.startswith("to ") or " to." in lower:
                        score = 30

                    if score > 0:
                        full_path = os.path.join(d, fname)
                        candidates.append((score, os.path.getmtime(full_path), full_path))
        except Exception:
            pass

    if candidates:
        candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return candidates[0][2]
    return ""


def find_matching_to_cogs_file(reference_dir=None):
    """
    Mencari file Data TO atau COGS secara otomatis (kompatibilitas).
    Prioritaskan file COGS jika ada, jika tidak cari Data TO.
    """
    cogs_f = find_matching_cogs_file(reference_dir)
    if cogs_f:
        return cogs_f
    return find_matching_to_file(reference_dir)


def parse_date_flexibly(val):
    """Mengonversi nilai teks atau tanggal menjadi objek datetime secara fleksibel"""
    if pd.isna(val) or val is None:
        return None
    if isinstance(val, (datetime, pd.Timestamp)):
        return pd.to_datetime(val)
    val_str = str(val).strip()
    for fmt in [
        "%b %Y", "%B %Y", "%b-%y", "%b-%Y", "%B-%Y",
        "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%Y%m", "%m-%Y", "%Y-%m"
    ]:
        try:
            return pd.to_datetime(datetime.strptime(val_str, fmt))
        except Exception:
            pass
    try:
        return pd.to_datetime(val_str, errors='coerce')
    except Exception:
        return None


def calculate_manual_turnover(total_cogs_12m, stock_input, budget_to=None):
    """
    Menghitung Turnover Parts secara instan dari input manual:
    - total_cogs_12m: Total COGS 12 Bulan (float)
    - stock_input: float (langsung rata-rata) atau list of float (6 nilai bulanan)
    - budget_to: float target Budget TO (opsional, default 3.00 jika kosong)

    Rumus:
      Avg Stock 6 Bulan = Mean(stock_input)
      Actual TO = Total COGS 12 Bulan / Avg Stock 6 Bulan
      MOS (Months of Supply) = 12 / Actual TO
      DOH (Days on Hand) = 365 / Actual TO
      Suggest Stok Ideal = Total COGS 12 Bulan / Budget TO
      Suggest Stok Minimal = (Total COGS 12 Bulan / 12) * 2.5 bulan (Safe Buffer)
    """
    total_cogs = float(total_cogs_12m or 0)

    if isinstance(stock_input, (list, tuple)):
        clean_vals = [float(v) for v in stock_input if v is not None and not pd.isna(v)]
        avg_stock_6m = float(np.mean(clean_vals)) if clean_vals else 0.0
        stock_list = clean_vals
    else:
        avg_stock_6m = float(stock_input or 0)
        stock_list = [avg_stock_6m]

    actual_to = (total_cogs / avg_stock_6m) if avg_stock_6m > 0 else 0.0
    mos = (12.0 / actual_to) if actual_to > 0 else 0.0
    doh = (365.0 / actual_to) if actual_to > 0 else 0.0

    b_to = float(budget_to) if (budget_to is not None and float(budget_to) > 0) else 3.00
    gap = actual_to - b_to
    sug_ideal = (total_cogs / b_to) if b_to > 0 else 0.0
    sug_min = (total_cogs / 12.0) * 2.5
    stock_var = avg_stock_6m - sug_ideal

    if avg_stock_6m > sug_ideal:
        st_code = "OVERSTOCK"
        st_label = "OVERSTOCK (Di Atas Target Budget)"
        st_color = "#DC2626"
        rec = (
            f"Turn Over {actual_to:.2f} berada di bawah target Budget {b_to:.2f} (Gap: {gap:.2f}). "
            f"Rata-rata stok saat ini ({avg_stock_6m:,.0f}) melampaui batas ideal ({sug_ideal:,.0f}). "
            f"Disarankan rasionalisasi stok atau penundaan PO sebesar ~{stock_var:,.0f} agar perputaran optimal."
        )
    elif avg_stock_6m >= sug_min:
        st_code = "HEALTHY"
        st_label = "OPTIMAL & SEHAT (Melampaui Target)"
        st_color = "#16A34A"
        rec = (
            f"Performa Turn Over Parts sangat baik ({actual_to:.2f} vs Budget {b_to:.2f}). "
            f"Tingkat stok berada di level LEAN & SEHAT ({avg_stock_6m:,.0f}), berada di antara batas minimum aman "
            f"({sug_min:,.0f}) dan batas ideal ({sug_ideal:,.0f}). "
            f"Stok saat ini sanggup menopang operasional selama ~{mos:.2f} bulan ({doh:.0f} hari)."
        )
    else:
        st_code = "POTENTIAL_STOCKOUT"
        st_label = "PERHATIAN (Di Bawah Buffer Minimal)"
        st_color = "#D97706"
        rec = (
            f"Turn Over tercatat tinggi ({actual_to:.2f}). Namun rata-rata stok ({avg_stock_6m:,.0f}) berada di bawah "
            f"ambang batas minimal buffer 2.5 bulan ({sug_min:,.0f}). "
            f"Segera review kebutuhan critical spare parts untuk mencegah risiko kehabisan stok."
        )

    return {
        "cogs_12m": total_cogs,
        "avg_stock_6m": avg_stock_6m,
        "stock_list": stock_list,
        "actual_to": round(actual_to, 2),
        "actual_to_raw": actual_to,
        "mos": round(mos, 2),
        "doh": round(doh, 1),
        "budget_to": round(b_to, 2),
        "gap_to": round(gap, 2),
        "target_stock_max": sug_ideal,
        "suggest_stock_ideal": sug_ideal,
        "suggest_stock_min": sug_min,
        "stock_variance": stock_var,
        "status_code": st_code,
        "status_label": st_label,
        "status_badge_color": st_color,
        "recommendation": rec
    }


def process_turnover_excel(
    inventory_file_path=None,
    cogs_file_path=None,
    manual_cogs_12m=None,
    manual_budget_to=None,
    target_month=None,
    output_file_path=None,
    status_callback=None,
    **kwargs
):
    """
    Memproses histori inventory dan data COGS secara murni (pure formula) dari Database Internal
    atau dari file Excel yang diunggah.

    Formula Penentuan TO:
    - Total Inventory = Sum nilai inventory per bulan (SOH + GIT + GINI + Core PX)
    - Avg Stock 6M = Rolling 6 bulan rata-rata Total Inventory
    - COGS 12M = Akumulasi 12 bulan pengeluaran COGS (atau annualized rata-rata jika < 12 bulan)
    - Actual TO = COGS 12M / Avg Stock 6M
    - Months of Supply (MOS) = 12 / Actual TO
    - Days on Hand (DOH) = 365 / Actual TO
    - Suggest Stok Ideal = COGS 12M / Budget TO
    - Suggest Stok Minimal = (COGS 12M / 12) * 2.5 bulan (Safe Buffer)
    """
    def log(msg):
        try:
            print(msg)
        except Exception:
            try:
                print(str(msg).encode('ascii', errors='replace').decode('ascii'))
            except Exception:
                pass
        if status_callback:
            status_callback(msg)

    # -------------------------------------------------------------------------
    # 1. BACA HISTORI INVENTORY (DARI DATABASE INTERNAL ATAU FILE EXCEL)
    # -------------------------------------------------------------------------
    if not inventory_file_path:
        log("📖 Membaca data histori Inventory & COGS langsung dari Database Internal...")
        monthly_df = turnover_db.get_inventory_dataframe()
        if monthly_df.empty:
            raise ValueError("Database Inventory masih kosong. Silakan tambahkan data melalui menu Kelola Database.")
        categories_found = ["Parts SOH", "Parts GIT", "Parts GINI", "Core PX"]
        categories_found = [c for c in categories_found if c in monthly_df.columns]
    else:
        if not os.path.exists(inventory_file_path):
            raise FileNotFoundError(f"File histori inventory tidak ditemukan: {inventory_file_path}")

        inv_dir = os.path.dirname(inventory_file_path)

        # Auto-discover file COGS jika belum ditentukan
        if not cogs_file_path:
            # Cek jika ada di kwargs untuk kompatibilitas
            if kwargs.get('to_cogs_file_path') and os.path.exists(kwargs['to_cogs_file_path']):
                cogs_file_path = kwargs['to_cogs_file_path']
            else:
                cand_cogs = find_matching_cogs_file(inv_dir)
                if cand_cogs and os.path.exists(cand_cogs):
                    cogs_file_path = cand_cogs
                    log(f"🔍 Terdeteksi file COGS otomatis: {os.path.basename(cogs_file_path)}")

        log("📖 Membaca file Histori Inventory...")
        df_inv = pd.read_excel(inventory_file_path)

        col_month = None
        col_cat = None
        col_val = None

        for col in df_inv.columns:
            c_low = str(col).lower()
            if any(k in c_low for k in ["month", "bulan", "date", "periode"]):
                col_month = col
            elif any(k in c_low for k in ["cat", "tipe", "jenis", "group", "kategori"]):
                col_cat = col
            elif any(k in c_low for k in ["inv", "stock", "stok", "nilai", "value"]):
                col_val = col

        if not col_month or not col_val:
            raise ValueError("Format file inventory tidak valid. Kolom 'Month - Year' dan 'Inventory' wajib ada.")

        df_inv['Parsed_Date'] = df_inv[col_month].apply(parse_date_flexibly)
        df_inv['Month_Display'] = df_inv['Parsed_Date'].dt.strftime('%b %Y')
        df_inv['Month_Display'] = df_inv['Month_Display'].fillna(df_inv[col_month].astype(str))
        df_inv[col_val] = pd.to_numeric(df_inv[col_val], errors='coerce').fillna(0.0)

        # Pivot kategori jika ada (SOH, GIT, GINI, Core PX)
        categories_found = []
        if col_cat and col_cat in df_inv.columns:
            categories_found = [str(c) for c in df_inv[col_cat].dropna().unique().tolist()]
            cat_piv = df_inv.pivot_table(
                index=['Parsed_Date', 'Month_Display'],
                columns=col_cat,
                values=col_val,
                aggfunc='sum',
                fill_value=0.0
            ).reset_index()
        else:
            cat_piv = None

        # Total Inventory bulanan
        monthly_inv = df_inv.groupby(['Parsed_Date', 'Month_Display'])[col_val].sum().reset_index()
        monthly_inv.rename(columns={col_val: 'Total_Inventory'}, inplace=True)

        # Upsert inventory ke database internal
        try:
            turnover_db.upsert_inventory_dataframe(
                df_inv,
                date_col='Parsed_Date',
                cat_col=col_cat if col_cat else 'Category',
                val_col=col_val
            )
        except Exception as e:
            log(f"⚠️ Warning upsert inventory DB: {e}")

        if cat_piv is not None:
            monthly_df = pd.merge(monthly_inv, cat_piv, on=['Parsed_Date', 'Month_Display'], how='left')
        else:
            monthly_df = monthly_inv.copy()

    monthly_df = monthly_df.sort_values('Parsed_Date').reset_index(drop=True)
    monthly_df['Avg_Stock_6M'] = monthly_df['Total_Inventory'].rolling(window=6, min_periods=1).mean()
    monthly_df['Avg_Stock_12M'] = monthly_df['Total_Inventory'].rolling(window=12, min_periods=1).mean()

    # Siapkan kolom kalkulasi
    monthly_df['Actual_TO'] = np.nan
    monthly_df['COGS_Monthly'] = np.nan
    monthly_df['COGS_12M'] = np.nan

    # Target Budget TO (default 3.00 jika tidak diisi user)
    target_budget = float(manual_budget_to) if (manual_budget_to is not None and float(manual_budget_to) > 0) else 3.00
    monthly_df['Budget_TO'] = target_budget

    # -------------------------------------------------------------------------
    # 2. BACA FILE DATA COGS & UPSERT KE DATABASE INTERNAL
    # -------------------------------------------------------------------------
    if cogs_file_path and os.path.exists(cogs_file_path):
        log(f"📖 Membaca data pengeluaran COGS dari: {os.path.basename(cogs_file_path)}")
        try:
            df_c = pd.read_excel(cogs_file_path)
            c_m_col = None
            c_val_col = None

            for c in df_c.columns:
                cl = str(c).lower()
                if any(k in cl for k in ["month", "bulan", "date", "periode", "year"]):
                    c_m_col = c
                elif any(k in cl for k in ["cogs", "hpp", "cost", "nilai"]):
                    c_val_col = c

            if c_m_col and c_val_col:
                df_c['Parsed_Date'] = df_c[c_m_col].apply(parse_date_flexibly)
                df_c['Month_Display'] = df_c['Parsed_Date'].dt.strftime('%b %Y')
                df_c['Month_Display'] = df_c['Month_Display'].fillna(df_c[c_m_col].astype(str))
                df_c['COGS_Raw'] = pd.to_numeric(df_c[c_val_col], errors='coerce')

                # Upsert ke database internal persisten
                turnover_db.upsert_cogs_dataframe(df_c, date_col='Parsed_Date', val_col='COGS_Raw')
        except Exception as e:
            log(f"⚠️ Gagal membaca/upsert file COGS: {e}")

    # -------------------------------------------------------------------------
    # 2.5 MUAT COGS 12 BULAN & TARGET BUDGET DARI DATABASE INTERNAL
    # -------------------------------------------------------------------------
    cogs_series = turnover_db.get_cogs_series()
    budget_map = turnover_db.get_budget_map()

    # Target Budget TO dinamis dari DB jika tidak diinput manual
    if manual_budget_to is None:
        monthly_df['Budget_TO'] = monthly_df['Month_Display'].map(budget_map).fillna(target_budget)

    log("💡 Menghitung Total COGS 12 Bulan bergulir (pure formula database)...")
    for i in range(len(monthly_df)):
        r_date = monthly_df.loc[i, 'Parsed_Date']
        if pd.notna(r_date):
            if r_date in cogs_series.index:
                monthly_df.loc[i, 'COGS_Monthly'] = cogs_series.loc[r_date]
            cogs_win = cogs_series[cogs_series.index <= r_date]
            if len(cogs_win) >= 12:
                monthly_df.loc[i, 'COGS_12M'] = cogs_win.iloc[-12:].sum()
            elif len(cogs_win) > 0:
                monthly_df.loc[i, 'COGS_12M'] = cogs_win.mean() * 12.0

    # -------------------------------------------------------------------------
    # 3. OVERRIDE MANUAL (JIKA USER MEMASUKKAN COGS MANUAL)
    # -------------------------------------------------------------------------
    if manual_cogs_12m is not None and float(manual_cogs_12m) > 0:
        cogs_val = float(manual_cogs_12m)
        monthly_df['COGS_12M'] = monthly_df['COGS_12M'].fillna(cogs_val)
        if target_month and str(target_month).strip().lower() not in ["", "none", "auto", "terbaru", "bulan terakhir (auto)"]:
            t_clean = str(target_month).strip().lower()
            m_mask = monthly_df['Month_Display'].astype(str).str.lower().str.contains(t_clean)
            if m_mask.any():
                monthly_df.loc[m_mask, 'COGS_12M'] = cogs_val
            else:
                monthly_df.iloc[-1, monthly_df.columns.get_loc('COGS_12M')] = cogs_val
        else:
            monthly_df.iloc[-1, monthly_df.columns.get_loc('COGS_12M')] = cogs_val

    # -------------------------------------------------------------------------
    # 4. HITUNG TO RM12, MOS RM12, DOH, SUGGEST IDEAL & MINIMAL
    # -------------------------------------------------------------------------
    # TO RM12 Bulan (Rolling 12M): COGS_12M / Avg_Stock_6M
    mask_calc = monthly_df['COGS_12M'].notna() & (monthly_df['Avg_Stock_6M'] > 0)
    monthly_df.loc[mask_calc, 'Actual_TO'] = monthly_df.loc[mask_calc, 'COGS_12M'] / monthly_df.loc[mask_calc, 'Avg_Stock_6M']
    monthly_df['TO_RM12'] = monthly_df['Actual_TO']

    # MOS RM12 Bulan: 12 / TO_RM12
    monthly_df['MOS_Months'] = np.where(monthly_df['Actual_TO'] > 0, 12.0 / monthly_df['Actual_TO'], np.nan)
    monthly_df['MOS_RM12'] = monthly_df['MOS_Months']
    monthly_df['DOH_Days'] = np.where(monthly_df['Actual_TO'] > 0, 365.0 / monthly_df['Actual_TO'], np.nan)
    monthly_df['Gap_TO'] = monthly_df['Actual_TO'] - monthly_df['Budget_TO']

    # Suggest Inventory Ideal & Minimal (Safe Buffer 2.5 Bulan)
    monthly_df['Suggest_Stock_Ideal'] = np.where(
        (monthly_df['Budget_TO'] > 0) & (monthly_df['COGS_12M'] > 0),
        monthly_df['COGS_12M'] / monthly_df['Budget_TO'],
        np.nan
    )
    monthly_df['Suggest_Stock_Min'] = np.where(
        monthly_df['COGS_12M'] > 0,
        (monthly_df['COGS_12M'] / 12.0) * 2.5,
        np.nan
    )
    monthly_df['Target_Stock_Max'] = monthly_df['Suggest_Stock_Ideal']
    monthly_df['Stock_Variance'] = monthly_df['Total_Inventory'] - monthly_df['Suggest_Stock_Ideal']

    # Ambil baris data bulan target (atau bulan terbaru yang memiliki angka Actual TO atau COGS)
    if target_month and str(target_month).strip().lower() not in ["", "none", "auto", "terbaru", "bulan terakhir (auto)"]:
        t_clean = str(target_month).strip().lower()
        match_rows = monthly_df[monthly_df['Month_Display'].astype(str).str.lower().str.contains(t_clean)]
        if not match_rows.empty:
            latest_row = match_rows.iloc[-1]
            log(f"🎯 Memilih bulan target evaluasi: {latest_row['Month_Display']}")
        else:
            df_with_to = monthly_df[monthly_df['Actual_TO'].notna()]
            latest_row = df_with_to.iloc[-1] if not df_with_to.empty else monthly_df.iloc[-1]
    else:
        df_with_to = monthly_df[monthly_df['Actual_TO'].notna()]
        if not df_with_to.empty:
            latest_row = df_with_to.iloc[-1]
        else:
            latest_row = monthly_df.iloc[-1]

    act_to = float(latest_row['Actual_TO']) if pd.notna(latest_row['Actual_TO']) else 0.0
    bud_to = float(latest_row['Budget_TO']) if pd.notna(latest_row['Budget_TO']) else 0.0
    gap_to = float(latest_row['Gap_TO']) if pd.notna(latest_row['Gap_TO']) else 0.0
    mos = float(latest_row['MOS_Months']) if pd.notna(latest_row['MOS_Months']) else 0.0
    doh = float(latest_row['DOH_Days']) if pd.notna(latest_row['DOH_Days']) else 0.0
    tot_inv = float(latest_row['Total_Inventory'])
    avg_stock = float(latest_row['Avg_Stock_6M'])
    cogs_m = float(latest_row['COGS_Monthly']) if pd.notna(latest_row.get('COGS_Monthly')) else 0.0
    cogs_12m = float(latest_row['COGS_12M']) if pd.notna(latest_row['COGS_12M']) else 0.0
    sug_ideal = float(latest_row['Suggest_Stock_Ideal']) if pd.notna(latest_row['Suggest_Stock_Ideal']) else 0.0
    sug_min = float(latest_row['Suggest_Stock_Min']) if pd.notna(latest_row['Suggest_Stock_Min']) else 0.0
    variance = tot_inv - sug_ideal

    cat_breakdown = {}
    if categories_found:
        for c in categories_found:
            if c in latest_row:
                cat_breakdown[c] = float(latest_row[c]) if pd.notna(latest_row[c]) else 0.0

    if tot_inv > sug_ideal:
        st_code = "OVERSTOCK"
        st_label = "OVERSTOCK (Di Atas Target Budget)"
        st_color = "#DC2626"
        rec = (
            f"Turn Over RM12 {act_to:.2f} berada di bawah target Budget {bud_to:.2f} (Gap: {gap_to:.2f}). "
            f"Level stok saat ini (USD {tot_inv:,.0f}) melampaui batas ideal (USD {sug_ideal:,.0f}) sebesar USD {variance:,.0f}. "
            f"Disarankan menunda/merampingkan pengadaan suku cadang fast moving & slow moving sebesar ~USD {variance:,.0f} "
            f"agar stok kembali ke batas ideal USD {sug_ideal:,.0f}."
        )
    elif tot_inv >= sug_min:
        st_code = "HEALTHY"
        st_label = "OPTIMAL & SEHAT (Melampaui Target)"
        st_color = "#16A34A"
        rec = (
            f"Performa Turn Over Parts sangat baik ({act_to:.2f} vs Target Budget {bud_to:.2f}). "
            f"Tingkat stok berada di level LEAN & SEHAT (USD {tot_inv:,.0f}), berada di antara batas minimum aman "
            f"(USD {sug_min:,.0f}) dan batas ideal (USD {sug_ideal:,.0f}). "
            f"Stok saat ini sanggup menopang operasional selama ~{mos:.2f} bulan ({doh:.0f} hari)."
        )
    else:
        st_code = "POTENTIAL_STOCKOUT"
        st_label = "PERHATIAN (Di Bawah Buffer Minimal)"
        st_color = "#D97706"
        rec = (
            f"Turn Over tercatat tinggi ({act_to:.2f}). Namun level stok terkini (USD {tot_inv:,.0f}) berada di bawah "
            f"ambang batas minimal buffer aman 2.5 bulan (USD {sug_min:,.0f}). "
            f"Segera review kebutuhan critical spare parts untuk mencegah risiko kehabisan stok (stockout)."
        )

    latest_summary = {
        "currency": "USD",
        "latest_month": str(latest_row['Month_Display']),
        "total_inventory": tot_inv,
        "avg_stock_6m": avg_stock,
        "cogs_monthly": cogs_m,
        "cogs_12m": cogs_12m,
        "actual_to": round(act_to, 2),
        "to_rm12": round(act_to, 2),
        "budget_to": round(bud_to, 2),
        "gap_to": round(gap_to, 2),
        "mos": round(mos, 2),
        "mos_rm12": round(mos, 2),
        "doh": round(doh, 1),
        "target_stock_max": sug_ideal,
        "suggest_stock_ideal": sug_ideal,
        "suggest_stock_min": sug_min,
        "stock_variance": variance,
        "status_code": st_code,
        "status_label": st_label,
        "status_badge_color": st_color,
        "recommendation": rec,
        "categories_breakdown": cat_breakdown
    }

    # Tentukan output file path jika belum ada
    if not output_file_path:
        out_dir = config.get_output_dir("turnover")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_file_path = os.path.join(out_dir, f"Laporan_Turnover_Parts_{timestamp}.xlsx")

    log(f"💾 Menyusun Laporan Excel Profesional ke: {output_file_path}")
    _export_dataframe_to_excel(monthly_df, categories_found, latest_summary, output_file_path)

    available_months = [str(m) for m in monthly_df['Month_Display'].dropna().unique().tolist() if str(m) != "nan"]

    log("✅ Analisa Turn Over Parts selesai dengan sukses!")
    return {
        "summary": latest_summary,
        "df_monthly": monthly_df,
        "categories": categories_found,
        "available_months": available_months,
        "output_file": output_file_path
    }


def _export_dataframe_to_excel(monthly_df, categories_found, summary, output_path):
    """
    Menghasilkan file Excel multi-sheet terstruktur dengan formatting rapi (OpenPyXL).
    """
    wb = openpyxl.Workbook()
    # Sheet 1: Dashboard Turnover
    ws_dash = wb.active
    ws_dash.title = "Dashboard Turnover"
    ws_dash.views.sheetView[0].showGridLines = True

    # Styling Palette
    navy_dark = "1E3A8A"
    blue_accent = "2563EB"
    blue_soft = "EFF6FF"
    gray_border = "CBD5E1"
    font_family = "Segoe UI"

    font_title = Font(name=font_family, size=15, bold=True, color="1E293B")
    font_sub = Font(name=font_family, size=9, italic=True, color="64748B")
    font_card_num = Font(name=font_family, size=13, bold=True, color="1E3A8A")
    font_card_lbl = Font(name=font_family, size=8, bold=True, color="64748B")
    font_tbl_hdr = Font(name=font_family, size=9, bold=True, color="FFFFFF")
    font_tbl_data = Font(name=font_family, size=9)
    font_bold = Font(name=font_family, size=9, bold=True)

    fill_hdr = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
    fill_accent = PatternFill(start_color=blue_accent, end_color=blue_accent, fill_type="solid")
    fill_zebra = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    fill_card = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")

    thin_border = Border(
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border),
        top=Side(style='thin', color=gray_border),
        bottom=Side(style='thin', color=gray_border)
    )

    # Header Title
    ws_dash['A1'] = "KERMEN TOOLS - PARTS INVENTORY TURNOVER DASHBOARD"
    ws_dash['A1'].font = font_title
    ws_dash['A2'] = f"Generated: {time.strftime('%d-%b-%Y %H:%M:%S')} | Nominal dalam USD ($) | Rumus: Total COGS 12 Bulan / Rata-rata Total Stock 6 Bulan"
    ws_dash['A2'].font = font_sub

    # KPI Summary Cards (Row 4 to 6)
    kpis = [
        ("BULAN TERAKHIR", summary.get("latest_month", "-"), "@"),
        ("ACTUAL TO (RM12)", summary.get("actual_to", 0.0), "0.00"),
        ("BUDGET TO", summary.get("budget_to", 0.0), "0.00"),
        ("GAP TO (RM12)", summary.get("gap_to", 0.0), "+0.00;-0.00;0.00"),
        ("TOTAL STOCK (USD)", summary.get("total_inventory", 0.0), "$#,##0"),
        ("AVG STOCK 6M (USD)", summary.get("avg_stock_6m", 0.0), "$#,##0"),
        ("COGS BULANAN (USD)", summary.get("cogs_monthly", 0.0), "$#,##0"),
        ("TOTAL COGS 12M (USD)", summary.get("cogs_12m", 0.0), "$#,##0"),
        ("SUGGEST IDEAL (USD)", summary.get("suggest_stock_ideal", 0.0), "$#,##0"),
        ("SUGGEST MIN (USD)", summary.get("suggest_stock_min", 0.0), "$#,##0"),
        ("MOS RM12 (SUPPLY)", summary.get("mos", 0.0), "0.00 \"Bln\""),
    ]

    col_idx = 1
    for title, val, num_fmt in kpis:
        cell_lbl = ws_dash.cell(row=4, column=col_idx, value=title)
        cell_lbl.font = font_card_lbl
        cell_lbl.fill = fill_card
        cell_lbl.alignment = Alignment(horizontal="center", vertical="center")
        cell_lbl.border = thin_border

        cell_val = ws_dash.cell(row=5, column=col_idx, value=val)
        cell_val.font = font_card_num
        cell_val.fill = fill_card
        cell_val.alignment = Alignment(horizontal="center", vertical="center")
        cell_val.border = thin_border
        cell_val.number_format = num_fmt

        ws_dash.row_dimensions[4].height = 18
        ws_dash.row_dimensions[5].height = 28
        col_idx += 1

    # Table Header (Row 8)
    ws_dash['A7'] = "HISTORI TREN BULANAN INVENTORY TURNOVER (NOMINAL DALAM USD $)"
    ws_dash['A7'].font = Font(name=font_family, size=11, bold=True, color="1E3A8A")

    table_headers = [
        "Bulan - Tahun",
        "Total Inventory ($)",
        "Avg Stock 6M ($)",
        "COGS Bulanan ($)",
        "COGS 12M ($)",
        "TO RM12 Bulan",
        "Budget TO",
        "Gap TO (RM12)",
        "MOS RM12",
        "Suggest Stok Ideal ($)",
        "Suggest Stok Minimal ($)",
        "Status Evaluasi"
    ]

    for c_i, h_text in enumerate(table_headers, start=1):
        cell = ws_dash.cell(row=8, column=c_i, value=h_text)
        cell.font = font_tbl_hdr
        cell.fill = fill_hdr
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border

    ws_dash.row_dimensions[8].height = 26

    # Table Rows
    curr_row = 9
    for _, row in monthly_df.iterrows():
        is_zebra = (curr_row % 2 == 0)
        row_fill = fill_zebra if is_zebra else None

        act = row.get('Actual_TO')
        bud = row.get('Budget_TO')
        gap = row.get('Gap_TO')
        tot_i = row.get('Total_Inventory')
        s_ideal = row.get('Suggest_Stock_Ideal')
        s_min = row.get('Suggest_Stock_Min')

        status_text = "-"
        if pd.notna(act) and pd.notna(bud):
            if pd.notna(s_ideal) and pd.notna(s_min):
                if tot_i > s_ideal:
                    status_text = "Overstock"
                elif tot_i >= s_min:
                    status_text = "Optimal (Lean)"
                else:
                    status_text = "Di Bawah Min"
            else:
                status_text = "Optimal (Lean)" if act >= bud else "Overstock"

        row_data = [
            (row['Month_Display'], "@", "center"),
            (row['Total_Inventory'], "#,##0", "right"),
            (row['Avg_Stock_6M'], "#,##0", "right"),
            (row.get('COGS_Monthly'), "#,##0", "right"),
            (row['COGS_12M'], "#,##0", "right"),
            (act, "0.00", "center"),
            (bud, "0.00", "center"),
            (gap, "+0.00;-0.00;0.00", "center"),
            (row['MOS_Months'], "0.00", "center"),
            (s_ideal, "#,##0", "right"),
            (s_min, "#,##0", "right"),
            (status_text, "@", "center")
        ]

        for c_i, (val, fmt, align) in enumerate(row_data, start=1):
            cell = ws_dash.cell(row=curr_row, column=c_i, value=val if pd.notna(val) else "-")
            cell.font = font_tbl_data
            if row_fill:
                cell.fill = row_fill
            cell.alignment = Alignment(horizontal=align, vertical="center")
            cell.border = thin_border
            if fmt != "@" and pd.notna(val) and isinstance(val, (int, float)):
                cell.number_format = fmt

            # Highlight gap (kolom ke-8: Gap TO)
            if c_i == 8 and pd.notna(val) and isinstance(val, (int, float)):
                if val >= 0:
                    cell.font = Font(name=font_family, size=9, bold=True, color="16A34A")
                else:
                    cell.font = Font(name=font_family, size=9, bold=True, color="DC2626")

        ws_dash.row_dimensions[curr_row].height = 20
        curr_row += 1

    # Auto-adjust column widths Sheet 1
    for col in ws_dash.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws_dash.column_dimensions[col_letter].width = max(max_len + 3, 14)

    # Sheet 2: Inventory Breakdown (jika ada kategori)
    if categories_found:
        ws_cat = wb.create_sheet(title="Breakdown Kategori")
        ws_cat.views.sheetView[0].showGridLines = True

        ws_cat['A1'] = "RINCIAN INVENTORY PER KATEGORI (SOH, GIT, GINI, CORE PX)"
        ws_cat['A1'].font = font_title
        ws_cat['A2'] = "Data nilai stok bulanan per kategori penyusun Total Inventory"
        ws_cat['A2'].font = font_sub

        cat_headers = ["Bulan - Tahun"] + categories_found + ["Total Inventory"]
        for c_i, h in enumerate(cat_headers, start=1):
            cell = ws_cat.cell(row=4, column=c_i, value=h)
            cell.font = font_tbl_hdr
            cell.fill = fill_hdr
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border
        ws_cat.row_dimensions[4].height = 24

        r_cat = 5
        for _, row in monthly_df.iterrows():
            is_zebra = (r_cat % 2 == 0)
            row_fill = fill_zebra if is_zebra else None

            ws_cat.cell(row=r_cat, column=1, value=row['Month_Display']).alignment = Alignment(horizontal="center")
            col_k = 2
            for cat_name in categories_found:
                val = row.get(cat_name, 0.0)
                c_cell = ws_cat.cell(row=r_cat, column=col_k, value=val if pd.notna(val) else 0.0)
                c_cell.number_format = "#,##0"
                c_cell.alignment = Alignment(horizontal="right")
                c_cell.border = thin_border
                c_cell.font = font_tbl_data
                if row_fill:
                    c_cell.fill = row_fill
                col_k += 1

            tot_cell = ws_cat.cell(row=r_cat, column=col_k, value=row['Total_Inventory'])
            tot_cell.number_format = "#,##0"
            tot_cell.alignment = Alignment(horizontal="right")
            tot_cell.font = font_bold
            tot_cell.border = thin_border
            if row_fill:
                tot_cell.fill = row_fill

            ws_cat.row_dimensions[r_cat].height = 20
            r_cat += 1

        for col in ws_cat.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                val_str = str(cell.value or "")
                if len(val_str) > max_len:
                    max_len = len(val_str)
            ws_cat.column_dimensions[col_letter].width = max(max_len + 3, 16)

    # Simpan workbook
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)


def export_manual_turnover_to_excel(result, output_path=None):
    """
    Mengekspor ringkasan perhitungan manual Turnover ke file Excel.
    """
    if not output_path:
        out_dir = config.get_output_dir("turnover")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(out_dir, f"Ringkasan_Kalkulasi_Turnover_{timestamp}.xlsx")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Kalkulasi Turnover"
    ws.views.sheetView[0].showGridLines = True

    navy_dark = "1E3A8A"
    gray_border = "CBD5E1"
    font_family = "Segoe UI"

    ws['A1'] = "KERMEN TOOLS - RINGKASAN KALKULASI TURN OVER PARTS"
    ws['A1'].font = Font(name=font_family, size=14, bold=True, color="1E293B")
    ws['A2'] = f"Tanggal Kalkulasi: {time.strftime('%d-%b-%Y %H:%M:%S')}"
    ws['A2'].font = Font(name=font_family, size=9, italic=True, color="64748B")

    headers = ["Parameter Analisis", "Nilai / Hasil", "Satuan", "Keterangan"]
    for c_i, h in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=c_i, value=h)
        cell.font = Font(name=font_family, size=9, bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color=navy_dark, end_color=navy_dark, fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center")

    rows = [
        ("Total COGS 12 Bulan", result.get("cogs_12m", 0.0), "USD ($)", "$#,##0", "Total Cost of Goods Sold 12 Bulan Terakhir"),
        ("Rata-rata Stock 6 Bulan", result.get("avg_stock_6m", 0.0), "USD ($)", "$#,##0", "Penyebut Pembagi (Rata-rata Total Inventory 6 Bulan)"),
        ("Actual Turn Over (TO)", result.get("actual_to", 0.0), "Turns / Year", "0.00", "Hasil bagi Total COGS 12 Bulan / Avg Stock 6 Bulan"),
        ("Target Budget TO", result.get("budget_to", 3.00), "Turns / Year", "0.00", "Target manajerial Turn Over"),
        ("Gap vs Budget", result.get("gap_to", 0.0), "Turns", "+0.00;-0.00;0.00", "Selisih Actual TO terhadap Budget TO"),
        ("Months of Supply (MOS)", result.get("mos", 0.0), "Bulan", "0.00", "Estimasi lama stok bertahan (12 / Actual TO)"),
        ("Days on Hand (DOH)", result.get("doh", 0.0), "Hari", "#,##0", "Estimasi hari ketahanan stok (365 / Actual TO)"),
        ("Suggest Stok Ideal", result.get("suggest_stock_ideal", result.get("target_stock_max", 0.0)), "USD ($)", "$#,##0", "Level stok ideal sesuai target Budget TO"),
        ("Suggest Stok Minimal", result.get("suggest_stock_min", 0.0), "USD ($)", "$#,##0", "Batas minimum safe buffer 2.5 bulan operasional"),
        ("Status / Evaluasi", result.get("status_label", "-"), "Status", "@", "Kondisi kesehatan stok terkini"),
    ]

    curr_row = 5
    thin_border = Border(
        left=Side(style='thin', color=gray_border),
        right=Side(style='thin', color=gray_border),
        top=Side(style='thin', color=gray_border),
        bottom=Side(style='thin', color=gray_border)
    )

    for item in rows:
        title, val, unit, num_fmt, desc = item
        ws.cell(row=curr_row, column=1, value=title).font = Font(name=font_family, size=9, bold=True)
        c2 = ws.cell(row=curr_row, column=2, value=val)
        c2.font = Font(name=font_family, size=9)
        if num_fmt != "@" and isinstance(val, (int, float)):
            c2.number_format = num_fmt

        ws.cell(row=curr_row, column=3, value=unit).alignment = Alignment(horizontal="center")
        ws.cell(row=curr_row, column=4, value=desc)

        for col_k in range(1, 5):
            ws.cell(row=curr_row, column=col_k).border = thin_border
        curr_row += 1

    # Rekomendasi
    rec_row = curr_row + 1
    ws.cell(row=rec_row, column=1, value="Rekomendasi Manajerial:").font = Font(name=font_family, size=10, bold=True, color="1E3A8A")
    ws.cell(row=rec_row + 1, column=1, value=result.get("recommendation", "-")).font = Font(name=font_family, size=9, italic=True)

    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 18)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)
    return output_path


def extract_turnover_metrics_from_excel(filepath):
    """
    Mengekstrak ringkasan metrik Turn Over dari file Excel laporan (- Dashboard Turnover)
    untuk keperluan preview dialog email dan pembentukan laporan HTML.
    """
    if not filepath or not os.path.exists(filepath):
        return None

    try:
        wb = openpyxl.load_workbook(filepath, data_only=True, read_only=True)
        sheet_names = wb.sheetnames
        target_sheet = "Dashboard Turnover" if "Dashboard Turnover" in sheet_names else sheet_names[0]
        ws = wb[target_sheet]

        rows = [list(r) for r in ws.iter_rows(values_only=True)]
        wb.close()
    except Exception:
        return None

    if len(rows) < 6:
        return None

    # Parse KPI Cards baris 4 (label) dan baris 5 (nilai)
    card_labels = [str(c).strip().upper() if c is not None else "" for c in rows[3]]
    card_values = rows[4]

    summary = {
        "output_path": filepath,
        "latest_month": "-",
        "actual_to": 0.0,
        "to_rm12": 0.0,
        "to_monthly": 0.0,
        "mos_monthly": 0.0,
        "budget_to": 3.00,
        "gap_to": 0.0,
        "total_inventory": 0.0,
        "avg_stock_6m": 0.0,
        "cogs_monthly": 0.0,
        "cogs_12m": 0.0,
        "suggest_stock_ideal": 0.0,
        "suggest_stock_min": 0.0,
        "mos": 0.0,
        "mos_rm12": 0.0,
        "doh": 0.0,
        "monthly_rows": []
    }

    def clean_num(v):
        if v is None:
            return 0.0
        if isinstance(v, (int, float)):
            return float(v)
        s = re.sub(r'[^\d.-]', '', str(v).replace(',', ''))
        try:
            return float(s) if s else 0.0
        except Exception:
            return 0.0

    for idx, lbl in enumerate(card_labels):
        if idx >= len(card_values):
            break
        val = card_values[idx]
        if "BULAN TERAKHIR" in lbl:
            summary["latest_month"] = str(val or "-")
        elif "ACTUAL TO" in lbl or "TO RM12" in lbl:
            summary["actual_to"] = clean_num(val)
            summary["to_rm12"] = clean_num(val)
        elif "TO PER BULAN" in lbl or "TO BULANAN" in lbl:
            summary["to_monthly"] = clean_num(val)
        elif "BUDGET TO" in lbl:
            summary["budget_to"] = clean_num(val)
        elif "GAP TO" in lbl:
            summary["gap_to"] = clean_num(val)
        elif "TOTAL STOCK TERKINI" in lbl or "TOTAL STOK TERKINI" in lbl:
            summary["total_inventory"] = clean_num(val)
        elif "AVG STOCK" in lbl or "AVG STOK" in lbl:
            summary["avg_stock_6m"] = clean_num(val)
        elif "COGS BULANAN" in lbl:
            summary["cogs_monthly"] = clean_num(val)
        elif "TOTAL COGS 12" in lbl:
            summary["cogs_12m"] = clean_num(val)
        elif "SUGGEST STOK IDEAL" in lbl or "BATAS TARGET" in lbl:
            summary["suggest_stock_ideal"] = clean_num(val)
        elif "SUGGEST STOK MINIMAL" in lbl:
            summary["suggest_stock_min"] = clean_num(val)
        elif "MOS RM12" in lbl:
            summary["mos"] = clean_num(val)
            summary["mos_rm12"] = clean_num(val)
        elif "MOS BULANAN" in lbl:
            summary["mos_monthly"] = clean_num(val)
        elif "MONTHS OF SUPPLY" in lbl or "MOS" in lbl:
            summary["mos"] = clean_num(val)
        elif "DAYS ON HAND" in lbl or "DOH" in lbl:
            summary["doh"] = clean_num(val)

    if summary["suggest_stock_ideal"] == 0.0 and summary["budget_to"] > 0 and summary["cogs_12m"] > 0:
        summary["suggest_stock_ideal"] = summary["cogs_12m"] / summary["budget_to"]

    if summary["suggest_stock_min"] == 0.0 and summary["cogs_12m"] > 0:
        summary["suggest_stock_min"] = (summary["cogs_12m"] / 12.0) * 2.5

    summary["target_stock_max"] = summary["suggest_stock_ideal"]
    summary["stock_variance"] = summary["total_inventory"] - summary["suggest_stock_ideal"]

    # Parse tabel histori tren bulanan (Mulai baris ke-8 atau 9)
    tbl_start = None
    for r_idx, r_val in enumerate(rows[:12]):
        r_str = " ".join([str(c) for c in r_val if c is not None]).lower()
        if "bulan - tahun" in r_str or "total inventory" in r_str:
            tbl_start = r_idx
            break

    if tbl_start is not None and len(rows) > tbl_start + 1:
        tbl_headers = [str(c).strip() if c is not None else "" for c in rows[tbl_start]]
        for r_val in rows[tbl_start + 1:]:
            if not r_val or r_val[0] is None:
                continue
            r_dict = {}
            for c_i, h_name in enumerate(tbl_headers):
                if c_i < len(r_val):
                    r_dict[h_name] = r_val[c_i]
            summary["monthly_rows"].append(r_dict)

    # Status & Rekomendasi
    tot_i = summary["total_inventory"]
    s_ideal = summary["suggest_stock_ideal"]
    s_min = summary["suggest_stock_min"]
    act_to = summary["actual_to"]
    bud_to = summary["budget_to"]
    gap_to = summary["gap_to"]
    variance = summary["stock_variance"]
    mos = summary["mos"]
    doh = summary["doh"]

    if tot_i > s_ideal and s_ideal > 0:
        summary["status_code"] = "OVERSTOCK"
        summary["status_label"] = "OVERSTOCK (Di Atas Target Budget)"
        summary["status_badge_color"] = "#DC2626"
        summary["recommendation"] = (
            f"Turn Over {act_to:.2f} berada di bawah target Budget {bud_to:.2f} (Gap: {gap_to:.2f}). "
            f"Level stok saat ini ({tot_i:,.0f}) melampaui batas ideal ({s_ideal:,.0f}) sebesar {variance:,.0f}. "
            f"Disarankan menunda/merampingkan pengadaan suku cadang fast moving & slow moving sebesar ~{variance:,.0f} "
            f"agar stok kembali ke batas ideal {s_ideal:,.0f}."
        )
    elif tot_i >= s_min:
        summary["status_code"] = "HEALTHY"
        summary["status_label"] = "OPTIMAL & SEHAT (Melampaui Target)"
        summary["status_badge_color"] = "#16A34A"
        summary["recommendation"] = (
            f"Performa Turn Over Parts sangat baik ({act_to:.2f} vs Target Budget {bud_to:.2f}). "
            f"Tingkat stok berada di level LEAN & SEHAT ({tot_i:,.0f}), berada di antara batas minimum aman "
            f"({s_min:,.0f}) dan batas ideal ({s_ideal:,.0f}). "
            f"Stok saat ini sanggup menopang operasional selama ~{mos:.2f} bulan ({doh:.0f} hari)."
        )
    else:
        summary["status_code"] = "POTENTIAL_STOCKOUT"
        summary["status_label"] = "PERHATIAN (Di Bawah Buffer Minimal)"
        summary["status_badge_color"] = "#D97706"
        summary["recommendation"] = (
            f"Turn Over tercatat tinggi ({act_to:.2f}). Namun level stok terkini ({tot_i:,.0f}) berada di bawah "
            f"ambang batas minimal buffer aman 2.5 bulan ({s_min:,.0f}). "
            f"Segera review kebutuhan critical spare parts untuk mencegah risiko kehabisan stok (stockout)."
        )

    return summary

