"""
Module: email_helper.py
Khusus mengelola pembuatan dan pengiriman email laporan melalui Microsoft Outlook Desktop.
Mendukung pembuatan draft (Display) agar pengguna dapat mereview sebelum kirim,
maupun pengiriman langsung (Send) di latar belakang.
"""
import os
import glob
import re
import html
import time
import win32com.client
import pythoncom
import config


def is_outlook_available():
    """
    Memeriksa apakah aplikasi Microsoft Outlook tersedia pada sistem.
    """
    pythoncom.CoInitialize()
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        return outlook is not None
    except Exception:
        return False
    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def extract_readiness_metrics_from_excel(filepath):
    """
    Mengekstrak metrik KPI dari file laporan Part Readiness secara otomatis:
    - Mendeteksi apakah file memiliki sheet Monthly Plan ('Part Readiness - Monthly Plan')
    - Mengekstrak metrik Monthly Plan (mp_parts_required, mp_req_qty, mp_ready, mp_not_ready, dll)
    - Mengekstrak metrik All WO / Backlog (all_parts_required, filtered_parts_required, dll)
    - Mengekstrak breakdown stok (total_stock_mb52, total_stock_info, total_stock_oo)
    Mendukung format .xlsx, .xlsb, dan .xls dengan python-calamine (fallback openpyxl).
    """
    if not filepath or not os.path.exists(filepath):
        return None

    import re

    def parse_num(val):
        if val is None:
            return 0.0
        if isinstance(val, (int, float)):
            return float(val)
        cleaned = re.sub(r'[^\d.-]', '', str(val).replace(',', ''))
        try:
            return float(cleaned) if cleaned else 0.0
        except Exception:
            return 0.0

    def parse_sheet_kpi_rows(data):
        if not data or len(data) < 2:
            return {'total_parts': 0, 'req_qty': 0.0, 'ready': 0, 'not_ready': 0, 'pct_ready': 0.0, 'pct_not_ready': 0.0}

        total_parts = 0
        ready_parts = 0
        not_ready_parts = 0
        total_req_qty = 0.0

        for r in data[:9]:
            r_str = ' '.join(str(c) for c in r if c is not None)
            if 'Total Part Number:' in r_str or 'Total Part Ready:' in r_str:
                for c in r:
                    c_s = str(c).strip()
                    if 'items' in c_s.lower():
                        num = int(parse_num(c_s))
                        if total_parts == 0:
                            total_parts = num
                        elif ready_parts == 0:
                            ready_parts = num
                        elif not_ready_parts == 0:
                            not_ready_parts = num

            if 'Total Requirement:' in r_str:
                for c in r:
                    c_s = str(c).strip()
                    if 'total requirement' not in c_s.lower() and ('qty' in c_s.lower() or any(char.isdigit() for char in c_s)):
                        val = parse_num(c_s)
                        if val > 0 and total_req_qty == 0.0:
                            total_req_qty = val

        if total_parts == 0 and len(data) > 11:
            h_idx = None
            for idx, r in enumerate(data[:16]):
                r_str = ' '.join(str(c) for c in r if c is not None)
                if 'Material Number' in r_str and 'Requirement Qty' in r_str:
                    h_idx = idx
                    break

            if h_idx is not None:
                headers = [str(c).strip() for c in data[h_idx]]
                req_col = next((i for i, h in enumerate(headers) if 'Requirement Qty' in h or 'Requirement_Qty' in h), None)
                status_col = next((i for i, h in enumerate(headers) if 'Status' in h), None)

                for r in data[h_idx + 1:]:
                    if not r or r[1] is None or str(r[1]).strip() == '':
                        continue
                    total_parts += 1
                    if req_col is not None and len(r) > req_col:
                        total_req_qty += parse_num(r[req_col])
                    if status_col is not None and len(r) > status_col:
                        st = str(r[status_col])
                        if 'Ready' in st and 'Not Ready' not in st:
                            ready_parts += 1
                        elif 'Not Ready' in st:
                            not_ready_parts += 1

        pct_ready = (ready_parts / total_parts * 100) if total_parts > 0 else 0.0
        pct_not_ready = (not_ready_parts / total_parts * 100) if total_parts > 0 else 0.0
        return {
            'total_parts': total_parts,
            'req_qty': total_req_qty,
            'ready': ready_parts,
            'not_ready': not_ready_parts,
            'pct_ready': pct_ready,
            'pct_not_ready': pct_not_ready
        }

    mb52_sum = 0.0
    atp_sum = 0.0
    oo_sum = 0.0
    sheet_names = []
    mp_kpi = None
    all_kpi = None
    filt_kpi = None

    try:
        from python_calamine import CalamineWorkbook
        wb = CalamineWorkbook.from_path(filepath)
        sheet_names = wb.sheet_names

        if 'AS57D' in sheet_names and 'MB52' in sheet_names:
            return {
                "is_raw_data": True,
                "sheet_names": sheet_names,
                "output_path": filepath
            }

        if 'Part Readiness - Monthly Plan' in sheet_names:
            mp_kpi = parse_sheet_kpi_rows(wb.get_sheet_by_name('Part Readiness - Monthly Plan').to_python())

        if 'Part Readiness - All' in sheet_names:
            all_kpi = parse_sheet_kpi_rows(wb.get_sheet_by_name('Part Readiness - All').to_python())

        if 'Part Readiness - COMP PROG RELE' in sheet_names:
            filt_kpi = parse_sheet_kpi_rows(wb.get_sheet_by_name('Part Readiness - COMP PROG RELE').to_python())

        if 'Part Readiness' in sheet_names and not all_kpi and not filt_kpi:
            all_kpi = parse_sheet_kpi_rows(wb.get_sheet_by_name('Part Readiness').to_python())

        if 'Pivot MB52' in sheet_names:
            s_mb52 = wb.get_sheet_by_name('Pivot MB52').to_python()
            if len(s_mb52) > 1:
                h = [str(col).strip() for col in s_mb52[0]]
                stock_col = next((i for i, c in enumerate(h) if 'Stock_MB52' in c or 'MB52' in c), 1)
                mb52_sum = sum(parse_num(row[stock_col]) for row in s_mb52[1:] if len(row) > stock_col)

        if 'Stock Info ATP' in sheet_names:
            s_inv = wb.get_sheet_by_name('Stock Info ATP').to_python()
            if len(s_inv) > 1:
                h = [str(col).strip() for col in s_inv[0]]
                atp_col = next((i for i, c in enumerate(h) if 'ATP' in c), None)
                oo_col = next((i for i, c in enumerate(h) if 'OO' in c or 'On-Order' in c or 'On Order' in c), None)
                if atp_col is not None:
                    atp_sum = sum(parse_num(row[atp_col]) for row in s_inv[1:] if len(row) > atp_col)
                if oo_col is not None:
                    oo_sum = sum(parse_num(row[oo_col]) for row in s_inv[1:] if len(row) > oo_col)

    except Exception:
        # Fallback openpyxl
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, data_only=True, read_only=True)
            sheet_names = wb.sheetnames

            if 'AS57D' in sheet_names and 'MB52' in sheet_names:
                return {
                    "is_raw_data": True,
                    "sheet_names": sheet_names,
                    "output_path": filepath
                }

            if 'Part Readiness - Monthly Plan' in sheet_names:
                ws_mp = wb['Part Readiness - Monthly Plan']
                mp_rows = [list(r) for r in ws_mp.iter_rows(values_only=True)]
                mp_kpi = parse_sheet_kpi_rows(mp_rows)

            if 'Part Readiness - All' in sheet_names:
                ws_all = wb['Part Readiness - All']
                all_rows = [list(r) for r in ws_all.iter_rows(values_only=True)]
                all_kpi = parse_sheet_kpi_rows(all_rows)

            if 'Part Readiness - COMP PROG RELE' in sheet_names:
                ws_filt = wb['Part Readiness - COMP PROG RELE']
                filt_rows = [list(r) for r in ws_filt.iter_rows(values_only=True)]
                filt_kpi = parse_sheet_kpi_rows(filt_rows)

            if 'Part Readiness' in sheet_names and not all_kpi and not filt_kpi:
                ws_gen = wb['Part Readiness']
                gen_rows = [list(r) for r in ws_gen.iter_rows(values_only=True)]
                all_kpi = parse_sheet_kpi_rows(gen_rows)

            if 'Pivot MB52' in sheet_names:
                ws_m = wb['Pivot MB52']
                for r in ws_m.iter_rows(min_row=2, values_only=True):
                    if len(r) > 1:
                        mb52_sum += parse_num(r[1])

            if 'Stock Info ATP' in sheet_names:
                ws_i = wb['Stock Info ATP']
                for r in ws_i.iter_rows(min_row=2, values_only=True):
                    if len(r) >= 3:
                        atp_sum += parse_num(r[2])
                    if len(r) >= 6:
                        oo_sum += parse_num(r[5])
            wb.close()
        except Exception:
            pass

    has_mp = (mp_kpi is not None and mp_kpi['total_parts'] > 0)
    primary_wo_kpi = all_kpi or filt_kpi or mp_kpi or {'total_parts': 0, 'req_qty': 0.0, 'ready': 0, 'not_ready': 0, 'pct_ready': 0.0, 'pct_not_ready': 0.0}
    active_kpi = mp_kpi if has_mp else primary_wo_kpi

    if active_kpi['total_parts'] == 0:
        return None

    return {
        "output_path": filepath,
        "sheet_names": sheet_names,
        "has_mp_info": has_mp,
        
        # Monthly Plan metrics
        "mp_parts_required": mp_kpi['total_parts'] if mp_kpi else 0,
        "mp_req_qty": mp_kpi['req_qty'] if mp_kpi else 0.0,
        "mp_ready": mp_kpi['ready'] if mp_kpi else 0,
        "mp_not_ready": mp_kpi['not_ready'] if mp_kpi else 0,
        "mp_pct_ready": mp_kpi['pct_ready'] if mp_kpi else 0.0,
        "mp_pct_not_ready": mp_kpi['pct_not_ready'] if mp_kpi else 0.0,

        # All WO metrics
        "all_parts_required": all_kpi['total_parts'] if all_kpi else (filt_kpi['total_parts'] if filt_kpi else primary_wo_kpi['total_parts']),
        "all_req_qty": all_kpi['req_qty'] if all_kpi else (filt_kpi['req_qty'] if filt_kpi else primary_wo_kpi['req_qty']),
        "all_ready": all_kpi['ready'] if all_kpi else (filt_kpi['ready'] if filt_kpi else primary_wo_kpi['ready']),
        "all_not_ready": all_kpi['not_ready'] if all_kpi else (filt_kpi['not_ready'] if filt_kpi else primary_wo_kpi['not_ready']),
        "all_pct_ready": all_kpi['pct_ready'] if all_kpi else (filt_kpi['pct_ready'] if filt_kpi else primary_wo_kpi['pct_ready']),
        "all_pct_not_ready": all_kpi['pct_not_ready'] if all_kpi else (filt_kpi['pct_not_ready'] if filt_kpi else primary_wo_kpi['pct_not_ready']),

        # Filtered metrics (COMP PROG RELE)
        "filtered_parts_required": filt_kpi['total_parts'] if filt_kpi else 0,
        "filtered_req_qty": filt_kpi['req_qty'] if filt_kpi else 0.0,
        "filtered_ready": filt_kpi['ready'] if filt_kpi else 0,
        "filtered_not_ready": filt_kpi['not_ready'] if filt_kpi else 0,
        "filtered_pct_ready": filt_kpi['pct_ready'] if filt_kpi else 0.0,
        "filtered_pct_not_ready": filt_kpi['pct_not_ready'] if filt_kpi else 0.0,

        # Top-level fallback
        "pct_ready": active_kpi['pct_ready'],
        "pct_not_ready": active_kpi['pct_not_ready'],
        "total_stock_mb52": mb52_sum,
        "total_stock_info": atp_sum,
        "total_stock_oo": oo_sum,
    }


def generate_readiness_email_body(report_summary=None, notes="", report_file_path=None, report_type="report"):
    """
    Menyusun template HTML email profesional:
    - Jika report_type == 'mp': Fokus pada Monthly Plan (KPI cards Monthly Plan, perbandingan backlog WO)
    - Jika report_type == 'report': Fokus pada WO Allocation umum / backlog aktif
    - Kartu KPI ringkasan kebutuhan, fulfillment rate (%), dan shortage
    - Breakdown ketersediaan stok MB52 (S), Stock Info (ATP), dan On-Order (OO)
    - Catatan tambahan & info lampiran
    """
    timestamp = time.strftime("%d-%b-%Y %H:%M")
    
    summary = dict(report_summary) if report_summary else {}
    target_file = report_file_path or summary.get("output_path", "")

    # Ambil metrik fresh jika summary belum lengkap
    if (summary.get("all_parts_required", 0) == 0 and summary.get("mp_parts_required", 0) == 0) and target_file and os.path.exists(target_file):
        extracted = extract_readiness_metrics_from_excel(target_file)
        if extracted:
            summary = extracted

    output_path = summary.get("output_path", "") or target_file
    filename = os.path.basename(output_path) if output_path else "Laporan_Part_Readiness.xlsx"
    has_mp = summary.get("has_mp_info", False) or (summary.get("mp_parts_required", 0) > 0)

    if report_type == "mp":
        # Mode Monthly Plan
        header_title = "MONTHLY PLAN PART READINESS REPORT"
        header_badge = "MONTHLY PLAN"
        greeting_text = "Dear All,<br><br>Berikut update Readiness part khusus <b>Monthly Plan</b> per hari ini."
        total_parts = summary.get("mp_parts_required", 0)
        total_req_qty = summary.get("mp_req_qty", 0.0)
        ready_parts = summary.get("mp_ready", 0)
        not_ready_parts = summary.get("mp_not_ready", 0)
        pct_ready = summary.get("mp_pct_ready", 0.0)
        pct_not_ready = summary.get("mp_pct_not_ready", 0.0)
        card1_label = "TOTAL PART"
        card2_label = "🟢 FULFILLMENT RATE"
        card3_label = "🔴 NOT READY RATE"
    else:
        # Mode Alokasi WO Umum
        header_title = "WORK ORDER PART READINESS REPORT"
        header_badge = "WO ALLOCATION"
        greeting_text = "Dear All,<br><br>Berikut update WO Allocation hari ini."
        total_parts = summary.get("all_parts_required", 0) or summary.get("filtered_parts_required", 0)
        total_req_qty = summary.get("all_req_qty", 0.0) or summary.get("filtered_req_qty", 0.0)
        ready_parts = summary.get("all_ready", 0) or summary.get("filtered_ready", 0)
        not_ready_parts = summary.get("all_not_ready", 0) or summary.get("filtered_not_ready", 0)
        pct_ready = summary.get("all_pct_ready", 0.0) or summary.get("pct_ready", 0.0)
        pct_not_ready = summary.get("all_pct_not_ready", 0.0) or summary.get("pct_not_ready", 0.0)
        card1_label = "TOTAL PART WO"
        card2_label = "🟢 FULFILLMENT RATE"
        card3_label = "🔴 NOT READY RATE"

    # Fallback jika total_parts masih 0
    if total_parts == 0:
        alt_parts = summary.get("filtered_parts_required", 0) or summary.get("all_parts_required", 0) or summary.get("mp_parts_required", 0)
        if alt_parts > 0:
            total_parts = alt_parts
            total_req_qty = summary.get("filtered_req_qty", 0.0) or summary.get("all_req_qty", 0.0) or summary.get("mp_req_qty", 0.0)
            ready_parts = summary.get("filtered_ready", 0) or summary.get("all_ready", 0) or summary.get("mp_ready", 0)
            not_ready_parts = summary.get("filtered_not_ready", 0) or summary.get("all_not_ready", 0) or summary.get("mp_not_ready", 0)
            pct_ready = (ready_parts / total_parts * 100) if total_parts > 0 else 0.0
            pct_not_ready = (not_ready_parts / total_parts * 100) if total_parts > 0 else 0.0

    stock_mb52 = summary.get("total_stock_mb52", 0.0)
    stock_info = summary.get("total_stock_info", 0.0)
    stock_oo = summary.get("total_stock_oo", 0.0)

    # Catatan Pengirim
    notes_section = ""
    if notes and str(notes).strip():
        clean_notes = str(notes).strip().replace("\n", "<br>")
        notes_section = f"""
        <div style="background-color: #FEF3C7; border-left: 4px solid #D97706; padding: 10px 14px; margin: 16px 0; border-radius: 4px;">
            <b style="color: #92400E; font-size: 12px;">Catatan Pengirim:</b>
            <div style="color: #78350F; font-size: 13px; margin-top: 4px;">{clean_notes}</div>
        </div>
        """

    # Callout perbandingan (jika ada data kedua jenis)
    comparison_section = ""
    if report_type == "mp":
        wo_p = summary.get("all_parts_required", 0) or summary.get("filtered_parts_required", 0)
        if wo_p > 0 and wo_p != total_parts:
            wo_req = summary.get("all_req_qty", 0.0) or summary.get("filtered_req_qty", 0.0)
            wo_r = summary.get("all_ready", 0) or summary.get("filtered_ready", 0)
            wo_nr = summary.get("all_not_ready", 0) or summary.get("filtered_not_ready", 0)
            wo_pct_r = summary.get("all_pct_ready", 0.0) or ((wo_r / wo_p * 100) if wo_p > 0 else 0.0)
            wo_pct_nr = summary.get("all_pct_not_ready", 0.0) or ((wo_nr / wo_p * 100) if wo_p > 0 else 0.0)
            comparison_section = f"""
            <div style="margin-top: 16px; padding: 12px 14px; background-color: #F8FAFC; border: 1px solid #E2E8F0; border-left: 4px solid #3B82F6; border-radius: 6px; font-size: 12px; color: #1E293B;">
                <b style="color: #1E3A8A;">📌 Summary Part WO Allocation:</b><br>
                <div style="color: #475569; margin-top: 4px;">
                    Total Part: <b>{wo_p:,} items</b> ({wo_req:,.0f} qty) &nbsp;&bull;&nbsp; 
                    Ready: <b style="color: #059669;">{wo_r:,} ({wo_pct_r:.1f}%)</b> &nbsp;&bull;&nbsp; 
                    Shortage: <b style="color: #DC2626;">{wo_nr:,} ({wo_pct_nr:.1f}%)</b>
                </div>
            </div>
            """
    elif has_mp and summary.get("mp_parts_required", 0) > 0:
        mp_p = summary.get("mp_parts_required", 0)
        mp_req = summary.get("mp_req_qty", 0.0)
        mp_r = summary.get("mp_ready", 0)
        mp_nr = summary.get("mp_not_ready", 0)
        mp_pct_r = summary.get("mp_pct_ready", 0.0)
        comparison_section = f"""
        <div style="margin-top: 16px; padding: 12px 14px; background-color: #ECFDF5; border: 1px solid #A7F3D0; border-left: 4px solid #059669; border-radius: 6px; font-size: 12px; color: #065F46;">
            <b style="color: #065F46;">🗓️ Status Khusus Monthly Plan:</b><br>
            <div style="color: #047857; margin-top: 4px;">
                Total Part: <b>{mp_p:,} items</b> ({mp_req:,.0f} qty) &nbsp;&bull;&nbsp; 
                Ready: <b style="color: #059669;">{mp_r:,} ({mp_pct_r:.1f}%)</b> &nbsp;&bull;&nbsp; 
                Shortage: <b style="color: #DC2626;">{mp_nr:,} items</b>
            </div>
        </div>
        """

    # Rincian Sumber Stok (hanya untuk Laporan Alokasi WO Umum, diabaikan untuk Monthly Plan)
    stock_breakdown_section = ""
    if report_type != "mp":
        stock_breakdown_section = f"""
                <!-- Summary Breakdown Table -->
                <div style="margin-top: 16px;">
                    <div style="font-size: 12px; font-weight: bold; color: #1E3A8A; margin-bottom: 8px;">📊 Rincian Sumber Stok & Ketersediaan:</div>
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #E2E8F0; border-radius: 6px; overflow: hidden;">
                        <tr style="background-color: #F1F5F9; border-bottom: 2px solid #CBD5E1;">
                            <th style="padding: 10px 14px; text-align: left; color: #334155; font-weight: bold;">Kategori Sumber Stok</th>
                            <th style="padding: 10px 14px; text-align: right; color: #334155; font-weight: bold;">Kuantitas (Qty)</th>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9; background-color: #FFFFFF;">
                            <td style="padding: 9px 14px; color: #1F2937;">Special Stock S (MB52)</td>
                            <td style="padding: 9px 14px; text-align: right; font-weight: 600; color: #1F2937;">{stock_mb52:,.2f}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9; background-color: #F8FAFC;">
                            <td style="padding: 9px 14px; color: #1F2937;">Stok ATP (Stock Info)</td>
                            <td style="padding: 9px 14px; text-align: right; font-weight: 600; color: #1F2937;">{stock_info:,.2f}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9; background-color: #FFFFFF;">
                            <td style="padding: 9px 14px; color: #1F2937;">On-Order & In-Transit STO (Total OO)</td>
                            <td style="padding: 9px 14px; text-align: right; font-weight: 600; color: #2563EB;">{stock_oo:,.2f}</td>
                        </tr>
                    </table>
                </div>
        """

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
    </head>
    <body style="margin: 0; padding: 12px; background-color: #F8FAFC; font-family: 'Segoe UI', Arial, sans-serif;">
        <div style="max-width: 650px; margin: 0 auto; background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.06);">
            
            <!-- Header Banner -->
            <div style="background-color: #1E3A8A; color: #FFFFFF; padding: 20px 24px;">
                <div style="display: inline-block; background-color: #2563EB; color: #FFFFFF; font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 4px; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 6px;">
                    {header_badge}
                </div>
                <h2 style="margin: 0; font-size: 18px; font-weight: 700; letter-spacing: 0.5px;">{header_title}</h2>
                <div style="margin-top: 6px; font-size: 12px; color: #93C5FD;">
                    Generated: {timestamp} &nbsp;|&nbsp; File: {filename}
                </div>
            </div>

            <!-- Main Content -->
            <div style="padding: 22px 24px;">
                <p style="font-size: 13px; color: #374151; margin-top: 0; line-height: 1.6;">
                    {greeting_text}
                </p>

                {notes_section}

                <!-- KPI Summary Cards -->
                <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin: 18px 0;">
                    <tr>
                        <td style="background-color: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 14px 10px; text-align: center; width: 33%;">
                            <div style="font-size: 11px; font-weight: bold; color: #1E40AF; text-transform: uppercase;">{card1_label}</div>
                            <div style="font-size: 22px; font-weight: bold; color: #1E3A8A; margin: 6px 0;">{total_parts:,} <span style="font-size: 12px; font-weight: normal;">items</span></div>
                            <div style="font-size: 11px; color: #6B7280;">({total_req_qty:,.0f} qty kebutuhan)</div>
                        </td>
                        <td style="background-color: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 6px; padding: 14px 10px; text-align: center; width: 33%;">
                            <div style="font-size: 11px; font-weight: bold; color: #065F46; text-transform: uppercase;">{card2_label}</div>
                            <div style="font-size: 22px; font-weight: bold; color: #059669; margin: 6px 0;">{pct_ready:.1f}%</div>
                            <div style="font-size: 11px; color: #047857; font-weight: 600;">{ready_parts:,} items Ready</div>
                        </td>
                        <td style="background-color: #FEF2F2; border: 1px solid #FECACA; border-radius: 6px; padding: 14px 10px; text-align: center; width: 33%;">
                            <div style="font-size: 11px; font-weight: bold; color: #991B1B; text-transform: uppercase;">{card3_label}</div>
                            <div style="font-size: 22px; font-weight: bold; color: #DC2626; margin: 6px 0;">{pct_not_ready:.1f}%</div>
                            <div style="font-size: 11px; color: #B91C1C; font-weight: 600;">{not_ready_parts:,} items Shortage</div>
                        </td>
                    </tr>
                </table>

                {comparison_section}

                {stock_breakdown_section}

                <!-- Attachment Info Note -->
                <div style="margin-top: 20px; padding: 12px 14px; background-color: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 6px; font-size: 12px; color: #4B5563;">
                    📎 <b>File Terlampir:</b> <span style="color: #1E3A8A; font-weight: bold;">{filename}</span><br>
                    <span style="font-size: 11px; color: #6B7280; margin-top: 3px; display: inline-block;">
                        Dilengkapi sheet <i>Part Readiness</i>, <i>Stock Info ATP</i> (dengan Order Method BB/PT, HS Code & Kuota Import AF/SF), serta <i>Data Clean</i>.
                    </span>
                </div>

                <div style="margin-top: 24px; border-top: 1px solid #E2E8F0; padding-top: 12px; font-size: 11px; color: #94A3B8; text-align: right;">
                    Otomasi dikirim melalui <b>Kermen Tools</b>
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return html


def extract_not_ready_details_from_excel(filepath, top_n=25, target_sheet=None):
    """
    Mengekstrak daftar dan ringkasan part Not Ready khusus untuk follow up Team Counter:
    - target_sheet: jika ditentukan, ekstrak dari sheet tersebut (misal: 'Part Readiness - Monthly Plan')
    - total_not_ready (items)
    - total_deficit (qty)
    - items_with_oo & items_zero_oo
    - remarks_count (dict per kategori remarks)
    - top_items (list detail part dengan shortage terbesar)
    """
    if not filepath or not os.path.exists(filepath):
        return None

    import re

    def parse_cell_num(v):
        if v is None:
            return None
        if isinstance(v, (int, float)):
            return float(v)
        s = str(v).strip()
        if not s or s.startswith('='):
            return None
        is_neg = '-' in s or (s.startswith('(') and s.endswith(')'))
        digits = re.sub(r'[^\d.]', '', s)
        try:
            n = float(digits) if digits else None
            if n is not None:
                return -n if is_neg else n
        except Exception:
            pass
        return None

    def parse_num(v):
        res = parse_cell_num(v)
        return res if res is not None else 0.0

    chosen_sheet = None
    data = None

    try:
        from python_calamine import CalamineWorkbook
        wb = CalamineWorkbook.from_path(filepath)
        sheet_names = wb.sheet_names

        if target_sheet and target_sheet in sheet_names:
            chosen_sheet = target_sheet
        elif target_sheet:
            t_low = target_sheet.lower()
            if "monthly plan" in t_low or "mp" in t_low:
                chosen_sheet = next((s for s in sheet_names if "monthly plan" in s.lower() or "mp" in s.lower()), None)
            elif "comp" in t_low or "rele" in t_low:
                chosen_sheet = next((s for s in sheet_names if "comp" in s.lower() or "rele" in s.lower()), None)
            elif "all" in t_low:
                chosen_sheet = next((s for s in sheet_names if "all" in s.lower()), None)

        if not chosen_sheet:
            chosen_sheet = next((s for s in ['Part Readiness - Monthly Plan', 'Part Readiness - COMP PROG RELE', 'Part Readiness - All'] if s in sheet_names), None)
            if not chosen_sheet:
                chosen_sheet = next((s for s in sheet_names if 'part readiness' in s.lower()), None)
            if not chosen_sheet and sheet_names:
                chosen_sheet = sheet_names[0]

        if chosen_sheet:
            data = wb.get_sheet_by_name(chosen_sheet).to_python()
    except Exception:
        pass

    if not data:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, data_only=True, read_only=True)
            sheet_names = wb.sheetnames
            if target_sheet and target_sheet in sheet_names:
                chosen_sheet = target_sheet
            elif target_sheet:
                t_low = target_sheet.lower()
                if "monthly plan" in t_low or "mp" in t_low:
                    chosen_sheet = next((s for s in sheet_names if "monthly plan" in s.lower() or "mp" in s.lower()), None)
                elif "comp" in t_low or "rele" in t_low:
                    chosen_sheet = next((s for s in sheet_names if "comp" in s.lower() or "rele" in s.lower()), None)
                elif "all" in t_low:
                    chosen_sheet = next((s for s in sheet_names if "all" in s.lower()), None)

            if not chosen_sheet:
                chosen_sheet = next((s for s in ['Part Readiness - Monthly Plan', 'Part Readiness - COMP PROG RELE', 'Part Readiness - All'] if s in sheet_names), None)
                if not chosen_sheet:
                    chosen_sheet = next((s for s in sheet_names if 'part readiness' in s.lower()), None)
                if not chosen_sheet and sheet_names:
                    chosen_sheet = sheet_names[0]

            if chosen_sheet:
                ws = wb[chosen_sheet]
                data = [list(row) for row in ws.iter_rows(values_only=True)]
            wb.close()
        except Exception:
            pass

    if not data:
        return None

    # Cari baris header tabel
    h_idx = None
    for idx, r in enumerate(data[:16]):
        r_str = ' '.join(str(c) for c in r if c is not None)
        if 'Material Number' in r_str and ('Requirement' in r_str or 'Req Qty' in r_str):
            h_idx = idx
            break

    if h_idx is None:
        return None

    headers = [str(c).strip() if c is not None else "" for c in data[h_idx]]

    def find_col(pattern):
        return next((i for i, h in enumerate(headers) if pattern.lower() in h.lower()), None)

    mat_col = find_col('Material Number')
    pn_col = find_col('Part Number') or find_col('PN')
    desc_col = find_col('Description')
    req_col = (find_col('Requirement Qty (AS57D)') or find_col('Requirement Qty (All)') or 
               find_col('Requirement Qty') or find_col('Requirement_Qty') or find_col('Req Qty'))
    mb52_col = find_col('Stock MB52') or find_col('MB52')
    atp_col = find_col('Stock ATP') or find_col('Stock Info') or find_col('ATP')
    avail_col = find_col('Total Available') or find_col('Available Stock')
    deficit_col = find_col('Balance') or find_col('Deficit')
    status_col = find_col('Status')
    oo_col = find_col('On Order') or find_col('OO')
    rem_col = find_col('Remarks')

    not_ready_items = []
    remarks_count = {}
    total_deficit = 0.0
    items_with_oo = 0
    items_zero_oo = 0

    for r in data[h_idx + 1:]:
        if not r or mat_col is None or len(r) <= mat_col or r[mat_col] is None or str(r[mat_col]).strip() == '':
            continue

        req_q = parse_cell_num(r[req_col]) or 0.0 if req_col is not None and len(r) > req_col else 0.0
        mb52_q = parse_cell_num(r[mb52_col]) or 0.0 if mb52_col is not None and len(r) > mb52_col else 0.0
        atp_q = parse_cell_num(r[atp_col]) or 0.0 if atp_col is not None and len(r) > atp_col else 0.0

        avail_raw = parse_cell_num(r[avail_col]) if avail_col is not None and len(r) > avail_col else None
        if avail_raw is not None:
            avail_q = avail_raw
        else:
            avail_q = mb52_q + atp_q

        def_raw = parse_cell_num(r[deficit_col]) if deficit_col is not None and len(r) > deficit_col else None
        if def_raw is not None:
            balance_val = def_raw
        else:
            balance_val = avail_q - req_q

        oo_q = parse_num(r[oo_col]) if oo_col is not None and len(r) > oo_col else 0.0
        rem_val = str(r[rem_col]).strip() if rem_col is not None and len(r) > rem_col and r[rem_col] is not None else '-'
        if not rem_val:
            rem_val = '-'

        status_str = str(r[status_col]).strip() if status_col is not None and len(r) > status_col and r[status_col] is not None else ""

        # Filter: Hanya yang bernilai minus ATAU status ketersediaan not ready
        is_minus = (balance_val < -1e-6)
        is_not_ready = any(w in status_str.lower() for w in ['not ready', 'shortage', 'defisit', 'kurang'])

        if not (is_minus or is_not_ready):
            continue

        # Kuantitas Kebutuhan: Yang diambil requirement Qty harusnya Balance Defisitnya saja
        if balance_val < -1e-6:
            shortage_qty = abs(balance_val)
        else:
            shortage_qty = max(0.0, req_q - avail_q)

        # Lewati jika tidak ada defisit aktual
        if shortage_qty <= 0:
            continue

        total_deficit += shortage_qty

        if oo_q > 0:
            items_with_oo += 1
        else:
            items_zero_oo += 1

        remarks_count[rem_val] = remarks_count.get(rem_val, 0) + 1

        not_ready_items.append({
            'mat_no': str(r[mat_col]).strip() if mat_col is not None and len(r) > mat_col and r[mat_col] is not None else '',
            'pn': str(r[pn_col]).strip() if pn_col is not None and len(r) > pn_col and r[pn_col] is not None else '',
            'desc': str(r[desc_col]).strip() if desc_col is not None and len(r) > desc_col and r[desc_col] is not None else '',
            'req_qty': req_q,
            'avail_stock': avail_q,
            'balance': balance_val,
            'deficit': shortage_qty,
            'oo_qty': oo_q,
            'status': status_str,
            'remarks': rem_val
        })

    # Urutkan berdasarkan shortage/defisit terbesar
    not_ready_items.sort(key=lambda x: x['deficit'], reverse=True)

    return {
        'output_path': filepath,
        'sheet_name': chosen_sheet,
        'total_not_ready': len(not_ready_items),
        'total_deficit': total_deficit,
        'items_with_oo': items_with_oo,
        'items_zero_oo': items_zero_oo,
        'remarks_count': remarks_count,
        'all_items': not_ready_items,
        'top_items': not_ready_items[:top_n] if top_n else not_ready_items
    }


def generate_counter_followup_email_body(report_file_path=None, report_summary=None, notes="", top_n=25, source_type=None):
    """
    Menyusun template HTML email khusus Team Counter untuk follow up part yang NOT READY:
    - Jika source_type == 'mp': Fokus pada part Not Ready dari Monthly Plan
    - Jika source_type == 'all': Fokus pada part Not Ready dari All WO
    - Header bertema alert crimson / dark red (Urgent action needed)
    - Kartu KPI ringkasan: Total Part Not Ready, Total Shortage Qty, Zero OO (butuh PO), Ada OO (follow up ETA)
    - Rekapitulasi kategori Remarks / Status Tindak Lanjut
    - Tabel interaktif daftar Part Not Ready dengan defisit terbesar (Top N)
    - Catatan tambahan pengirim & lampiran file Excel
    """
    import html
    timestamp = time.strftime("%d-%b-%Y %H:%M")

    # Ambil detail dari file laporan jika ada
    target_file = report_file_path or (report_summary.get("output_path") if report_summary else "")
    
    target_sheet = None
    if source_type == "mp":
        target_sheet = 'Part Readiness - Monthly Plan'
    elif source_type == "all":
        target_sheet = 'Part Readiness - COMP PROG RELE'

    data = None
    if target_file and os.path.exists(target_file):
        data = extract_not_ready_details_from_excel(target_file, top_n=top_n, target_sheet=target_sheet)

    if not data:
        # Fallback dari report_summary jika ada
        summary = report_summary or {}
        total_nr = summary.get("all_not_ready", 0) or summary.get("filtered_not_ready", 0) or summary.get("mp_not_ready", 0)
        data = {
            'total_not_ready': total_nr,
            'total_deficit': 0.0,
            'items_with_oo': 0,
            'items_zero_oo': total_nr,
            'remarks_count': {},
            'top_items': []
        }

    filename = os.path.basename(target_file) if target_file else "Laporan_Part_Readiness.xlsx"
    total_not_ready = data.get('total_not_ready', 0)
    total_deficit = data.get('total_deficit', 0.0)
    items_with_oo = data.get('items_with_oo', 0)
    items_zero_oo = data.get('items_zero_oo', 0)
    remarks_count = data.get('remarks_count', {})
    top_items = data.get('top_items', [])
    used_sheet = data.get('sheet_name', '')
    is_mp_focus = ('monthly plan' in str(used_sheet).lower()) or (source_type == "mp")

    badge_text = "&#9888; ACTION REQUIRED &bull; TEAM COUNTER &bull; MONTHLY PLAN" if is_mp_focus else "&#9888; ACTION REQUIRED &bull; TEAM COUNTER"
    header_title = "FOLLOW UP PART NOT READY &bull; MONTHLY PLAN" if is_mp_focus else "FOLLOW UP PART NOT READY &bull; WORK ORDER ALLOCATION"
    intro_text = (
        "Dear Team Counter,<br><br>Berikut list part <b>Monthly Plan</b> dengan status <b>NOT READY / SHORTAGE</b> per hari ini untuk segera difollow up ketersediaan maupun pengadaannya."
        if is_mp_focus else
        "Dear Team Counter,<br><br>Berikut list part Work Order Allocation dengan status <b>NOT READY / SHORTAGE</b> per hari ini untuk segera follow up release ke cabang terdekat atau raise ke CAT."
    )

    notes_section = ""
    if notes and str(notes).strip():
        clean_notes = str(notes).strip().replace("\n", "<br>")
        notes_section = f"""
        <div style="background-color: #FEF3C7; border-left: 4px solid #D97706; padding: 10px 14px; margin: 16px 0; border-radius: 4px;">
            <b style="color: #92400E; font-size: 12px;">Catatan Pengirim:</b>
            <div style="color: #78350F; font-size: 13px; margin-top: 4px;">{clean_notes}</div>
        </div>
        """

    # Buat baris tabel rekap remarks
    remarks_rows = ""
    if remarks_count:
        sorted_rem = sorted(remarks_count.items(), key=lambda x: x[1], reverse=True)
        for rem_label, count_val in sorted_rem:
            pct_rem = (count_val / total_not_ready * 100) if total_not_ready > 0 else 0.0
            badge_color = "#DC2626" if "vendor" in rem_label.lower() or "not" in rem_label.lower() else ("#D97706" if "checking" in rem_label.lower() else "#2563EB")
            remarks_rows += f"""
            <tr style="border-bottom: 1px solid #F1F5F9;">
                <td style="padding: 7px 12px; color: #1F2937; font-weight: 500;">
                    <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: {badge_color}; margin-right: 6px;"></span>
                    {html.escape(rem_label)}
                </td>
                <td style="padding: 7px 12px; text-align: right; font-weight: 700; color: #1F2937;">{count_val:,} <span style="font-weight: normal; font-size: 11px; color: #6B7280;">items</span></td>
                <td style="padding: 7px 12px; text-align: right; font-weight: 600; color: #4B5563;">{pct_rem:.1f}%</td>
            </tr>
            """

    # Buat baris tabel daftar top items Not Ready
    items_table_rows = ""
    for idx, item in enumerate(top_items, start=1):
        bg_col = "#FFFFFF" if idx % 2 == 1 else "#F8FAFC"
        oo_display = f"{item['oo_qty']:,.0f}" if item['oo_qty'] > 0 else "<span style='color: #DC2626; font-weight: bold;'>0 (No PO)</span>"
        rem_text = item['remarks']
        rem_color = "#DC2626" if "vendor" in rem_text.lower() or "not" in rem_text.lower() else ("#B45309" if "checking" in rem_text.lower() else "#1D4ED8")

        items_table_rows += f"""
        <tr style="background-color: {bg_col}; border-bottom: 1px solid #E2E8F0; font-size: 11px;">
            <td style="padding: 8px 6px; text-align: center; color: #64748B;">{idx}</td>
            <td style="padding: 8px 10px; font-weight: 700; color: #0F172A; white-space: nowrap;">{html.escape(item['pn'])}</td>
            <td style="padding: 8px 10px; color: #334155; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{html.escape(item['desc'])}">{html.escape(item['desc'])}</td>
            <td style="padding: 8px 8px; text-align: right; font-weight: 600; color: #1E293B;">{item['req_qty']:,.0f}</td>
            <td style="padding: 8px 8px; text-align: right; color: #475569;">{item['avail_stock']:,.0f}</td>
            <td style="padding: 8px 8px; text-align: right; font-weight: 700; color: #DC2626;">-{item['deficit']:,.0f}</td>
            <td style="padding: 8px 8px; text-align: right;">{oo_display}</td>
            <td style="padding: 8px 10px; font-weight: 600; color: {rem_color}; white-space: nowrap;">{html.escape(rem_text)}</td>
        </tr>
        """

    showing_count = len(top_items)

    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
    </head>
    <body style="margin: 0; padding: 12px; background-color: #F8FAFC; font-family: 'Segoe UI', Arial, sans-serif;">
        <div style="max-width: 780px; margin: 0 auto; background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.06);">
            
            <!-- Header Banner Urgent / Follow Up -->
            <div style="background-color: #991B1B; color: #FFFFFF; padding: 20px 24px;">
                <div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #FECACA; text-transform: uppercase;">
                    {badge_text}
                </div>
                <h2 style="margin: 6px 0 0 0; font-size: 18px; font-weight: 700;">
                    {header_title}
                </h2>
                <div style="margin-top: 6px; font-size: 12px; color: #FEE2E2;">
                    Generated: {timestamp} &nbsp;|&nbsp; File: {filename}
                </div>
            </div>

            <!-- Main Content -->
            <div style="padding: 22px 24px;">
                <p style="font-size: 13px; color: #374151; margin-top: 0; line-height: 1.6;">
                    {intro_text}
                </p>

                {notes_section}

                <!-- Action KPI Cards -->
                <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin: 16px 0;">
                    <tr>
                        <td style="background-color: #FEF2F2; border: 1px solid #FECACA; border-radius: 6px; padding: 12px 10px; text-align: center; width: 25%;">
                            <div style="font-size: 11px; font-weight: bold; color: #991B1B; text-transform: uppercase;">Total Part Shortage</div>
                            <div style="font-size: 20px; font-weight: bold; color: #DC2626; margin: 4px 0;">{total_not_ready:,} <span style="font-size: 11px; font-weight: normal;">items</span></div>
                            <div style="font-size: 10px; color: #7F1D1D;">Status Not Ready</div>
                        </td>
                        <td style="background-color: #FFFBEB; border: 1px solid #FDE68A; border-radius: 6px; padding: 12px 10px; text-align: center; width: 25%;">
                            <div style="font-size: 11px; font-weight: bold; color: #92400E; text-transform: uppercase;">Total Defisit Qty</div>
                            <div style="font-size: 20px; font-weight: bold; color: #D97706; margin: 4px 0;">-{total_deficit:,.0f} <span style="font-size: 11px; font-weight: normal;">qty</span></div>
                            <div style="font-size: 10px; color: #78350F;">Kekurangan Stok</div>
                        </td>
                        <td style="background-color: #FFF1F2; border: 1px solid #FECDD3; border-radius: 6px; padding: 12px 10px; text-align: center; width: 25%;">
                            <div style="font-size: 11px; font-weight: bold; color: #BE123C; text-transform: uppercase;">Zero On-Order</div>
                            <div style="font-size: 20px; font-weight: bold; color: #E11D48; margin: 4px 0;">{items_zero_oo:,} <span style="font-size: 11px; font-weight: normal;">items</span></div>
                            <div style="font-size: 10px; color: #881337;">Need STO/PO</div>
                        </td>
                        <td style="background-color: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 12px 10px; text-align: center; width: 25%;">
                            <div style="font-size: 11px; font-weight: bold; color: #1E40AF; text-transform: uppercase;">Ada On-Order (OO)</div>
                            <div style="font-size: 20px; font-weight: bold; color: #2563EB; margin: 4px 0;">{items_with_oo:,} <span style="font-size: 11px; font-weight: normal;">items</span></div>
                            <div style="font-size: 10px; color: #1E3A8A;">Follow Up ETA / Delivery</div>
                        </td>
                    </tr>
                </table>

                <!-- Remarks Breakdown Table -->
                <div style="margin-top: 18px; margin-bottom: 22px;">
                    <div style="font-size: 12px; font-weight: bold; color: #1E3A8A; margin-bottom: 6px;">
                        &#128202; Summary Status (Remarks):
                    </div>
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #E2E8F0; border-radius: 6px; overflow: hidden;">
                        <tr style="background-color: #F1F5F9; border-bottom: 2px solid #CBD5E1;">
                            <th style="padding: 8px 12px; text-align: left; color: #334155; font-weight: bold;">Status / Action Remarks</th>
                            <th style="padding: 8px 12px; text-align: right; color: #334155; font-weight: bold;">Jumlah Part</th>
                            <th style="padding: 8px 12px; text-align: right; color: #334155; font-weight: bold;">Porsi (%)</th>
                        </tr>
                        {remarks_rows}
                    </table>
                </div>

                <!-- Priority Shortage Table -->
                <div style="margin-top: 18px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span style="font-size: 12px; font-weight: bold; color: #991B1B;">
                            &#128293; Daftar Prioritas Part Not Ready (Top {showing_count} Defisit Terbesar):
                        </span>
                    </div>
                    <div style="border: 1px solid #E2E8F0; border-radius: 6px; overflow: hidden;">
                        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                            <thead>
                                <tr style="background-color: #1E3A8A; color: #FFFFFF;">
                                    <th style="padding: 9px 6px; text-align: center; width: 28px;">#</th>
                                    <th style="padding: 9px 10px; text-align: left;">Part Number</th>
                                    <th style="padding: 9px 10px; text-align: left;">Deskripsi Material</th>
                                    <th style="padding: 9px 8px; text-align: right;">Req Qty</th>
                                    <th style="padding: 9px 8px; text-align: right;">Stok</th>
                                    <th style="padding: 9px 8px; text-align: right;">Defisit</th>
                                    <th style="padding: 9px 8px; text-align: right;">On Order</th>
                                    <th style="padding: 9px 10px; text-align: left;">Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                {items_table_rows}
                            </tbody>
                        </table>
                    </div>
                    <div style="font-size: 11px; color: #64748B; margin-top: 6px; text-align: right;">
                        <i>*Menampilkan {showing_count} dari total {total_not_ready:,} part Not Ready</i>
                    </div>
                </div>

                <!-- Attachment Note -->
                <div style="margin-top: 20px; padding: 12px 14px; background-color: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 6px; font-size: 12px; color: #4B5563;">
                    &#128206; <b>File Laporan Terlampir:</b> <span style="color: #1E3A8A; font-weight: bold;">{filename}</span><br>
                    <span style="font-size: 11px; color: #6B7280; margin-top: 3px; display: inline-block;">
                        Daftar lengkap seluruh <b>{total_not_ready:,} part Not Ready</b> dan informasi alokasi stok dapat diakses langsung pada file Excel terlampir.
                    </span>
                </div>

                <div style="margin-top: 24px; border-top: 1px solid #E2E8F0; padding-top: 12px; font-size: 11px; color: #94A3B8; text-align: right;">
                    Otomasi dikirim melalui <b>Kermen Tools</b>
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return html_content


def send_report_email_outlook(to, cc="", subject="", body_html="", attachment_paths=None, display=True, send=False):
    """
    Membuat email di Microsoft Outlook Desktop dengan lampiran laporan.
    Jika display=True: Buka jendela draft email Outlook di layar (rekomendasi agar bisa direview).
    Jika send=True: Kirim email langsung di latar belakang melalui Outlook.
    """
    pythoncom.CoInitialize()
    try:
        try:
            outlook = win32com.client.Dispatch("Outlook.Application")
        except Exception as e:
            raise RuntimeError(
                f"Tidak dapat terhubung ke Microsoft Outlook: {str(e)}\n\n"
                "Pastikan aplikasi Microsoft Outlook sudah terinstall dan telah dibuka/dikonfigurasi di komputer Anda."
            )

        mail = outlook.CreateItem(0)  # 0 = olMailItem

        if to:
            # Standarisasi pemisah email (titik koma untuk Outlook)
            to_formatted = "; ".join([e.strip() for e in str(to).replace(",", ";").split(";") if e.strip()])
            mail.To = to_formatted

        if cc:
            cc_formatted = "; ".join([e.strip() for e in str(cc).replace(",", ";").split(";") if e.strip()])
            mail.CC = cc_formatted

        if subject:
            mail.Subject = str(subject).strip()

        if body_html:
            mail.HTMLBody = body_html

        if attachment_paths:
            if isinstance(attachment_paths, str):
                attachment_paths = [attachment_paths]
            for att in attachment_paths:
                if att and os.path.exists(att):
                    mail.Attachments.Add(os.path.abspath(att))

        if send:
            mail.Send()
            return {"status": "sent", "mode": "send"}
        else:
            mail.Display()
            return {"status": "displayed", "mode": "display"}

    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def extract_otif_metrics_from_excel(filepath):
    """
    Mengekstrak metrik KPI OTIF & Absorption dari sheet 'Summary' pada file Excel laporan:
    - total_orders, c_otif_sim, pct_otif_sim, c_not_otif_sim, c_not_comp_sim
    - parts_fully_issued, parts_partial, parts_unissued, total_target_parts, pct_parts_issued
    - wo_fully_absorbed, wo_partial_absorbed, wo_unabsorbed, pct_wo_absorbed
    - purchasing_group, wo_parts_status, delta_days, date_filter_label
    Mendukung format summary baru (Simulasi H-1 & Absorption) dan format lama secara fleksibel.
    """
    if not filepath or not os.path.exists(filepath):
        return None

    import re

    def parse_num(val):
        if val is None:
            return 0.0
        if isinstance(val, (int, float)):
            return float(val)
        cleaned = re.sub(r'[^\d.-]', '', str(val).replace(',', ''))
        try:
            return float(cleaned) if cleaned else 0.0
        except Exception:
            return 0.0

    summary_rows = None
    try:
        from python_calamine import CalamineWorkbook
        wb = CalamineWorkbook.from_path(filepath)
        if 'Summary' in wb.sheet_names:
            summary_rows = wb.get_sheet_by_name('Summary').to_python()
    except Exception:
        pass

    if not summary_rows:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, data_only=True, read_only=True)
            if 'Summary' in wb.sheetnames:
                ws = wb['Summary']
                summary_rows = [list(r) for r in ws.iter_rows(values_only=True)]
            wb.close()
        except Exception:
            pass

    if not summary_rows or len(summary_rows) < 10:
        return None

    metrics = {
        "output_path": filepath,
        "purchasing_group": "3VH",
        "wo_parts_status": "CAT ONLY",
        "delta_days": 1,
        "total_orders": 0,
        "c_otif_100": 0,
        "c_not_otif_100": 0,
        "c_not_comp_100": 0,
        "pct_otif_100": 0.0,
        "c_otif_sim": 0,
        "c_not_otif_sim": 0,
        "c_not_comp_sim": 0,
        "pct_otif_sim": 0.0,
        "delta_otif_orders": 0,
        "delta_otif_pct": 0.0,
        "parts_fully_issued": 0,
        "parts_partial": 0,
        "parts_unissued": 0,
        "total_target_parts": 0,
        "pct_parts_issued": 0.0,
        "wo_fully_absorbed": 0,
        "wo_partial_absorbed": 0,
        "wo_unabsorbed": 0,
        "pct_wo_absorbed": 0.0,
    }

    # 1. Ekstrak Subtitle & Metadata
    for r in summary_rows[:5]:
        r_str = ' '.join(str(c) for c in r if c is not None)
        if 'Purchasing Group' in r_str:
            pg_match = re.search(r'Purchasing Group\s*=\s*\[(.*?)\]', r_str)
            if pg_match:
                metrics['purchasing_group'] = pg_match.group(1).strip()
            cat_match = re.search(r'Kategori Part\s*=\s*\[(.*?)\]', r_str)
            if cat_match:
                metrics['wo_parts_status'] = cat_match.group(1).strip()
            date_match = re.search(r'Periode Plan\s*=\s*\[(.*?)\]', r_str)
            if date_match:
                metrics['date_filter_label'] = date_match.group(1).strip()
            tot_match = re.search(r'Pembagi Persentase:\s*([\d,]+)', r_str)
            if tot_match:
                metrics['total_orders'] = int(parse_num(tot_match.group(1)))

    # 2. Deteksi Delta Days dari Cards atau Header Tabel
    for r in summary_rows[:12]:
        r_str = ' '.join(str(c) for c in r if c is not None)
        sim_match = re.search(r'SIMULASI (?:OTIF )?H-(\d+)', r_str, re.IGNORECASE)
        if sim_match:
            metrics['delta_days'] = int(sim_match.group(1))
            break

    # 3. Deteksi layout (baru vs lama)
    is_new_layout = False
    for r in summary_rows[:10]:
        r_str = ' '.join(str(c) for c in r if c is not None)
        if '1. SIMULASI OTIF' in r_str or 'STATUS ABSORPTION' in r_str or 'ABSORPTION RATE' in r_str:
            is_new_layout = True
            break

    # 4. Ekstrak data dari baris tabel
    for r in summary_rows:
        if not r:
            continue
        for col_idx, cell in enumerate(r):
            if cell is None:
                continue
            s_val = str(cell).strip()

            # Tabel 1: Simulasi OTIF
            if s_val == 'Complete OTIF' and len(r) > col_idx + 1:
                val_cnt = int(parse_num(r[col_idx + 1]))
                val_pct = parse_num(r[col_idx + 2]) if len(r) > col_idx + 2 else 0.0
                val_pct = val_pct * 100 if val_pct <= 1.0 else val_pct
                if is_new_layout or col_idx >= 3:
                    metrics['c_otif_sim'] = val_cnt
                    metrics['pct_otif_sim'] = val_pct
                else:
                    metrics['c_otif_100'] = val_cnt
                    metrics['pct_otif_100'] = val_pct

            elif s_val == 'Complete Not OTIF' and len(r) > col_idx + 1:
                val_cnt = int(parse_num(r[col_idx + 1]))
                if is_new_layout or col_idx >= 3:
                    metrics['c_not_otif_sim'] = val_cnt
                else:
                    metrics['c_not_otif_100'] = val_cnt

            elif s_val == 'Not Complete' and len(r) > col_idx + 1:
                val_cnt = int(parse_num(r[col_idx + 1]))
                if is_new_layout or col_idx >= 3:
                    metrics['c_not_comp_sim'] = val_cnt
                else:
                    metrics['c_not_comp_100'] = val_cnt

            elif s_val == 'Grand Total' and len(r) > col_idx + 1:
                gt = int(parse_num(r[col_idx + 1]))
                if col_idx < 4 and metrics['total_orders'] == 0:
                    metrics['total_orders'] = gt
                elif col_idx >= 4 and gt > 0:
                    metrics['total_target_parts'] = gt

            # Tabel 2: Status Absorption Parts
            elif s_val == 'Fully Issued' and len(r) > col_idx + 1:
                metrics['parts_fully_issued'] = int(parse_num(r[col_idx + 1]))
                if len(r) > col_idx + 2:
                    p = parse_num(r[col_idx + 2])
                    metrics['pct_parts_issued'] = p * 100 if p <= 1.0 else p
            elif s_val == 'Partial' and len(r) > col_idx + 1:
                metrics['parts_partial'] = int(parse_num(r[col_idx + 1]))
            elif s_val == 'Unissued' and len(r) > col_idx + 1:
                metrics['parts_unissued'] = int(parse_num(r[col_idx + 1]))

            # Tabel 3: Ringkasan Status Absorption Work Order
            elif 'Fully Absorbed' in s_val and len(r) > col_idx + 1:
                metrics['wo_fully_absorbed'] = int(parse_num(r[col_idx + 1]))
                if len(r) > col_idx + 2:
                    p = parse_num(r[col_idx + 2])
                    metrics['pct_wo_absorbed'] = p * 100 if p <= 1.0 else p
            elif 'Partially Absorbed' in s_val and len(r) > col_idx + 1:
                metrics['wo_partial_absorbed'] = int(parse_num(r[col_idx + 1]))
            elif 'Unabsorbed' in s_val and len(r) > col_idx + 1:
                metrics['wo_unabsorbed'] = int(parse_num(r[col_idx + 1]))

    # Validasi & Kalkulasi jika field belum terisi
    if metrics['total_target_parts'] == 0:
        metrics['total_target_parts'] = metrics['parts_fully_issued'] + metrics['parts_partial'] + metrics['parts_unissued']

    if metrics['total_orders'] == 0:
        metrics['total_orders'] = metrics['c_otif_sim'] + metrics['c_not_otif_sim'] + metrics['c_not_comp_sim']

    metrics['complete_orders'] = metrics['c_otif_sim'] + metrics['c_not_otif_sim']

    if metrics['pct_otif_sim'] == 0.0 and metrics['total_orders'] > 0:
        metrics['pct_otif_sim'] = (metrics['c_otif_sim'] / metrics['total_orders']) * 100

    if metrics['pct_wo_absorbed'] == 0.0 and metrics['complete_orders'] > 0:
        metrics['pct_wo_absorbed'] = (metrics['wo_fully_absorbed'] / metrics['complete_orders']) * 100

    if metrics['pct_parts_issued'] == 0.0 and metrics['total_target_parts'] > 0:
        metrics['pct_parts_issued'] = (metrics['parts_fully_issued'] / metrics['total_target_parts']) * 100

    metrics['delta_otif_orders'] = metrics['c_otif_sim'] - metrics['c_otif_100']
    metrics['delta_otif_pct'] = metrics['pct_otif_sim'] - metrics['pct_otif_100']

    return metrics


def generate_otif_daily_email_body(report_summary=None, notes="", report_file_path=None, otif_summary=None, **kwargs):
    """
    Menyusun template HTML email profesional untuk OTIF & Absorption Report Daily:
    - Header bertema Navy & Emerald ('OTIF & ABSORPTION REPORT DAILY - CK BMB')
    - 4 KPI Cards: TOTAL WO (CAT ONLY 3VH), SIMULASI H-1 OTIF (%), ABSORPTION RATE (WO), PART ABSORPTION (%)
    - Tabel 1: Rincian Performa OTIF Work Order (Acuan Simulasi H-1 Hari)
    - Tabel 2: Status Absorption Parts (Part Issue MB51 Movement 261)
    - Tabel 3: Ringkasan Status Absorption Work Order (Fully Absorbed, Partially Absorbed, Unabsorbed)
    - Catatan Pengirim & Info Lampiran Excel
    """
    if report_summary is None and otif_summary is not None:
        report_summary = otif_summary

    timestamp = time.strftime("%d-%b-%Y %H:%M")

    target_file = report_file_path or (report_summary.get("output_path") if report_summary else "")
    summary = dict(report_summary) if report_summary else {}

    if (not summary or summary.get("total_orders", 0) == 0) and target_file and os.path.exists(target_file):
        extracted = extract_otif_metrics_from_excel(target_file)
        if extracted:
            summary = extracted

    total_orders = summary.get("total_orders", summary.get("filtered_orders", 0))
    c_otif_sim = summary.get("c_otif_sim", 0)
    c_not_otif_sim = summary.get("c_not_otif_sim", 0)
    c_not_comp_sim = summary.get("c_not_comp_sim", 0)
    pct_otif_sim = summary.get("pct_otif_sim", 0.0)

    complete_orders = summary.get("complete_orders", c_otif_sim + c_not_otif_sim)
    if complete_orders == 0 and total_orders > 0:
        complete_orders = c_otif_sim + c_not_otif_sim

    wo_fully_absorbed = summary.get("wo_fully_absorbed", 0)
    wo_partial_absorbed = summary.get("wo_partial_absorbed", 0)
    wo_unabsorbed = summary.get("wo_unabsorbed", 0)
    pct_wo_absorbed = summary.get("pct_wo_absorbed", 0.0)

    total_target_parts = summary.get("total_target_parts", 0)
    parts_fully_issued = summary.get("parts_fully_issued", 0)
    parts_partial = summary.get("parts_partial", 0)
    parts_unissued = summary.get("parts_unissued", 0)
    pct_parts_issued = summary.get("pct_parts_issued", 0.0)

    delta_days = summary.get("delta_days", 1)
    pg_target = summary.get("purchasing_group", "3VH")
    wo_target = summary.get("wo_parts_status", "CAT ONLY")

    filename = os.path.basename(target_file) if target_file else "OTIF_Report_Daily.xlsx"

    notes_section = ""
    if notes and str(notes).strip():
        clean_notes = str(notes).strip().replace("\n", "<br>")
        notes_section = f"""
        <div style="background-color: #FEF3C7; border-left: 4px solid #D97706; padding: 10px 14px; margin: 16px 0; border-radius: 4px;">
            <b style="color: #92400E; font-size: 12px;">Catatan Pengirim:</b>
            <div style="color: #78350F; font-size: 13px; margin-top: 4px;">{clean_notes}</div>
        </div>
        """

    denom = total_orders if total_orders > 0 else 1
    pct_not_otif_sim = c_not_otif_sim / denom * 100
    pct_not_comp_sim = c_not_comp_sim / denom * 100

    denom_comp = complete_orders if complete_orders > 0 else 1
    pct_wo_partial = wo_partial_absorbed / denom_comp * 100
    pct_wo_unabsorbed = wo_unabsorbed / denom_comp * 100

    denom_parts = total_target_parts if total_target_parts > 0 else 1
    pct_parts_partial = parts_partial / denom_parts * 100
    pct_parts_unissued = parts_unissued / denom_parts * 100

    date_filter_label = summary.get("date_filter_label")
    has_date_filter = bool(date_filter_label and date_filter_label != "Semua Tanggal")
    period_badge_suffix = f" &bull; {html.escape(date_filter_label)}" if has_date_filter else ""
    period_info_sub = f" &bull; Periode Plan: <b>{html.escape(date_filter_label)}</b>" if has_date_filter else ""
    period_card_sub = f"<br><span style='font-size: 10px; color: #1D4ED8;'>({html.escape(date_filter_label)})</span>" if has_date_filter else ""

    has_absorption = bool(total_target_parts > 0 or wo_fully_absorbed > 0 or parts_fully_issued > 0)

    # Susunan 4 KPI Cards
    if has_absorption:
        kpi_cards_html = f"""
        <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin: 16px 0;">
            <tr>
                <td style="width: 25%; background-color: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #1D4ED8; text-transform: uppercase;">TOTAL WO ({wo_target} {pg_target})</div>
                    <div style="font-size: 20px; font-weight: bold; color: #1E3A8A; margin: 5px 0;">{total_orders:,}</div>
                    <div style="font-size: 11px; color: #64748B;">Distinct Work Order{period_card_sub}</div>
                </td>
                <td style="width: 25%; background-color: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #15803D; text-transform: uppercase;">🟢 OTIF RATE (H-{delta_days})</div>
                    <div style="font-size: 20px; font-weight: bold; color: #166534; margin: 5px 0;">{pct_otif_sim:.2f}%</div>
                    <div style="font-size: 11px; color: #15803D; font-weight: 600;">{c_otif_sim:,} WO OTIF</div>
                </td>
                <td style="width: 25%; background-color: #F0F9FF; border: 1px solid #BAE6FD; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #0284C7; text-transform: uppercase;">🔵 ABSORPTION RATE (WO)</div>
                    <div style="font-size: 20px; font-weight: bold; color: #0369A1; margin: 5px 0;">{pct_wo_absorbed:.2f}%</div>
                    <div style="font-size: 11px; color: #0284C7; font-weight: 600;">{wo_fully_absorbed:,} / {complete_orders:,} Complete WO</div>
                </td>
                <td style="width: 25%; background-color: #F5F3FF; border: 1px solid #DDD6FE; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #7C3AED; text-transform: uppercase;">🟣 PART ABSORPTION</div>
                    <div style="font-size: 20px; font-weight: bold; color: #6D28D9; margin: 5px 0;">{pct_parts_issued:.2f}%</div>
                    <div style="font-size: 11px; color: #7C3AED; font-weight: 600;">{parts_fully_issued:,} / {total_target_parts:,} Parts</div>
                </td>
            </tr>
        </table>
        """
    else:
        kpi_cards_html = f"""
        <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin: 16px 0;">
            <tr>
                <td style="width: 25%; background-color: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #1D4ED8; text-transform: uppercase;">TOTAL WO ({wo_target} {pg_target})</div>
                    <div style="font-size: 20px; font-weight: bold; color: #1E3A8A; margin: 5px 0;">{total_orders:,}</div>
                    <div style="font-size: 11px; color: #64748B;">Distinct Work Order{period_card_sub}</div>
                </td>
                <td style="width: 25%; background-color: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #15803D; text-transform: uppercase;">🟢 OTIF RATE (H-{delta_days})</div>
                    <div style="font-size: 20px; font-weight: bold; color: #166534; margin: 5px 0;">{pct_otif_sim:.2f}%</div>
                    <div style="font-size: 11px; color: #15803D; font-weight: 600;">{c_otif_sim:,} WO OTIF</div>
                </td>
                <td style="width: 25%; background-color: #FEF2F2; border: 1px solid #FECACA; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #B91C1C; text-transform: uppercase;">🔴 NOT OTIF (H-{delta_days})</div>
                    <div style="font-size: 20px; font-weight: bold; color: #991B1B; margin: 5px 0;">{pct_not_otif_sim:.2f}%</div>
                    <div style="font-size: 11px; color: #B91C1C; font-weight: 600;">{c_not_otif_sim:,} WO Not OTIF</div>
                </td>
                <td style="width: 25%; background-color: #FFFBEB; border: 1px solid #FDE68A; border-radius: 6px; padding: 14px 10px; text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; color: #B45309; text-transform: uppercase;">🟡 NOT COMPLETE</div>
                    <div style="font-size: 20px; font-weight: bold; color: #92400E; margin: 5px 0;">{pct_not_comp_sim:.2f}%</div>
                    <div style="font-size: 11px; color: #92400E; font-weight: 600;">{c_not_comp_sim:,} WO Pending</div>
                </td>
            </tr>
        </table>
        """

    # Bagian Tabel Absorption (jika ada data)
    absorption_tables_html = ""
    if has_absorption:
        absorption_tables_html = f"""
        <!-- Tabel 2: Status Absorption Parts -->
        <div style="margin-top: 18px; margin-bottom: 20px;">
            <div style="font-size: 13px; font-weight: bold; color: #0D9488; margin-bottom: 8px;">
                📦 2. Status Absorption Parts (Complete WO: {complete_orders:,} WO):
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #CBD5E1; border-radius: 4px; overflow: hidden;">
                <tr style="background-color: #0D9488; color: #FFFFFF;">
                    <th style="padding: 10px 14px; text-align: left; color: #FFFFFF;">Status Part Issue (MB51 Movement 261)</th>
                    <th style="padding: 10px 14px; text-align: right; color: #FFFFFF;">Jumlah Parts</th>
                    <th style="padding: 10px 14px; text-align: right; color: #FFFFFF;">Persentase (%)</th>
                </tr>
                <tr style="background-color: #F0FDF4; border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 14px; font-weight: 600; color: #166534;">🟢 Fully Issued</td>
                    <td style="padding: 9px 14px; text-align: right; font-weight: bold; color: #166534;">{parts_fully_issued:,} Part</td>
                    <td style="padding: 9px 14px; text-align: right; font-weight: bold; color: #166534;">{pct_parts_issued:.2f}%</td>
                </tr>
                <tr style="background-color: #FEF3C7; border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 14px; color: #92400E;">🟡 Partial</td>
                    <td style="padding: 9px 14px; text-align: right; color: #92400E;">{parts_partial:,} Part</td>
                    <td style="padding: 9px 14px; text-align: right; color: #92400E;">{pct_parts_partial:.2f}%</td>
                </tr>
                <tr style="background-color: #FEF2F2; border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 14px; color: #991B1B;">🔴 Unissued</td>
                    <td style="padding: 9px 14px; text-align: right; color: #991B1B;">{parts_unissued:,} Part</td>
                    <td style="padding: 9px 14px; text-align: right; color: #991B1B;">{pct_parts_unissued:.2f}%</td>
                </tr>
                <tr style="background-color: #E2E8F0; font-weight: bold;">
                    <td style="padding: 10px 14px; color: #1E293B;">Grand Total</td>
                    <td style="padding: 10px 14px; text-align: right; color: #1E293B;">{total_target_parts:,} Part</td>
                    <td style="padding: 10px 14px; text-align: right; color: #1E293B;">100.00%</td>
                </tr>
            </table>
        </div>

        <!-- Tabel 3: Ringkasan Status Absorption Work Order -->
        <div style="margin-top: 18px; margin-bottom: 22px;">
            <div style="font-size: 13px; font-weight: bold; color: #1E3A8A; margin-bottom: 8px;">
                📋 3. Ringkasan Status Absorption Work Order (Complete WO: {complete_orders:,} WO):
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #CBD5E1; border-radius: 4px; overflow: hidden;">
                <tr style="background-color: #1E3A8A; color: #FFFFFF;">
                    <th style="padding: 10px 14px; text-align: left; color: #FFFFFF;">Kategori WO Absorption</th>
                    <th style="padding: 10px 14px; text-align: right; color: #FFFFFF;">Jumlah WO</th>
                    <th style="padding: 10px 14px; text-align: right; color: #FFFFFF;">Persentase WO</th>
                    <th style="padding: 10px 14px; text-align: left; color: #FFFFFF;">Status Kesiapan Eksekusi</th>
                </tr>
                <tr style="background-color: #F0FDF4; border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 14px; font-weight: 600; color: #166534;">🟢 Fully Absorbed (100% Parts)</td>
                    <td style="padding: 9px 14px; text-align: right; font-weight: bold; color: #166534;">{wo_fully_absorbed:,} WO</td>
                    <td style="padding: 9px 14px; text-align: right; font-weight: bold; color: #166534;">{pct_wo_absorbed:.2f}%</td>
                    <td style="padding: 9px 14px; color: #166534; font-size: 11px;">Full Issued</td>
                </tr>
                <tr style="background-color: #FEF3C7; border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 14px; color: #92400E;">🟡 Partially Absorbed</td>
                    <td style="padding: 9px 14px; text-align: right; color: #92400E;">{wo_partial_absorbed:,} WO</td>
                    <td style="padding: 9px 14px; text-align: right; color: #92400E;">{pct_wo_partial:.2f}%</td>
                    <td style="padding: 9px 14px; color: #92400E; font-size: 11px;">Issued Sebagian</td>
                </tr>
                <tr style="background-color: #FEF2F2; border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 14px; color: #991B1B;">🔴 Unabsorbed (0% Parts)</td>
                    <td style="padding: 9px 14px; text-align: right; color: #991B1B;">{wo_unabsorbed:,} WO</td>
                    <td style="padding: 9px 14px; text-align: right; color: #991B1B;">{pct_wo_unabsorbed:.2f}%</td>
                    <td style="padding: 9px 14px; color: #991B1B; font-size: 11px;">Belum Ada Issued</td>
                </tr>
                <tr style="background-color: #E2E8F0; font-weight: bold;">
                    <td style="padding: 10px 14px; color: #1E293B;">Grand Total (Complete WO)</td>
                    <td style="padding: 10px 14px; text-align: right; color: #1E293B;">{complete_orders:,} WO</td>
                    <td style="padding: 10px 14px; text-align: right; color: #1E293B;">100.00%</td>
                    <td style="padding: 10px 14px; color: #1E293B;">-</td>
                </tr>
            </table>
            <div style="font-size: 11px; color: #64748B; font-style: italic; margin-top: 6px;">
                *Catatan: Evaluasi Absorption Rate khusus Work Order status Complete ({complete_orders:,} WO). Sebanyak {c_not_comp_sim:,} WO Not Complete (Pending) tidak dihitung dalam absorption.
            </div>
        </div>
        """

    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
    </head>
    <body style="margin: 0; padding: 12px; background-color: #F8FAFC; font-family: 'Segoe UI', Arial, sans-serif;">
        <div style="max-width: 680px; margin: 0 auto; background-color: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.06);">
            
            <!-- Header Banner (Warna Solid Navy & Royal Blue, 100% didukung Outlook tanpa menyempitkan layout) -->
            <div style="background-color: #1E3A8A; color: #FFFFFF; padding: 22px 24px;">
                <div style="display: inline-block; background-color: #2563EB; color: #FFFFFF; font-size: 11px; font-weight: bold; padding: 4px 10px; border-radius: 4px; letter-spacing: 0.5px; text-transform: uppercase; margin-bottom: 8px;">
                    🎯 DAILY REPORT &bull; CAT ONLY (3VH){period_badge_suffix}
                </div>
                <h2 style="margin: 0; font-size: 20px; font-weight: 700; color: #FFFFFF; letter-spacing: -0.3px;">
                    OTIF & ABSORPTION REPORT DAILY - CK BMB
                </h2>
                <div style="font-size: 12px; color: #93C5FD; margin-top: 6px;">
                    Update Performa OTIF & Absorption Parts (MB51){period_info_sub} &bull; {timestamp}
                </div>
            </div>

            <!-- Body Content -->
            <div style="padding: 22px 24px;">
                <p style="font-size: 13px; color: #334155; line-height: 1.5; margin: 0 0 16px 0;">
                    Dear All,<br><br>
                    Berikut Update Performa OTIF dan Status Absorption Parts Work Order (CAT ONLY 3VH) hari ini:
                </p>

                <!-- KPI Cards (4 Cards) -->
                {kpi_cards_html}

                {notes_section}

                <!-- Tabel 1: Performa OTIF H-1 -->
                <div style="margin-top: 18px; margin-bottom: 20px;">
                    <div style="font-size: 13px; font-weight: bold; color: #1E3A8A; margin-bottom: 8px;">
                        📊 1. Rincian Performa OTIF Work Order (Acuan Toleransi H-{delta_days} Hari):
                    </div>
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #CBD5E1; border-radius: 4px; overflow: hidden;">
                        <tr style="background-color: #1E3A8A; color: #FFFFFF;">
                            <th style="padding: 10px 14px; text-align: left; color: #FFFFFF;">Status OTIF</th>
                            <th style="padding: 10px 14px; text-align: right; color: #FFFFFF;">Jumlah Work Order</th>
                            <th style="padding: 10px 14px; text-align: right; color: #FFFFFF;">Persentase (%)</th>
                        </tr>
                        <tr style="background-color: #F0FDF4; border-bottom: 1px solid #E2E8F0;">
                            <td style="padding: 9px 14px; font-weight: 600; color: #166534;">🟢 Complete OTIF</td>
                            <td style="padding: 9px 14px; text-align: right; font-weight: bold; color: #166534;">{c_otif_sim:,} WO</td>
                            <td style="padding: 9px 14px; text-align: right; font-weight: bold; color: #166534;">{pct_otif_sim:.2f}%</td>
                        </tr>
                        <tr style="background-color: #FEF2F2; border-bottom: 1px solid #E2E8F0;">
                            <td style="padding: 9px 14px; color: #991B1B;">🔴 Complete Not OTIF</td>
                            <td style="padding: 9px 14px; text-align: right; color: #991B1B;">{c_not_otif_sim:,} WO</td>
                            <td style="padding: 9px 14px; text-align: right; color: #991B1B;">{pct_not_otif_sim:.2f}%</td>
                        </tr>
                        <tr style="background-color: #FFFBEB; border-bottom: 1px solid #E2E8F0;">
                            <td style="padding: 9px 14px; color: #92400E;">🟡 Not Complete (Pending)</td>
                            <td style="padding: 9px 14px; text-align: right; color: #92400E;">{c_not_comp_sim:,} WO</td>
                            <td style="padding: 9px 14px; text-align: right; color: #92400E;">{pct_not_comp_sim:.2f}%</td>
                        </tr>
                        <tr style="background-color: #E2E8F0; font-weight: bold;">
                            <td style="padding: 10px 14px; color: #1E293B;">Grand Total</td>
                            <td style="padding: 10px 14px; text-align: right; color: #1E293B;">{total_orders:,} WO</td>
                            <td style="padding: 10px 14px; text-align: right; color: #1E293B;">100.00%</td>
                        </tr>
                    </table>
                </div>

                {absorption_tables_html}

                <!-- Attachment Note -->
                <div style="margin-top: 18px; padding: 12px 14px; background-color: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 6px; font-size: 12px; color: #4B5563;">
                    &#128206; <b>File Laporan Terlampir:</b> <span style="color: #1E3A8A; font-weight: bold;">{filename}</span><br>
                    <span style="font-size: 11px; color: #6B7280; margin-top: 3px; display: inline-block;">
                        Rincian sheet <b>Summary</b>, <b>WO Analysis ({total_orders:,} WO)</b> dengan status Absorption Rate & True Date, serta seluruh transaksi <b>RAW</b> dapat dilihat pada lampiran Excel.
                    </span>
                </div>

                <div style="margin-top: 24px; border-top: 1px solid #E2E8F0; padding-top: 12px; font-size: 11px; color: #94A3B8; text-align: right;">
                    Otomasi dikirim melalui <b>Kermen Tools</b>
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return html_content


def get_outlook_signature(preferred_name="yusril"):
    r"""
    Membaca signature resmi Outlook pengguna dari folder %APPDATA%\Microsoft\Signatures.
    Memprioritaskan file .htm yang mengandung preferred_name (misal: 'yusril').
    """
    sig_dir = os.path.join(os.environ.get('APPDATA', ''), 'Microsoft', 'Signatures')
    if not os.path.exists(sig_dir):
        return ""

    candidates = glob.glob(os.path.join(sig_dir, "*.htm"))
    if not candidates:
        return ""

    matched_file = None
    for c in candidates:
        fname = os.path.basename(c).lower()
        if preferred_name.lower() in fname and "dluar" not in fname:
            matched_file = c
            break

    if not matched_file:
        for c in candidates:
            if "dluar" not in os.path.basename(c).lower():
                matched_file = c
                break
        if not matched_file and candidates:
            matched_file = candidates[0]

    try:
        for enc in ['utf-8', 'cp1252', 'latin-1']:
            try:
                with open(matched_file, 'r', encoding=enc) as f:
                    content = f.read()
                body_match = re.search(r'<body[^>]*>(.*?)</body>', content, re.IGNORECASE | re.DOTALL)
                if body_match:
                    return body_match.group(1).strip()
                return content.strip()
            except UnicodeDecodeError:
                continue
    except Exception as e:
        print(f"[Warning] Gagal membaca signature file: {e}")

    return ""


def generate_sto_email_body(sto_result=None, message_text=None, notes=None, include_signature=False):
    """
    Menyusun isi body email STO sederhana, bersih, dan profesional:
    'Dear Mba Carinda, Pak Ari,
    Mohon dibantu STO file terlampir untuk pemenuhan Reservasi CK.'
    """
    text_content = message_text or notes or getattr(config, "DEFAULT_STO_EMAIL_MESSAGE", "Dear Mba Carinda, Pak Ari,\n\nMohon dibantu STO file terlampir untuk pemenuhan Reservasi CK.")

    lines = [line.strip() for line in str(text_content).strip().splitlines()]

    # Format paragraf HTML rapi (font Calibri 11pt standar email Outlook)
    paragraphs = []
    curr_lines = []
    for line in lines:
        if not line:
            if curr_lines:
                paragraphs.append("<br>".join(curr_lines))
                curr_lines = []
        else:
            curr_lines.append(html.escape(line))
    if curr_lines:
        paragraphs.append("<br>".join(curr_lines))

    html_paragraphs = "".join([
        f'<p class="MsoNormal" style="font-family: Calibri, Aptos, Arial, sans-serif; font-size: 11pt; color: #000000; margin: 0 0 10pt 0; line-height: 1.35;">{p}</p>'
        for p in paragraphs
    ])

    sig_html = ""
    if include_signature:
        sig = get_outlook_signature("yusril")
        if sig:
            sig_html = f'<div style="margin-top: 16pt;">{sig}</div>'

    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body style="font-family: Calibri, Aptos, Arial, sans-serif; font-size: 11pt; color: #000000; margin: 0; padding: 0;">
    {html_paragraphs}
    {sig_html}
</body>
</html>"""
    return html_content


def send_sto_email_outlook(to, cc="", subject="", body_html="", attachment_paths=None, display=True, send=False):
    """
    Membuat email pengajuan STO di Microsoft Outlook Desktop dengan teks sederhana
    dan signature resmi bawaan Outlook (yusril).
    """
    pythoncom.CoInitialize()
    try:
        try:
            outlook = win32com.client.Dispatch("Outlook.Application")
        except Exception as e:
            raise RuntimeError(
                f"Tidak dapat terhubung ke Microsoft Outlook: {str(e)}\n\n"
                "Pastikan aplikasi Microsoft Outlook sudah terinstall dan telah dibuka di komputer Anda."
            )

        mail = outlook.CreateItem(0)  # 0 = olMailItem

        if to:
            to_formatted = "; ".join([e.strip() for e in str(to).replace(",", ";").split(";") if e.strip()])
            mail.To = to_formatted

        if cc:
            cc_formatted = "; ".join([e.strip() for e in str(cc).replace(",", ";").split(";") if e.strip()])
            mail.CC = cc_formatted

        if subject:
            mail.Subject = str(subject).strip()

        if attachment_paths:
            if isinstance(attachment_paths, str):
                attachment_paths = [attachment_paths]
            for att in attachment_paths:
                if att and os.path.exists(att):
                    mail.Attachments.Add(os.path.abspath(att))

        # Panggil Display() terlebih dahulu agar Outlook otomatis memuat signature bawaan (yusril)
        mail.Display()

        existing_body = mail.HTMLBody or ""

        # Ambil konten paragraf saja jika body_html dibungkus tag <body>
        inner_content = body_html.strip()
        body_match = re.search(r'<body[^>]*>(.*?)</body>', inner_content, re.IGNORECASE | re.DOTALL)
        if body_match:
            inner_content = body_match.group(1).strip()

        # Sisipkan teks pesan sederhana sebelum signature bawaan Outlook
        if existing_body and ("<div class=wordsection1>" in existing_body.lower() or "<body" in existing_body.lower()):
            if "<div class=wordsection1>" in existing_body.lower():
                # Bersihkan spasi kosong default di atas WordSection1 lalu sisipkan pesan
                mail.HTMLBody = re.sub(
                    r'(<div class=WordSection1>)(?:\s*<p[^>]*><o:p>&nbsp;</o:p></p>)*',
                    r'\1' + inner_content + '<p class="MsoNormal"><o:p>&nbsp;</o:p></p>',
                    existing_body,
                    count=1,
                    flags=re.IGNORECASE
                )
            else:
                mail.HTMLBody = re.sub(
                    r'(<body[^>]*>)',
                    r'\1' + inner_content + '<br>',
                    existing_body,
                    count=1,
                    flags=re.IGNORECASE
                )
        else:
            # Fallback jika Outlook tidak otomatis memasang signature:
            # Muat signature resmi yusril dari folder Microsoft/Signatures
            sig_file_html = get_outlook_signature("yusril")
            mail.HTMLBody = f"""<!DOCTYPE html>
<html>
<body style="font-family: Calibri, Aptos, Arial, sans-serif; font-size: 11pt; color: #000000;">
{inner_content}
<br><br>
{sig_file_html}
</body>
</html>"""

        if send:
            mail.Send()
            return {"status": "sent", "mode": "send"}
        else:
            return {"status": "displayed", "mode": "display"}

    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def generate_turnover_email_body(report_summary=None, notes="", report_file_path=None):
    """
    Menyusun template HTML email profesional untuk Laporan Analisa Turn Over Parts:
    - Header bertema Navy Eksekutif ('PARTS INVENTORY TURN OVER ANALYSIS REPORT')
    - 4 KPI Cards: ACTUAL TO (TURNS), BUDGET TO, MONTHS OF SUPPLY (MOS), STATUS EVALUASI
    - Tabel 1: Ringkasan Level Stok & Rekomendasi (Suggest Ideal & Minimal)
    - Tabel 2: Tren Bulanan Performa Turn Over & Level Stok
    - Rekomendasi Strategis & Tindak Lanjut Manajerial
    - Catatan Pengirim & Info Lampiran Excel
    - Signature Outlook Resmi
    """
    from modules.turnover_helper import extract_turnover_metrics_from_excel

    timestamp = time.strftime("%d-%b-%Y %H:%M")
    target_file = report_file_path or (report_summary.get("output_path") if report_summary else "")
    summary = dict(report_summary) if report_summary else {}

    if (not summary or summary.get("actual_to", 0) == 0) and target_file and os.path.exists(target_file):
        extracted = extract_turnover_metrics_from_excel(target_file)
        if extracted:
            summary = extracted

    latest_month = summary.get("latest_month", time.strftime("%b %Y"))
    actual_to = float(summary.get("actual_to", 0.0) or 0.0)
    budget_to = float(summary.get("budget_to", 3.00) or 3.00)
    gap_to = float(summary.get("gap_to", actual_to - budget_to) or 0.0)
    mos = float(summary.get("mos", (12.0 / actual_to) if actual_to > 0 else 0.0) or 0.0)
    doh = float(summary.get("doh", (365.0 / actual_to) if actual_to > 0 else 0.0) or 0.0)
    total_inv = float(summary.get("total_inventory", 0.0) or 0.0)
    avg_stock_6m = float(summary.get("avg_stock_6m", 0.0) or 0.0)
    cogs_monthly = float(summary.get("cogs_monthly", 0.0) or 0.0)
    cogs_12m = float(summary.get("cogs_12m", 0.0) or 0.0)
    sug_ideal = float(summary.get("suggest_stock_ideal", (cogs_12m / budget_to) if budget_to > 0 else 0.0) or 0.0)
    sug_min = float(summary.get("suggest_stock_min", (cogs_12m / 12.0) * 2.5 if cogs_12m > 0 else 0.0) or 0.0)
    variance = float(summary.get("stock_variance", total_inv - sug_ideal) or (total_inv - sug_ideal))
    status_label = summary.get("status_label", "OPTIMAL & SEHAT" if actual_to >= budget_to else "OVERSTOCK")
    status_badge_color = summary.get("status_badge_color", "#16A34A" if actual_to >= budget_to else "#DC2626")
    recommendation = summary.get("recommendation", "")

    filename = os.path.basename(target_file) if target_file else "Laporan_Turnover_Parts.xlsx"

    # Notes section
    notes_section = ""
    if notes and str(notes).strip():
        clean_notes = str(notes).strip().replace("\n", "<br>")
        notes_section = f"""
        <div style="background-color: #FEF3C7; border-left: 4px solid #D97706; padding: 10px 14px; margin: 16px 0; border-radius: 4px;">
            <b style="color: #92400E; font-size: 12px;">Catatan Pengirim:</b>
            <div style="color: #78350F; font-size: 13px; margin-top: 4px;">{clean_notes}</div>
        </div>
        """

    def try_float(v):
        if v is None:
            return 0.0
        try:
            return float(str(v).replace(",", ""))
        except Exception:
            return 0.0

    def fmt_val(v, dec=0):
        if v is None or v == "-":
            return "-"
        try:
            vf = float(str(v).replace(",", ""))
            return f"{vf:,.{dec}f}"
        except Exception:
            return str(v)

    def fmt_gap(v):
        if v is None or v == "-":
            return "-"
        try:
            vf = float(str(v).replace(",", ""))
            return f"{vf:+.2f}"
        except Exception:
            return str(v)

    # Monthly rows table HTML
    monthly_rows = summary.get("monthly_rows", [])
    tbl_rows_html = ""
    if monthly_rows:
        display_rows = monthly_rows[-12:]
        for idx, r in enumerate(display_rows):
            bg = "#F8FAFC" if idx % 2 == 1 else "#FFFFFF"
            m_txt = r.get("Bulan - Tahun", r.get("Bulan", "-"))
            t_inv = r.get("Total Inventory", 0.0)
            a_6m = r.get("Avg Stock 6M", 0.0)
            c_bln = r.get("COGS Bulanan", 0.0)
            c_12 = r.get("COGS 12M", 0.0)
            act = r.get("TO RM12 Bulan", r.get("Actual TO", 0.0))
            bud = r.get("Budget TO", 0.0)
            gp = r.get("Gap TO (RM12)", r.get("Gap TO", 0.0))
            m_mos = r.get("MOS RM12", r.get("MOS (Bulan)", 0.0))
            s_idl = r.get("Suggest Stok Ideal", 0.0)
            s_mn = r.get("Suggest Stok Minimal", 0.0)
            st_eval = r.get("Status Evaluasi", "-")

            gap_col = "#16A34A" if (try_float(gp) >= 0) else "#DC2626"
            tbl_rows_html += f"""
            <tr style="background-color: {bg}; border-bottom: 1px solid #E2E8F0;">
                <td style="padding: 7px 6px; text-align: center; font-weight: bold; color: #1E293B;">{m_txt}</td>
                <td style="padding: 7px 6px; text-align: right; color: #334155;">{fmt_val(t_inv)}</td>
                <td style="padding: 7px 6px; text-align: right; color: #334155;">{fmt_val(a_6m)}</td>
                <td style="padding: 7px 6px; text-align: right; color: #334155;">{fmt_val(c_bln)}</td>
                <td style="padding: 7px 6px; text-align: right; color: #334155;">{fmt_val(c_12)}</td>
                <td style="padding: 7px 6px; text-align: center; font-weight: bold; color: #1E3A8A;">{fmt_val(act, dec=2)}x</td>
                <td style="padding: 7px 6px; text-align: center; color: #64748B;">{fmt_val(bud, dec=2)}x</td>
                <td style="padding: 7px 6px; text-align: center; font-weight: bold; color: {gap_col};">{fmt_gap(gp)}</td>
                <td style="padding: 7px 6px; text-align: center; color: #334155;">{fmt_val(m_mos, dec=1)}m</td>
                <td style="padding: 7px 6px; text-align: right; color: #2563EB; font-weight: 500;">{fmt_val(s_idl)}</td>
                <td style="padding: 7px 6px; text-align: right; color: #0D9488; font-weight: 500;">{fmt_val(s_mn)}</td>
                <td style="padding: 7px 6px; text-align: center; font-size: 11px;">{st_eval}</td>
            </tr>
            """

    # Section table if monthly rows available
    monthly_table_section = ""
    if tbl_rows_html:
        monthly_table_section = f"""
        <div style="margin-top: 24px;">
            <h3 style="color: #1E3A8A; font-size: 14px; margin-bottom: 8px; padding-bottom: 4px; border-bottom: 2px solid #DBEAFE;">
                📅 TREN HISTORI BULANAN TURN OVER RM12 & LEVEL INVENTORY
            </h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-top: 8px;">
                <thead>
                    <tr style="background-color: #1E3A8A; color: #FFFFFF;">
                        <th style="padding: 8px 5px; text-align: center;">Bulan</th>
                        <th style="padding: 8px 5px; text-align: right;">Total Stok</th>
                        <th style="padding: 8px 5px; text-align: right;">Avg 6M</th>
                        <th style="padding: 8px 5px; text-align: right;">COGS Bln</th>
                        <th style="padding: 8px 5px; text-align: right;">COGS 12M</th>
                        <th style="padding: 8px 5px; text-align: center;">TO RM12</th>
                        <th style="padding: 8px 5px; text-align: center;">Budget</th>
                        <th style="padding: 8px 5px; text-align: center;">Gap</th>
                        <th style="padding: 8px 5px; text-align: center;">MOS RM12</th>
                        <th style="padding: 8px 5px; text-align: right;">Suggest Ideal</th>
                        <th style="padding: 8px 5px; text-align: right;">Suggest Min</th>
                        <th style="padding: 8px 5px; text-align: center;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    {tbl_rows_html}
                </tbody>
            </table>
        </div>
        """

    gap_display = f"{gap_to:+.2f}"
    gap_color = "#16A34A" if gap_to >= 0 else "#DC2626"
    var_label = "Surplus (Perlu Dirampingkan)" if variance > 0 else "Optimal & Lean (Efisiensi Modal)"
    var_badge_bg = "#FEE2E2" if variance > 0 else "#DCFCE7"
    var_badge_fg = "#991B1B" if variance > 0 else "#166534"

    sig_html = get_outlook_signature("yusril") or ""

    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body style="font-family: Calibri, Aptos, 'Segoe UI', Arial, sans-serif; font-size: 11pt; color: #1E293B; margin: 0; padding: 12px; background-color: #F8FAFC;">
    <div style="max-width: 960px; margin: 0 auto; background-color: #FFFFFF; border-radius: 8px; border: 1px solid #E2E8F0; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
        
        <!-- HEADER BANNER -->
        <div style="background: linear-gradient(135deg, #1E3A8A 0%, #1E40AF 100%); color: #FFFFFF; padding: 18px 22px; border-radius: 6px; margin-bottom: 20px;">
            <div style="font-size: 18px; font-weight: bold; letter-spacing: 0.5px;">📈 PARTS INVENTORY TURN OVER ANALYSIS REPORT</div>
            <div style="font-size: 13px; color: #BFDBFE; margin-top: 4px;">
                Plant 1346 &bull; Periode Evaluasi: <b>{latest_month}</b> &bull; Dibuat: {timestamp}
            </div>
            <div style="font-size: 11px; color: #93C5FD; margin-top: 2px;">
                Metrik Evaluasi: <b>TO RM12</b> (Total COGS 12 Bulan / Rata-rata Total Stock 6 Bulan)
            </div>
        </div>

        {notes_section}

        <!-- 4 TOP KPI CARDS -->
        <table style="width: 100%; border-collapse: separate; border-spacing: 8px; margin: 16px 0;">
            <tr>
                <td style="width: 25%; background-color: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 6px; padding: 12px 10px; text-align: center;">
                    <div style="font-size: 10px; font-weight: bold; color: #1D4ED8; text-transform: uppercase;">ACTUAL TO (RM12)</div>
                    <div style="font-size: 24px; font-weight: bold; color: #1E3A8A; margin: 4px 0;">{actual_to:.2f}</div>
                    <div style="font-size: 11px; color: #2563EB;">MOS: ~{mos:.2f} Bln</div>
                </td>
                <td style="width: 25%; background-color: #F8FAFC; border: 1px solid #CBD5E1; border-radius: 6px; padding: 12px 10px; text-align: center;">
                    <div style="font-size: 10px; font-weight: bold; color: #475569; text-transform: uppercase;">TARGET BUDGET TO</div>
                    <div style="font-size: 24px; font-weight: bold; color: #334155; margin: 4px 0;">{budget_to:.2f}</div>
                    <div style="font-size: 11px; color: #64748B;">Target Korporat</div>
                </td>
                <td style="width: 25%; background-color: {'#F0FDF4' if gap_to >= 0 else '#FEF2F2'}; border: 1px solid {'#BBF7D0' if gap_to >= 0 else '#FECACA'}; border-radius: 6px; padding: 12px 10px; text-align: center;">
                    <div style="font-size: 10px; font-weight: bold; color: {gap_color}; text-transform: uppercase;">GAP TO (RM12)</div>
                    <div style="font-size: 24px; font-weight: bold; color: {gap_color}; margin: 4px 0;">{gap_display}</div>
                    <div style="font-size: 11px; color: {gap_color};">{'Melampaui Target' if gap_to >= 0 else 'Di Bawah Target'}</div>
                </td>
                <td style="width: 25%; background-color: #F1F5F9; border: 1px solid #CBD5E1; border-radius: 6px; padding: 12px 10px; text-align: center;">
                    <div style="font-size: 10px; font-weight: bold; color: #475569; text-transform: uppercase;">STATUS EVALUASI</div>
                    <div style="display: inline-block; background-color: {status_badge_color}; color: #FFFFFF; font-size: 11px; font-weight: bold; padding: 4px 8px; border-radius: 4px; margin-top: 8px;">
                        {status_label}
                    </div>
                </td>
            </tr>
        </table>

        <!-- RINGKASAN LEVEL STOK & SUGGESTION TABLE -->
        <div style="margin-top: 20px;">
            <h3 style="color: #1E3A8A; font-size: 14px; margin-bottom: 8px; padding-bottom: 4px; border-bottom: 2px solid #DBEAFE;">
                📊 RINGKASAN POSISI STOK & REKOMENDASI LEVEL INVENTORY
            </h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                <tr style="border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 12px; font-weight: bold; width: 45%;">Total Stok Terkini ({latest_month}):</td>
                    <td style="padding: 9px 12px; font-weight: bold; color: #1E293B; text-align: right; width: 25%;">USD {total_inv:,.0f}</td>
                    <td style="padding: 9px 12px; color: #64748B; font-size: 11px; width: 30%;">Total akumulasi Parts SOH, GIT, GINI, Core PX</td>
                </tr>
                <tr style="border-bottom: 1px solid #E2E8F0; background-color: #F8FAFC;">
                    <td style="padding: 9px 12px; font-weight: bold;">Rata-rata Stok 6 Bulan Terakhir:</td>
                    <td style="padding: 9px 12px; font-weight: bold; color: #0D9488; text-align: right;">USD {avg_stock_6m:,.0f}</td>
                    <td style="padding: 9px 12px; color: #64748B; font-size: 11px;">Dasar pembagi penentuan Turn Over (TO)</td>
                </tr>
                <tr style="border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 12px; font-weight: bold;">Total COGS 12 Bulan (Run-rate):</td>
                    <td style="padding: 9px 12px; font-weight: bold; color: #D97706; text-align: right;">USD {cogs_12m:,.0f}</td>
                    <td style="padding: 9px 12px; color: #64748B; font-size: 11px;">Akumulasi 12 bulan pengeluaran suku cadang</td>
                </tr>
                <tr style="border-bottom: 1px solid #BFDBFE; background-color: #EFF6FF;">
                    <td style="padding: 10px 12px; font-weight: bold; color: #1D4ED8;">🎯 Suggest Inventory Ideal (Target Budget {budget_to:.2f}):</td>
                    <td style="padding: 10px 12px; font-weight: bold; color: #1D4ED8; font-size: 14px; text-align: right;">USD {sug_ideal:,.0f}</td>
                    <td style="padding: 10px 12px; color: #1E40AF; font-size: 11px;">Batas maksimal stok rata-rata agar target budget tercapai</td>
                </tr>
                <tr style="border-bottom: 1px solid #A7F3D0; background-color: #ECFDF5;">
                    <td style="padding: 10px 12px; font-weight: bold; color: #065F46;">🛡️ Suggest Inventory Minimal (Safe Buffer 2.5 Bulan):</td>
                    <td style="padding: 10px 12px; font-weight: bold; color: #065F46; font-size: 14px; text-align: right;">USD {sug_min:,.0f}</td>
                    <td style="padding: 10px 12px; color: #047857; font-size: 11px;">Ambang batas minimum stok aman pencegah kehabisan suku cadang</td>
                </tr>
                <tr style="border-bottom: 1px solid #E2E8F0;">
                    <td style="padding: 9px 12px; font-weight: bold;">Selisih Stok Terkini vs Ideal:</td>
                    <td style="padding: 9px 12px; font-weight: bold; text-align: right;">
                        <span style="background-color: {var_badge_bg}; color: {var_badge_fg}; padding: 2px 8px; border-radius: 4px; font-size: 12px;">
                            {variance:+,.0f}
                        </span>
                    </td>
                    <td style="padding: 9px 12px; color: #64748B; font-size: 11px;">{var_label}</td>
                </tr>
            </table>
        </div>

        {monthly_table_section}

        <!-- STRATEGIC RECOMMENDATION BOX -->
        <div style="background-color: #F8FAFC; border: 1px solid #CBD5E1; border-left: 4px solid #2563EB; border-radius: 6px; padding: 14px 16px; margin-top: 22px;">
            <b style="color: #1E3A8A; font-size: 13px;">💡 Rekomendasi Strategis & Tindak Lanjut:</b>
            <div style="color: #334155; font-size: 13px; line-height: 1.5; margin-top: 6px;">
                {recommendation}
            </div>
            <ul style="color: #475569; font-size: 12px; margin: 8px 0 0 18px; padding: 0;">
                <li>Monitoring berkala terhadap pergerakan deadstock & slow moving material secara proaktif.</li>
                <li>Pertahankan level stok pada koridor ideal (antara <b>USD {sug_min:,.0f}</b> s/d <b>USD {sug_ideal:,.0f}</b>) guna menyeimbangkan ketersediaan part dan efisiensi modal kerja.</li>
            </ul>
        </div>

        <!-- ATTACHMENT INFO -->
        <div style="margin-top: 20px; padding: 10px 14px; background-color: #F1F5F9; border-radius: 6px; font-size: 12px; color: #475569;">
            📎 <b>Lampiran:</b> File Excel laporan lengkap terlampir: <b>{filename}</b>
        </div>

        <!-- OUTLOOK SIGNATURE -->
        {f'<div style="margin-top: 24px;">{sig_html}</div>' if sig_html else ''}

    </div>
</body>
</html>"""
    return html_content



