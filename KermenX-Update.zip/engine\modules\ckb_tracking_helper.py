"""
CKB Logistics Web Scraping Helper
Portal: https://erp.ckb.co.id/oportal/TrackingDetails.aspx

Menggunakan Windows Schannel curl.exe untuk koneksi HTTPS Azure Application Gateway yang 100% stabil,
bebas timeout, dan mendukung Batch Multi-Query (seluruh resi dipisah koma dalam 1 request cepat <4 detik).
"""

import os
import sys
import time
import re
import urllib.parse
import subprocess
from typing import Dict, List, Optional, Callable

CKB_TRACKING_URL = "https://erp.ckb.co.id/oportal/TrackingDetails.aspx"


def _extract_aspnet_tokens(html_str: str) -> Dict[str, str]:
    tokens = {}
    for name in ["__VIEWSTATE", "__VIEWSTATEGENERATOR", "__EVENTVALIDATION", "__PREVIOUSPAGE"]:
        m = re.search(rf'name="{name}"[^>]*value="([^"]*)"', html_str)
        tokens[name] = m.group(1) if m else ""
    return tokens


def _parse_batch_html(html_str: str) -> Dict[str, dict]:
    """
    Mengekstrak seluruh baris data tracking dari respon HTML batch CKB.
    Mengembalikan dict { query_key: result_dict }
    """
    results = {}
    br_matches = re.findall(r'id="[^"]*BrfNoLinkButton_(\d+)"[^>]*>([^<]+)</a>', html_str)

    for idx_str, br_val in br_matches:
        br_val_clean = br_val.strip()

        # CN No
        m_cn = re.search(rf'id="[^"]*CnNoLinkButton_{idx_str}"[^>]*>([^<]+)</a>', html_str)
        cn_no = m_cn.group(1).strip() if m_cn else "-"

        # Ref No
        m_ref = re.search(rf'id="[^"]*RefNoLinkButton_{idx_str}"[^>]*>([^<]+)</a>', html_str)
        ref_no = m_ref.group(1).strip() if m_ref else br_val_clean

        # Tanggal Kirim
        m_dt = re.search(rf'BrfNoLinkButton_{idx_str}.*?</a>\s*</td>\s*<td[^>]*>([^<]+)</td>', html_str, re.DOTALL)
        ship_date = m_dt.group(1).strip() if m_dt else "-"

        # Ship From
        m_from = re.search(rf'id="[^"]*shipfromlab_{idx_str}"[^>]*>([^<]+)</span>', html_str)
        ship_from = m_from.group(1).strip() if m_from else "-"

        # Ship To
        m_to = re.search(rf'id="[^"]*shiptolab_{idx_str}"[^>]*>([^<]+)</span>', html_str)
        ship_to = m_to.group(1).strip() if m_to else "-"

        # Status Pengiriman
        status = "Tidak Diketahui"
        m_st = re.search(rf'<td class="GridTopLine"[^>]*>([^<]+)</td>\s*<td[^>]*>\s*<a[^>]*lnk_btn_traking_br_{idx_str}', html_str)
        if not m_st:
            m_st = re.search(rf'<td class="GridTopLine"[^>]*>([^<]+)</td>\s*<td>\s*<a[^>]*lnk_btn_traking_br_{idx_str}', html_str)
        if m_st:
            raw_st = m_st.group(1).strip()
            if raw_st and raw_st != "&nbsp;":
                status = raw_st

        # Cek detail dialog apakah ada riwayat Hand over Rantau
        has_handover = bool(re.search(rf'id="[^"]*lnk_btn_traking_br_{idx_str}"[\s\S]*?hand\s*over\s*rantau', html_str, re.IGNORECASE))

        res_obj = {
            "br_number": br_val_clean,
            "ref_number": ref_no,
            "cn_number": cn_no,
            "ship_date": ship_date,
            "ship_from": ship_from,
            "ship_to": ship_to,
            "ckb_status": status,
            "has_handover_rantau": has_handover,
            "found": True
        }

        results[br_val_clean] = res_obj
        if ref_no and ref_no != "-":
            results[ref_no] = res_obj

    return results


def _send_ckb_post(tokens_dict: Dict[str, str], cookie_file: str, post_file: str, tracking_numbers: List[str], timeout: int = 30) -> subprocess.CompletedProcess:
    query_str = ", ".join(tracking_numbers)
    payload = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": tokens_dict.get("__VIEWSTATE", ""),
        "__VIEWSTATEGENERATOR": tokens_dict.get("__VIEWSTATEGENERATOR", ""),
        "__VIEWSTATEENCRYPTED": "",
        "__PREVIOUSPAGE": tokens_dict.get("__PREVIOUSPAGE", ""),
        "__EVENTVALIDATION": tokens_dict.get("__EVENTVALIDATION", ""),
        "hdn_ou": "2",
        "hdn_user": "TMSUSER",
        "hdnOPTheme": "Default",
        "TrackingNos": query_str,
        "traceButton": " Track "
    }
    post_bytes = urllib.parse.urlencode(payload).encode("utf-8")
    with open(post_file, "wb") as pf:
        pf.write(post_bytes)

    return subprocess.run(
        ["curl.exe", "-4", "-s", "-L", "--ssl-no-revoke", "-m", str(timeout),
         "-b", cookie_file, "-c", cookie_file,
         "--data-binary", f"@{post_file}", CKB_TRACKING_URL],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace"
    )


def _fetch_fresh_tokens(cookie_file: str) -> Dict[str, str]:
    """Mengambil sesi baru dan memutus kunci antrean ASP.NET jika terjadi kegagalan jaringan."""
    if os.path.exists(cookie_file):
        try:
            os.remove(cookie_file)
        except Exception:
            pass
    for attempt in range(1, 3):
        try:
            p_get = subprocess.run(
                ["curl.exe", "-4", "-s", "-L", "--ssl-no-revoke", "-m", "25", "-c", cookie_file, CKB_TRACKING_URL],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )
            tokens = _extract_aspnet_tokens(p_get.stdout)
            if tokens.get("__VIEWSTATE"):
                return tokens
        except Exception:
            pass
        time.sleep(0.5)
    return {}


def _isolated_single_rescue(br: str, temp_dir: str = r"C:\TEMP") -> Dict[str, dict]:
    """
    Melakukan pelacakan tunggal mandiri (Isolated Single Rescue) dengan file cookie dan sesi khusus.
    Menghilangkan risiko ASP.NET Session State Locking antar-resi 100%.
    """
    c_file = os.path.join(temp_dir, f"ckb_res_{br}.txt")
    p_file = os.path.join(temp_dir, f"ckb_res_{br}.bin")
    for f in [c_file, p_file]:
        if os.path.exists(f):
            try:
                os.remove(f)
            except Exception:
                pass

    tokens = {}
    for att in range(1, 3):
        try:
            p_get = subprocess.run(
                ["curl.exe", "-4", "-s", "-L", "--ssl-no-revoke", "-m", "20", "-c", c_file, CKB_TRACKING_URL],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )
            t_cand = _extract_aspnet_tokens(p_get.stdout)
            if t_cand.get("__VIEWSTATE"):
                tokens = t_cand
                break
        except Exception:
            pass
        time.sleep(0.8)

    if not tokens.get("__VIEWSTATE"):
        return {}

    payload = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": tokens.get("__VIEWSTATE", ""),
        "__VIEWSTATEGENERATOR": tokens.get("__VIEWSTATEGENERATOR", ""),
        "__VIEWSTATEENCRYPTED": "",
        "__PREVIOUSPAGE": tokens.get("__PREVIOUSPAGE", ""),
        "__EVENTVALIDATION": tokens.get("__EVENTVALIDATION", ""),
        "hdn_ou": "2",
        "hdn_user": "TMSUSER",
        "hdnOPTheme": "Default",
        "TrackingNos": br,
        "traceButton": " Track "
    }
    with open(p_file, "wb") as pf:
        pf.write(urllib.parse.urlencode(payload).encode("utf-8"))

    p_post = subprocess.run(
        ["curl.exe", "-4", "-s", "-L", "--ssl-no-revoke", "-m", "25",
         "-b", c_file, "-c", c_file,
         "--data-binary", f"@{p_file}", CKB_TRACKING_URL],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

    for f in [c_file, p_file]:
        if os.path.exists(f):
            try:
                os.remove(f)
            except Exception:
                pass

    if p_post.returncode == 0 and p_post.stdout:
        return _parse_batch_html(p_post.stdout)
    return {}


def track_multiple_brs(
    br_list: List[str],
    batch_size: int = 5,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> Dict[str, dict]:
    """
    Melakukan tracking terhadap daftar nomor BR unik menggunakan curl.exe batch query.
    Default batch_size = 5 (sweet spot paling aman: super cepat ~1.5-2.0s per batch, bebas overload server CKB).
    Dilengkapi Isolated Single Rescue Protocol untuk mencegah resi hilang 100%.
    Mengembalikan dict mapping: { br_number: parsed_result }
    """
    def _log(msg):
        if log_callback:
            safe_msg = msg.encode("ascii", errors="replace").decode("ascii")
            log_callback(safe_msg)

    def _prog(pct, msg):
        if progress_callback:
            safe_msg = msg.encode("ascii", errors="replace").decode("ascii")
            progress_callback(pct, safe_msg)

    unique_brs = []
    seen = set()
    for b in br_list:
        clean = str(b).strip()
        if clean and clean.lower() not in ("nan", "none", "-", "") and clean not in seen:
            seen.add(clean)
            unique_brs.append(clean)

    total_brs = len(unique_brs)
    final_results = {}
    if total_brs == 0:
        return final_results

    chunks = [unique_brs[i:i + batch_size] for i in range(0, total_brs, batch_size)]
    total_chunks = len(chunks)

    _log(f"[CKB SCRAPER] Menyiapkan pelacakan {total_brs} nomor resi CKB ({total_chunks} batch request @ {batch_size} resi)...")
    _prog(5, f"Menghubungi portal CKB ({total_brs} resi dalam {total_chunks} batch)...")

    temp_dir = r"C:\TEMP"
    os.makedirs(temp_dir, exist_ok=True)
    cookie_file = os.path.join(temp_dir, f"ckb_c_{os.getpid()}.txt")
    post_file = os.path.join(temp_dir, f"ckb_p_{os.getpid()}.bin")

    # Bersihkan file temp lama dari proses sebelumnya jika ada
    for tmp in [cookie_file, post_file]:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass

    # 1. Initial GET dengan retry cerdas (Wajib -4 untuk stabilitas IPv4 Azure App Gateway)
    tokens = {}
    for attempt in range(1, 4):
        try:
            p_get = subprocess.run(
                ["curl.exe", "-4", "-s", "-L", "--ssl-no-revoke", "-m", "25", "-c", cookie_file, CKB_TRACKING_URL],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace"
            )
            if p_get.returncode != 0 and p_get.stderr:
                _log(f"[CKB SCRAPER] Upaya {attempt} curl gagal (exit {p_get.returncode}): {p_get.stderr.strip()[:120]}")
            t_cand = _extract_aspnet_tokens(p_get.stdout)
            if t_cand.get("__VIEWSTATE"):
                tokens = t_cand
                _log(f"[CKB SCRAPER] Sesi awal CKB siap (ViewState: {len(tokens['__VIEWSTATE'])} bytes).")
                break
        except Exception as ex:
            _log(f"[CKB SCRAPER] Upaya {attempt} mengambil sesi CKB: {ex}")
        time.sleep(1.0)

    if not tokens.get("__VIEWSTATE"):
        _log("[CKB SCRAPER] Peringatan: Kunci sesi awal CKB tidak didapatkan, mencoba pelacakan langsung...")

    # 2. Eksekusi Batch Query (Wajib -4 untuk stabilitas IPv4)
    for chunk_idx, chunk in enumerate(chunks, start=1):
        pct = 5 + int(80 * (chunk_idx / total_chunks))
        _prog(pct, f"Melacak Batch {chunk_idx}/{total_chunks} ({len(chunk)} resi)...")

        try:
            p_post = _send_ckb_post(tokens, cookie_file, post_file, chunk, timeout=28)

            if p_post.returncode != 0 and p_post.stderr:
                _log(f"[CKB SCRAPER] Batch {chunk_idx}/{total_chunks} curl exit {p_post.returncode}: {p_post.stderr.strip()[:120]}")

            p_html = p_post.stdout
            batch_data = _parse_batch_html(p_html) if p_post.returncode == 0 else {}

            if batch_data:
                # Update tokens dari respon sukses
                new_tokens = _extract_aspnet_tokens(p_html)
                for tk, tv in new_tokens.items():
                    if tv:
                        tokens[tk] = tv
            elif len(chunk) > 1:
                # Auto-fallback jika batch mengembalikan 0 hasil (Session-Lock Breaker + sub-batch 2 resi)
                _log(f"[CKB SCRAPER] Batch {chunk_idx}/{total_chunks} tidak merespons, jeda cool-down & reset sesi untuk fallback...")
                time.sleep(2.0)  # Cool-down agar koneksi server CKB lega
                fresh_tok = _fetch_fresh_tokens(cookie_file)
                if fresh_tok.get("__VIEWSTATE"):
                    tokens = fresh_tok

                sub_chunks = [chunk[j:j + 2] for j in range(0, len(chunk), 2)]
                for sub_idx, sub in enumerate(sub_chunks, start=1):
                    try:
                        p_sub = _send_ckb_post(tokens, cookie_file, post_file, sub, timeout=18)
                        if p_sub.returncode == 0 and p_sub.stdout:
                            sub_data = _parse_batch_html(p_sub.stdout)
                            batch_data.update(sub_data)
                            new_tok = _extract_aspnet_tokens(p_sub.stdout)
                            for tk, tv in new_tok.items():
                                if tv:
                                    tokens[tk] = tv
                    except Exception as sub_ex:
                        _log(f"  -> Sub-batch {sub_idx} error: {sub_ex}")
                    time.sleep(0.8)

            for k, v in batch_data.items():
                final_results[k] = v

            _log(f"[CKB SCRAPER] Batch {chunk_idx}/{total_chunks} selesai: {len(batch_data)} resi terpetakan.")
        except Exception as ex:
            _log(f"[CKB SCRAPER] Batch {chunk_idx}/{total_chunks} gagal: {ex}")

        if chunk_idx < total_chunks:
            time.sleep(1.0)  # Pacing delay adaptif antar batch

    # 3. RESCUE PROTOCOL (Jaring Pengaman Verifikasi Tunggal Terisolasi Anti-Lock)
    missing_brs = [b for b in unique_brs if b not in final_results]
    if missing_brs:
        _log(f"[CKB SCRAPER] Menjalankan Rescue Protocol untuk {len(missing_brs)} resi yang belum terpetakan...")
        _prog(85, f"Memverifikasi ulang {len(missing_brs)} resi (Rescue Protocol)...")
        time.sleep(1.0)

        for rescue_idx, r_br in enumerate(missing_brs, start=1):
            try:
                r_data = _isolated_single_rescue(r_br, temp_dir)
                if r_data:
                    for k, v in r_data.items():
                        final_results[k] = v
                    _log(f"[CKB RESCUE] Resi {r_br} berhasil diselamatkan -> {r_data.get(r_br, {}).get('ckb_status', 'Terlacak')}")
                else:
                    _log(f"[CKB RESCUE] Resi {r_br} terkonfirmasi tidak ada di portal CKB.")
            except Exception as rx:
                _log(f"[CKB RESCUE] Gagal memverifikasi resi {r_br}: {rx}")
            time.sleep(0.3)

    # Cleanup temp files
    for tmp in [cookie_file, post_file]:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass

    # Map fallback untuk nomor yang belum terdaftar di CKB
    for br in unique_brs:
        if br not in final_results:
            final_results[br] = {
                "br_number": br,
                "ref_number": br,
                "cn_number": "-",
                "ship_date": "-",
                "ship_from": "-",
                "ship_to": "-",
                "ckb_status": "Belum Terdaftar di CKB",
                "has_handover_rantau": False,
                "found": False
            }

    _prog(90, f"Tracking CKB selesai ({len(final_results)} resi berhasil dilacak).")
    return final_results
