"""
Configuration file for SAP Automation
Simpan semua konfigurasi terpusat di sini agar mudah diubah tanpa mengubah kode utama.
"""
import sys
import os
import hashlib

def hash_pin(pin_str):
    """Menghasilkan hash SHA-256 dari string PIN"""
    return hashlib.sha256(str(pin_str).strip().encode('utf-8')).hexdigest()

# Master PIN Keamanan Aplikasi (Default: 1346)
DEFAULT_MASTER_PIN = "1346"
DEFAULT_MASTER_PIN_HASH = hash_pin(DEFAULT_MASTER_PIN)

# Direktori dasar project (support running dari source code maupun compiled EXE)
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Direktori default output project
DEFAULT_OUTPUT_DIR = os.path.join(os.path.dirname(BASE_DIR), "output") if os.path.exists(os.path.join(os.path.dirname(BASE_DIR), "output")) else os.path.join(BASE_DIR, "output")

# Pemetaan Sub-folder Output Terpusat
OUTPUT_SUBDIRS = {
    "readiness": "01_Part_Readiness",
    "otif": "02_OTIF_Report",
    "sto": "03_Form_STO",
    "sap": "04_SAP_Export",
    "turnover": "05_Turnover_Report",
    "androheld": "06_AndroHeld_Sync",
    "swift": "07_SWIFT_Engine",
    "git": "08_GIT_Monitoring",
    "git_monitoring": "08_GIT_Monitoring",
}

def get_base_output_dir():
    """
    Mengembalikan direktori utama penyimpanan output.
    Mengecek apakah pengguna telah mengatur folder kustom di kermen_settings.json.
    Jika tidak ada atau direktori tidak valid/tidak bisa dibuat, kembali ke DEFAULT_OUTPUT_DIR.
    """
    try:
        from modules.settings_helper import get_custom_output_dir
        custom_dir = get_custom_output_dir()
        if custom_dir and os.path.isabs(custom_dir):
            try:
                os.makedirs(custom_dir, exist_ok=True)
                return custom_dir
            except Exception:
                pass
    except Exception:
        pass

    try:
        os.makedirs(DEFAULT_OUTPUT_DIR, exist_ok=True)
    except Exception:
        pass
    return DEFAULT_OUTPUT_DIR


def get_output_dir(category=None):
    """
    Mengembalikan sub-direktori output spesifik berdasarkan kategori:
    - 'readiness': 01_Part_Readiness
    - 'otif': 02_OTIF_Report
    - 'sto': 03_Form_STO
    - 'sap': 04_SAP_Export
    Jika category None atau tidak dikenali, mengembalikan base output dir.
    Direktori otomatis dibuat jika belum ada.
    """
    base = get_base_output_dir()
    if category and category in OUTPUT_SUBDIRS:
        target_dir = os.path.join(base, OUTPUT_SUBDIRS[category])
    else:
        target_dir = base

    try:
        os.makedirs(target_dir, exist_ok=True)
    except Exception:
        pass
    return target_dir


# Folder output tempat menyimpan file (Backward compatibility)
OUTPUT_DIR = get_base_output_dir()



# Konfigurasi SAP
SAP_CONNECTION = "SAP ECC"
SAP_CLIENT = "300"
SAP_LANGUAGE = "EN"

# Parameter Default Transaksi ZMMM_STOCK_INFO & MB52
DEFAULT_PLANT = "1346"
DEFAULT_SLOC = "dmdv"
DEFAULT_VARIANT = "/YUSRIL"
DEFAULT_MB52_VARIANT = "/YUSRIL"

# Konfigurasi Email Report (Outlook - Executive / Umum)
DEFAULT_EMAIL_TO = ""
DEFAULT_EMAIL_CC = ""
DEFAULT_EMAIL_SUBJECT = "[REPORT] Work Order Part Readiness"

# Konfigurasi Email Report Monthly Plan (Outlook)
DEFAULT_MP_EMAIL_TO = ""
DEFAULT_MP_EMAIL_CC = ""
DEFAULT_MP_EMAIL_SUBJECT = "[REPORT] Monthly Plan Part Readiness"

# Konfigurasi Email Follow Up Team Counter (Outlook)
DEFAULT_COUNTER_EMAIL_TO = ""
DEFAULT_COUNTER_EMAIL_CC = ""
DEFAULT_COUNTER_EMAIL_SUBJECT = "[FOLLOW UP] Part Not Ready - Work Order Allocation"

# Konfigurasi Email OTIF Report Daily (Outlook)
DEFAULT_OTIF_EMAIL_TO = ""
DEFAULT_OTIF_EMAIL_CC = ""
DEFAULT_OTIF_EMAIL_SUBJECT = "OTIF Report Daily"

# Konfigurasi Email Report Turn Over Parts (Outlook)
DEFAULT_TURNOVER_EMAIL_TO = ""
DEFAULT_TURNOVER_EMAIL_CC = ""
DEFAULT_TURNOVER_EMAIL_SUBJECT = "[REPORT] Parts Inventory Turn Over Analysis"

# Konfigurasi Email Pengajuan STO ke HO (Outlook)
DEFAULT_STO_EMAIL_TO = ""
DEFAULT_STO_EMAIL_CC = ""
DEFAULT_STO_EMAIL_SUBJECT = "[STO REQUEST] WO CK Part Not Ready - Plant 1346"
DEFAULT_STO_EMAIL_MESSAGE = "Dear Mba Carinda, Pak Ari,\n\nMohon dibantu STO file terlampir untuk pemenuhan Reservasi CK."

# Parameter Default Form STO SAP
DEFAULT_STO_DOC_TYPE = "ZOTS"
DEFAULT_STO_SUPPLYING_SLOC = "DMDV"
DEFAULT_STO_HEADER_NOTE = "Replenish Stock for Reservasi CK"
DEFAULT_STO_PURCH_ORG = 1001
DEFAULT_STO_PURCH_GRP = "H13"
DEFAULT_STO_COMP_CODE = 1000
DEFAULT_STO_SHIP_IN = "S"
DEFAULT_STO_SHIPPING_COND = "ED"
DEFAULT_STO_RECEIVING_PLANT = "1346"
DEFAULT_STO_RECEIVING_SLOC = "DMDV"

# Urutan Prioritas Pemenuhan Stok HUB (Kaskade: Banjar -> Samarinda -> Surabaya -> Jakarta)
HUB_PRIORITY_ORDER = [
    {"code": "1S66", "name": "Banjarmasin Hub", "slug": "BANJARMASIN"},
    {"code": "1S67", "name": "Samarinda Hub", "slug": "SAMARINDA"},
    {"code": "1S81", "name": "Surabaya Hub", "slug": "SURABAYA"},
    {"code": "1S76", "name": "Jakarta Mega Hub", "slug": "JAKARTA"},
]

# Daftar Valuation Type Standar SAP & Hasil Olah Data Stock Info
STO_VALUATION_TYPES = [
    "Auto",
    "CATNEW",
    "NCATNEW",
    "RPRODUCT",
    "PXPRODUCT",
    "PEPRODUCT",
    "KITNEW"
]

# Parameter Default Transaksi /NZCKWOPART (OTIF Report SAP)
DEFAULT_OTIF_SAP_PLANT = "3069"
DEFAULT_OTIF_EXPORT_DIR = get_output_dir("sap")


# Custom Mapping Part Number untuk WO Readiness
# Menyesuaikan suffix/format part number dari AS57D ke format Stock Info / SAP
CUSTOM_PN_MAPPING = {
    'HP426PIB:AA': 'HP426PI B:LS',
    'HP426PIB': 'HP426PI B:LS',
    'HP-426PIB': 'HP426PI B:LS',
    'HP426 PLUS:AA': 'HP426 PLUS B:LS',
    'HP426 PLUS': 'HP426 PLUS B:LS',
    'HP426PLUS:AA': 'HP426 PLUS B:LS',
    'HP426PLUS': 'HP426 PLUS B:LS',
    'HP426 B:AA': 'HP426 B:LS',
    'HP426 B': 'HP426 B:LS',
    'HP427PI:AA': 'HP427PI B:LS',
    'HP427PI': 'HP427PI B:LS',
    'HP-427PI': 'HP427PI B:LS',
    'HP427 B:AA': 'HP427 B:LS',
    'HP427 B': 'HP427 B:LS',
    'HP428 B:AA': 'HP428 B:LS',
    'HP428 B': 'HP428 B:LS',
    'HP429 B:AA': 'HP429 B:LS',
    'HP429 B': 'HP429 B:LS',
    '230592:AA': '230592:HI',
    '230592': '230592:HI',
    '555354:AA': '555354:HI',
    '555354': '555354:HI',
    '232077:AA': '232077:HI',
    '232077': '232077:HI',
    '2153634:AA': '2153634-T:NM',
    '2153634': '2153634-T:NM',
    '215-3634:AA': '2153634-T:NM',
    '215-3634': '2153634-T:NM',
    '2153634-T:AA': '2153634-T:NM',
}

# Parameter Default SWIFT (Smart Wear Indicator & Forecasting Tools)
DEFAULT_SWIFT_DAILY_HOURS = 16.0
DEFAULT_SWIFT_CRITICAL_WEAR = 100.0
DEFAULT_SWIFT_WARNING_WEAR = 80.0
DEFAULT_SWIFT_ATTENTION_WEAR = 60.0
DEFAULT_SWIFT_CRITICAL_RUL = 150.0
DEFAULT_SWIFT_WARNING_RUL = 350.0
DEFAULT_SWIFT_MEP_PATH = os.path.join(BASE_DIR, "data", "mep_database.xlsx")

