"""
WHERE-USED CAT & INVENTORY COMPARE HELPER (SQLCipher AES-256)
Menangani pencarian cepat Part -> Model/Prefix, pencarian Model -> Parts,
Batch Paste lookup, dan Compare massal file Excel Inventory.
"""

import os
import re
from datetime import datetime
import sqlcipher3

CIPHER_KEY = "KermenX#WhereUsed@2026!CatSIS"
CIPHER_PAGE_SIZE = 8192
EXCEL_CELL_CAP = 30000


def _find_db_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    engine_dir = os.path.dirname(here)
    kermen_root = os.path.dirname(engine_dir)
    app_root = os.path.dirname(kermen_root)

    candidates = [
        os.path.join(kermen_root, "data_where_used", "where_used_secure.db"),
        os.path.join(kermen_root, "app", "data", "where_used_secure.db"),
        os.path.join(kermen_root, "data", "where_used_secure.db"),
        os.path.join(app_root, "Database", "where_used_secure.db"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0]


def _connect():
    db_path = _find_db_path()
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database terenkripsi tidak ditemukan: {db_path}")
    conn = sqlcipher3.connect(db_path)
    safe_key = CIPHER_KEY.replace("'", "''")
    conn.execute(f"PRAGMA key = '{safe_key}';")
    conn.execute(f"PRAGMA cipher_page_size = {CIPHER_PAGE_SIZE};")
    return conn


def clean_pn(raw: str) -> str:
    if raw is None:
        return ""
    s = str(raw).strip()
    if ":" in s:
        s = s.split(":", 1)[0]
    return s.strip().upper().replace("-", "").replace(" ", "")


def safe_cap(text: str, limit: int = EXCEL_CELL_CAP) -> str:
    if not text or len(text) <= limit:
        return text
    cut = text[:limit]
    idx = cut.rfind(";")
    if idx > 0:
        cut = cut[:idx]
    return cut + " ... [Terpotong batas Excel]"


def search_single(query: str, mode: str = "part") -> dict:
    q = (query or "").strip()
    if not q:
        return {"found": False, "mode": mode, "query": "", "rows": [], "total_models": 0, "total_prefixes": 0, "families": []}

    conn = _connect()
    cur = conn.cursor()
    try:
        if mode.lower() == "model":
            q_upper = q.upper()
            model_rows = cur.execute(
                "SELECT model_id, sales_model, product_family FROM dim_models WHERE UPPER(sales_model) = ?",
                (q_upper,),
            ).fetchall()
            if not model_rows:
                model_rows = cur.execute(
                    "SELECT model_id, sales_model, product_family FROM dim_models WHERE UPPER(sales_model) LIKE ? LIMIT 20",
                    (f"%{q_upper}%",),
                ).fetchall()

            if not model_rows:
                return {"found": False, "mode": "model", "query": q_upper, "rows": [], "total_models": 0, "total_prefixes": 0, "families": []}

            m_ids = [r[0] for r in model_rows]
            placeholders = ",".join("?" * len(m_ids))
            sql = f"""
                SELECT p.part_number, m.sales_model, m.product_family,
                       COUNT(DISTINCT x.prefix) AS px_cnt,
                       GROUP_CONCAT(DISTINCT x.prefix) AS prefixes
                FROM part_unit_map u
                JOIN parts p ON p.part_id = u.part_id
                JOIN dim_models m ON m.model_id = u.model_id
                JOIN dim_prefixes x ON x.prefix_id = u.prefix_id
                WHERE u.model_id IN ({placeholders})
                GROUP BY p.part_id, m.model_id
                ORDER BY px_cnt DESC, p.part_number ASC
                LIMIT 500
            """
            rows_raw = cur.execute(sql, m_ids).fetchall()
            rows = []
            families = set()
            all_prefixes = set()
            for pn, sm, pf, cnt, pxs in rows_raw:
                px_list = sorted([p for p in (pxs or "").split(",") if p])
                all_prefixes.update(px_list)
                if pf:
                    families.add(pf)
                rows.append({
                    "primary": pn,
                    "sales_model": sm,
                    "product_family": pf,
                    "prefix_count": cnt,
                    "prefixes": ", ".join(px_list),
                })
            return {
                "found": len(rows) > 0,
                "mode": "model",
                "query": q_upper,
                "total_models": len({r["sales_model"] for r in rows}),
                "total_prefixes": len(all_prefixes),
                "total_parts": len(rows),
                "families": sorted(families),
                "rows": rows,
            }

        # Default: mode == "part"
        pn = clean_pn(q)
        p_row = cur.execute(
            "SELECT part_id, part_number, total_models, total_prefix FROM parts WHERE part_number = ?",
            (pn,),
        ).fetchone()
        if not p_row:
            return {"found": False, "mode": "part", "query": pn, "rows": [], "total_models": 0, "total_prefixes": 0, "families": []}

        part_id, part_num, tm, tp = p_row
        rows_raw = cur.execute(
            """
            SELECT m.sales_model, m.product_family,
                   COUNT(DISTINCT x.prefix) AS px_cnt,
                   GROUP_CONCAT(DISTINCT x.prefix) AS prefixes
            FROM part_unit_map u
            JOIN dim_models m ON m.model_id = u.model_id
            JOIN dim_prefixes x ON x.prefix_id = u.prefix_id
            WHERE u.part_id = ?
            GROUP BY m.model_id
            ORDER BY px_cnt DESC, m.sales_model ASC
            """,
            (part_id,),
        ).fetchall()

        rows = []
        families = set()
        for sm, pf, cnt, pxs in rows_raw:
            px_list = sorted([p for p in (pxs or "").split(",") if p])
            if pf:
                families.add(pf)
            rows.append({
                "primary": sm,
                "sales_model": sm,
                "product_family": pf,
                "prefix_count": cnt,
                "prefixes": ", ".join(px_list),
            })

        return {
            "found": True,
            "mode": "part",
            "query": part_num,
            "total_models": tm or len(rows),
            "total_prefixes": tp,
            "families": sorted(families),
            "rows": rows,
        }
    finally:
        conn.close()


def _lookup_many_pns(conn, unique_pns: list) -> dict:
    """Mengambil ringkasan Where-Used untuk sekumpulan Clean PN secara batch."""
    cur = conn.cursor()
    info_map = {}

    chunk_size = 400
    for i in range(0, len(unique_pns), chunk_size):
        chunk = unique_pns[i : i + chunk_size]
        ph = ",".join("?" * len(chunk))
        part_rows = cur.execute(
            f"SELECT part_id, part_number, total_models, total_prefix FROM parts WHERE part_number IN ({ph})",
            chunk,
        ).fetchall()
        if not part_rows:
            continue

        pid_to_pn = {}
        for pid, pn, tm, tp in part_rows:
            pid_to_pn[pid] = pn
            info_map[pn] = {
                "total_models": tm or 0,
                "total_prefix": tp or 0,
                "families": set(),
                "models": [],
                "grouping": [],
            }

        pids = list(pid_to_pn.keys())
        ph_p = ",".join("?" * len(pids))
        detail_rows = cur.execute(
            f"""
            SELECT u.part_id, m.sales_model, m.product_family, GROUP_CONCAT(DISTINCT x.prefix)
            FROM part_unit_map u
            JOIN dim_models m ON m.model_id = u.model_id
            JOIN dim_prefixes x ON x.prefix_id = u.prefix_id
            WHERE u.part_id IN ({ph_p})
            GROUP BY u.part_id, m.model_id
            ORDER BY m.sales_model ASC
            """,
            pids,
        ).fetchall()

        for pid, sm, pf, pxs in detail_rows:
            pn = pid_to_pn[pid]
            rec = info_map[pn]
            if pf:
                rec["families"].add(pf)
            if sm:
                rec["models"].append(sm)
            px_sorted = sorted([p for p in (pxs or "").split(",") if p])
            rec["grouping"].append(f"{sm}: [{', '.join(px_sorted)}]")

    final_map = {}
    for pn, rec in info_map.items():
        final_map[pn] = {
            "total_models": rec["total_models"],
            "total_prefix": rec["total_prefix"],
            "product_families": "; ".join(sorted(rec["families"])) if rec["families"] else "-",
            "sales_models": "; ".join(sorted(set(rec["models"]))) if rec["models"] else "-",
            "grouping": "; ".join(rec["grouping"]) if rec["grouping"] else "-",
        }
    return final_map


def batch_search(items: list) -> dict:
    cleaned = [(str(it).strip(), clean_pn(it)) for it in items if str(it).strip()]
    unique_pns = list({cpn for _, cpn in cleaned if cpn})

    conn = _connect()
    try:
        lookup = _lookup_many_pns(conn, unique_pns)
    finally:
        conn.close()

    results = []
    found_cnt = 0
    for idx, (raw_pn, cpn) in enumerate(cleaned, start=1):
        hit = lookup.get(cpn)
        if hit:
            found_cnt += 1
            results.append({
                "no": idx,
                "input_pn": raw_pn,
                "clean_pn": cpn,
                "total_models": hit["total_models"],
                "total_prefix": hit["total_prefix"],
                "product_families": hit["product_families"],
                "sales_models": hit["sales_models"],
                "grouping": hit["grouping"],
                "status": "Ditemukan",
            })
        else:
            results.append({
                "no": idx,
                "input_pn": raw_pn,
                "clean_pn": cpn,
                "total_models": 0,
                "total_prefix": 0,
                "product_families": "-",
                "sales_models": "-",
                "grouping": "-",
                "status": "Tidak Ditemukan",
            })

    return {
        "total": len(results),
        "found": found_cnt,
        "not_found": len(results) - found_cnt,
        "results": results,
    }


def export_batch_excel(items: list, output_dir: str = None) -> str:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment

    res = batch_search(items)
    if not output_dir:
        kermen_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        output_dir = os.path.join(kermen_root, "output", "09_WhereUsed_Compare")
    os.makedirs(output_dir, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = os.path.join(output_dir, f"WhereUsed_Batch_{ts}.xlsx")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Where-Used Batch"

    headers = ["No", "Input PN", "Clean PN", "Status", "Total Model", "Total Prefix", "Product Family", "Sales Models", "Grouping Model & Prefix"]
    ws.append(headers)

    hdr_fill = PatternFill("solid", fgColor="1E3A8A")
    hdr_font = Font(bold=True, color="FFFFFF", size=10)
    for col_idx in range(1, len(headers) + 1):
        c = ws.cell(row=1, column=col_idx)
        c.fill = hdr_fill
        c.font = hdr_font
        c.alignment = Alignment(horizontal="center", vertical="center")

    for r in res["results"]:
        ws.append([
            r["no"],
            r["input_pn"],
            r["clean_pn"],
            r["status"],
            r["total_models"],
            r["total_prefix"],
            safe_cap(r["product_families"]),
            safe_cap(r["sales_models"]),
            safe_cap(r["grouping"]),
        ])

    widths = [6, 18, 16, 16, 13, 13, 32, 42, 65]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    wb.save(out_path)
    return out_path


def compare_excel(excel_path: str, sheet_name: str = "Data", pn_column: str = "Material Number", output_dir: str = None, progress_cb=None) -> dict:
    import pandas as pd

    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"File Excel tidak ditemukan: {excel_path}")

    if progress_cb:
        progress_cb(15, f"Membaca sheet '{sheet_name}' dari Excel...")

    df = pd.read_excel(excel_path, sheet_name=sheet_name)
    if pn_column not in df.columns:
        raise ValueError(f"Kolom '{pn_column}' tidak ditemukan di sheet '{sheet_name}'. Kolom tersedia: {list(df.columns)[:10]}")

    if progress_cb:
        progress_cb(35, f"Membersihkan {len(df):,d} nomor part & mencocokkan ke database...")

    clean_series = df[pn_column].astype(str).map(clean_pn)
    unique_pns = [p for p in clean_series.unique().tolist() if p]

    conn = _connect()
    try:
        lookup = _lookup_many_pns(conn, unique_pns)
    finally:
        conn.close()

    if progress_cb:
        progress_cb(70, "Menggabungkan hasil Where-Used & menulis file Excel...")

    statuses = []
    tot_models = []
    tot_prefixes = []
    families = []
    sales_models = []
    groupings = []
    matched_cnt = 0

    for cpn in clean_series:
        hit = lookup.get(cpn)
        if hit:
            matched_cnt += 1
            statuses.append("Ditemukan")
            tot_models.append(hit["total_models"])
            tot_prefixes.append(hit["total_prefix"])
            families.append(safe_cap(hit["product_families"]))
            sales_models.append(safe_cap(hit["sales_models"]))
            groupings.append(safe_cap(hit["grouping"]))
        else:
            statuses.append("Belum Ada di DB")
            tot_models.append(0)
            tot_prefixes.append(0)
            families.append("-")
            sales_models.append("-")
            groupings.append("-")

    df["Clean PN"] = clean_series
    df["Status Where-Used"] = statuses
    df["Total Model"] = tot_models
    df["Total Prefix"] = tot_prefixes
    df["Product Family"] = families
    df["Sales Models"] = sales_models
    df["Grouping Model & Prefix"] = groupings

    if not output_dir:
        kermen_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        output_dir = os.path.join(kermen_root, "output", "09_WhereUsed_Compare")
    os.makedirs(output_dir, exist_ok=True)

    base_name = os.path.splitext(os.path.basename(excel_path))[0]
    safe_base = re.sub(r"[^A-Za-z0-9_-]+", "_", base_name).strip("_")[:40]
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = os.path.join(output_dir, f"WhereUsed_Compare_{safe_base}_{ts}.xlsx")

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Compare Result", index=False)

    if progress_cb:
        progress_cb(100, "Compare Excel Where-Used selesai!")

    return {
        "total_rows": int(len(df)),
        "unique_pns": int(len(unique_pns)),
        "matched_rows": int(matched_cnt),
        "unmatched_rows": int(len(df) - matched_cnt),
        "output_path": out_path,
    }
