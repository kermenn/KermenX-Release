# -*- coding: utf-8 -*-
"""
KermenX - Billing Supporting Document Macro Helper
Menangani otomatisasi transaksi SAP /NZVBL_SUPP_DOC untuk proses billing MRKO dan PO Normal.
Fitur:
1. Run Billing MRKO (Centang BAST JB) + Auto-Save
2. Run Unthick MRKO (Hapus Centang BAST JB) + Auto-Save
3. Run Billing PO Normal (Centang PO, DO, GRCUST) + Auto-Save
4. Run Unthick PO Normal (Hapus Centang PO, DO, GRCUST) + Auto-Save
"""

import time
import win32clipboard
import win32con

def copy_documents_to_clipboard(doc_list):
    """Menyalin daftar nomor dokumen ke Windows Clipboard dengan pemisah baris (CRLF)."""
    cleaned = [str(d).strip() for d in doc_list if str(d).strip()]
    text_data = "\r\n".join(cleaned)
    for _ in range(5):
        try:
            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardText(text_data, win32con.CF_UNICODETEXT)
            win32clipboard.CloseClipboard()
            return len(cleaned)
        except Exception:
            time.sleep(0.1)
    return len(cleaned)

def process_billing_supp_doc(
    session,
    doc_list,
    action_type="billing_mrko",
    sales_office="0H86",
    customer="*",
    log_callback=None,
    progress_callback=None
):
    """
    Menjalankan transaksi /NZVBL_SUPP_DOC secara otomatis dan aman.
    action_type:
      - 'billing_mrko': Centang BAST JB
      - 'unthick_mrko': Hapus centang BAST JB
      - 'billing_po': Centang PO, DO, GRCUST
      - 'unthick_po': Hapus centang PO, DO, GRCUST
    """
    def _log(msg):
        if log_callback:
            log_callback(msg)
        print(msg, flush=True)

    def _prog(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)
        _log(f"[{pct}%] {msg}")

    if not doc_list:
        raise ValueError("Daftar nomor dokumen (DOCNO) kosong!")

    _prog(5, f"Menyiapkan {len(doc_list)} nomor dokumen ke clipboard...")
    copy_documents_to_clipboard(doc_list)

    # 1. Buka transaksi /NZVBL_SUPP_DOC
    _prog(15, "Membuka transaksi /NZVBL_SUPP_DOC di SAP...")
    try:
        session.findById("wnd[0]").maximize()
    except Exception:
        pass

    session.findById("wnd[0]/tbar[0]/okcd").text = "/NZVBL_SUPP_DOC"
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(0.8)

    # 2. Isi Kriteria Seleksi
    _prog(25, "Mengisi parameter seleksi Customer & Sales Office...")
    try:
        session.findById("wnd[0]/usr/ctxtS_KUNNR-LOW").text = customer if customer else "*"
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/ctxtS_VKBUR-LOW").text = sales_office if sales_office else "0H86"
    except Exception:
        pass

    try:
        session.findById("wnd[0]/usr/chkCB_INCM").selected = False
    except Exception:
        pass

    # 3. Paste Nomor Dokumen via Multiple Selection
    _prog(35, "Mem-paste daftar nomor dokumen ke Multiple Selection...")
    session.findById("wnd[0]/usr/txtS_DOCNO-LOW").setFocus()
    session.findById("wnd[0]/usr/btn%_S_DOCNO_%_APP_%-VALU_PUSH").press()
    time.sleep(0.5)

    # Upload from Clipboard (btn[24])
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    time.sleep(0.5)

    # Execute / Copy Selection (btn[8])
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    time.sleep(0.5)

    # 4. Pilih Mode Update (RB_UPDT) & Eksekusi (F8)
    _prog(45, "Memilih Mode Update dan mengeksekusi pencarian (F8)...")
    try:
        session.findById("wnd[0]/usr/radRB_UPDT").setFocus()
        session.findById("wnd[0]/usr/radRB_UPDT").select()
    except Exception:
        pass

    session.findById("wnd[0]").sendVKey(8)
    time.sleep(1.5)

    # Cek pesan error di Status Bar jika data tidak ditemukan
    try:
        sbar = session.findById("wnd[0]/sbar")
        if sbar and sbar.messageType in ("E", "A"):
            raise RuntimeError(f"SAP Error: {sbar.text}")
    except Exception as ex:
        if "SAP Error:" in str(ex):
            raise

    # 5. Manipulasi Checkbox Tabel
    _prog(55, f"Memproses baris data di tabel SAP (Mode: {action_type.upper()})...")
    tbl = session.findById("wnd[0]/usr/tblZLV_E_MAINT_SUPP_DOC_DATATC_SUPP_DOC")

    total_rows = len(doc_list)
    try:
        if hasattr(tbl, "RowCount") and tbl.RowCount > 0:
            total_rows = tbl.RowCount
    except Exception:
        pass

    _log(f"[BILLING] Total baris di tabel SAP: {total_rows}")

    processed_count = 0
    for current_row in range(total_rows):
        i = current_row % 22

        try:
            if action_type == "billing_mrko":
                # Centang BAST JB (MRKO)
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_BAST_JB[13,{i}]").selected = True
            elif action_type == "unthick_mrko":
                # Hapus Centang BAST JB (MRKO)
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_BAST_JB[13,{i}]").selected = False
            elif action_type == "billing_po":
                # Centang PO, DO, GRCUST
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_PO[10,{i}]").selected = True
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_DO[11,{i}]").selected = True
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_GRCUST[12,{i}]").selected = True
            elif action_type == "unthick_po":
                # Hapus Centang PO, DO, GRCUST
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_PO[10,{i}]").selected = False
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_DO[11,{i}]").selected = False
                tbl.findById(f"chkGW_SUPP_DOC-SUPP_DOC_GRCUST[12,{i}]").selected = False
            
            processed_count += 1
        except Exception as ex:
            _log(f"[BILLING] Baris {current_row + 1} dilewati / info: {ex}")

        # Scroll jika sudah di baris terakhir layar (22 baris per halaman)
        if i == 21:
            try:
                tbl.verticalScrollbar.position = current_row + 1
                time.sleep(0.05)
            except Exception:
                pass

        if current_row % 25 == 0 or current_row == total_rows - 1:
            pct = 55 + int(35 * ((current_row + 1) / max(1, total_rows)))
            _prog(pct, f"Memproses baris {current_row + 1}/{total_rows}...")

    # 6. Simpan Perubahan (SAVE / Ctrl+S / btn[11])
    _prog(92, "Menyimpan perubahan ke SAP (Save / btn[11])...")
    save_msg = "Perubahan berhasil disimpan."
    try:
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        time.sleep(1.5)
        sbar = session.findById("wnd[0]/sbar")
        if sbar and sbar.text:
            save_msg = sbar.text
            _log(f"[BILLING] Status Simpan SAP: {save_msg}")
    except Exception as ex:
        _log(f"[BILLING] Info tombol save: {ex}")

    _prog(100, f"Selesai! {processed_count} baris diproses. {save_msg}")

    return {
        "status": "success",
        "action": action_type,
        "processed_count": processed_count,
        "save_message": save_msg
    }
